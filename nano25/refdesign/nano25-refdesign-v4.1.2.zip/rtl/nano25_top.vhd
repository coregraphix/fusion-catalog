

library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;
use     ieee.math_real.all;

library work;
--use     work.build_pkg.all; 
--use     work.bsp_pkg.all; 

entity nano25_top is
  port
  (
      --///////// CLOCK /////////
      CLOCK0_50        : in    std_logic;
      CLOCK1_50        : in    std_logic;
      CLOCK2_50        : in    std_logic;

      --///////// KEY /////////
      KEY              : in    std_logic_vector(1 downto 0); -- BUTTON is Low-Active

      --///////// SW /////////
      SW               : in    std_logic_vector(3 downto 0);

      --///////// LED /////////
      LED              : out   std_logic_vector(7 downto 0); 

      --///////// SDRAM /////////
      DRAM_CLK         : out   std_logic;                    --output             DRAM_CLK,
      DRAM_CKE         : out   std_logic;                    --output             DRAM_CKE,
      DRAM_ADDR        : out   std_logic_vector(12 downto 0);--output   [12: 0]   DRAM_ADDR,
      DRAM_BA          : out   std_logic_vector(1 downto 0); --output   [ 1: 0]   DRAM_BA,
      DRAM_DQ          : inout std_logic_vector(15 downto 0);--inout    [15: 0]   DRAM_DQ,
      DRAM_LDQM        : out   std_logic;                    --output             DRAM_LDQM,
      DRAM_UDQM        : out   std_logic;                    --output             DRAM_UDQM,
      DRAM_CS_n        : out   std_logic_vector(1 downto 0); --output   [ 1: 0]   DRAM_CS_n,
      DRAM_WE_n        : out   std_logic;                    --output             DRAM_WE_n,
      DRAM_CAS_n       : out   std_logic;                    --output             DRAM_CAS_n,
      DRAM_RAS_n       : out   std_logic;                    --output             DRAM_RAS_n,

      --///////// LPDDR4A /////////
      LPDDR4A_REFCLK_p : in    std_logic;                    -- input              LPDDR4A_REFCLK_p,
      LPDDR4A_CS_n     : out   std_logic;                    -- output             LPDDR4A_CS_n,
      LPDDR4A_CA       : out   std_logic_vector(5 downto 0); -- output   [ 5: 0]   LPDDR4A_CA,
      LPDDR4A_CK       : out   std_logic;                    -- output             LPDDR4A_CK,
      LPDDR4A_CKE      : out   std_logic;                    -- output             LPDDR4A_CKE,
      LPDDR4A_CK_n     : out   std_logic;                    -- output             LPDDR4A_CK_n,
      LPDDR4A_DM       : inout std_logic_vector(3 downto 0); -- inout    [ 3: 0]   LPDDR4A_DM,
      LPDDR4A_DQ       : inout std_logic_vector(31 downto 0);-- inout    [31: 0]   LPDDR4A_DQ,
      LPDDR4A_DQS      : inout std_logic_vector(3 downto 0); -- inout    [ 3: 0]   LPDDR4A_DQS,
      LPDDR4A_DQS_n    : inout std_logic_vector(3 downto 0); -- inout    [ 3: 0]   LPDDR4A_DQS_n,
      LPDDR4A_RESET_n  : out   std_logic;                    -- output             LPDDR4A_RESET_n,
      LPDDR4A_RZQ      : in    std_logic;                    -- input              LPDDR4A_RZQ,

      --///////// LPDDR4B /////////
      LPDDR4B_REFCLK_p : in    std_logic;                    -- input              LPDDR4B_REFCLK_p,
      LPDDR4B_CS_n     : out   std_logic;                    -- output             LPDDR4B_CS_n,
      LPDDR4B_CA       : out   std_logic_vector(5 downto 0); -- output   [ 5: 0]   LPDDR4B_CA,
      LPDDR4B_CK       : out   std_logic;                    -- output             LPDDR4B_CK,
      LPDDR4B_CKE      : out   std_logic;                    -- output             LPDDR4B_CKE,
      LPDDR4B_CK_n     : out   std_logic;                    -- output             LPDDR4B_CK_n,
      LPDDR4B_DM       : inout std_logic_vector(3 downto 0); -- inout    [ 3: 0]   LPDDR4B_DM,
      LPDDR4B_DQ       : inout std_logic_vector(31 downto 0);-- inout    [31: 0]   LPDDR4B_DQ,
      LPDDR4B_DQS      : inout std_logic_vector(3 downto 0); -- inout    [ 3: 0]   LPDDR4B_DQS,
      LPDDR4B_DQS_n    : inout std_logic_vector(3 downto 0); -- inout    [ 3: 0]   LPDDR4B_DQS_n,
      LPDDR4B_RESET_n  : out   std_logic;                    -- output             LPDDR4B_RESET_n,
      LPDDR4B_RZQ      : in    std_logic;                    -- input              LPDDR4B_RZQ,

      --///////// HDMI /////////
      HDMI_LRCLK       : inout std_logic;                     -- inout              HDMI_LRCLK,
      HDMI_MCLK        : inout std_logic;                     -- inout              HDMI_MCLK,
      HDMI_SCLK        : inout std_logic;                     -- inout              HDMI_SCLK,
      HDMI_TX_CLK      : out   std_logic;                     -- output             HDMI_TX_CLK,
      HDMI_TX_HS       : out   std_logic;                     -- output             HDMI_TX_HS,
      HDMI_TX_VS       : out   std_logic;                     -- output             HDMI_TX_VS,
      HDMI_TX_D        : out   std_logic_vector(23 downto 0); -- output   [23: 0]   HDMI_TX_D,
      HDMI_TX_DE       : out   std_logic;                     -- output             HDMI_TX_DE,
      HDMI_I2C_SCL     : inout std_logic;                     -- inout              HDMI_I2C_SCL,
      HDMI_I2C_SDA     : inout std_logic;                     -- inout              HDMI_I2C_SDA,
      HDMI_TX_INT      : inout std_logic;                     -- input              HDMI_TX_INT,
      HDMI_I2S         : inout std_logic;                     -- inout              HDMI_I2S,

--    ///////// CAM /////////
--    CAM_CLK_p        : in    std_logic;                    --input              CAM_CLK_p,
--    CAM_CLK_n        : in    std_logic;                    --input              CAM_CLK_n,
--    CAM_D_p          : in    std_logic_vector(1 downto 0); --input    [ 1: 0]   CAM_D_p,
--    CAM_D_n          : in    std_logic_vector(1 downto 0); --input    [ 1: 0]   CAM_D_n,
--    CAM_I2C_SCL      : inout std_logic;                    --inout              CAM_I2C_SCL,
--    CAM_I2C_SDA      : inout std_logic;                    --inout              CAM_I2C_SDA,
--    CAM_GPIO         : inout std_logic;                    --inout              CAM_GPIO,
--    CAM_RZQ1         : in    std_logic;                    --input              CAM_RZQ1,

      --///////// FPGA UART /////////
      FPGA_UART_TX     : out   std_logic; -- output             FPGA_UART_TX,
      FPGA_UART_RX     : in    std_logic; -- input              FPGA_UART_RX,

      --///////// ADC /////////
      ADC_SCK          : out   std_logic; -- output             ADC_SCK,
      ADC_SDO          : in    std_logic; -- input              ADC_SDO,
      ADC_SDI          : out   std_logic; -- output             ADC_SDI,
      ADC_CS_n         : out   std_logic; -- output             ADC_CS_n,

      --///////// GPIO /////////
      GPIO0_D          : inout std_logic_vector(35 downto 0); -- inout    [35: 0]   GPIO0_D,
      GPIO1_D          : inout std_logic_vector(35 downto 0); -- inout    [35: 0]   GPIO1_D,

      --///////// HPS /////////
      HPS_CLK_25         : in    std_logic;                    --input              HPS_CLK_25,
      HPS_ENET_MDC       : out   std_logic;                    --output             HPS_ENET_MDC,
      HPS_ENET_MDIO      : inout std_logic;                    --inout              HPS_ENET_MDIO,
      HPS_ENET_RX_CLK    : in    std_logic;                    --input              HPS_ENET_RX_CLK,
      HPS_ENET_RX_CTL    : in    std_logic;                    --input              HPS_ENET_RX_CTL,
      HPS_ENET_RX_DATA   : in    std_logic_vector(3 downto 0); --input    [ 3: 0]   HPS_ENET_RX_DATA,
      HPS_ENET_TX_CLK    : out   std_logic;                    --output             HPS_ENET_TX_CLK,
      HPS_ENET_TX_CTL    : out   std_logic;                    --output             HPS_ENET_TX_CTL,
      HPS_ENET_TX_DATA   : out  std_logic_vector(3 downto 0);  --output   [ 3: 0]   HPS_ENET_TX_DATA,
      HPS_GSENSOR_I2C_EN : inout std_logic;                    --inout              HPS_GSENSOR_I2C_EN,
      HPS_GSENSOR_INT    : inout std_logic;                    --inout              HPS_GSENSOR_INT,
      HPS_I2C_SCL        : inout std_logic;                    --inout              HPS_I2C_SCL,
      HPS_I2C_SDA        : inout std_logic;                    --inout              HPS_I2C_SDA,
      HPS_KEY            : inout std_logic;                    --inout              HPS_KEY,
      HPS_LED            : inout std_logic;                    --inout              HPS_LED,
      HPS_SD_CLK         : out   std_logic;                    --output             HPS_SD_CLK,
      HPS_SD_CMD         : inout std_logic;                    --inout              HPS_SD_CMD,
      HPS_SD_DATA        : inout std_logic_vector(3 downto 0); --inout    [ 3: 0]   HPS_SD_DATA,
      HPS_UART_RX        : in    std_logic;                    --input              HPS_UART_RX,
      HPS_UART_TX        : out   std_logic;                    --output             HPS_UART_TX,
      HPS_USB_CLK        : in    std_logic;                    --input              HPS_USB_CLK,
      HPS_USB_DATA       : inout std_logic_vector(7 downto 0); --inout    [ 7: 0]   HPS_USB_DATA,
      HPS_USB_DIR        : in    std_logic;                    --input              HPS_USB_DIR,
      HPS_USB_NXT        : in    std_logic;                    --input              HPS_USB_NXT,
      HPS_USB_STP        : out   std_logic;                    --output             HPS_USB_STP,

      --///////// FAN /////////
      FAN_ALERT_n      : in    std_logic  --input              FAN_ALERT_n
);
end entity nano25_top;

 
ARCHITECTURE ARCH of nano25_top is


    component qsys_top is
        port (
            h2f_reset_reset                          : out   std_logic;                                        -- reset
            hps_h2f_warm_reset_handshake_reset_req   : out   std_logic;                                        -- reset_req
            hps_h2f_warm_reset_handshake_reset_ack   : in    std_logic                     := 'X';             -- reset_ack
            hps_io_hps_osc_clk                       : in    std_logic                     := 'X';             -- hps_osc_clk
            hps_io_sdmmc_data0                       : inout std_logic                     := 'X';             -- sdmmc_data0
            hps_io_sdmmc_data1                       : inout std_logic                     := 'X';             -- sdmmc_data1
            hps_io_sdmmc_cclk                        : out   std_logic;                                        -- sdmmc_cclk
            hps_io_sdmmc_data2                       : inout std_logic                     := 'X';             -- sdmmc_data2
            hps_io_sdmmc_data3                       : inout std_logic                     := 'X';             -- sdmmc_data3
            hps_io_sdmmc_cmd                         : inout std_logic                     := 'X';             -- sdmmc_cmd
            hps_io_usb0_clk                          : in    std_logic                     := 'X';             -- usb0_clk
            hps_io_usb0_stp                          : out   std_logic;                                        -- usb0_stp
            hps_io_usb0_dir                          : in    std_logic                     := 'X';             -- usb0_dir
            hps_io_usb0_data0                        : inout std_logic                     := 'X';             -- usb0_data0
            hps_io_usb0_data1                        : inout std_logic                     := 'X';             -- usb0_data1
            hps_io_usb0_nxt                          : in    std_logic                     := 'X';             -- usb0_nxt
            hps_io_usb0_data2                        : inout std_logic                     := 'X';             -- usb0_data2
            hps_io_usb0_data3                        : inout std_logic                     := 'X';             -- usb0_data3
            hps_io_usb0_data4                        : inout std_logic                     := 'X';             -- usb0_data4
            hps_io_usb0_data5                        : inout std_logic                     := 'X';             -- usb0_data5
            hps_io_usb0_data6                        : inout std_logic                     := 'X';             -- usb0_data6
            hps_io_usb0_data7                        : inout std_logic                     := 'X';             -- usb0_data7
            hps_io_emac0_tx_clk                      : out   std_logic;                                        -- emac0_tx_clk
            hps_io_emac0_tx_ctl                      : out   std_logic;                                        -- emac0_tx_ctl
            hps_io_emac0_rx_clk                      : in    std_logic                     := 'X';             -- emac0_rx_clk
            hps_io_emac0_rx_ctl                      : in    std_logic                     := 'X';             -- emac0_rx_ctl
            hps_io_emac0_txd0                        : out   std_logic;                                        -- emac0_txd0
            hps_io_emac0_txd1                        : out   std_logic;                                        -- emac0_txd1
            hps_io_emac0_rxd0                        : in    std_logic                     := 'X';             -- emac0_rxd0
            hps_io_emac0_rxd1                        : in    std_logic                     := 'X';             -- emac0_rxd1
            hps_io_emac0_txd2                        : out   std_logic;                                        -- emac0_txd2
            hps_io_emac0_txd3                        : out   std_logic;                                        -- emac0_txd3
            hps_io_emac0_rxd2                        : in    std_logic                     := 'X';             -- emac0_rxd2
            hps_io_emac0_rxd3                        : in    std_logic                     := 'X';             -- emac0_rxd3
            hps_io_mdio0_mdio                        : inout std_logic                     := 'X';             -- mdio0_mdio
            hps_io_mdio0_mdc                         : out   std_logic;                                        -- mdio0_mdc
            hps_io_uart1_tx                          : out   std_logic;                                        -- uart1_tx
            hps_io_uart1_rx                          : in    std_logic                     := 'X';             -- uart1_rx
            hps_io_i2c1_sda                          : inout std_logic                     := 'X';             -- i2c1_sda
            hps_io_i2c1_scl                          : inout std_logic                     := 'X';             -- i2c1_scl
            hps_io_gpio28                            : inout std_logic                     := 'X';             -- gpio28
            hps_io_gpio34                            : inout std_logic                     := 'X';             -- gpio34
            hps_io_gpio40                            : inout std_logic                     := 'X';             -- gpio40
            hps_io_gpio41                            : inout std_logic                     := 'X';             -- gpio41
          --button_pio_external_connection_export    : in    std_logic_vector(3 downto 0)  := (others => 'X'); -- export
            vid0_clock_i                             : in    std_logic                     := 'X';             -- clock_i
            vid0_clken_i                             : in    std_logic                     := 'X';             -- clken_i
            vid0_data_i                              : in    std_logic_vector(23 downto 0) := (others => 'X'); -- data_i
            vid0_de_i                                : in    std_logic                     := 'X';             -- de_i
            vid0_hsync_i                             : in    std_logic                     := 'X';             -- hsync_i
            vid0_vsync_i                             : in    std_logic                     := 'X';             -- vsync_i
            vid0_f_i                                 : in    std_logic                     := 'X';             -- f_i
            vid0_locked_i                            : in    std_logic                     := 'X';             -- locked_i
            vid0_overflow_o                          : out   std_logic;                                        -- overflow_o
            dpy0_clock_i                             : in    std_logic                     := 'X';             -- clock_i
            dpy0_clken_i                             : in    std_logic                     := 'X';             -- clken_i
            dpy0_data_o                              : out   std_logic_vector(23 downto 0);                    -- data_o
            dpy0_mask_o                              : out   std_logic;                                        -- mask_o
            dpy0_de_o                                : out   std_logic;                                        -- de_o
            dpy0_hsync_o                             : out   std_logic;                                        -- hsync_o
            dpy0_vsync_o                             : out   std_logic;                                        -- vsync_o
            dpy0_h_o                                 : out   std_logic;                                        -- h_o
            dpy0_v_o                                 : out   std_logic;                                        -- v_o
            dpy0_underflow_o                         : out   std_logic;                                        -- underflow_o
            clk_50_i_clk                             : in    std_logic                     := 'X';             -- clk
            clk_50_video_i_clk                       : in    std_logic                     := 'X';             -- clk
            dipsw_pio_external_connection_export     : in    std_logic_vector(3 downto 0)  := (others => 'X'); -- export
          --ddr4b_axi4_reset_bridge_reset_n          : in    std_logic                     := 'X';             -- reset_n
            emif_hps_emif_mem_0_mem_cs               : out   std_logic_vector(0 downto 0);                     -- mem_cs
            emif_hps_emif_mem_0_mem_ca               : out   std_logic_vector(5 downto 0);                     -- mem_ca
            emif_hps_emif_mem_0_mem_cke              : out   std_logic_vector(0 downto 0);                     -- mem_cke
            emif_hps_emif_mem_0_mem_dq               : inout std_logic_vector(31 downto 0) := (others => 'X'); -- mem_dq
            emif_hps_emif_mem_0_mem_dqs_t            : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- mem_dqs_t
            emif_hps_emif_mem_0_mem_dqs_c            : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- mem_dqs_c
            emif_hps_emif_mem_0_mem_dmi              : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- mem_dmi
            emif_hps_emif_mem_ck_0_mem_ck_t          : out   std_logic_vector(0 downto 0);                     -- mem_ck_t
            emif_hps_emif_mem_ck_0_mem_ck_c          : out   std_logic_vector(0 downto 0);                     -- mem_ck_c
            emif_hps_emif_mem_reset_n_mem_reset_n    : out   std_logic;                                        -- mem_reset_n
            emif_hps_emif_oct_0_oct_rzqin            : in    std_logic                     := 'X';             -- oct_rzqin
            emif_hps_emif_ref_clk_clk                : in    std_logic                     := 'X';             -- clk
            emif_lpddr4b_core_init_n_reset_n         : in    std_logic                     := 'X';             -- reset_n
            emif_lpddr4b_s0_axi4lite_clock_clk       : in    std_logic                     := 'X';             -- clk
            emif_lpddr4b_s0_axi4lite_reset_n_reset_n : in    std_logic                     := 'X';             -- reset_n
            emif_lpddr4b_s0_axi4lite_awaddr          : in    std_logic_vector(26 downto 0) := (others => 'X'); -- awaddr
            emif_lpddr4b_s0_axi4lite_awprot          : in    std_logic_vector(2 downto 0)  := (others => 'X'); -- awprot
            emif_lpddr4b_s0_axi4lite_awvalid         : in    std_logic                     := 'X';             -- awvalid
            emif_lpddr4b_s0_axi4lite_awready         : out   std_logic;                                        -- awready
            emif_lpddr4b_s0_axi4lite_araddr          : in    std_logic_vector(26 downto 0) := (others => 'X'); -- araddr
            emif_lpddr4b_s0_axi4lite_arprot          : in    std_logic_vector(2 downto 0)  := (others => 'X'); -- arprot
            emif_lpddr4b_s0_axi4lite_arvalid         : in    std_logic                     := 'X';             -- arvalid
            emif_lpddr4b_s0_axi4lite_arready         : out   std_logic;                                        -- arready
            emif_lpddr4b_s0_axi4lite_wdata           : in    std_logic_vector(31 downto 0) := (others => 'X'); -- wdata
            emif_lpddr4b_s0_axi4lite_wstrb           : in    std_logic_vector(3 downto 0)  := (others => 'X'); -- wstrb
            emif_lpddr4b_s0_axi4lite_wvalid          : in    std_logic                     := 'X';             -- wvalid
            emif_lpddr4b_s0_axi4lite_wready          : out   std_logic;                                        -- wready
            emif_lpddr4b_s0_axi4lite_bready          : in    std_logic                     := 'X';             -- bready
            emif_lpddr4b_s0_axi4lite_bresp           : out   std_logic_vector(1 downto 0);                     -- bresp
            emif_lpddr4b_s0_axi4lite_bvalid          : out   std_logic;                                        -- bvalid
            emif_lpddr4b_s0_axi4lite_rready          : in    std_logic                     := 'X';             -- rready
            emif_lpddr4b_s0_axi4lite_rdata           : out   std_logic_vector(31 downto 0);                    -- rdata
            emif_lpddr4b_s0_axi4lite_rresp           : out   std_logic_vector(1 downto 0);                     -- rresp
            emif_lpddr4b_s0_axi4lite_rvalid          : out   std_logic;                                        -- rvalid
            emif_lpddr4b_mem_0_mem_cs                : out   std_logic_vector(0 downto 0);                     -- mem_cs
            emif_lpddr4b_mem_0_mem_ca                : out   std_logic_vector(5 downto 0);                     -- mem_ca
            emif_lpddr4b_mem_0_mem_cke               : out   std_logic_vector(0 downto 0);                     -- mem_cke
            emif_lpddr4b_mem_0_mem_dq                : inout std_logic_vector(31 downto 0) := (others => 'X'); -- mem_dq
            emif_lpddr4b_mem_0_mem_dqs_t             : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- mem_dqs_t
            emif_lpddr4b_mem_0_mem_dqs_c             : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- mem_dqs_c
            emif_lpddr4b_mem_0_mem_dmi               : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- mem_dmi
            emif_lpddr4b_mem_ck_0_mem_ck_t           : out   std_logic_vector(0 downto 0);                     -- mem_ck_t
            emif_lpddr4b_mem_ck_0_mem_ck_c           : out   std_logic_vector(0 downto 0);                     -- mem_ck_c
            emif_lpddr4b_mem_reset_n_mem_reset_n     : out   std_logic;                                        -- mem_reset_n
            emif_lpddr4b_oct_0_oct_rzqin             : in    std_logic                     := 'X';             -- oct_rzqin
            emif_lpddr4b_ref_clk_clk                 : in    std_logic                     := 'X';             -- clk
          --led_pio_external_connection_in_port      : in    std_logic_vector(2 downto 0)  := (others => 'X'); -- in_port
          --led_pio_external_connection_out_port     : out   std_logic_vector(2 downto 0);                     -- out_port
            pll_sys_locked_o_export                  : out   std_logic;                                        -- export
            pll_sys_reset_i_reset                    : in    std_logic                     := 'X';             -- reset
            pll_video_locked_o_export                : out   std_logic;                                        -- export
            pll_video_reset_i_reset                  : in    std_logic                     := 'X';             -- reset
            pll_video_clk_o_clk                      : out   std_logic;                                        -- clk
            sys_reset_i_reset_n                      : in    std_logic                     := 'X';             -- reset_n
            sys_clk_100_o_clk                        : out   std_logic;                                        -- clk
            ninit_done_o_ninit_done                  : out   std_logic                                         -- ninit_done
        );
    end component qsys_top;

 
--  component ddio_out24 IS
--   PORT
--   (
--    aclr  : IN STD_LOGIC ;
--    datain_h  : IN STD_LOGIC_VECTOR (23 DOWNTO 0);
--    datain_l  : IN STD_LOGIC_VECTOR (23 DOWNTO 0);
--    outclock  : IN STD_LOGIC ;
--    dataout  : OUT STD_LOGIC_VECTOR (23 DOWNTO 0)
--   );
--  END component ddio_out24;
--
--  component ddio_out1 IS
--   PORT
--   (
--    aclr  : IN STD_LOGIC ;
--    datain_h  : IN STD_LOGIC_VECTOR (0 DOWNTO 0);
--    datain_l  : IN STD_LOGIC_VECTOR (0 DOWNTO 0);
--    outclock  : IN STD_LOGIC ;
--    dataout  : OUT STD_LOGIC_VECTOR (0 DOWNTO 0)
--   );
--  END component ddio_out1;

--component pll is
--	port (
--		refclk   : in  std_logic := 'X'; -- clk
--		locked   : out std_logic;        -- export
--		rst      : in  std_logic := 'X'; -- reset
--		outclk_0 : out std_logic         -- clk
--	);
--end component pll;


  signal dpy0_clk    : std_logic;                           
  signal dpy0_clken  : std_logic;                           
  signal dpy0_data   : std_logic_vector(23 downto 0);                                         
  signal dpy0_de     : std_logic;                                                             
  signal dpy0_hs     : std_logic;                                                             
  signal dpy0_vs     : std_logic;                                                             

  signal system_clk_100              : std_logic; 
  signal system_reset_n          : std_logic; 
--signal system_clk_100_internal : std_logic; 
  signal ninit_done              : std_logic; 
--signal fpga_led_pio            : std_logic_vector(10-3 downto 0);                                    
  signal fpga_dipsw_pio          : std_logic_vector(SW'length-1 downto 0);                                   
  signal fpga_button_pio         : std_logic_vector(KEY'length-1 downto 0);                                  
  signal fpga_debounced_buttons  : std_logic_vector(KEY'length-1 downto 0);                               
--signal fpga_led_internal       : std_logic_vector(10-4 downto 0);                                
  signal heartbeat_count         : unsigned(24 downto 0);                                  
  signal heartbeat_led           : std_logic; 

  signal pll_locked_sys          : std_logic; 
  signal pll_locked_video        : std_logic; 
                       
                                         

  constant AXIL_DRIVER_ADDRESS_WIDTH : integer := 27;  --parameter AXIL_DRIVER_ADDRESS_WIDTH = 27; 

  
  signal AXI_LITE_CLK                : std_logic; 
  signal AXI_LITE_reset_n            : std_logic; 
  signal LPDDR4B_axil_driver_araddr  : std_logic_vector(AXIL_DRIVER_ADDRESS_WIDTH-1 downto 0); --  wire  [AXIL_DRIVER_ADDRESS_WIDTH - 1:0]	LPDDR4B_axil_driver_araddr;                     
  signal LPDDR4B_axil_driver_arprot  : std_logic_vector(2 downto 0);                           --  wire  [2:0]											LPDDR4B_axil_driver_arprot;                             
  signal LPDDR4B_axil_driver_arvalid : std_logic;                                              --  wire  												LPDDR4B_axil_driver_arvalid;                              
  signal LPDDR4B_axil_driver_arready : std_logic;                                              --  wire  												LPDDR4B_axil_driver_arready;                              
  signal LPDDR4B_axil_driver_rdata   : std_logic_vector(31 downto 0);                          --  wire  [31:0]										LPDDR4B_axil_driver_rdata;                              
  signal LPDDR4B_axil_driver_rresp   : std_logic_vector(1 downto 0);                           --  wire  [1:0]											LPDDR4B_axil_driver_rresp;                              
  signal LPDDR4B_axil_driver_rvalid  : std_logic;                                              --  wire  												LPDDR4B_axil_driver_rvalid;                               
  signal LPDDR4B_axil_driver_rready  : std_logic;                                              --  wire                                      LPDDR4B_axil_driver_rready;                   
  signal LPDDR4B_axil_driver_awaddr  : std_logic_vector(AXIL_DRIVER_ADDRESS_WIDTH-1 downto 0); --  wire   [AXIL_DRIVER_ADDRESS_WIDTH - 1:0]  LPDDR4B_axil_driver_awaddr;                   
  signal LPDDR4B_axil_driver_awprot  : std_logic_vector(2 downto 0);                           --  wire   [2:0]                              LPDDR4B_axil_driver_awprot;                   
  signal LPDDR4B_axil_driver_awvalid : std_logic;                                              --  wire                                      LPDDR4B_axil_driver_awvalid;                  
  signal LPDDR4B_axil_driver_awready : std_logic;                                              --  wire                                      LPDDR4B_axil_driver_awready;                  
  signal LPDDR4B_axil_driver_wdata   : std_logic_vector(31 downto 0);                          --  wire   [31:0]                             LPDDR4B_axil_driver_wdata;                    
  signal LPDDR4B_axil_driver_wstrb   : std_logic_vector(3 downto 0);                           --  wire   [3:0]                              LPDDR4B_axil_driver_wstrb;                    
  signal LPDDR4B_axil_driver_wvalid  : std_logic;                                              --  wire                                      LPDDR4B_axil_driver_wvalid;                   
  signal LPDDR4B_axil_driver_wready  : std_logic;                                              --  wire                                      LPDDR4B_axil_driver_wready;                   
  signal LPDDR4B_axil_driver_bresp   : std_logic_vector(1 downto 0);                           --  wire   [1:0]                              LPDDR4B_axil_driver_bresp;                    
  signal LPDDR4B_axil_driver_bvalid  : std_logic;                                              --  wire                                      LPDDR4B_axil_driver_bvalid;                   
  signal LPDDR4B_axil_driver_bready  : std_logic;                                              --  wire                                      LPDDR4B_axil_driver_bready;                   
  signal LPDDR4B_cal_done_rst_n      : std_logic;                                              --  wire													LPDDR4B_cal_done_rst_n;                                   

  signal hdmi_i2c_ready   : std_logic;  
  signal hdmi_i2c_reset_n : std_logic;  


begin




--//=======================================================
--//  REG/WIRE declarations
--//=======================================================
--wire                   system_clk_50;
--wire                   system_clk_100_internal;
--wire                   ninit_done;
--wire                   system_reset_n;
--wire [10-3:0]          fpga_led_pio;
--wire [10-7:0]          fpga_dipsw_pio;
--wire [10-9:0]          fpga_button_pio;
--wire [10-9:0]          fpga_debounced_buttons;
--wire [10-4:0]          fpga_led_internal;
--wire                   heartbeat_led;
--reg  [24:0]            heartbeat_count;

--//=======================================================
--//  Structural coding
--//=======================================================
--assign                 system_reset_n = ~ninit_done;
--assign                 system_clk_50  = CLOCK2_50;
--
--assign                 LED = fpga_led_pio;
--assign                 fpga_dipsw_pio = SW;
--assign                 fpga_button_pio = KEY;
--assign                 heartbeat_led = ~heartbeat_count[24];
--assign                 fpga_led_pio = {heartbeat_led,fpga_led_internal};


  -- 1 when all plls are locked
  -- reminder: plls are reseted with 'ninit_done' 
  system_reset_n <= pll_locked_sys and
                    pll_locked_video; 


--system_reset_n <= not ninit_done;

--  system_clk_50  <= CLOCK2_50;
  
  LED(7) <= heartbeat_led;
  LED(6) <= not hdmi_i2c_ready; -- 'on' when ready
  LED(5) <= hdmi_i2c_reset_n;   -- 'on' when reset asserted low
  LED(4 downto 2) <= (others => '1'); -- all 'off'
  LED(1) <= not system_reset_n;         -- 'on' when reset_n de-asserted 
  LED(0) <= not LPDDR4B_cal_done_rst_n; -- 'on' when cal_is done

  fpga_dipsw_pio <= SW;
  fpga_button_pio <= KEY;


--fpga_led_pio <= (heartbeat_led &  fpga_led_internal);

--pll pll_inst (
--.refclk   (system_clk_50),
--.locked   (),
--.rst      (ninit_done),
--.outclk_0 (system_clk_100_internal)
--);

--  pll_inst: component pll  
--  port map
--  (
--    refclk   => system_clk_50,
--    rst      => ninit_done,
--    locked   => open ,
--    outclk_0 => system_clk_100_internal
--  );

  heartbeat_led <= not heartbeat_count(24);
    
  process(system_clk_100)
  begin                                                                    
    if rising_edge(system_clk_100) then
              
      heartbeat_count <= heartbeat_count + 1;
   
    end if;
  end process;


  u0 : component qsys_top
    port map 
    (
      ninit_done_o_ninit_done   => ninit_done,  
      
      clk_50_i_clk              => CLOCK2_50,  
      clk_50_video_i_clk        => CLOCK1_50, 
                                
      pll_sys_reset_i_reset     => ninit_done,                                                                                            
      pll_sys_locked_o_export   => pll_locked_sys,                                                                                        

      sys_clk_100_o_clk         => system_clk_100,
      sys_reset_i_reset_n       => system_reset_n,    
                                                                                                                                                                                                                                                                                    
      pll_video_reset_i_reset   => ninit_done,                                                                                            
      pll_video_locked_o_export => pll_locked_video,                                                                                      
      pll_video_clk_o_clk       => dpy0_clk,                                                                                              
      
    --led_pio_external_connection_in_port      => (others => '0'), --fpga_led_internal(2 downto 0),                                                    
    --led_pio_external_connection_out_port     => open , -- fpga_led_internal(2 downto 0),                                                     
      dipsw_pio_external_connection_export     => fpga_dipsw_pio,                                                       
    --button_pio_external_connection_export    => (others => '0'), -- TMP !!!   fpga_debounced_buttons,                                                

      -- TBD
      h2f_reset_reset                          => open , --CONNECTED_TO_h2f_reset_reset,                          --                        h2f_reset.reset
      hps_h2f_warm_reset_handshake_reset_req   => open , --CONNECTED_TO_h2f_warm_reset_handshake_reset_req,       --         h2f_warm_reset_handshake.reset_req
      hps_h2f_warm_reset_handshake_reset_ack   => '1',   --CONNECTED_TO_h2f_warm_reset_handshake_reset_ack,       --                                 .reset_ack

      emif_hps_emif_mem_0_mem_cs(0)            => LPDDR4A_CS_n,                                                                        
      emif_hps_emif_mem_0_mem_ca               => LPDDR4A_CA,                                                                          
      emif_hps_emif_mem_0_mem_cke(0)           => LPDDR4A_CKE,                                                                         
      emif_hps_emif_mem_0_mem_dq               => LPDDR4A_DQ,                                                                          
      emif_hps_emif_mem_0_mem_dqs_t            => LPDDR4A_DQS,                                                                         
      emif_hps_emif_mem_0_mem_dqs_c            => LPDDR4A_DQS_n,                                                                       
      emif_hps_emif_mem_0_mem_dmi              => LPDDR4A_DM,                                                                          
      emif_hps_emif_mem_ck_0_mem_ck_t(0)       => LPDDR4A_CK,                                                                          
      emif_hps_emif_mem_ck_0_mem_ck_c(0)       => LPDDR4A_CK_n,                                                                        
      emif_hps_emif_mem_reset_n_mem_reset_n    => LPDDR4A_RESET_n,                                                                     
      emif_hps_emif_oct_0_oct_rzqin            => LPDDR4A_RZQ,                                                                         
      emif_hps_emif_ref_clk_clk                => LPDDR4A_REFCLK_p,                                                                    

      hps_io_hps_osc_clk                       => HPS_CLK_25,                           --                           hps_io.hps_osc_clk
                                                                                        
      hps_io_sdmmc_cclk                        => HPS_SD_CLK,                           --                                 .sdmmc_cclk
      hps_io_sdmmc_cmd                         => HPS_SD_CMD,                           --                                 .sdmmc_cmd
      hps_io_sdmmc_data0                       => HPS_SD_DATA(0),                       --                                 .sdmmc_data0
      hps_io_sdmmc_data1                       => HPS_SD_DATA(1),                       --                                 .sdmmc_data1
      hps_io_sdmmc_data2                       => HPS_SD_DATA(2),                       --                                 .sdmmc_data2
      hps_io_sdmmc_data3                       => HPS_SD_DATA(3),                       --                                 .sdmmc_data3

      hps_io_usb0_clk                          => HPS_USB_CLK,                          --                                 .usb0_clk
      hps_io_usb0_stp                          => HPS_USB_STP,                          --                                 .usb0_stp
      hps_io_usb0_dir                          => HPS_USB_DIR,                          --                                 .usb0_dir
      hps_io_usb0_nxt                          => HPS_USB_NXT,                          --                                 .usb0_nxt
      hps_io_usb0_data0                        => HPS_USB_DATA(0),                      --                                 .usb0_data0
      hps_io_usb0_data1                        => HPS_USB_DATA(1),                      --                                 .usb0_data1
      hps_io_usb0_data2                        => HPS_USB_DATA(2),                      --                                 .usb0_data2
      hps_io_usb0_data3                        => HPS_USB_DATA(3),                      --                                 .usb0_data3
      hps_io_usb0_data4                        => HPS_USB_DATA(4),                      --                                 .usb0_data4
      hps_io_usb0_data5                        => HPS_USB_DATA(5),                      --                                 .usb0_data5
      hps_io_usb0_data6                        => HPS_USB_DATA(6),                      --                                 .usb0_data6
      hps_io_usb0_data7                        => HPS_USB_DATA(7),                      --                                 .usb0_data7

      hps_io_emac0_tx_clk                      => HPS_ENET_TX_CLK,                      --                                 .emac0_tx_clk
      hps_io_emac0_tx_ctl                      => HPS_ENET_TX_CTL,                      --                                 .emac0_tx_ctl
      hps_io_emac0_rx_clk                      => HPS_ENET_RX_CLK,                      --                                 .emac0_rx_clk
      hps_io_emac0_rx_ctl                      => HPS_ENET_RX_CTL,                      --                                 .emac0_rx_ctl
      hps_io_emac0_txd0                        => HPS_ENET_TX_DATA(0),                        --                                 .emac0_txd0
      hps_io_emac0_txd1                        => HPS_ENET_TX_DATA(1),                        --                                 .emac0_txd1
      hps_io_emac0_txd2                        => HPS_ENET_TX_DATA(2),                        --                                 .emac0_txd2
      hps_io_emac0_txd3                        => HPS_ENET_TX_DATA(3),                        --                                 .emac0_txd3
      hps_io_emac0_rxd0                        => HPS_ENET_RX_DATA(0),                        --                                 .emac0_rxd0
      hps_io_emac0_rxd1                        => HPS_ENET_RX_DATA(1),                        --                                 .emac0_rxd1
      hps_io_emac0_rxd2                        => HPS_ENET_RX_DATA(2),                        --                                 .emac0_rxd2
      hps_io_emac0_rxd3                        => HPS_ENET_RX_DATA(3),                        --                                 .emac0_rxd3
      hps_io_mdio0_mdio                        => HPS_ENET_MDIO,                        --                                 .mdio0_mdio
      hps_io_mdio0_mdc                         => HPS_ENET_MDC,                         --                                 .mdio0_mdc
      hps_io_uart1_tx                          => HPS_UART_TX,                          --                                 .uart1_tx
      hps_io_uart1_rx                          => HPS_UART_RX,                          --                                 .uart1_rx
      hps_io_i2c1_sda                          => HPS_I2C_SDA,                          --                                 .i2c1_sda
      hps_io_i2c1_scl                          => HPS_I2C_SCL,                          --                                 .i2c1_scl
      hps_io_gpio28                            => HPS_GSENSOR_INT,                            --                                 .gpio28
      hps_io_gpio34                            => HPS_GSENSOR_I2C_EN,                            --                                 .gpio34
      hps_io_gpio40                            => HPS_KEY,                            --                                 .gpio40
      hps_io_gpio41                            => HPS_LED,                            --                                 .gpio41

      vid0_clock_i                             => dpy0_clk, -- tmp
      vid0_clken_i                             => '1',
      vid0_data_i                              => (others => '0'), -- data_i
      vid0_de_i                                => '0',             -- de_i
      vid0_hsync_i                             => '0',             -- hsync_i
      vid0_vsync_i                             => '0',             -- vsync_i
      vid0_f_i                                 => '0',             -- f_i
      vid0_locked_i                            => '0',             -- locked_i
      vid0_overflow_o                          => open, --: out   std_logic;                                        -- overflow_o

      dpy0_clock_i                             => dpy0_clk,    
      dpy0_clken_i                             => dpy0_clken,    
      dpy0_data_o                              => dpy0_data,     
      dpy0_de_o                                => dpy0_de,       
      dpy0_hsync_o                             => dpy0_hs,    
      dpy0_vsync_o                             => dpy0_vs,    
      dpy0_h_o                                 => open ,        
      dpy0_v_o                                 => open ,        
      dpy0_underflow_o                         => open ,

   -- TBD
  -- emif_lpddr4b_s0_axi4_ctrl_ready_reset_n  (LPDDR4B_AXI_Ready_ctrl),  //  output,   width = 1,  emif_lpddr4b_s0_axi4_ctrl_ready.reset_n

   --ddr4b_axi4_reset_bridge_reset_n          => LPDDR4B_cal_done_rst_n,            
     emif_lpddr4b_core_init_n_reset_n         => LPDDR4B_cal_done_rst_n,                                                                          
     emif_lpddr4b_s0_axi4lite_clock_clk       => AXI_LITE_CLK,                                                                                    
     emif_lpddr4b_s0_axi4lite_reset_n_reset_n => AXI_LITE_reset_n, --LPDDR4B_IOPLL_Lock,                                                                               
     emif_lpddr4b_s0_axi4lite_awaddr          => LPDDR4B_axil_driver_awaddr,                                                                      
     emif_lpddr4b_s0_axi4lite_awprot          => LPDDR4B_axil_driver_awprot,                                                                      
     emif_lpddr4b_s0_axi4lite_awvalid         => LPDDR4B_axil_driver_awvalid,                                                                     
     emif_lpddr4b_s0_axi4lite_awready         => LPDDR4B_axil_driver_awready,                                                                     
     emif_lpddr4b_s0_axi4lite_araddr          => LPDDR4B_axil_driver_araddr,                                                                      
     emif_lpddr4b_s0_axi4lite_arprot          => LPDDR4B_axil_driver_arprot,                                                                      
     emif_lpddr4b_s0_axi4lite_arvalid         => LPDDR4B_axil_driver_arvalid,                                                                     
     emif_lpddr4b_s0_axi4lite_arready         => LPDDR4B_axil_driver_arready,                                                                     
     emif_lpddr4b_s0_axi4lite_wdata           => LPDDR4B_axil_driver_wdata,                                                                       
     emif_lpddr4b_s0_axi4lite_wstrb           => LPDDR4B_axil_driver_wstrb,                                                                       
     emif_lpddr4b_s0_axi4lite_wvalid          => LPDDR4B_axil_driver_wvalid,                                                                      
     emif_lpddr4b_s0_axi4lite_wready          => LPDDR4B_axil_driver_wready,                                                                      
     emif_lpddr4b_s0_axi4lite_bready          => LPDDR4B_axil_driver_bready,                                                                      
     emif_lpddr4b_s0_axi4lite_bresp           => LPDDR4B_axil_driver_bresp,                                                                       
     emif_lpddr4b_s0_axi4lite_bvalid          => LPDDR4B_axil_driver_bvalid,                                                                      
     emif_lpddr4b_s0_axi4lite_rready          => LPDDR4B_axil_driver_rready,                                                                      
     emif_lpddr4b_s0_axi4lite_rdata           => LPDDR4B_axil_driver_rdata,                                                                       
     emif_lpddr4b_s0_axi4lite_rresp           => LPDDR4B_axil_driver_rresp,                                                                       
     emif_lpddr4b_s0_axi4lite_rvalid          => LPDDR4B_axil_driver_rvalid,                                                                      
     emif_lpddr4b_mem_0_mem_cs(0)             => LPDDR4B_CS_n,                                                                                    
     emif_lpddr4b_mem_0_mem_ca                => LPDDR4B_CA,                                                                                      
     emif_lpddr4b_mem_0_mem_cke(0)            => LPDDR4B_CKE,                                                                   
     emif_lpddr4b_mem_0_mem_dq                => LPDDR4B_DQ,                                                                    
     emif_lpddr4b_mem_0_mem_dqs_t             => LPDDR4B_DQS,                                                                   
     emif_lpddr4b_mem_0_mem_dqs_c             => LPDDR4B_DQS_n,                                                                 
     emif_lpddr4b_mem_0_mem_dmi               => LPDDR4B_DM,                                                                    
     emif_lpddr4b_mem_ck_0_mem_ck_t(0)        => LPDDR4B_CK,                                                                    
     emif_lpddr4b_mem_ck_0_mem_ck_c(0)        => LPDDR4B_CK_n,                                                                  
     emif_lpddr4b_mem_reset_n_mem_reset_n     => LPDDR4B_RESET_n,                                                               
     emif_lpddr4b_oct_0_oct_rzqin             => LPDDR4B_RZQ,                                                                   
     emif_lpddr4b_ref_clk_clk                 => LPDDR4B_REFCLK_p                                                                      
  );


  blk_display: block is 
  
    signal dpy0_pixclk_polarity : std_logic;

    signal r1_data : std_logic_vector(23 downto 0);                                         
    signal r1_de   : std_logic;                                                             
    signal r1_hs   : std_logic;                                                             
    signal r1_vs   : std_logic;                                                             

  
  begin
  
      
    process(dpy0_clk)
    begin                                                                    
      if rising_edge(dpy0_clk) then
                
        r1_data <= dpy0_data;
        r1_de   <= dpy0_de  ;
        r1_hs   <= dpy0_hs  ;
        r1_vs   <= dpy0_vs  ;
     
      end if;
    end process;
  
    -- 0: non inverted 
    -- 1: inverted
    dpy0_pixclk_polarity <= '1'; -- inverted to be center-aligned (required by ADV7513, cf UG page 13) 
   
    dpy0_clken <= '1'; -- no sub-sampling
  
  HDMI_TX_CLK <= not dpy0_clk;
  HDMI_TX_D  <= r1_data;
  HDMI_TX_DE <= r1_de;
  HDMI_TX_HS <= r1_hs;
  HDMI_TX_VS <= r1_vs;
  
--  -- clock output
--  tx_dout_clk : ddio_out1 PORT MAP (
--    aclr        => '0', 
--    datain_h(0) => (not dpy0_pixclk_polarity),
--    datain_l(0) =>      dpy0_pixclk_polarity,
--    outclock    => dpy0_clk,
--    dataout(0)  => HDMI_TX_CLK
--   );
--  
--  -- data output
--  tx_dout_d : ddio_out24 PORT MAP (
--    aclr      => '0', 
--    datain_h  => r1_data,
--    datain_l  => r1_data,
--    outclock  => dpy0_clk,
--    dataout   => HDMI_TX_D
--   );
--
--  tx_dout_de : ddio_out1 PORT MAP (
--    aclr        => '0', 
--    datain_h(0) => r1_de,
--    datain_l(0) => r1_de,
--    outclock    => dpy0_clk,
--    dataout(0)  => HDMI_TX_DE
--   );
--
--  tx_dout_hs : ddio_out1 PORT MAP (
--    aclr        => '0', 
--    datain_h(0) => r1_hs,
--    datain_l(0) => r1_hs,
--    outclock    => dpy0_clk,
--    dataout(0)  => HDMI_TX_HS
--   );
--
--  tx_dout_vs : ddio_out1 PORT MAP (
--    aclr        => '0', 
--    datain_h(0) => r1_vs,
--    datain_l(0) => r1_vs,
--    outclock    => dpy0_clk,
--    dataout(0)  => HDMI_TX_VS
--   );
  

--     HDMI_LRCLK       : inout std_logic;                     -- inout              HDMI_LRCLK,
--     HDMI_MCLK        : inout std_logic;                     -- inout              HDMI_MCLK,
--     HDMI_SCLK        : inout std_logic;                     -- inout              HDMI_SCLK,
--  --   HDMI_TX_CLK      : out   std_logic;                     -- output             HDMI_TX_CLK,
--  --   HDMI_TX_HS       : out   std_logic;                     -- output             HDMI_TX_HS,
--  --   HDMI_TX_VS       : out   std_logic;                     -- output             HDMI_TX_VS,
--  --   HDMI_TX_D        : out   std_logic_vector(23 downto 0); -- output   [23: 0]   HDMI_TX_D,
--  --   HDMI_TX_DE       : out   std_logic;                     -- output             HDMI_TX_DE,
--     HDMI_I2C_SCL     : inout std_logic;                     -- inout              HDMI_I2C_SCL,
--     HDMI_I2C_SDA     : inout std_logic;                     -- inout              HDMI_I2C_SDA,
--     HDMI_TX_INT      : inout std_logic;                     -- input              HDMI_TX_INT,
--     HDMI_I2S         : inout std_logic;                     -- inout              HDMI_I2S,




  hdmi_i2c_reset_n <= system_reset_n and fpga_debounced_buttons(0); -- KEY(0);

  inst_I2C_HDMI_Config: entity work.I2C_HDMI_Config
  port map
  (
	  iCLK        => CLOCK0_50,
	  iRST_N      => hdmi_i2c_reset_n,
	  I2C_SCLK    => HDMI_I2C_SCL,
	  I2C_SDAT    => HDMI_I2C_SDA,
	  HDMI_TX_INT => HDMI_TX_INT,
	  READY       => hdmi_i2c_ready 	
	);
			


--//--  HDMI I2C	SETTING
--wire HDMI_READY ;
--wire HDMI_I2C_SCLK ; 
--I2C_HDMI_Config entity work. u_I2C_HDMI_Config (
--	              .iCLK       (SYSTEM_50MHZ  ),
--	              .iRST_N     (reset_n & KEY[0]),
--	              .I2C_SCLK   (HDMI_I2C_SCL  ),
--	              .I2C_SDAT   (HDMI_I2C_SDA  ),
--	              .HDMI_TX_INT(HDMI_TX_INT   ),
--	              .READY      (HDMI_READY    ) 	
--	            );
--			


  end block; -- blk_display 



  AXI_LITE_CLK     <= system_clk_100; 
  AXI_LITE_reset_n <= system_reset_n;

 
  LPDDR4B_axil_driver_calibration_Inst : entity work.axil_driver_calibration
--defparam LPDDR4B_axil_driver_calibration_Inst.AXIL_DRIVER_ADDRESS_WIDTH = AXIL_DRIVER_ADDRESS_WIDTH; 
  generic map
  (
    AXIL_DRIVER_ADDRESS_WIDTH => AXIL_DRIVER_ADDRESS_WIDTH
  )	
  port map
  (
    axil_driver_clk     => AXI_LITE_CLK,                 --  /*input    wire                                         */    .axil_driver_clk(AXI_LITE_CLK),
    axil_driver_rst_n   => AXI_LITE_reset_n, --LPDDR4B_IOPLL_Lock,            --  /*input    wire                                         */    .axil_driver_rst_n(LPDDR4_IOPLL_Lock),
    axil_driver_araddr  => LPDDR4B_axil_driver_araddr,   --  /*output   wire     [AXIL_DRIVER_ADDRESS_WIDTH - 1:0]   */    .axil_driver_araddr(LPDDR4B_axil_driver_araddr),
    axil_driver_arprot  => LPDDR4B_axil_driver_arprot,   --  /*output   wire     [2:0]                               */    .axil_driver_arprot(LPDDR4B_axil_driver_arprot),
    axil_driver_arvalid => LPDDR4B_axil_driver_arvalid,  --  /*output   wire                                         */    .axil_driver_arvalid(LPDDR4B_axil_driver_arvalid),
    axil_driver_arready => LPDDR4B_axil_driver_arready,  --  /*input    wire                                         */    .axil_driver_arready(LPDDR4B_axil_driver_arready),
    axil_driver_rdata   => LPDDR4B_axil_driver_rdata,    --  /*input    wire     [31:0]                              */    .axil_driver_rdata(LPDDR4B_axil_driver_rdata),
    axil_driver_rresp   => LPDDR4B_axil_driver_rresp,    --  /*input    wire     [1:0]                               */    .axil_driver_rresp(LPDDR4B_axil_driver_rresp),
    axil_driver_rvalid  => LPDDR4B_axil_driver_rvalid,   --  /*input    wire                                         */    .axil_driver_rvalid(LPDDR4B_axil_driver_rvalid),

    axil_driver_rready  => LPDDR4B_axil_driver_rready,   --  /*output   wire                                         */    .axil_driver_rready(LPDDR4B_axil_driver_rready),
    axil_driver_awaddr  => LPDDR4B_axil_driver_awaddr,   --  /*output   wire     [AXIL_DRIVER_ADDRESS_WIDTH - 1:0]   */    .axil_driver_awaddr(LPDDR4B_axil_driver_awaddr),
    axil_driver_awprot  => LPDDR4B_axil_driver_awprot,   --  /*output   wire     [2:0]                               */    .axil_driver_awprot(LPDDR4B_axil_driver_awprot),
    axil_driver_awvalid => LPDDR4B_axil_driver_awvalid,  --  /*output   wire                                         */    .axil_driver_awvalid(LPDDR4B_axil_driver_awvalid),
    axil_driver_awready => LPDDR4B_axil_driver_awready,  --  /*input    wire                                         */    .axil_driver_awready(LPDDR4B_axil_driver_awready),
    axil_driver_wdata   => LPDDR4B_axil_driver_wdata,    --  /*output   wire     [31:0]                              */    .axil_driver_wdata(LPDDR4B_axil_driver_wdata),
    axil_driver_wstrb   => LPDDR4B_axil_driver_wstrb,    --  /*output   wire     [3:0]                               */    .axil_driver_wstrb(LPDDR4B_axil_driver_wstrb),
    axil_driver_wvalid  => LPDDR4B_axil_driver_wvalid,   --  /*output   wire                                         */    .axil_driver_wvalid(LPDDR4B_axil_driver_wvalid),
    axil_driver_wready  => LPDDR4B_axil_driver_wready,   --  /*input    wire                                         */    .axil_driver_wready(LPDDR4B_axil_driver_wready),
    axil_driver_bresp   => LPDDR4B_axil_driver_bresp,    --  /*input    wire     [1:0]                               */    .axil_driver_bresp(LPDDR4B_axil_driver_bresp),
    axil_driver_bvalid  => LPDDR4B_axil_driver_bvalid,   --  /*input    wire                                         */    .axil_driver_bvalid(LPDDR4B_axil_driver_bvalid),
    axil_driver_bready  => LPDDR4B_axil_driver_bready,   --  /*output   wire                                         */    .axil_driver_bready(LPDDR4B_axil_driver_bready),
    cal_done_rst_n      => LPDDR4B_cal_done_rst_n        --  /*output   wire                                         */    .cal_done_rst_n(LPDDR4B_cal_done_rst_n)
  );



  -- Debounce logic to clean out glitches within 1ms
  debounce_inst : entity work.debounce
  generic map
  (
    WIDTH         => 2,                                                                   
    POLARITY      => "LOW",                                                               
    TIMEOUT       => 10000, -- at 100Mhz this is a debounce time of 1ms     
    TIMEOUT_WIDTH => 32     -- ceil(log2(TIMEOUT))                                
  )	
  port map
  (
    clk      => system_clk_100, 
    reset_n  => system_reset_n,          
    data_in  => fpga_button_pio,         
    data_out => fpga_debounced_buttons   
  );


--debounce debounce_inst (
--.clk                                       (
--.reset_n                                   (
--.data_in                                   (
--.data_out                                  (
--);
--defparam debounce_inst.WIDTH         = 2;
--defparam debounce_inst.POLARITY      = "LOW";
--defparam debounce_inst.TIMEOUT       = 10000;               // at 100Mhz this is a debounce time of 1ms
--defparam debounce_inst.TIMEOUT_WIDTH = 32;            // ceil(log2(TIMEOUT))



end ARCH;





--always @(posedge system_clk_100_internal or negedge system_reset_n) begin
--  if (~system_reset_n)
--    heartbeat_count <= 25'd0;
--  else
--    heartbeat_count <= heartbeat_count + 25'd1;
--end



--qsys_top soc_inst (
--  .clk_100_clk                               (system_clk_100_internal),
--  .reset_reset_n                             (system_reset_n),
--  .ninit_done_ninit_done                     (ninit_done),
--  .led_pio_external_connection_in_port       (fpga_led_internal),
--  .led_pio_external_connection_out_port      (fpga_led_internal),
--  .dipsw_pio_external_connection_export      (fpga_dipsw_pio),
--  .button_pio_external_connection_export     (fpga_debounced_buttons),
  
--  .hps_io_hps_osc_clk                        (HPS_CLK_25),
--  .emif_hps_emif_mem_0_mem_cs            	 (LPDDR4A_CS_n),            
--  .emif_hps_emif_mem_0_mem_ca            	 (LPDDR4A_CA),            
--  .emif_hps_emif_mem_0_mem_cke           	 (LPDDR4A_CKE),           
--  .emif_hps_emif_mem_0_mem_dq             	 (LPDDR4A_DQ),            
--  .emif_hps_emif_mem_0_mem_dqs_t         	 (LPDDR4A_DQS),         
--  .emif_hps_emif_mem_0_mem_dqs_c         	 (LPDDR4A_DQS_n),         
--  .emif_hps_emif_mem_0_mem_dmi           	 (LPDDR4A_DM),          
--  .emif_hps_emif_mem_ck_0_mem_ck_t       	 (LPDDR4A_CK),      
--  .emif_hps_emif_mem_ck_0_mem_ck_c       	 (LPDDR4A_CK_n),                            
--  .emif_hps_emif_mem_reset_n_mem_reset_n 	 (LPDDR4A_RESET_n),
--  .emif_hps_emif_oct_0_oct_rzqin         	 (LPDDR4A_RZQ),   
--  .emif_hps_emif_ref_clk_clk            	 (LPDDR4A_REFCLK_p), 

  
--  .emif_lpddr4b_core_init_n_reset_n         (LPDDR4B_cal_done_rst_n),         //   input,   width = 1,         emif_lpddr4b_core_init_n.reset_n
--//.emif_lpddr4b_s0_axi4_ctrl_ready_reset_n  (LPDDR4B_AXI_Ready_ctrl),  //  output,   width = 1,  emif_lpddr4b_s0_axi4_ctrl_ready.reset_n
--  .emif_lpddr4b_s0_axi4lite_clock_clk       (AXI_LITE_CLK),       //   input,   width = 1,   emif_lpddr4b_s0_axi4lite_clock.clk
--  .emif_lpddr4b_s0_axi4lite_reset_n_reset_n (LPDDR4B_IOPLL_Lock), //   input,   width = 1, emif_lpddr4b_s0_axi4lite_reset_n.reset_n
--  .emif_lpddr4b_s0_axi4lite_awaddr          (LPDDR4B_axil_driver_awaddr),          //   input,  width = 27,         emif_lpddr4b_s0_axi4lite.awaddr
--  .emif_lpddr4b_s0_axi4lite_awprot          (LPDDR4B_axil_driver_awprot),          //   input,   width = 3,                                 .awprot
--  .emif_lpddr4b_s0_axi4lite_awvalid         (LPDDR4B_axil_driver_awvalid),         //   input,   width = 1,                                 .awvalid
--  .emif_lpddr4b_s0_axi4lite_awready         (LPDDR4B_axil_driver_awready),         //  output,   width = 1,                                 .awready
--  .emif_lpddr4b_s0_axi4lite_araddr          (LPDDR4B_axil_driver_araddr),          //   input,  width = 27,                                 .araddr
--  .emif_lpddr4b_s0_axi4lite_arprot          (LPDDR4B_axil_driver_arprot),          //   input,   width = 3,                                 .arprot
--  .emif_lpddr4b_s0_axi4lite_arvalid         (LPDDR4B_axil_driver_arvalid),         //   input,   width = 1,                                 .arvalid
--  .emif_lpddr4b_s0_axi4lite_arready         (LPDDR4B_axil_driver_arready),         //  output,   width = 1,                                 .arready
--  .emif_lpddr4b_s0_axi4lite_wdata           (LPDDR4B_axil_driver_wdata),           //   input,  width = 32,                                 .wdata
--  .emif_lpddr4b_s0_axi4lite_wstrb           (LPDDR4B_axil_driver_wstrb),           //   input,   width = 4,                                 .wstrb
--  .emif_lpddr4b_s0_axi4lite_wvalid          (LPDDR4B_axil_driver_wvalid),          //   input,   width = 1,                                 .wvalid
--  .emif_lpddr4b_s0_axi4lite_wready          (LPDDR4B_axil_driver_wready),          //  output,   width = 1,                                 .wready
--  .emif_lpddr4b_s0_axi4lite_bready          (LPDDR4B_axil_driver_bready),          //   input,   width = 1,                                 .bready
--  .emif_lpddr4b_s0_axi4lite_bresp           (LPDDR4B_axil_driver_bresp),           //  output,   width = 2,                                 .bresp
--  .emif_lpddr4b_s0_axi4lite_bvalid          (LPDDR4B_axil_driver_bvalid),          //  output,   width = 1,                                 .bvalid
--  .emif_lpddr4b_s0_axi4lite_rready          (LPDDR4B_axil_driver_rready),          //   input,   width = 1,                                 .rready
--  .emif_lpddr4b_s0_axi4lite_rdata           (LPDDR4B_axil_driver_rdata),           //  output,  width = 32,                                 .rdata
--  .emif_lpddr4b_s0_axi4lite_rresp           (LPDDR4B_axil_driver_rresp),           //  output,   width = 2,                                 .rresp
--  .emif_lpddr4b_s0_axi4lite_rvalid          (LPDDR4B_axil_driver_rvalid),          //  output,   width = 1,                                 .rvalid
--  .emif_lpddr4b_mem_0_mem_cs                (LPDDR4B_CS_n),                //  output,   width = 1,               emif_lpddr4b_mem_0.mem_cs
--  .emif_lpddr4b_mem_0_mem_ca                (LPDDR4B_CA),                //  output,   width = 6,                                 .mem_ca
--  .emif_lpddr4b_mem_0_mem_cke               (LPDDR4B_CKE),               //  output,   width = 1,                                 .mem_cke
--  .emif_lpddr4b_mem_0_mem_dq                (LPDDR4B_DQ),                //   inout,  width = 32,                                 .mem_dq
--  .emif_lpddr4b_mem_0_mem_dqs_t             (LPDDR4B_DQS),             //   inout,   width = 4,                                 .mem_dqs_t
--  .emif_lpddr4b_mem_0_mem_dqs_c             (LPDDR4B_DQS_n),             //   inout,   width = 4,                                 .mem_dqs_c
--  .emif_lpddr4b_mem_0_mem_dmi               (LPDDR4B_DM),               //   inout,   width = 4,                                 .mem_dmi
--  .emif_lpddr4b_mem_ck_0_mem_ck_t           (LPDDR4B_CK),           //  output,   width = 1,            emif_lpddr4b_mem_ck_0.mem_ck_t
--  .emif_lpddr4b_mem_ck_0_mem_ck_c           (LPDDR4B_CK_n),           //  output,   width = 1,                                 .mem_ck_c
--  .emif_lpddr4b_mem_reset_n_mem_reset_n     (LPDDR4B_RESET_n),     //  output,   width = 1,         emif_lpddr4b_mem_reset_n.mem_reset_n
--  .emif_lpddr4b_oct_0_oct_rzqin             (LPDDR4B_RZQ),             //   input,   width = 1,               emif_lpddr4b_oct_0.oct_rzqin
--  .emif_lpddr4b_ref_clk_clk                 (LPDDR4B_REFCLK_p),                 //   input,   width = 1,             emif_lpddr4b_ref_clk.clk

--  .dpy0_clock_i                             (_connected_to_dpy0_clock_i_),                             //   input,   width = 1,                             dpy0.clock_i
--  .dpy0_clken_i                             (_connected_to_dpy0_clken_i_),                             //   input,   width = 1,                                 .clken_i
--  .dpy0_data_o                              (HDMI_TX_D),                              //  output,  width = 24,                                 .data_o
--//.dpy0_mask_o                              (_connected_to_dpy0_mask_o_),                              //  output,   width = 1,                                 .mask_o
--  .dpy0_de_o                                (_connected_to_dpy0_de_o_),                                //  output,   width = 1,                                 .de_o
--  .dpy0_hsync_o                             (_connected_to_dpy0_hsync_o_),                             //  output,   width = 1,                                 .hsync_o
--  .dpy0_vsync_o                             (_connected_to_dpy0_vsync_o_),                             //  output,   width = 1,                                 .vsync_o
--  .dpy0_h_o                                 (_connected_to_dpy0_h_o_),                                 //  output,   width = 1,                                 .h_o
--  .dpy0_v_o                                 (_connected_to_dpy0_v_o_),                                 //  output,   width = 1,                                 .v_o
--//.dpy0_underflow_o                         (_connected_to_dpy0_underflow_o_),                         //  output,   width = 1,                                 .underflow_o
  
--  .hps_io_emac0_tx_clk                       (HPS_ENET_TX_CLK),
--  .hps_io_emac0_rx_clk                       (HPS_ENET_RX_CLK),
--  .hps_io_emac0_tx_ctl                       (HPS_ENET_TX_CTL),
--  .hps_io_emac0_rx_ctl                       (HPS_ENET_RX_CTL),
--  .hps_io_emac0_txd0                         (HPS_ENET_TX_DATA[0]),
--  .hps_io_emac0_txd1                         (HPS_ENET_TX_DATA[1]),
--  .hps_io_emac0_rxd0                         (HPS_ENET_RX_DATA[0]),
--  .hps_io_emac0_rxd1                         (HPS_ENET_RX_DATA[1]),
--  .hps_io_emac0_txd2                         (HPS_ENET_TX_DATA[2]),
--  .hps_io_emac0_txd3                         (HPS_ENET_TX_DATA[3]),
--  .hps_io_emac0_rxd2                         (HPS_ENET_RX_DATA[2]),
--  .hps_io_emac0_rxd3                         (HPS_ENET_RX_DATA[3]),
--  .hps_io_mdio0_mdio                         (HPS_ENET_MDIO),
--  .hps_io_mdio0_mdc                          (HPS_ENET_MDC),

--  .hps_io_sdmmc_cclk                         (HPS_SD_CLK),
--  .hps_io_sdmmc_cmd                          (HPS_SD_CMD),
--  .hps_io_sdmmc_data0                        (HPS_SD_DATA[0]),
--  .hps_io_sdmmc_data1                        (HPS_SD_DATA[1]),
--  .hps_io_sdmmc_data2                        (HPS_SD_DATA[2]),
--  .hps_io_sdmmc_data3                        (HPS_SD_DATA[3]),
--  .hps_io_uart1_rx                           (HPS_UART_RX),
--  .hps_io_uart1_tx                           (HPS_UART_TX),
--  .hps_io_usb0_clk                           (HPS_USB_CLK),
--  .hps_io_usb0_stp                           (HPS_USB_STP),
--  .hps_io_usb0_dir                           (HPS_USB_DIR),
--  // Todo clarify for NXT or NXR
--  .hps_io_usb0_nxt                           (HPS_USB_NXT),
--  .hps_io_usb0_data0                         (HPS_USB_DATA[0]),
--  .hps_io_usb0_data1                         (HPS_USB_DATA[1]),
--  .hps_io_usb0_data2                         (HPS_USB_DATA[2]),
--  .hps_io_usb0_data3                         (HPS_USB_DATA[3]),
--  .hps_io_usb0_data4                         (HPS_USB_DATA[4]),
--  .hps_io_usb0_data5                         (HPS_USB_DATA[5]),
--  .hps_io_usb0_data6                         (HPS_USB_DATA[6]),
--  .hps_io_usb0_data7                         (HPS_USB_DATA[7]),
--   .hps_io_i2c1_sda                           (HPS_I2C_SDA),
--   .hps_io_i2c1_scl                           (HPS_I2C_SCL),
--   .hps_io_gpio28                             (HPS_GSENSOR_INT),
--   .hps_io_gpio34                             (HPS_GSENSOR_I2C_EN),
-- //.hps_io_gpio33                           (HPS_GSENSOR_INT2),
--   .hps_io_gpio40                             (HPS_KEY),
--   .hps_io_gpio41                             (HPS_LED)
--
--);

