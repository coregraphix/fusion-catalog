# _hw.tcl file for fusion
package require -exact qsys 13.1


  # ------------------------------------------------------------------------------------------------
  # --                                                                                            --
  # -- sources tcl                                                                                --
  # --                                                                                            --
  # ------------------------------------------------------------------------------------------------

  source version.tcl
  source common_tcl/cgx_common_surface.tcl
  source common_tcl/cgx_common_tpg.tcl
  source common_tcl/cgx_common_fusion.tcl
  source common_tcl/cgx_common_display.tcl
  source common_tcl/cgx_common_video.tcl
  source common_tcl/cgx_common_cvi.tcl
  source common_tcl/cgx_common_vgr.tcl


  # ------------------------------------------------------------------------------------------------
  # --                                                                                            --
  # -- Module top                                                                                 --
  # --                                                                                            --
  # ------------------------------------------------------------------------------------------------

  set_module_property NAME cgx_fusion
  set_module_property VERSION $FUSION_VERSION  
  set_module_property DESCRIPTION "FUSION"
  set_module_property INTERNAL false
  set_module_property OPAQUE_ADDRESS_MAP true
  set_module_property DISPLAY_NAME "FUSION"
  set_module_property GROUP "Coregraphix"
  set_module_property AUTHOR CGX
  set_module_property INSTANTIATE_IN_SYSTEM_MODULE true
  set_module_property EDITABLE true
  set_module_property ANALYZE_HDL false
  set_module_property ICON_PATH cgx_fusion_logo.png
  set_module_property VALIDATION_CALLBACK  core_validation_callback
  set_module_property ELABORATION_CALLBACK core_elaboration_callback
  
  # do not work
  #add_documentation_link "User Guide" file:///Vector-Graphics_Renderer_1.1_preliminary.pdf 
  #add_documentation_link "User Guide" file:///datasheet.pdf 
  
  add_display_item "" "Block Diagram" GROUP

  # ------------------------------------------------------------------------------------------------
  # --                                                                                            --
  # -- Files                                                                                      --
  # --                                                                                            --
  # ------------------------------------------------------------------------------------------------

  add_fileset QUARTUS_SYNTH QUARTUS_SYNTH "" ""
  set_fileset_property QUARTUS_SYNTH TOP_LEVEL cgx_fusion_top
  set_fileset_property QUARTUS_SYNTH ENABLE_RELATIVE_INCLUDE_PATHS false
  set_fileset_property QUARTUS_SYNTH ENABLE_FILE_OVERWRITE_MODE false


  # common
  add_fileset_file cgx_fusion.sdc   SDC  PATH cgx_fusion.sdc

  vip_add_fileset $FUSION_HDL_DIRECTORY

                  
   
  # ------------------------------------------------------------------------------------------------
  # --                                                                                            --
  # -- Interfaces                                                                                 --
  # --                                                                                            --
  # ------------------------------------------------------------------------------------------------
  
  vip_add_interface

  for {set i 0} {$i<$MAX_VID} {incr i} {
 
    video_add_interface "vid$i"
       
  }

  display_add_interface dpy0


# sfr_add_interface surface_reader

#  vgr_add_interface vgr0

 
  # ------------------------------------------------------------------------------------------------
  # --                                                                                            --
  # -- GUI Parameters                                                                             --
  # --                                                                                            --
  # ------------------------------------------------------------------------------------------------



  # ------------------------------------------------------------------------------------------------
  # --                                                                                            --
  # -- GUI Parameters                                                                             --
  # --                                                                                            --
  # ------------------------------------------------------------------------------------------------


  # General Parameters  

  add_parameter          WZD_VERSION_MAJOR INTEGER 0
  set_parameter_property WZD_VERSION_MAJOR DISPLAY_NAME "major";
  set_parameter_property WZD_VERSION_MAJOR DISPLAY_HINT INTEGER
  set_parameter_property WZD_VERSION_MAJOR DESCRIPTION " "
  set_parameter_property WZD_VERSION_MAJOR VISIBLE false 
  set_parameter_property WZD_VERSION_MAJOR DERIVED true 
  set_parameter_property WZD_VERSION_MAJOR HDL_PARAMETER true

  add_parameter          WZD_VERSION_MINOR INTEGER 0
  set_parameter_property WZD_VERSION_MINOR DISPLAY_NAME "minor";
  set_parameter_property WZD_VERSION_MINOR DISPLAY_HINT INTEGER
  set_parameter_property WZD_VERSION_MINOR DESCRIPTION " "
  set_parameter_property WZD_VERSION_MINOR VISIBLE false 
  set_parameter_property WZD_VERSION_MINOR DERIVED true 
  set_parameter_property WZD_VERSION_MINOR HDL_PARAMETER true

#  add_parameter          WZD_TPG_VERSION_MAJOR INTEGER 0
#  set_parameter_property WZD_TPG_VERSION_MAJOR DISPLAY_NAME "tpg major";
#  set_parameter_property WZD_TPG_VERSION_MAJOR DISPLAY_HINT INTEGER
#  set_parameter_property WZD_TPG_VERSION_MAJOR DESCRIPTION " "
#  set_parameter_property WZD_TPG_VERSION_MAJOR VISIBLE false 
#  set_parameter_property WZD_TPG_VERSION_MAJOR DERIVED true 
#  set_parameter_property WZD_TPG_VERSION_MAJOR HDL_PARAMETER true
#
#  add_parameter          WZD_TPG_VERSION_MINOR INTEGER 0
#  set_parameter_property WZD_TPG_VERSION_MINOR DISPLAY_NAME "tpg minor";
#  set_parameter_property WZD_TPG_VERSION_MINOR DISPLAY_HINT INTEGER
#  set_parameter_property WZD_TPG_VERSION_MINOR DESCRIPTION " "
#  set_parameter_property WZD_TPG_VERSION_MINOR VISIBLE false 
#  set_parameter_property WZD_TPG_VERSION_MINOR DERIVED true 
#  set_parameter_property WZD_TPG_VERSION_MINOR HDL_PARAMETER true
#
#  add_parameter          WZD_CVI_VERSION_MAJOR INTEGER 0
#  set_parameter_property WZD_CVI_VERSION_MAJOR DISPLAY_NAME "cvi major";
#  set_parameter_property WZD_CVI_VERSION_MAJOR DISPLAY_HINT INTEGER
#  set_parameter_property WZD_CVI_VERSION_MAJOR DESCRIPTION " "
#  set_parameter_property WZD_CVI_VERSION_MAJOR VISIBLE false 
#  set_parameter_property WZD_CVI_VERSION_MAJOR DERIVED true 
#  set_parameter_property WZD_CVI_VERSION_MAJOR HDL_PARAMETER true
#
#  add_parameter          WZD_CVI_VERSION_MINOR INTEGER 0
#  set_parameter_property WZD_CVI_VERSION_MINOR DISPLAY_NAME "cvi minor";
#  set_parameter_property WZD_CVI_VERSION_MINOR DISPLAY_HINT INTEGER
#  set_parameter_property WZD_CVI_VERSION_MINOR DESCRIPTION " "
#  set_parameter_property WZD_CVI_VERSION_MINOR VISIBLE false 
#  set_parameter_property WZD_CVI_VERSION_MINOR DERIVED true 
#  set_parameter_property WZD_CVI_VERSION_MINOR HDL_PARAMETER true
#
#  add_parameter          WZD_VSC_VERSION_MAJOR INTEGER 0
#  set_parameter_property WZD_VSC_VERSION_MAJOR DISPLAY_NAME "vsc major";
#  set_parameter_property WZD_VSC_VERSION_MAJOR DISPLAY_HINT INTEGER
#  set_parameter_property WZD_VSC_VERSION_MAJOR DESCRIPTION " "
#  set_parameter_property WZD_VSC_VERSION_MAJOR VISIBLE false 
#  set_parameter_property WZD_VSC_VERSION_MAJOR DERIVED true 
#  set_parameter_property WZD_VSC_VERSION_MAJOR HDL_PARAMETER true
#
#  add_parameter          WZD_VSC_VERSION_MINOR INTEGER 0
#  set_parameter_property WZD_VSC_VERSION_MINOR DISPLAY_NAME "vsc minor";
#  set_parameter_property WZD_VSC_VERSION_MINOR DISPLAY_HINT INTEGER
#  set_parameter_property WZD_VSC_VERSION_MINOR DESCRIPTION " "
#  set_parameter_property WZD_VSC_VERSION_MINOR VISIBLE false 
#  set_parameter_property WZD_VSC_VERSION_MINOR DERIVED true 
#  set_parameter_property WZD_VSC_VERSION_MINOR HDL_PARAMETER true


  # invisible
  add_parameter          WZD_CLOCK_RATE INTEGER
  set_parameter_property WZD_CLOCK_RATE DISPLAY_NAME "core clock rate" 
  set_parameter_property WZD_CLOCK_RATE system_info {CLOCK_RATE clock}
  set_parameter_property WZD_CLOCK_RATE VISIBLE false
  set_parameter_property WZD_CLOCK_RATE HDL_PARAMETER true

  global MAX_VID
  global MAX_DPY 
  global MAX_GFX 
  global vip_add_interface_mem_gpu 
 
  add_parameter          WZD_ENA_DPY INTEGER 1
  set_parameter_property WZD_ENA_DPY DISPLAY_HINT boolean
  set_parameter_property WZD_ENA_DPY DISPLAY_NAME "use display-out" 
  set_parameter_property WZD_ENA_DPY AFFECTS_ELABORATION true  
  set_parameter_property WZD_ENA_DPY HDL_PARAMETER true
  
  add_parameter          WZD_ENA_VID INTEGER 1
  set_parameter_property WZD_ENA_VID DISPLAY_HINT boolean
  set_parameter_property WZD_ENA_VID DISPLAY_NAME "use video-in" 
  set_parameter_property WZD_ENA_VID AFFECTS_ELABORATION true  
  set_parameter_property WZD_ENA_VID HDL_PARAMETER true
  
  add_parameter          WZD_ENA_GFX INTEGER 1
  set_parameter_property WZD_ENA_GFX DISPLAY_HINT boolean
  set_parameter_property WZD_ENA_GFX DISPLAY_NAME "use graphics" 
  set_parameter_property WZD_ENA_GFX AFFECTS_ELABORATION true  
  set_parameter_property WZD_ENA_GFX HDL_PARAMETER true

  add_parameter          WZD_ENA_DMA INTEGER 1
  set_parameter_property WZD_ENA_DMA DISPLAY_HINT boolean
  set_parameter_property WZD_ENA_DMA DISPLAY_NAME "use DMA" 
  set_parameter_property WZD_ENA_DMA AFFECTS_ELABORATION true  
  set_parameter_property WZD_ENA_DMA HDL_PARAMETER true

  add_parameter          WZD_ENA_AXI_CSR INTEGER 0
  set_parameter_property WZD_ENA_AXI_CSR DISPLAY_HINT boolean
  set_parameter_property WZD_ENA_AXI_CSR DISPLAY_NAME "use AXI for CSR (instead of Avalon)" 
  set_parameter_property WZD_ENA_AXI_CSR AFFECTS_ELABORATION true  
  set_parameter_property WZD_ENA_AXI_CSR HDL_PARAMETER true

# add_parameter          WZD_ENA_AXI_MEM INTEGER 0
# set_parameter_property WZD_ENA_AXI_MEM DISPLAY_HINT boolean
# set_parameter_property WZD_ENA_AXI_MEM DISPLAY_NAME "use AXI for MEM (instead of Avalon)" 
# set_parameter_property WZD_ENA_AXI_MEM AFFECTS_ELABORATION true  
# set_parameter_property WZD_ENA_AXI_MEM HDL_PARAMETER true
          
  add_parameter          WZD_NUM_DPY INTEGER 1
  set display_number_range "{1:$MAX_DPY}"
  set_parameter_property WZD_NUM_DPY ALLOWED_RANGES $display_number_range
  set_parameter_property WZD_NUM_DPY DISPLAY_NAME "number of outputs" 
  set_parameter_property WZD_NUM_DPY AFFECTS_ELABORATION true  
  set_parameter_property WZD_NUM_DPY HDL_PARAMETER true
  set_parameter_property WZD_NUM_DPY ENABLED true
  if {$MAX_DPY==1} { 
  set_parameter_property WZD_NUM_DPY ENABLED false
  }
  
  add_parameter          WZD_NUM_VID INTEGER 1
  set video_number_range "{1:$MAX_VID}"
  set_parameter_property WZD_NUM_VID ALLOWED_RANGES $video_number_range
  set_parameter_property WZD_NUM_VID DISPLAY_NAME "number of inputs" 
  set_parameter_property WZD_NUM_VID AFFECTS_ELABORATION true  
  set_parameter_property WZD_NUM_VID HDL_PARAMETER true
  set_parameter_property WZD_NUM_VID ENABLED true
  if {$MAX_VID==1} { 
  set_parameter_property WZD_NUM_VID ENABLED false
  }
  
  add_parameter          WZD_NUM_GFX INTEGER 1
  set graphics_number_range "{1:$MAX_GFX}"
  set_parameter_property WZD_NUM_GFX ALLOWED_RANGES $graphics_number_range
  set_parameter_property WZD_NUM_GFX DISPLAY_NAME "number of cores" 
  set_parameter_property WZD_NUM_GFX AFFECTS_ELABORATION true  
  set_parameter_property WZD_NUM_GFX HDL_PARAMETER true
  set_parameter_property WZD_NUM_GFX ENABLED true
  if {$MAX_GFX==1} { 
  set_parameter_property WZD_NUM_GFX ENABLED false
  }

  add_parameter          WZD_MEM_ENABLE_DEBUG INTEGER 1
  set_parameter_property WZD_MEM_ENABLE_DEBUG DISPLAY_NAME "use monitor" 
  set_parameter_property WZD_MEM_ENABLE_DEBUG DISPLAY_HINT boolean
  set_parameter_property WZD_MEM_ENABLE_DEBUG HDL_PARAMETER true



  
  add_parameter          WZD_ENABLE_DEBUG INTEGER 0
  set_parameter_property WZD_ENABLE_DEBUG DISPLAY_NAME "Debug";
  set_parameter_property WZD_ENABLE_DEBUG DISPLAY_HINT boolean
  set_parameter_property WZD_ENABLE_DEBUG DESCRIPTION "Turn on to support debug"
  set_parameter_property WZD_ENABLE_DEBUG VISIBLE true 
  set_parameter_property WZD_ENABLE_DEBUG HDL_PARAMETER true

  add_parameter          WZD_ENABLE_CSR_READBACK_REDUCED INTEGER 0
  set_parameter_property WZD_ENABLE_CSR_READBACK_REDUCED DISPLAY_NAME "Reduced CSR Readback";
  set_parameter_property WZD_ENABLE_CSR_READBACK_REDUCED DISPLAY_HINT boolean
  set_parameter_property WZD_ENABLE_CSR_READBACK_REDUCED DESCRIPTION "Turn on to disable Control-Status Registers Readback and save ressources"
  # not yet released
  set_parameter_property WZD_ENABLE_CSR_READBACK_REDUCED VISIBLE false 
 #set_parameter_property WZD_ENABLE_CSR_READBACK_REDUCED HDL_PARAMETER true

      
  add_display_item "" WZD_ENA_DPY     PARAMETER
  add_display_item "" WZD_ENA_VID     PARAMETER
  add_display_item "" WZD_ENA_GFX     PARAMETER
  add_display_item "" WZD_ENA_DMA     PARAMETER
  add_display_item "" WZD_ENA_AXI_CSR PARAMETER
# add_display_item "" WZD_ENA_AXI_MEM PARAMETER


  add_display_item "" "display"       GROUP tab 
  add_display_item "" "video"         GROUP tab 
  add_display_item "" "graphics"      GROUP tab 
  add_display_item "" "memory"        GROUP tab 
  add_display_item "" "optimizations" GROUP tab
  
  add_display_item "video"         WZD_NUM_VID                     PARAMETER
  add_display_item "graphics"      WZD_NUM_GFX                     PARAMETER
  add_display_item "memory"        WZD_MEM_ENABLE_DEBUG            PARAMETER        
  add_display_item "display"       WZD_NUM_DPY                     PARAMETER
  add_display_item "optimizations" WZD_ENABLE_DEBUG                PARAMETER
  add_display_item "optimizations" WZD_ENABLE_CSR_READBACK_REDUCED PARAMETER

  add_display_item "optimizations" "surfaces" GROUP

  surface_ctrl_add_parameters_opt "surfaces"



# #== asg ===== 
#
# asg_add_parameters WZD_ASG "asg"


  #== display ===== 

  display_add_parameters_core      "" WZD_DPY "display"
  display_add_parameters_video_out "" WZD_DPY "display"
  display_add_parameters_overlay   "" WZD_DPY "display" 1    
# display_add_parameters_sb        "" WZD_DPY "display"


  #== graphics ===== 

  vgr_add_parameters "" WZD_VGR "graphics"


  #== video =====

  # video_add_parameters_core WZD_VSC "vsc"
 
  for {set i 0} {$i<$MAX_VID} {incr i} {
 
    add_display_item "video" "port#$i" GROUP tab 
    
    video_add WZD_VID$i "port#$i" "$i" 
   
  }


  #== memory =====

  vip_mem_add_parameters "WZD" "memory" 
  
 
 
 
proc core_elaboration_callback { } {

  global FUSION_VERSION_MAJOR 
  global FUSION_VERSION_MINOR
# global DPY_VERSION_MAJOR 
# global DPY_VERSION_MINOR
# global VGR_VERSION_MAJOR 
# global VGR_VERSION_MINOR
# global VSC_VERSION_MAJOR 
# global VSC_VERSION_MINOR
# global ASG_VERSION_MAJOR 
# global ASG_VERSION_MINOR
# global TPG_VERSION_MAJOR 
# global TPG_VERSION_MINOR
# global CVI_VERSION_MAJOR 
# global CVI_VERSION_MINOR

  set_parameter_value WZD_VERSION_MAJOR     $FUSION_VERSION_MAJOR 
  set_parameter_value WZD_VERSION_MINOR     $FUSION_VERSION_MINOR 
# set_parameter_value WZD_TPG_VERSION_MAJOR $TPG_VERSION_MAJOR
# set_parameter_value WZD_TPG_VERSION_MINOR $TPG_VERSION_MINOR
# set_parameter_value WZD_CVI_VERSION_MAJOR $CVI_VERSION_MAJOR
# set_parameter_value WZD_CVI_VERSION_MINOR $CVI_VERSION_MINOR
# set_parameter_value WZD_VSC_VERSION_MAJOR $VSC_VERSION_MAJOR
# set_parameter_value WZD_VSC_VERSION_MINOR $VSC_VERSION_MINOR

  vip_elaborate_init


  #== bus protocoles ===== 
  if {[ get_parameter_value WZD_ENA_AXI_CSR] == 1} {
    set_interface_property csr       ENABLED false  
    set_interface_property csr_axi   ENABLED true 
  } else {
    set_interface_property csr       ENABLED true  
    set_interface_property csr_axi   ENABLED false  
  }

#  if {[ get_parameter_value WZD_ENA_AXI_MEM] == 1} {
#    set_interface_property mem32     ENABLED false  
#    set_interface_property mem32_axi ENABLED true      
#  # set_interface_property mem0      ENABLED false      
#  # set_interface_property mem1      ENABLED false      
#  # set_interface_property mem0_axi  ENABLED true      
#  } else {
#    set_interface_property mem32     ENABLED true   
#    set_interface_property mem32_axi ENABLED false     
#  # set_interface_property mem0      ENABLED true      
#  # set_interface_property mem1      ENABLED true      
#  # set_interface_property mem0_axi  ENABLED false      
#  }



  #== sfr ===== 
# sfr_elaborate_interface surface_reader

# #== asg ===== 
# asg_elaborate WZD_ASG $ASG_VERSION_MAJOR $ASG_VERSION_MINOR
# set_display_item_property "asg" VISIBLE false

  #== display ===== 

# display_elaborate_core  WZD_DPY $DPY_VERSION_MAJOR $DPY_VERSION_MINOR  

  display_elaborate_video_out WZD_DPY    

  display_elaborate_interface dpy0    


  #== graphics =====
  
# vgr_elaborate "" WZD_VGR $VGR_VERSION_MAJOR $VGR_VERSION_MINOR  

# # note: "asg2vip" interface defined temporarily into the "vgr_elaborate" (because only used by VGR) 
# if {[ get_parameter_value WZD_ENA_ASG] == 1} {
#   set_interface_property asg2vip ENABLED true  
# } else {
#   set_interface_property asg2vip ENABLED false  
# }

 
  #== video =====
  
# video_elaborate_core WZD_VSC $VSC_VERSION_MAJOR $VSC_VERSION_MINOR 
  set_display_item_property "vsc" VISIBLE false

  global MAX_VID
  set vip_num_vid [ get_parameter_value WZD_NUM_VID ]       
  	   
  for {set i 0} {$i<$MAX_VID} {incr i} {

    if { [ get_parameter_value WZD_ENA_VID ] == 0} {
      set vid_enabled 0
    } elseif { $i<$vip_num_vid } { 
      set vid_enabled 1
    } else {
      set vid_enabled 0
    }        
  
    video_elaborate_interface "vid$i" $vid_enabled WZD_VID$i 
       
  }


  #== memory =====
  
  vip_mem_elaborate  
    

} 

proc core_validation_callback { } {

# vip_valid_general WZD

  #== graphics =====
    
  if {[ get_parameter_value WZD_ENA_GFX] == 1} {
    set_display_item_property "graphics" VISIBLE true  
    vgr_valid "" WZD_VGR
  } else {
    set_display_item_property "graphics" VISIBLE false
  }

  
  #== display ===== 

  global MAX_DPY

  if { [ get_parameter_value WZD_ENA_DPY ] == 0 } { 
    set_display_item_property "display" VISIBLE false
  } else {

    for {set i 0} {$i<$MAX_DPY} {incr i} {
    
      if { $i<[ get_parameter_value WZD_NUM_DPY ] } {  
        set dpy_enabled 1
      } else {      
        set dpy_enabled 0
      }

      # tmp
      set_display_item_property "display" VISIBLE true  
      display_valid "0"  WZD_DPY
      display_valid_core WZD_DPY     	
      
    # vip_valid_sfc_alloc "screen" $i $dpy_enabled 
    # vip_valid_sfc_dma   "layer"  $i $dpy_enabled
    # vip_valid_sfc_dma   "screen" $i $dpy_enabled
           
    }

  # memory section => all displays must be validated to be fully refreshed


  }


  #== video =====

  global MAX_VID

  if { [ get_parameter_value WZD_ENA_VID ] == 0 } { 
    set_display_item_property "video" VISIBLE false
  } else {

    set_display_item_property "video" VISIBLE true  
  	
    for {set i 0} {$i<$MAX_VID} {incr i} {
    
      if { $i<[ get_parameter_value WZD_NUM_VID ] } { 
        set_display_item_property "port#$i" VISIBLE true

        video_valid WZD_VID$i $i

      } else {
        set_display_item_property "port#$i" VISIBLE false
      }     
            
    }
  }

  # memory section => all videos must be validated to be fully refreshed
  for {set i 0} {$i<$MAX_VID} {incr i} {
  
    set video_enabled 1
    if { [ get_parameter_value WZD_ENA_VID ] == 0 } { 
      set video_enabled 0
    } elseif { $i>=[ get_parameter_value WZD_NUM_VID ] } { 
      set video_enabled 0
    }
  
  # vip_valid_sfc_alloc "video" $i $video_enabled  
  # vip_valid_sfc_dma   "video" $i $video_enabled
    
  }





  #== memory =====

  set_display_item_property "memory" VISIBLE true

  vip_mem_valid  
 
}


 