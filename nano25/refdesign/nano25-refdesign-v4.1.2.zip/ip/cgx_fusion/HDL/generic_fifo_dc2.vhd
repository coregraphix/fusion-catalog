
library ieee;
use     ieee.std_logic_1164.all;

library altera_mf;
use     altera_mf.all;


entity generic_fifo_dc2 is
  generic
  (
    G_DPS        : integer := 32;
    G_APS        : integer := 8  
  );
  port
  (     
     wr_clock    : in   std_logic;
     wr_reset_n  : in   std_logic;     
     wr_valid_i  : in   std_logic;
     wr_ready_o  : out  std_logic;
     wr_data_i   : in   std_logic_vector(G_DPS-1 downto 0);
     wr_level_o  : out  std_logic_vector(G_APS downto 0); -- !!! 1 CLK delayed from write port  
     wr_full_o   : out  std_logic; -- sync with write port 
   --wr_empty_o  : out  std_logic; -- !!! delayed rd_empty_o  

     rd_clock    : in   std_logic;
     rd_reset_n  : in   std_logic;     
     rd_ready_i  : in   std_logic;
     rd_valid_o  : out  std_logic;
     rd_data_o   : out  std_logic_vector(G_DPS-1 downto 0);
     rd_level_o  : out  std_logic_vector(G_APS downto 0); -- !!! 1 CLK delayed from read port
   --rd_full_o   : out  std_logic; -- !!! delayed wr_full_o 
     rd_empty_o  : out  std_logic  -- sync with read port
  );
end generic_fifo_dc2;

             
architecture syn of generic_fifo_dc2 is

  component dcfifo
  generic 
  (
    add_usedw_msb_bit      : string;
    intended_device_family : string;
    lpm_numwords           : natural;
    lpm_showahead          : string;
    lpm_type               : string;
    lpm_width              : natural;
    lpm_widthu             : natural;
    overflow_checking      : string;
    rdsync_delaypipe       : natural;
    read_aclr_synch        : string;
    underflow_checking     : string;
    use_eab                : string;
    write_aclr_synch       : string;
    wrsync_delaypipe       : natural
  );
  port 
  (
    aclr    : in  std_logic;
    data    : in  std_logic_vector(G_DPS-1 DOWNTO 0);
    rdclk   : in  std_logic;
    rdreq   : in  std_logic;
    wrclk   : in  std_logic;
    wrreq   : in  std_logic;
    q       : out std_logic_vector(G_DPS-1 DOWNTO 0);
    rdempty : out std_logic;
    rdfull  : out std_logic;
    rdusedw : out std_logic_vector(G_APS DOWNTO 0);
    wrempty : out std_logic;
    wrfull  : out std_logic;
    wrusedw : out std_logic_vector(G_APS DOWNTO 0)
  );
  end component;


  signal aclr     : std_logic ;
  signal rdempty  : std_logic ;
  signal wrfull   : std_logic ;


begin

  rd_empty_o <= rdempty;
  rd_valid_o <= not rdempty;

  wr_ready_o <= not wrfull;
  wr_full_o  <= wrfull;

  aclr <= not wr_reset_n;

  dcfifo_component : dcfifo
  generic map (
    add_usedw_msb_bit      => "ON",
    intended_device_family => "Cyclone V",
    lpm_numwords           => (2**G_APS),
    lpm_showahead          => "ON",
    lpm_type               => "dcfifo",
    lpm_width              => G_DPS,
    lpm_widthu             => G_APS+1,
    overflow_checking      => "ON",
    rdsync_delaypipe       => 5,
    read_aclr_synch        => "ON",
    underflow_checking     => "ON",
    use_eab                => "ON",
    write_aclr_synch       => "ON",
    wrsync_delaypipe       => 5
  )
  port map 
  (
    aclr     => aclr,
    data     => wr_data_i,
    rdclk    => rd_clock,
    rdreq    => rd_ready_i,
    wrclk    => wr_clock,
    wrreq    => wr_valid_i,
    q        => rd_data_o,
    rdempty  => rdempty,
    rdfull   => open , -- rd_full_o,
    rdusedw  => rd_level_o,
    wrempty  => open , -- wr_empty_o
    wrfull   => wrfull,
    wrusedw  => wr_level_o
  );



end syn;

 