
set corename "cgx_fusion"

set_false_path -to   *${corename}*.xo_*    
set_false_path -from *${corename}*.xi_*    
set_false_path -to   *${corename}*.xio_*    
set_false_path -from *${corename}*.xio_*    

set_false_path -to   *${corename}*|xo_*    
set_false_path -from *${corename}*|xi_*    
set_false_path -to   *${corename}*|xio_*    
set_false_path -from *${corename}*|xio_*    

set_false_path -to   *${corename}*:xo_*    
set_false_path -from *${corename}*:xi_*    
set_false_path -to   *${corename}*:xio_*    
set_false_path -from *${corename}*:xio_*    
 

#  proc alt_vip_get_timequest_name {hier_name} {
#  	set sta_name ""
#  	for {set inst_start [string first ":" $hier_name]} {$inst_start != -1} {set inst_start [string first ":" $hier_name $inst_start]} {
#  		incr inst_start
#  		set inst_end [string first "|" $hier_name $inst_start]
#  		if {$inst_end == -1} {
#  			append sta_name [string range $hier_name $inst_start end]
#  		} else {
#  			append sta_name [string range $hier_name $inst_start $inst_end]
#  		}
#  	}
#  	return $sta_name
#  }
#  
#  proc alt_vip_get_core_instance_list {corename} {
#  	set full_instance_list [alt_vip_get_core_full_instance_list $corename]
#  	set instance_list [list]
#  
#  	foreach inst $full_instance_list {
#  		set sta_name [alt_vip_get_timequest_name $inst]
#  		if {[lsearch $instance_list $sta_name] == -1} {
#  			lappend instance_list $sta_name
#  		}
#  	}
#  	return $instance_list
#  }
#  
#  proc alt_vip_get_core_full_instance_list {corename} {
#  	set instance_list [list]
#  
#  	# Look for a keeper (register) name
#  	# Try mem_clk[0] to determine core instances
#  	set search_list [list "*"]
#  	set found 0
#  	for {set i 0} {$found == 0 && $i != [llength $search_list]} {incr i} {
#  		set pattern [lindex $search_list $i]
#  		set instance_collection [get_keepers -nowarn "*|${corename}:*|$pattern"]
#  		if {[get_collection_size $instance_collection] == 0} {
#  			set instance_collection [get_keepers "${corename}:*|$pattern"]
#  		}
#  		if {[get_collection_size $instance_collection] > 0} {
#  			set found 1
#  		}
#  	}
#  	# regexp to extract the full hierarchy path of an instance name
#  	set inst_regexp {(^.*}
#  	append inst_regexp ${corename}
#  	append inst_regexp {:[A-Za-z0-9\.\\_\[\]\-\$()]+)\|}
#  	foreach_in_collection inst $instance_collection {
#  		set name [get_node_info -name $inst]
#  		if {[regexp -- $inst_regexp $name -> hier_name] == 1} {
#  			if {[lsearch $instance_list $hier_name] == -1} {
#  				lappend instance_list $hier_name
#  			}
#  		}
#  	}
#  	return $instance_list
#  }
#  
#  set corename "cgx_fusion_top"
#  set instance_list [alt_vip_get_core_instance_list $corename]
#  
#  foreach inst $instance_list {
#  
#     set_false_path -to   [get_keepers "${inst}|xo_*"]    
#     set_false_path -from [get_keepers "${inst}|xi_*"]    
#     set_false_path -to   [get_keepers "${inst}|xio_*"]    
#     set_false_path -from [get_keepers "${inst}|xio_*"]    
#  
#     set_false_path -to   [get_keepers "${inst}|\*:xo_*"]    
#     set_false_path -from [get_keepers "${inst}|\*:xi_*"]    
#     set_false_path -to   [get_keepers "${inst}|\*:xio_*"]    
#     set_false_path -from [get_keepers "${inst}|\*:xio_*"]    
#   
#     set_false_path -to   [get_keepers "${inst}|*|xo_*"]    
#     set_false_path -from [get_keepers "${inst}|*|xi_*"]    
#     set_false_path -to   [get_keepers "${inst}|*|xio_*"]    
#     set_false_path -from [get_keepers "${inst}|*|xio_*"]    
#   
#     set_false_path -to   [get_keepers "${inst}|*|\*:xo_*"]    
#     set_false_path -from [get_keepers "${inst}|*|\*:xi_*"]    
#     set_false_path -to   [get_keepers "${inst}|*|\*:xio_*"]    
#     set_false_path -from [get_keepers "${inst}|*|\*:xio_*"]    
#  
#  }

 