

 
  global MAX_VID
  global MAX_DPY 
  global MAX_GFX 

  set MAX_VID 2
  set MAX_DPY 1
  set MAX_GFX 1


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- General                                                                                --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Interfaces                                                                                 --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc vip_add_interface { } {

    # +-----------------------------------
    # | connection point clock
    # | 
    add_interface clock clock end
    set_interface_property clock clockRate 0
    
    set_interface_property clock ENABLED true
    
    add_interface_port clock clock_i clk Input 1
    # | 
    # +-----------------------------------
    
    # +-----------------------------------
    # | connection point reset
    # | 
    add_interface reset reset end
    set_interface_property reset associatedClock clock
    set_interface_property reset synchronousEdges DEASSERT
    
    set_interface_property reset ENABLED true
    
    add_interface_port reset reset_n_i reset_n Input 1
    # | 
    # +-----------------------------------
    
    # +-----------------------------------
    # | connection point csr
    # | 
    
    add_interface csr avalon end
    set_interface_property csr addressAlignment DYNAMIC
    set_interface_property csr addressUnits WORDS
    set_interface_property csr associatedClock clock
    set_interface_property csr associatedReset reset
    set_interface_property csr burstOnBurstBoundariesOnly false
    set_interface_property csr explicitAddressSpan 0
    set_interface_property csr holdTime 0
    set_interface_property csr isMemoryDevice false
    set_interface_property csr isNonVolatileStorage false
    set_interface_property csr linewrapBursts false
    set_interface_property csr maximumPendingReadTransactions 0
    set_interface_property csr printableDevice false
    set_interface_property csr readLatency 0
    set_interface_property csr readWaitTime 1
    set_interface_property csr setupTime 0
    set_interface_property csr timingUnits Cycles
    set_interface_property csr writeWaitTime 0
    
    set_interface_property csr ENABLED true
    
    add_interface_port csr csr_avl_readdata_o      readdata      Output 32
    add_interface_port csr csr_avl_writedata_i     writedata     Input  32
    add_interface_port csr csr_avl_address_i       address       Input  13
    add_interface_port csr csr_avl_waitrequest_n_o waitrequest_n Output 1
    add_interface_port csr csr_avl_write_i         write         Input  1
    add_interface_port csr csr_avl_read_i          read          Input  1


    # +-----------------------------------
    # | connection point csr_axi
    # | 
    
    add_interface csr_axi axi4lite end
    set_interface_property csr_axi associatedClock clock
    set_interface_property csr_axi associatedReset reset
    set_interface_property csr_axi readAcceptanceCapability 1
    set_interface_property csr_axi writeAcceptanceCapability 1
    set_interface_property csr_axi combinedAcceptanceCapability 1
    set_interface_property csr_axi readDataReorderingDepth 1
    set_interface_property csr_axi bridgesToMaster ""
    set_interface_property csr_axi ENABLED true
    set_interface_property csr_axi EXPORT_OF ""
    set_interface_property csr_axi PORT_NAME_MAP ""
    set_interface_property csr_axi CMSIS_SVD_VARIABLES ""
    set_interface_property csr_axi SVD_ADDRESS_GROUP ""
 
    set_interface_property csr_axi ENABLED false
 
    add_interface_port csr_axi csr_axi_awaddr_i  awaddr  Input 15
    add_interface_port csr_axi csr_axi_awvalid_i awvalid Input 1
    add_interface_port csr_axi csr_axi_awready_o awready Output 1
    add_interface_port csr_axi csr_axi_awprot_i  awprot  Input 3
    add_interface_port csr_axi csr_axi_wdata_i   wdata   Input 32
    add_interface_port csr_axi csr_axi_wstrb_i   wstrb   Input 4
    add_interface_port csr_axi csr_axi_wvalid_i  wvalid  Input 1
    add_interface_port csr_axi csr_axi_wready_o  wready  Output 1
    add_interface_port csr_axi csr_axi_bvalid_o  bvalid  Output 1
    add_interface_port csr_axi csr_axi_bready_i  bready  Input 1
    add_interface_port csr_axi csr_axi_bresp_o   bresp   Output 2
    add_interface_port csr_axi csr_axi_araddr_i  araddr  Input 15
    add_interface_port csr_axi csr_axi_arvalid_i arvalid Input 1
    add_interface_port csr_axi csr_axi_arready_o arready Output 1
    add_interface_port csr_axi csr_axi_arprot_i  arprot  Input 3
    add_interface_port csr_axi csr_axi_rdata_o   rdata   Output 32
    add_interface_port csr_axi csr_axi_rvalid_o  rvalid  Output 1
    add_interface_port csr_axi csr_axi_rready_i  rready  Input 1
    add_interface_port csr_axi csr_axi_rresp_o   rresp   Output 2

        
 #  # +-----------------------------------
 #  # connection point csr_irq
 #  # 
 #  add_interface csr_irq interrupt end
 #  set_interface_property csr_irq associatedAddressablePoint csr
 #  set_interface_property csr_irq associatedClock clock
 #  set_interface_property csr_irq associatedReset reset 
 #  set_interface_property csr_irq ENABLED true
 #  
 #  add_interface_port csr_irq csr_irq irq Output 1
    

    # +-----------------------------------
    # | connection point memcpu_clock
    # | 
    add_interface memcpu_clock clock end
    set_interface_property memcpu_clock clockRate 0
    
    set_interface_property memcpu_clock ENABLED true
    
    add_interface_port memcpu_clock memcpu_clock_i clk Input 1
    # | 
    # +-----------------------------------
        
    # +-----------------------------------
    # | connection point memcpu
    # | 
    add_interface memcpu avalon start
    set_interface_property memcpu addressUnits SYMBOLS
    set_interface_property memcpu burstOnBurstBoundariesOnly false
    set_interface_property memcpu linewrapBursts false
    set_interface_property memcpu associatedClock memcpu_clock
    set_interface_property memcpu associatedReset reset
    
    set_interface_property memcpu ENABLED true
    
    add_interface_port memcpu memcpu_avl_address_o       address       Output -1
    add_interface_port memcpu memcpu_avl_readdata_i      readdata      Input  64
    add_interface_port memcpu memcpu_avl_read_o          read          Output 1
    add_interface_port memcpu memcpu_avl_readdatavalid_i readdatavalid Input  1
    add_interface_port memcpu memcpu_avl_waitrequest_i   waitrequest   Input  1
    add_interface_port memcpu memcpu_avl_burstcount_o    burstcount    Output 6
    add_interface_port memcpu memcpu_avl_write_o         write         Output 1
    add_interface_port memcpu memcpu_avl_writedata_o     writedata     Output 64
    add_interface_port memcpu memcpu_avl_byteenable_o    byteenable    Output 8
    # | 
    # +-----------------------------------

    # +-----------------------------------
    # | connection point memcpu_axi
    # | 
    add_interface memcpu_axi axi4 start
    set_interface_property memcpu_axi associatedClock clock
    set_interface_property memcpu_axi associatedReset reset
    set_interface_property memcpu_axi readIssuingCapability 8
    set_interface_property memcpu_axi writeIssuingCapability 8
    set_interface_property memcpu_axi combinedIssuingCapability 8
    set_interface_property memcpu_axi ENABLED true
    set_interface_property memcpu_axi EXPORT_OF ""
    set_interface_property memcpu_axi PORT_NAME_MAP ""
    set_interface_property memcpu_axi CMSIS_SVD_VARIABLES ""
    set_interface_property memcpu_axi SVD_ADDRESS_GROUP ""
    
    add_interface_port memcpu_axi memcpu_axi_awid_o    awid    Output 4
    add_interface_port memcpu_axi memcpu_axi_awaddr_o  awaddr  Output -1
    add_interface_port memcpu_axi memcpu_axi_awlen_o   awlen   Output 8
    add_interface_port memcpu_axi memcpu_axi_awprot_o  awprot  Output 3
    add_interface_port memcpu_axi memcpu_axi_awvalid_o awvalid Output 1
    add_interface_port memcpu_axi memcpu_axi_awready_i awready Input  1
    add_interface_port memcpu_axi memcpu_axi_wdata_o   wdata   Output 64
    add_interface_port memcpu_axi memcpu_axi_wstrb_o   wstrb   Output 8
    add_interface_port memcpu_axi memcpu_axi_wlast_o   wlast   Output 1
    add_interface_port memcpu_axi memcpu_axi_wvalid_o  wvalid  Output 1
    add_interface_port memcpu_axi memcpu_axi_wready_i  wready  Input  1
    add_interface_port memcpu_axi memcpu_axi_bid_i     bid     Input  4
    add_interface_port memcpu_axi memcpu_axi_bvalid_i  bvalid  Input  1
    add_interface_port memcpu_axi memcpu_axi_bready_o  bready  Output 1
    add_interface_port memcpu_axi memcpu_axi_arid_o    arid    Output 4
    add_interface_port memcpu_axi memcpu_axi_araddr_o  araddr  Output -1
    add_interface_port memcpu_axi memcpu_axi_arlen_o   arlen   Output 8
    add_interface_port memcpu_axi memcpu_axi_arprot_o  arprot  Output 3
    add_interface_port memcpu_axi memcpu_axi_arvalid_o arvalid Output 1
    add_interface_port memcpu_axi memcpu_axi_arready_i arready Input  1
    add_interface_port memcpu_axi memcpu_axi_rid_i     rid     Input  4
    add_interface_port memcpu_axi memcpu_axi_rdata_i   rdata   Input  64
    add_interface_port memcpu_axi memcpu_axi_rvalid_i  rvalid  Input  1
    add_interface_port memcpu_axi memcpu_axi_rready_o  rready  Output 1
    add_interface_port memcpu_axi memcpu_axi_rlast_i   rlast   Input  1
    

    vip_add_interface_mem_gpu "memgpu"


    
  }


  proc vip_add_interface_mem_gpu { if_name } {


    # +-----------------------------------
    # | connection point ${if_name}_clock
    # | 
    
    add_interface          ${if_name}_clock clock end
    set_interface_property ${if_name}_clock clockRate 0  
    set_interface_property ${if_name}_clock ENABLED true
    
    add_interface_port ${if_name}_clock ${if_name}_clock_i clk Input 1
    
    # | 
    # +-----------------------------------
    
  
    # +-----------------------------------
    # | connection point ${if_name}
    # | 
    
    add_interface          ${if_name} avalon start
    set_interface_property ${if_name} addressUnits SYMBOLS
#   set_interface_property ${if_name} associatedClock ${if_name}_rd_clock
    set_interface_property ${if_name} associatedClock ${if_name}_clock
    set_interface_property ${if_name} associatedReset reset
    set_interface_property ${if_name} burstOnBurstBoundariesOnly false
    set_interface_property ${if_name} doStreamReads false
    set_interface_property ${if_name} doStreamWrites false
    set_interface_property ${if_name} linewrapBursts false
    set_interface_property ${if_name} readLatency 0
    set_interface_property ${if_name} ENABLED true
    
    add_interface_port ${if_name} ${if_name}_avl_address_o       address       Output -1
    add_interface_port ${if_name} ${if_name}_avl_readdata_i      readdata      Input -1
    add_interface_port ${if_name} ${if_name}_avl_writedata_o     writedata     Output -1
    add_interface_port ${if_name} ${if_name}_avl_read_o          read          Output 1
    add_interface_port ${if_name} ${if_name}_avl_write_o         write         Output  1
    add_interface_port ${if_name} ${if_name}_avl_readdatavalid_i readdatavalid Input 1
    add_interface_port ${if_name} ${if_name}_avl_byteenable_o    byteenable    Output -1
    add_interface_port ${if_name} ${if_name}_avl_waitrequest_i   waitrequest   Input 1
    add_interface_port ${if_name} ${if_name}_avl_burstcount_o    burstcount    Output -1


    # +-----------------------------------
    # | connection point ${if_name}_axi
    # | 
    add_interface ${if_name}_axi axi4 start
    set_interface_property ${if_name}_axi associatedClock ${if_name}_clock
    set_interface_property ${if_name}_axi associatedReset reset
    set_interface_property ${if_name}_axi readIssuingCapability 8
    set_interface_property ${if_name}_axi writeIssuingCapability 8
    set_interface_property ${if_name}_axi combinedIssuingCapability 8
    set_interface_property ${if_name}_axi ENABLED true
    set_interface_property ${if_name}_axi EXPORT_OF ""
    set_interface_property ${if_name}_axi PORT_NAME_MAP ""
    set_interface_property ${if_name}_axi CMSIS_SVD_VARIABLES ""
    set_interface_property ${if_name}_axi SVD_ADDRESS_GROUP ""

    add_interface_port ${if_name}_axi ${if_name}_axi_awid_o    awid    Output 4
    add_interface_port ${if_name}_axi ${if_name}_axi_awqos_o   awqos   Output 4
    add_interface_port ${if_name}_axi ${if_name}_axi_awaddr_o  awaddr  Output -1
    add_interface_port ${if_name}_axi ${if_name}_axi_awlen_o   awlen   Output 8
    add_interface_port ${if_name}_axi ${if_name}_axi_awprot_o  awprot  Output 3
    add_interface_port ${if_name}_axi ${if_name}_axi_awvalid_o awvalid Output 1
    add_interface_port ${if_name}_axi ${if_name}_axi_awready_i awready Input  1
    add_interface_port ${if_name}_axi ${if_name}_axi_wdata_o   wdata   Output -1
    add_interface_port ${if_name}_axi ${if_name}_axi_wstrb_o   wstrb   Output -1
    add_interface_port ${if_name}_axi ${if_name}_axi_wlast_o   wlast   Output 1
    add_interface_port ${if_name}_axi ${if_name}_axi_wvalid_o  wvalid  Output 1
    add_interface_port ${if_name}_axi ${if_name}_axi_wready_i  wready  Input  1
    add_interface_port ${if_name}_axi ${if_name}_axi_bid_i     bid     Input  4
    add_interface_port ${if_name}_axi ${if_name}_axi_bvalid_i  bvalid  Input  1
    add_interface_port ${if_name}_axi ${if_name}_axi_bready_o  bready  Output 1
    add_interface_port ${if_name}_axi ${if_name}_axi_arid_o    arid    Output 4
    add_interface_port ${if_name}_axi ${if_name}_axi_arqos_o   arqos   Output 4
    add_interface_port ${if_name}_axi ${if_name}_axi_araddr_o  araddr  Output -1
    add_interface_port ${if_name}_axi ${if_name}_axi_arlen_o   arlen   Output 8
    add_interface_port ${if_name}_axi ${if_name}_axi_arprot_o  arprot  Output 3
    add_interface_port ${if_name}_axi ${if_name}_axi_arvalid_o arvalid Output 1
    add_interface_port ${if_name}_axi ${if_name}_axi_arready_i arready Input  1
    add_interface_port ${if_name}_axi ${if_name}_axi_rid_i     rid     Input  4
    add_interface_port ${if_name}_axi ${if_name}_axi_rdata_i   rdata   Input  -1
    add_interface_port ${if_name}_axi ${if_name}_axi_rvalid_i  rvalid  Input  1
    add_interface_port ${if_name}_axi ${if_name}_axi_rready_o  rready  Output 1
    add_interface_port ${if_name}_axi ${if_name}_axi_rlast_i   rlast   Input  1

    # | 
    # +-----------------------------------

         
  }


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Memory                                                                                     --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc vip_mem_add_parameters {ctrl_name inst_gui_name} {

    add_display_item $inst_gui_name "port-cpu" GROUP tab 
    add_display_item $inst_gui_name "port-gpu" GROUP tab 
    
    set param_name "MEMCPU"
    set param_name ${ctrl_name}_${param_name} 
    vip_memcpu_add_parameters ${param_name} "port-cpu" "memcpu"
    
    set param_name "MEMGPU"
    set param_name ${ctrl_name}_${param_name} 
    vip_memgpu_add_parameters ${param_name} "port-gpu" "memgpu"

  }


# proc vip_mem_add_parameters_sfc_alloc {sfc_class sfc_idx inst_gui_name } {
# 
#   set sfc_name ${sfc_class}${sfc_idx} 
#   set param_name "sfc_${sfc_name}" 
#
#   set MEM_ALLOCATED ${param_name}_MEM_ALLOCATED
#   set MEM_BASE8     ${param_name}_MEM_BASE8
#   set MEM_SIZE8     ${param_name}_MEM_SIZE8
#   set MEM_END8      ${param_name}_MEM_END8 
#
#   add_parameter          $MEM_ALLOCATED INTEGER 0; # runtime alloc
#   set_parameter_property $MEM_ALLOCATED DISPLAY_HINT boolean
#   set_parameter_property $MEM_ALLOCATED DISPLAY_NAME "${sfc_name} static alloc" 
#   set_parameter_property $MEM_ALLOCATED DESCRIPTION "Turn off for runtime allocation, Turn on to set static allocation"
#   set_parameter_property $MEM_ALLOCATED AFFECTS_ELABORATION true  
#   set_parameter_property $MEM_ALLOCATED HDL_PARAMETER true
# 
#   add_parameter          $MEM_BASE8 INTEGER 0x0
#   set_parameter_property $MEM_BASE8 DISPLAY_NAME "${sfc_name} Base" 
#   set_parameter_property $MEM_BASE8 DISPLAY_HINT hexadecimal
#   set_parameter_property $MEM_BASE8 DISPLAY_UNITS "Bytes"
#   set_parameter_property $MEM_BASE8 AFFECTS_ELABORATION true        
#   set_parameter_property $MEM_BASE8 HDL_PARAMETER true
#   
#   add_parameter          $MEM_SIZE8 INTEGER 0x0
#   set_parameter_property $MEM_SIZE8 DISPLAY_NAME "${sfc_name} Size" 
#   set_parameter_property $MEM_SIZE8 DISPLAY_HINT hexadecimal
#   set_parameter_property $MEM_SIZE8 DISPLAY_UNITS "Bytes"
#   set_parameter_property $MEM_SIZE8 AFFECTS_ELABORATION true        
#   set_parameter_property $MEM_SIZE8 HDL_PARAMETER true
#   set_parameter_property $MEM_SIZE8 DERIVED true
#
#   add_parameter          $MEM_END8 INTEGER 0x0
#   set_parameter_property $MEM_END8 DISPLAY_NAME "${sfc_name} End" 
#   set_parameter_property $MEM_END8 DISPLAY_HINT hexadecimal
#   set_parameter_property $MEM_END8 DISPLAY_UNITS "Bytes"
#   set_parameter_property $MEM_END8 AFFECTS_ELABORATION true        
#   set_parameter_property $MEM_END8 HDL_PARAMETER true
#   set_parameter_property $MEM_END8 DERIVED true
# 
#   add_display_item $inst_gui_name $MEM_ALLOCATED PARAMETER
#   add_display_item $inst_gui_name $MEM_BASE8     PARAMETER
#   add_display_item $inst_gui_name $MEM_SIZE8     PARAMETER
#   add_display_item $inst_gui_name $MEM_END8      PARAMETER
#
# }


# proc vip_valid_sfc_dma {sfc_class sfc_idx sfc_enabled } {
#
#   set sfc_name ${sfc_class}${sfc_idx} 
#   set param_name "sfc_${sfc_name}" 
#
#   set MEM_IDX ${param_name}_MEM_IDX  
#
#   if {$sfc_enabled == 0} {  
#     set_parameter_property $MEM_IDX       VISIBLE false  
#   } else {
#
#     set_parameter_property $MEM_IDX       VISIBLE true  
#
#     if { [ get_parameter_value $MEM_IDX ] > [ get_parameter_value WZD_NUM_MEM ] } {  
#       send_message error "DMA#[ get_parameter_value $MEM_IDX ] is not active. Please turn it On."
#     }
#   }
# }
#
#
#  proc vip_valid_sfc_alloc {sfc_class sfc_idx sfc_enabled } {
#  
#    set sfc_name ${sfc_class}${sfc_idx} 
#    set param_name "sfc_${sfc_name}" 
#
#    set MEM_ALLOCATED ${param_name}_MEM_ALLOCATED
#    set MEM_BASE8     ${param_name}_MEM_BASE8
#    set MEM_SIZE8     ${param_name}_MEM_SIZE8
#    set MEM_END8      ${param_name}_MEM_END8 
#
#    set sfc_size8 $::imt_surface::surface_pool($sfc_class,$sfc_idx,size8) 
#
#    # if device has not set the surface size, it is assumed that the device is disabled
#    if {$sfc_enabled ==0 || $sfc_size8 == 0} {  
#
#      set_parameter_property $MEM_ALLOCATED VISIBLE false  
#      set_parameter_property $MEM_BASE8     VISIBLE false  
#      set_parameter_property $MEM_SIZE8     VISIBLE false  
#      set_parameter_property $MEM_END8      VISIBLE false  
#
#    } else {
#
#      set_parameter_property $MEM_ALLOCATED VISIBLE true  
#      set_parameter_property $MEM_SIZE8     VISIBLE true  
#
#      # runtime alloc. base and end are unknown
#      if { [ get_parameter_value $MEM_ALLOCATED ] == 0} {  
#        set_parameter_property $MEM_BASE8 VISIBLE false  
#        set_parameter_property $MEM_END8  VISIBLE false 
#        set_parameter_value    $MEM_END8  0x0
#      } else {
#        set_parameter_property $MEM_BASE8 VISIBLE true  
#        set_parameter_property $MEM_END8  VISIBLE true  
#        set_parameter_value    $MEM_END8  [ expr [ get_parameter_value $MEM_BASE8 ] + [ get_parameter_value $MEM_SIZE8 ] ] 
#      }
#
#      set_parameter_value $MEM_SIZE8 $sfc_size8
#
#    }    
# 
#  }


  proc vip_memcpu_add_parameters {param_name inst_gui_name if_name} {
  
    set ENA_AXI             ${param_name}_ENA_AXI
    set HAS_DEDICATED_CLK   ${param_name}_HAS_DEDICATED_CLK
  # set DATA_WIDTH          ${param_name}_DATA_WIDTH
    set ADDR8_SIZE          ${param_name}_ADDR8_SIZE
  # set FIFODEPTH           ${param_name}_FIFODEPTH
#   set BURSTLENGTH         ${param_name}_BURSTLENGTH
  # set FIFODEPTH_LOG2      ${param_name}_FIFODEPTH_LOG2
#   set BURSTLENGTH_LOG2    ${param_name}_BURSTLENGTH_LOG2

    add_parameter          $ENA_AXI  INTEGER             0
    set_parameter_property $ENA_AXI  DISPLAY_NAME        "Use AXI (instead of Avalon)" 
    set_parameter_property $ENA_AXI  DISPLAY_HINT        boolean 
    set_parameter_property $ENA_AXI  AFFECTS_ELABORATION true        
    set_parameter_property $ENA_AXI  HDL_PARAMETER       true
  
    add_parameter          $HAS_DEDICATED_CLK  INTEGER             1
    set_parameter_property $HAS_DEDICATED_CLK  DISPLAY_NAME        "Dedicated clock domain" 
    set_parameter_property $HAS_DEDICATED_CLK  DISPLAY_HINT        boolean 
    set_parameter_property $HAS_DEDICATED_CLK  AFFECTS_ELABORATION true        
    set_parameter_property $HAS_DEDICATED_CLK  HDL_PARAMETER       true
  
  # add_parameter          $DATA_WIDTH INTEGER             64
  # set_parameter_property $DATA_WIDTH DISPLAY_NAME        "Data width" 
  # set_parameter_property $DATA_WIDTH ALLOWED_RANGES      {"32" "64" "128" "256" "512" "1024"}  
  # set_parameter_property $DATA_WIDTH AFFECTS_ELABORATION true        
  # set_parameter_property $DATA_WIDTH HDL_PARAMETER true
    
    add_parameter          $ADDR8_SIZE INTEGER             30
    set_parameter_property $ADDR8_SIZE DISPLAY_NAME        "Address width" 
    set_parameter_property $ADDR8_SIZE ALLOWED_RANGES      {1:64} 
    set_parameter_property $ADDR8_SIZE AFFECTS_ELABORATION true        
    set_parameter_property $ADDR8_SIZE HDL_PARAMETER true
    
#   add_parameter          $FIFODEPTH INTEGER             256
#   set_parameter_property $FIFODEPTH DISPLAY_NAME        "Fifo depth" 
#                                                         # !!! do not decrease depth min (=32) due to dcfifo margin
#   set_parameter_property $FIFODEPTH ALLOWED_RANGES      {"32" "64" "128" "256" "512" "1024" "2048" "4096"}
#   set_parameter_property $FIFODEPTH AFFECTS_ELABORATION true        
# # set_parameter_property $FIFODEPTH HDL_PARAMETER true
        
#   add_parameter          $BURSTLENGTH INTEGER           64
#   set_parameter_property $BURSTLENGTH DISPLAY_NAME      "Maximum burst length" 
#   set_parameter_property $BURSTLENGTH ALLOWED_RANGES    {"2" "4" "8" "16" "32" "64" "128" "256" "512" "1024"}
#   set_parameter_property $BURSTLENGTH AFFECTS_ELABORATION true        
# # set_parameter_property $BURSTLENGTH HDL_PARAMETER true
  
#   add_parameter          $FIFODEPTH_LOG2 INTEGER        1
#   set_parameter_property $FIFODEPTH_LOG2 DISPLAY_NAME   "Fifo depth (log2)" 
#   set_parameter_property $FIFODEPTH_LOG2 DERIVED true   
#   set_parameter_property $FIFODEPTH_LOG2 HDL_PARAMETER true
#   set_parameter_property $FIFODEPTH_LOG2 VISIBLE false
        
#   add_parameter          $BURSTLENGTH_LOG2 INTEGER      1
#   set_parameter_property $BURSTLENGTH_LOG2 DISPLAY_NAME "Maximum burst length (log2)" 
#   set_parameter_property $BURSTLENGTH_LOG2 DERIVED      true        
#   set_parameter_property $BURSTLENGTH_LOG2 HDL_PARAMETER true
#   set_parameter_property $BURSTLENGTH_LOG2 VISIBLE false

    add_display_item $inst_gui_name $ENA_AXI            PARAMETER
    add_display_item $inst_gui_name $HAS_DEDICATED_CLK  PARAMETER
#   add_display_item $inst_gui_name $DATA_WIDTH         PARAMETER
    add_display_item $inst_gui_name $ADDR8_SIZE         PARAMETER
#   add_display_item $inst_gui_name $FIFODEPTH          PARAMETER
#   add_display_item $inst_gui_name $FIFODEPTH_LOG2     PARAMETER
#   add_display_item $inst_gui_name $BURSTLENGTH        PARAMETER
#   add_display_item $inst_gui_name $BURSTLENGTH_LOG2   PARAMETER

  }


  proc vip_memgpu_add_parameters { param_name inst_gui_name if_name } {
  
    set ENA_AXI             ${param_name}_ENA_AXI
    set HAS_DEDICATED_CLK   ${param_name}_HAS_DEDICATED_CLK
    set DATA_WIDTH          ${param_name}_DATA_WIDTH
    set ADDR8_SIZE          ${param_name}_ADDR8_SIZE
    set FIFODEPTH           ${param_name}_FIFODEPTH
    set BURSTLENGTH         ${param_name}_BURSTLENGTH
    set FIFODEPTH_LOG2      ${param_name}_FIFODEPTH_LOG2
    set BURSTLENGTH_LOG2    ${param_name}_BURSTLENGTH_LOG2
  # set CLOCK_RATE          ${param_name}_CLOCK_RATE

    add_parameter          $ENA_AXI  INTEGER             0
    set_parameter_property $ENA_AXI  DISPLAY_NAME        "Use AXI (instead of Avalon)" 
    set_parameter_property $ENA_AXI  DISPLAY_HINT        boolean 
    set_parameter_property $ENA_AXI  AFFECTS_ELABORATION true        
    set_parameter_property $ENA_AXI  HDL_PARAMETER       true
  
    add_parameter          $HAS_DEDICATED_CLK  INTEGER             1
    set_parameter_property $HAS_DEDICATED_CLK  DISPLAY_NAME        "Dedicated clock domain" 
    set_parameter_property $HAS_DEDICATED_CLK  DISPLAY_HINT        boolean 
    set_parameter_property $HAS_DEDICATED_CLK  AFFECTS_ELABORATION true        
    set_parameter_property $HAS_DEDICATED_CLK  HDL_PARAMETER       true
  
    add_parameter          $DATA_WIDTH INTEGER             32
    set_parameter_property $DATA_WIDTH DISPLAY_NAME        "Data width" 
    set_parameter_property $DATA_WIDTH ALLOWED_RANGES      {"32" "64" "128" "256" "512" "1024"}  
    set_parameter_property $DATA_WIDTH AFFECTS_ELABORATION true        
    set_parameter_property $DATA_WIDTH HDL_PARAMETER true
    
    add_parameter          $ADDR8_SIZE INTEGER             30
    set_parameter_property $ADDR8_SIZE DISPLAY_NAME        "Address width" 
    set_parameter_property $ADDR8_SIZE ALLOWED_RANGES      {1:64} 
    set_parameter_property $ADDR8_SIZE AFFECTS_ELABORATION true        
    set_parameter_property $ADDR8_SIZE HDL_PARAMETER true
    
    add_parameter          $FIFODEPTH INTEGER             256
    set_parameter_property $FIFODEPTH DISPLAY_NAME        "Fifo depth" 
                                                          # !!! do not decrease depth min (=32) due to dcfifo margin
    set_parameter_property $FIFODEPTH ALLOWED_RANGES      {"32" "64" "128" "256" "512" "1024" "2048" "4096"}
    set_parameter_property $FIFODEPTH AFFECTS_ELABORATION true        
  # set_parameter_property $FIFODEPTH HDL_PARAMETER true
        
    add_parameter          $BURSTLENGTH INTEGER           64
    set_parameter_property $BURSTLENGTH DISPLAY_NAME      "Maximum burst length" 
    set_parameter_property $BURSTLENGTH ALLOWED_RANGES    {"2" "4" "8" "16" "32" "64" "128" "256" "512" "1024"}
    set_parameter_property $BURSTLENGTH AFFECTS_ELABORATION true        
  # set_parameter_property $BURSTLENGTH HDL_PARAMETER true
  
    add_parameter          $FIFODEPTH_LOG2 INTEGER        1
    set_parameter_property $FIFODEPTH_LOG2 DISPLAY_NAME   "Fifo depth (log2)" 
    set_parameter_property $FIFODEPTH_LOG2 DERIVED true   
    set_parameter_property $FIFODEPTH_LOG2 HDL_PARAMETER true
    set_parameter_property $FIFODEPTH_LOG2 VISIBLE false
        
    add_parameter          $BURSTLENGTH_LOG2 INTEGER      1
    set_parameter_property $BURSTLENGTH_LOG2 DISPLAY_NAME "Maximum burst length (log2)" 
    set_parameter_property $BURSTLENGTH_LOG2 DERIVED      true        
    set_parameter_property $BURSTLENGTH_LOG2 HDL_PARAMETER true
    set_parameter_property $BURSTLENGTH_LOG2 VISIBLE false

  # add_parameter          $CLOCK_RATE INTEGER
  # set_parameter_property $CLOCK_RATE DISPLAY_NAME "clock rate" 
  # set_parameter_property $CLOCK_RATE system_info {CLOCK_RATE ${if_name}_clock}
  # set_parameter_property $CLOCK_RATE HDL_PARAMETER true
  # set_parameter_property $CLOCK_RATE VISIBLE true
  
    add_display_item $inst_gui_name $ENA_AXI            PARAMETER
    add_display_item $inst_gui_name $HAS_DEDICATED_CLK  PARAMETER
    add_display_item $inst_gui_name $DATA_WIDTH         PARAMETER
    add_display_item $inst_gui_name $ADDR8_SIZE         PARAMETER
    add_display_item $inst_gui_name $FIFODEPTH          PARAMETER
    add_display_item $inst_gui_name $FIFODEPTH_LOG2     PARAMETER
    add_display_item $inst_gui_name $BURSTLENGTH        PARAMETER
    add_display_item $inst_gui_name $BURSTLENGTH_LOG2   PARAMETER
  # add_display_item $inst_gui_name $CLOCK_RATE         PARAMETER

  }


  proc vip_memcpu_elaborate { if_name param_name } {
 
    set ENA_AXI             ${param_name}_ENA_AXI
    set HAS_DEDICATED_CLK   ${param_name}_HAS_DEDICATED_CLK
#   set DATA_WIDTH          ${param_name}_DATA_WIDTH
    set ADDR8_SIZE          ${param_name}_ADDR8_SIZE
#   set FIFODEPTH           ${param_name}_FIFODEPTH
#   set BURSTLENGTH         ${param_name}_BURSTLENGTH
#   set FIFODEPTH_LOG2      ${param_name}_FIFODEPTH_LOG2
#   set BURSTLENGTH_LOG2    ${param_name}_BURSTLENGTH_LOG2
 
    set_port_property ${if_name}_avl_address_o  WIDTH_EXPR [ get_parameter_value $ADDR8_SIZE ]
    set_port_property ${if_name}_axi_awaddr_o   WIDTH_EXPR [ get_parameter_value $ADDR8_SIZE ]
    set_port_property ${if_name}_axi_araddr_o   WIDTH_EXPR [ get_parameter_value $ADDR8_SIZE ]
 
    if {[ get_parameter_value $HAS_DEDICATED_CLK ] == 1} {  
      set_interface_property ${if_name}_clock ENABLED true  
      set_interface_property ${if_name}     associatedClock ${if_name}_clock
      set_interface_property ${if_name}_axi associatedClock ${if_name}_clock
    } else {
      set_interface_property ${if_name}_clock ENABLED false  
      set_interface_property ${if_name}     associatedClock clock
      set_interface_property ${if_name}_axi associatedClock clock
    }    

    if {[ get_parameter_value $ENA_AXI] == 1} {
      set_interface_property ${if_name}     ENABLED false  
      set_interface_property ${if_name}_axi ENABLED true      
    } else {
      set_interface_property ${if_name}     ENABLED true   
      set_interface_property ${if_name}_axi ENABLED false     
    }

  }  


  proc vip_memgpu_elaborate { if_name if_enabled param_name } {
 
    set ENA_AXI             ${param_name}_ENA_AXI
    set HAS_DEDICATED_CLK   ${param_name}_HAS_DEDICATED_CLK
    set DATA_WIDTH          ${param_name}_DATA_WIDTH
    set ADDR8_SIZE          ${param_name}_ADDR8_SIZE
    set FIFODEPTH           ${param_name}_FIFODEPTH
    set BURSTLENGTH         ${param_name}_BURSTLENGTH
    set FIFODEPTH_LOG2      ${param_name}_FIFODEPTH_LOG2
    set BURSTLENGTH_LOG2    ${param_name}_BURSTLENGTH_LOG2
 
    set_port_property ${if_name}_avl_address_o     WIDTH_EXPR [ get_parameter_value $ADDR8_SIZE ]  
    set_port_property ${if_name}_avl_readdata_i    WIDTH_EXPR [ get_parameter_value $DATA_WIDTH ]    
    set_port_property ${if_name}_avl_writedata_o   WIDTH_EXPR [ get_parameter_value $DATA_WIDTH ]
    set_port_property ${if_name}_avl_byteenable_o  WIDTH_EXPR [ expr [ get_parameter_value $DATA_WIDTH ] / 8 ]
 
    # avalon: max burst size = 2 EXP (burstcount - 1) 
    set_port_property ${if_name}_avl_burstcount_o  WIDTH_EXPR [ expr ( [ get_parameter_value $BURSTLENGTH_LOG2 ] + 1 ) ]


    # AXI    
    set_port_property ${if_name}_axi_awaddr_o  WIDTH_EXPR [ get_parameter_value $ADDR8_SIZE ]  
    set_port_property ${if_name}_axi_araddr_o  WIDTH_EXPR [ get_parameter_value $ADDR8_SIZE ]  
    set_port_property ${if_name}_axi_rdata_i   WIDTH_EXPR [ get_parameter_value $DATA_WIDTH ]    
    set_port_property ${if_name}_axi_wdata_o   WIDTH_EXPR [ get_parameter_value $DATA_WIDTH ]
    set_port_property ${if_name}_axi_wstrb_o   WIDTH_EXPR [ expr [ get_parameter_value $DATA_WIDTH ] / 8 ]    
  # set_port_property ${if_name}_axi_awlen_o   WIDTH_EXPR [ get_parameter_value $BURSTLENGTH_LOG2 ]
  # set_port_property ${if_name}_axi_arlen_o   WIDTH_EXPR [ get_parameter_value $BURSTLENGTH_LOG2 ]
         

    if {$if_enabled == 0} {
      set_interface_property ${if_name}          ENABLED false  
      set_interface_property ${if_name}_axi      ENABLED false  
    } elseif {[ get_parameter_value $ENA_AXI] == 1} {  
      set_interface_property ${if_name}          ENABLED false  
      set_interface_property ${if_name}_axi      ENABLED true  
    } else {
      set_interface_property ${if_name}          ENABLED true  
      set_interface_property ${if_name}_axi      ENABLED false  
    }    

    if {$if_enabled == 0} {
      set_interface_property ${if_name}_clock    ENABLED false  
    } elseif {[ get_parameter_value $HAS_DEDICATED_CLK ] == 1} {  
      set_interface_property ${if_name}_clock    ENABLED true  
      set_interface_property ${if_name}     associatedClock ${if_name}_clock;                       
      set_interface_property ${if_name}_axi associatedClock ${if_name}_clock;                       
    } else {
      set_interface_property ${if_name}_clock    ENABLED false  
      set_interface_property ${if_name}     associatedClock clock
      set_interface_property ${if_name}_axi associatedClock clock
    }    

  }  

  # clear all primary surfaces
  proc vip_elaborate_init {  } {

    global MAX_DPY
    for {set i 0} {$i<$MAX_DPY} {incr i} {        
      surface_pool_add "screen" $i "" 0 
    }

    global MAX_VID
    for {set i 0} {$i<$MAX_VID} {incr i} {
      surface_pool_add "video" $i "" 0 
    }

  }  


  proc vip_mem_elaborate { } {
 
    vip_memcpu_elaborate "memcpu" "WZD_MEMCPU"
    vip_memgpu_elaborate "memgpu" 1 "WZD_MEMGPU"
         
  }  


  proc vip_mem_valid { } {

    vip_memcpu_valid "WZD_MEMCPU"
    vip_memgpu_valid "WZD_MEMGPU"

  }


  proc vip_memcpu_valid { ctrl_name } {
  # TODO
  }


  proc vip_memgpu_valid { param_name } {
               
   # set DATA_WIDTH            ${param_name}_DATA_WIDTH
   # set ADDR8_SIZE            ${param_name}_ADDR8_SIZE
     set FIFODEPTH             ${param_name}_FIFODEPTH
     set BURSTLENGTH           ${param_name}_BURSTLENGTH
     set FIFODEPTH_LOG2        ${param_name}_FIFODEPTH_LOG2
     set BURSTLENGTH_LOG2      ${param_name}_BURSTLENGTH_LOG2
 
     set min_burstlength [ expr int( 2 * [ get_parameter_value $BURSTLENGTH ] ) ]
     
     if { [get_parameter_value $FIFODEPTH ] < $min_burstlength} {
       send_message error "fifo depth must be >= $min_burstlength (must be at least twice the burst length) "
     }
     	   
     set_parameter_value $FIFODEPTH_LOG2   [ expr int(ceil((log([ get_parameter_value $FIFODEPTH   ])/(log(2))))) ]    
     set_parameter_value $BURSTLENGTH_LOG2 [ expr int(ceil((log([ get_parameter_value $BURSTLENGTH ])/(log(2))))) ]    
       
  }
            

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Optimizations                                                                              --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc vip_add_parameters_optimizations { inst_name grp_name } {

    set ENABLE_DEBUG                ${inst_name}_ENABLE_DEBUG
    set ENABLE_CSR_READBACK_REDUCED ${inst_name}_ENABLE_CSR_READBACK_REDUCED

    add_parameter          $ENABLE_DEBUG INTEGER 0
    set_parameter_property $ENABLE_DEBUG DISPLAY_NAME "Debug";
    set_parameter_property $ENABLE_DEBUG DISPLAY_HINT boolean
    set_parameter_property $ENABLE_DEBUG DESCRIPTION "Turn on to support debug"
    set_parameter_property $ENABLE_DEBUG VISIBLE true 
    set_parameter_property $ENABLE_DEBUG HDL_PARAMETER true

    add_parameter          $ENABLE_CSR_READBACK_REDUCED INTEGER 0
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED DISPLAY_NAME "Reduced CSR Readback";
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED DISPLAY_HINT boolean
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED DESCRIPTION "Turn on to disable Control-Status Registers Readback and save ressources"
    # not yet released
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED VISIBLE false 
   #set_parameter_property $ENABLE_CSR_READBACK_REDUCED HDL_PARAMETER true
 
    add_display_item $grp_name $ENABLE_DEBUG                PARAMETER
    add_display_item $grp_name $ENABLE_CSR_READBACK_REDUCED PARAMETER

  }



# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Optimizations                                                                              --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc vip_add_fileset { HDL_DIRECTORY } {
     
    if {$HDL_DIRECTORY == 0} { 
    	
    	set HDL_PATH "./HDL"

      add_fileset_file cgx_fusion_top.ocp  OTHER PATH $HDL_PATH/cgx_fusion_top.ocp    
      add_fileset_file cgx_fusion_top.vhd   VHDL PATH $HDL_PATH/cgx_fusion_top.vhd  TOP_LEVEL_FILE

    # add_fileset_file generic_ram_sdp_mixed.vhd  VHDL PATH $HDL_PATH/generic_ram_sdp_mixed.vhd                  
      add_fileset_file generic_fifo_dc2.vhd       VHDL PATH $HDL_PATH/generic_fifo_dc2.vhd                  
      
      add_fileset_file IMTFILE0300.vhd  VHDL PATH $HDL_PATH/IMTFILE0300.vhd
      add_fileset_file IMTFILE0301.vhd  VHDL PATH $HDL_PATH/IMTFILE0301.vhd
      add_fileset_file IMTFILE0302.vhd  VHDL PATH $HDL_PATH/IMTFILE0302.vhd
      add_fileset_file IMTFILE0303.vhd  VHDL PATH $HDL_PATH/IMTFILE0303.vhd
      add_fileset_file IMTFILE0304.vhd  VHDL PATH $HDL_PATH/IMTFILE0304.vhd
      add_fileset_file IMTFILE0305.vhd  VHDL PATH $HDL_PATH/IMTFILE0305.vhd
      add_fileset_file IMTFILE0306.vhd  VHDL PATH $HDL_PATH/IMTFILE0306.vhd
      add_fileset_file IMTFILE0307.vhd  VHDL PATH $HDL_PATH/IMTFILE0307.vhd
      add_fileset_file IMTFILE0308.vhd  VHDL PATH $HDL_PATH/IMTFILE0308.vhd
  #   add_fileset_file IMTFILE0309.vhd  VHDL PATH $HDL_PATH/IMTFILE0309.vhd
      add_fileset_file IMTFILE0310.vhd  VHDL PATH $HDL_PATH/IMTFILE0310.vhd
      add_fileset_file IMTFILE0311.vhd  VHDL PATH $HDL_PATH/IMTFILE0311.vhd
      add_fileset_file IMTFILE0312.vhd  VHDL PATH $HDL_PATH/IMTFILE0312.vhd
      add_fileset_file IMTFILE0313.vhd  VHDL PATH $HDL_PATH/IMTFILE0313.vhd
      add_fileset_file IMTFILE0314.vhd  VHDL PATH $HDL_PATH/IMTFILE0314.vhd
      add_fileset_file IMTFILE0315.vhd  VHDL PATH $HDL_PATH/IMTFILE0315.vhd
      add_fileset_file IMTFILE0316.vhd  VHDL PATH $HDL_PATH/IMTFILE0316.vhd
      add_fileset_file IMTFILE0317.vhd  VHDL PATH $HDL_PATH/IMTFILE0317.vhd
      add_fileset_file IMTFILE0318.vhd  VHDL PATH $HDL_PATH/IMTFILE0318.vhd
      add_fileset_file IMTFILE0319.vhd  VHDL PATH $HDL_PATH/IMTFILE0319.vhd
      add_fileset_file IMTFILE0320.vhd  VHDL PATH $HDL_PATH/IMTFILE0320.vhd
      add_fileset_file IMTFILE0321.vhd  VHDL PATH $HDL_PATH/IMTFILE0321.vhd
      add_fileset_file IMTFILE0322.vhd  VHDL PATH $HDL_PATH/IMTFILE0322.vhd
      add_fileset_file IMTFILE0323.vhd  VHDL PATH $HDL_PATH/IMTFILE0323.vhd
      add_fileset_file IMTFILE0324.vhd  VHDL PATH $HDL_PATH/IMTFILE0324.vhd
      add_fileset_file IMTFILE0325.vhd  VHDL PATH $HDL_PATH/IMTFILE0325.vhd
      add_fileset_file IMTFILE0326.vhd  VHDL PATH $HDL_PATH/IMTFILE0326.vhd
      add_fileset_file IMTFILE0327.vhd  VHDL PATH $HDL_PATH/IMTFILE0327.vhd
      add_fileset_file IMTFILE0328.vhd  VHDL PATH $HDL_PATH/IMTFILE0328.vhd
      add_fileset_file IMTFILE0329.vhd  VHDL PATH $HDL_PATH/IMTFILE0329.vhd
      add_fileset_file IMTFILE0330.vhd  VHDL PATH $HDL_PATH/IMTFILE0330.vhd
      add_fileset_file IMTFILE0331.vhd  VHDL PATH $HDL_PATH/IMTFILE0331.vhd
      add_fileset_file IMTFILE0332.vhd  VHDL PATH $HDL_PATH/IMTFILE0332.vhd
      add_fileset_file IMTFILE0333.vhd  VHDL PATH $HDL_PATH/IMTFILE0333.vhd
      add_fileset_file IMTFILE0334.vhd  VHDL PATH $HDL_PATH/IMTFILE0334.vhd
      add_fileset_file IMTFILE0335.vhd  VHDL PATH $HDL_PATH/IMTFILE0335.vhd
      add_fileset_file IMTFILE0336.vhd  VHDL PATH $HDL_PATH/IMTFILE0336.vhd
      add_fileset_file IMTFILE0337.vhd  VHDL PATH $HDL_PATH/IMTFILE0337.vhd
      add_fileset_file IMTFILE0338.vhd  VHDL PATH $HDL_PATH/IMTFILE0338.vhd
      add_fileset_file IMTFILE0339.vhd  VHDL PATH $HDL_PATH/IMTFILE0339.vhd
      add_fileset_file IMTFILE0340.vhd  VHDL PATH $HDL_PATH/IMTFILE0340.vhd
      add_fileset_file IMTFILE0341.vhd  VHDL PATH $HDL_PATH/IMTFILE0341.vhd
      add_fileset_file IMTFILE0342.vhd  VHDL PATH $HDL_PATH/IMTFILE0342.vhd
      add_fileset_file IMTFILE0343.vhd  VHDL PATH $HDL_PATH/IMTFILE0343.vhd
      add_fileset_file IMTFILE0344.vhd  VHDL PATH $HDL_PATH/IMTFILE0344.vhd
      add_fileset_file IMTFILE0345.vhd  VHDL PATH $HDL_PATH/IMTFILE0345.vhd
      add_fileset_file IMTFILE0346.vhd  VHDL PATH $HDL_PATH/IMTFILE0346.vhd
      add_fileset_file IMTFILE0347.vhd  VHDL PATH $HDL_PATH/IMTFILE0347.vhd
      add_fileset_file IMTFILE0348.vhd  VHDL PATH $HDL_PATH/IMTFILE0348.vhd
      add_fileset_file IMTFILE0349.vhd  VHDL PATH $HDL_PATH/IMTFILE0349.vhd
      add_fileset_file IMTFILE0350.vhd  VHDL PATH $HDL_PATH/IMTFILE0350.vhd
      add_fileset_file IMTFILE0351.vhd  VHDL PATH $HDL_PATH/IMTFILE0351.vhd
      add_fileset_file IMTFILE0352.vhd  VHDL PATH $HDL_PATH/IMTFILE0352.vhd
      add_fileset_file IMTFILE0353.vhd  VHDL PATH $HDL_PATH/IMTFILE0353.vhd
      add_fileset_file IMTFILE0354.vhd  VHDL PATH $HDL_PATH/IMTFILE0354.vhd
      add_fileset_file IMTFILE0355.vhd  VHDL PATH $HDL_PATH/IMTFILE0355.vhd
      add_fileset_file IMTFILE0356.vhd  VHDL PATH $HDL_PATH/IMTFILE0356.vhd
      add_fileset_file IMTFILE0357.vhd  VHDL PATH $HDL_PATH/IMTFILE0357.vhd
      add_fileset_file IMTFILE0358.vhd  VHDL PATH $HDL_PATH/IMTFILE0358.vhd
      add_fileset_file IMTFILE0359.vhd  VHDL PATH $HDL_PATH/IMTFILE0359.vhd
      add_fileset_file IMTFILE0360.vhd  VHDL PATH $HDL_PATH/IMTFILE0360.vhd
      add_fileset_file IMTFILE0361.vhd  VHDL PATH $HDL_PATH/IMTFILE0361.vhd
      add_fileset_file IMTFILE0362.vhd  VHDL PATH $HDL_PATH/IMTFILE0362.vhd
      add_fileset_file IMTFILE0363.vhd  VHDL PATH $HDL_PATH/IMTFILE0363.vhd
      add_fileset_file IMTFILE0364.vhd  VHDL PATH $HDL_PATH/IMTFILE0364.vhd
      add_fileset_file IMTFILE0365.vhd  VHDL PATH $HDL_PATH/IMTFILE0365.vhd
      add_fileset_file IMTFILE0366.vhd  VHDL PATH $HDL_PATH/IMTFILE0366.vhd
      add_fileset_file IMTFILE0367.vhd  VHDL PATH $HDL_PATH/IMTFILE0367.vhd
      add_fileset_file IMTFILE0368.vhd  VHDL PATH $HDL_PATH/IMTFILE0368.vhd
      add_fileset_file IMTFILE0369.vhd  VHDL PATH $HDL_PATH/IMTFILE0369.vhd
      add_fileset_file IMTFILE0370.vhd  VHDL PATH $HDL_PATH/IMTFILE0370.vhd
      add_fileset_file IMTFILE0371.vhd  VHDL PATH $HDL_PATH/IMTFILE0371.vhd
      add_fileset_file IMTFILE0372.vhd  VHDL PATH $HDL_PATH/IMTFILE0372.vhd
      add_fileset_file IMTFILE0373.vhd  VHDL PATH $HDL_PATH/IMTFILE0373.vhd
      add_fileset_file IMTFILE0374.vhd  VHDL PATH $HDL_PATH/IMTFILE0374.vhd
      add_fileset_file IMTFILE0375.vhd  VHDL PATH $HDL_PATH/IMTFILE0375.vhd
      add_fileset_file IMTFILE0376.vhd  VHDL PATH $HDL_PATH/IMTFILE0376.vhd
      add_fileset_file IMTFILE0377.vhd  VHDL PATH $HDL_PATH/IMTFILE0377.vhd
      add_fileset_file IMTFILE0378.vhd  VHDL PATH $HDL_PATH/IMTFILE0378.vhd
      add_fileset_file IMTFILE0379.vhd  VHDL PATH $HDL_PATH/IMTFILE0379.vhd
      add_fileset_file IMTFILE0380.vhd  VHDL PATH $HDL_PATH/IMTFILE0380.vhd
      add_fileset_file IMTFILE0381.vhd  VHDL PATH $HDL_PATH/IMTFILE0381.vhd
      add_fileset_file IMTFILE0382.vhd  VHDL PATH $HDL_PATH/IMTFILE0382.vhd
      add_fileset_file IMTFILE0383.vhd  VHDL PATH $HDL_PATH/IMTFILE0383.vhd
      add_fileset_file IMTFILE0384.vhd  VHDL PATH $HDL_PATH/IMTFILE0384.vhd
      add_fileset_file IMTFILE0385.vhd  VHDL PATH $HDL_PATH/IMTFILE0385.vhd
      add_fileset_file IMTFILE0386.vhd  VHDL PATH $HDL_PATH/IMTFILE0386.vhd
      add_fileset_file IMTFILE0387.vhd  VHDL PATH $HDL_PATH/IMTFILE0387.vhd
      add_fileset_file IMTFILE0388.vhd  VHDL PATH $HDL_PATH/IMTFILE0388.vhd
      add_fileset_file IMTFILE0389.vhd  VHDL PATH $HDL_PATH/IMTFILE0389.vhd
      add_fileset_file IMTFILE0390.vhd  VHDL PATH $HDL_PATH/IMTFILE0390.vhd
      add_fileset_file IMTFILE0391.vhd  VHDL PATH $HDL_PATH/IMTFILE0391.vhd
      add_fileset_file IMTFILE0392.vhd  VHDL PATH $HDL_PATH/IMTFILE0392.vhd
      add_fileset_file IMTFILE0393.vhd  VHDL PATH $HDL_PATH/IMTFILE0393.vhd
      add_fileset_file IMTFILE0394.vhd  VHDL PATH $HDL_PATH/IMTFILE0394.vhd
      add_fileset_file IMTFILE0395.vhd  VHDL PATH $HDL_PATH/IMTFILE0395.vhd
      add_fileset_file IMTFILE0396.vhd  VHDL PATH $HDL_PATH/IMTFILE0396.vhd
      add_fileset_file IMTFILE0397.vhd  VHDL PATH $HDL_PATH/IMTFILE0397.vhd
      add_fileset_file IMTFILE0398.vhd  VHDL PATH $HDL_PATH/IMTFILE0398.vhd
      add_fileset_file IMTFILE0399.vhd  VHDL PATH $HDL_PATH/IMTFILE0399.vhd
      add_fileset_file IMTFILE0400.vhd  VHDL PATH $HDL_PATH/IMTFILE0400.vhd
      add_fileset_file IMTFILE0401.vhd  VHDL PATH $HDL_PATH/IMTFILE0401.vhd
      add_fileset_file IMTFILE0402.vhd  VHDL PATH $HDL_PATH/IMTFILE0402.vhd
      add_fileset_file IMTFILE0403.vhd  VHDL PATH $HDL_PATH/IMTFILE0403.vhd
      add_fileset_file IMTFILE0404.vhd  VHDL PATH $HDL_PATH/IMTFILE0404.vhd
      add_fileset_file IMTFILE0405.vhd  VHDL PATH $HDL_PATH/IMTFILE0405.vhd
      add_fileset_file IMTFILE0406.vhd  VHDL PATH $HDL_PATH/IMTFILE0406.vhd
      add_fileset_file IMTFILE0407.vhd  VHDL PATH $HDL_PATH/IMTFILE0407.vhd
      add_fileset_file IMTFILE0408.vhd  VHDL PATH $HDL_PATH/IMTFILE0408.vhd
      add_fileset_file IMTFILE0409.vhd  VHDL PATH $HDL_PATH/IMTFILE0409.vhd
      add_fileset_file IMTFILE0410.vhd  VHDL PATH $HDL_PATH/IMTFILE0410.vhd
      add_fileset_file IMTFILE0411.vhd  VHDL PATH $HDL_PATH/IMTFILE0411.vhd
      add_fileset_file IMTFILE0412.vhd  VHDL PATH $HDL_PATH/IMTFILE0412.vhd
      add_fileset_file IMTFILE0413.vhd  VHDL PATH $HDL_PATH/IMTFILE0413.vhd
      add_fileset_file IMTFILE0414.vhd  VHDL PATH $HDL_PATH/IMTFILE0414.vhd
      add_fileset_file IMTFILE0415.vhd  VHDL PATH $HDL_PATH/IMTFILE0415.vhd
      add_fileset_file IMTFILE0416.vhd  VHDL PATH $HDL_PATH/IMTFILE0416.vhd
      add_fileset_file IMTFILE0417.vhd  VHDL PATH $HDL_PATH/IMTFILE0417.vhd
      add_fileset_file IMTFILE0418.vhd  VHDL PATH $HDL_PATH/IMTFILE0418.vhd
      add_fileset_file IMTFILE0419.vhd  VHDL PATH $HDL_PATH/IMTFILE0419.vhd
      add_fileset_file IMTFILE0420.vhd  VHDL PATH $HDL_PATH/IMTFILE0420.vhd
      add_fileset_file IMTFILE0421.vhd  VHDL PATH $HDL_PATH/IMTFILE0421.vhd
      add_fileset_file IMTFILE0422.vhd  VHDL PATH $HDL_PATH/IMTFILE0422.vhd
      add_fileset_file IMTFILE0423.vhd  VHDL PATH $HDL_PATH/IMTFILE0423.vhd
      add_fileset_file IMTFILE0424.vhd  VHDL PATH $HDL_PATH/IMTFILE0424.vhd
      add_fileset_file IMTFILE0425.vhd  VHDL PATH $HDL_PATH/IMTFILE0425.vhd
      add_fileset_file IMTFILE0426.vhd  VHDL PATH $HDL_PATH/IMTFILE0426.vhd
      add_fileset_file IMTFILE0427.vhd  VHDL PATH $HDL_PATH/IMTFILE0427.vhd
      add_fileset_file IMTFILE0428.vhd  VHDL PATH $HDL_PATH/IMTFILE0428.vhd
      add_fileset_file IMTFILE0429.vhd  VHDL PATH $HDL_PATH/IMTFILE0429.vhd
      add_fileset_file IMTFILE0430.vhd  VHDL PATH $HDL_PATH/IMTFILE0430.vhd
      
    } else {  
    
      set HDL_PATH "./SRC"
    
      # fusion                                                  
      add_fileset_file cgx_fusion_top.vhd               VHDL PATH $HDL_PATH/cgx_fusion_top.vhd TOP_LEVEL_FILE
      add_fileset_file fusion_build.vhd                 VHDL PATH $HDL_PATH/fusion_build.vhd  
      add_fileset_file fusion_def_csr.vhd               VHDL PATH $HDL_PATH/fusion_def_csr.vhd  

      # altera                                                  
      add_fileset_file generic_fifo_dc2.vhd             VHDL PATH $HDL_PATH/altera/generic_fifo_dc2.vhd                  

      # common                                                  
      add_fileset_file ath_def_pkg.vhd                  VHDL PATH $HDL_PATH/ath_def_pkg.vhd                                   
      add_fileset_file ath_def_csr.vhd                  VHDL PATH $HDL_PATH/ath_def_csr.vhd                                        
      add_fileset_file ath_math_pkg.vhd                 VHDL PATH $HDL_PATH/ath_math_pkg.vhd                                       

      # video                                                  
      add_fileset_file video_def_pkg.vhd                VHDL PATH $HDL_PATH/video_def_pkg.vhd  
      add_fileset_file video_banding.vhd                VHDL PATH $HDL_PATH/video_banding.vhd  
      add_fileset_file video_cropper.vhd                VHDL PATH $HDL_PATH/video_cropper.vhd  
      add_fileset_file video_scaler_h.vhd               VHDL PATH $HDL_PATH/video_scaler_h.vhd                                           
      add_fileset_file video_scaler_v.vhd               VHDL PATH $HDL_PATH/video_scaler_v.vhd                                           
      add_fileset_file video_scaler_fir.vhd             VHDL PATH $HDL_PATH/video_scaler_fir.vhd                                                
      add_fileset_file video_scaler.vhd                 VHDL PATH $HDL_PATH/video_scaler.vhd  
      add_fileset_file cgx_video.vhd                    VHDL PATH $HDL_PATH/cgx_video.vhd  
                                                                                          
      # utils                                                  
      add_fileset_file com_mult.vhd                     VHDL PATH $HDL_PATH/com_mult.vhd                  
      add_fileset_file com_pipe.vhd                     VHDL PATH $HDL_PATH/com_pipe.vhd                  
      add_fileset_file com_mux.vhd                      VHDL PATH $HDL_PATH/com_mux.vhd                  
      add_fileset_file com_demux.vhd                    VHDL PATH $HDL_PATH/com_demux.vhd                  
      add_fileset_file generic_ram_sdp.vhd              VHDL PATH $HDL_PATH/generic_ram_sdp.vhd                  
      add_fileset_file generic_fifo_sc2.vhd             VHDL PATH $HDL_PATH/generic_fifo_sc2.vhd                  
      add_fileset_file generic_rfifo_st.vhd             VHDL PATH $HDL_PATH/generic_rfifo_st.vhd             
      add_fileset_file data_width_mux.vhd               VHDL PATH $HDL_PATH/data_width_mux.vhd                                                                   
      add_fileset_file data_width_demux.vhd             VHDL PATH $HDL_PATH/data_width_demux.vhd                                                                 
      add_fileset_file data_width_multiplexer.vhd       VHDL PATH $HDL_PATH/data_width_multiplexer.vhd                                                           
      add_fileset_file data_width_converter.vhd         VHDL PATH $HDL_PATH/data_width_converter.vhd                     
      add_fileset_file data_aligner.vhd                 VHDL PATH $HDL_PATH/data_aligner.vhd                                    
      add_fileset_file color_premultiplier.vhd          VHDL PATH $HDL_PATH/color_premultiplier.vhd               
      add_fileset_file color_multiplier.vhd             VHDL PATH $HDL_PATH/color_multiplier.vhd               
      add_fileset_file color_blend_pre.vhd              VHDL PATH $HDL_PATH/color_blend_pre.vhd                                     
    
      # surface                                                  
      add_fileset_file sfc_def_pkg.vhd                  VHDL PATH $HDL_PATH/sfc_def_pkg.vhd               
      add_fileset_file sfc_def_csr.vhd                  VHDL PATH $HDL_PATH/sfc_def_csr.vhd                                 
      add_fileset_file cdma_read3.vhd                   VHDL PATH $HDL_PATH/cdma_read3.vhd                                    
      add_fileset_file color_encoder2.vhd               VHDL PATH $HDL_PATH/color_encoder2.vhd                   
      add_fileset_file color_decoder2.vhd               VHDL PATH $HDL_PATH/color_decoder2.vhd                                    
      add_fileset_file sfc_span2mem.vhd                 VHDL PATH $HDL_PATH/sfc_span2mem.vhd                                             
      add_fileset_file sfc_sync.vhd                     VHDL PATH $HDL_PATH/sfc_sync.vhd                               
      add_fileset_file surface_controller.vhd           VHDL PATH $HDL_PATH/surface_controller.vhd                                   
      add_fileset_file surface_reader.vhd               VHDL PATH $HDL_PATH/surface_reader.vhd                                   
      add_fileset_file surface_writer.vhd               VHDL PATH $HDL_PATH/surface_writer.vhd                                   

      # dma                                                       
      add_fileset_file dma_def_csr.vhd                  VHDL PATH $HDL_PATH/dma_def_csr.vhd                  
      add_fileset_file cgx_dma.vhd                      VHDL PATH $HDL_PATH/cgx_dma.vhd            

      # memory                                                       
      add_fileset_file mem_def_if.vhd                   VHDL PATH $HDL_PATH/mem_def_if.vhd            
      add_fileset_file mem_def_csr.vhd                  VHDL PATH $HDL_PATH/mem_def_csr.vhd                  
      add_fileset_file cgx_memory.vhd                   VHDL PATH $HDL_PATH/cgx_memory.vhd            

      # cvi                                                       
      add_fileset_file cvi_def_pkg.vhd                  VHDL PATH $HDL_PATH/cvi_def_pkg.vhd                     
      add_fileset_file bayer2rgb.vhd                    VHDL PATH $HDL_PATH/bayer2rgb.vhd                   
      add_fileset_file yuv2rgb.vhd                      VHDL PATH $HDL_PATH/yuv2rgb.vhd                   
      add_fileset_file bt_decoder.vhd                   VHDL PATH $HDL_PATH/bt_decoder.vhd                
      add_fileset_file cvi_core.vhd                     VHDL PATH $HDL_PATH/cvi_core.vhd                       
  
      # cvo                                                       
      add_fileset_file cvo_timings.vhd                  VHDL PATH $HDL_PATH/cvo_timings.vhd                                                        
      add_fileset_file cvo_def_pkg.vhd                  VHDL PATH $HDL_PATH/cvo_def_pkg.vhd                                                        
      add_fileset_file cvo.vhd                          VHDL PATH $HDL_PATH/cvo.vhd                       

      # tpg                                                       
      add_fileset_file tpg_def_pkg.vhd                  VHDL PATH $HDL_PATH/tpg_def_pkg.vhd                  
      add_fileset_file video_tpg.vhd                    VHDL PATH $HDL_PATH/video_tpg.vhd                 
    
      # vsc                                                       
      add_fileset_file cgx_vsc.vhd                      VHDL PATH $HDL_PATH/cgx_vsc.vhd  
      add_fileset_file vsc_rotation.vhd                 VHDL PATH $HDL_PATH/vsc_rotation.vhd                 
      add_fileset_file vsc_vid2sfc.vhd                  VHDL PATH $HDL_PATH/vsc_vid2sfc.vhd                   
      add_fileset_file vsc_sfc2vid.vhd                  VHDL PATH $HDL_PATH/vsc_sfc2vid.vhd                   
      add_fileset_file vsc_def_csr.vhd                  VHDL PATH $HDL_PATH/vsc_def_csr.vhd               
      
      # display                                                  
      add_fileset_file cgx_display.vhd                  VHDL PATH $HDL_PATH/cgx_display.vhd                   
      add_fileset_file dpy_def_pkg.vhd                  VHDL PATH $HDL_PATH/dpy_def_pkg.vhd                                        
      add_fileset_file dpy_def_csr.vhd                  VHDL PATH $HDL_PATH/dpy_def_csr.vhd                                        
      add_fileset_file dpy_def_desc.vhd                 VHDL PATH $HDL_PATH/dpy_def_desc.vhd                                       
      add_fileset_file dpy_scaler.vhd                   VHDL PATH $HDL_PATH/dpy_scaler.vhd                                             
      add_fileset_file dpy_filter_v.vhd                 VHDL PATH $HDL_PATH/dpy_filter_v.vhd                                           
      add_fileset_file dpy_line.vhd                     VHDL PATH $HDL_PATH/dpy_line.vhd                                           
      add_fileset_file line_buffers.vhd                 VHDL PATH $HDL_PATH/line_buffers.vhd                                
      add_fileset_file layer_builder.vhd                VHDL PATH $HDL_PATH/layer_builder.vhd                                      
      add_fileset_file dpy_ctrl_video.vhd               VHDL PATH $HDL_PATH/dpy_ctrl_video.vhd                                     
      add_fileset_file dpy_overlay.vhd                  VHDL PATH $HDL_PATH/dpy_overlay.vhd                                     
    
      # vgr                                                   
      add_fileset_file cgx_vgr.vhd                      VHDL PATH  $HDL_PATH/cgx_vgr.vhd     
      add_fileset_file vgr_def_pkg.vhd                  VHDL PATH  $HDL_PATH/vgr_def_pkg.vhd    
      add_fileset_file vgr_def_csr.vhd                  VHDL PATH  $HDL_PATH/vgr_def_csr.vhd               
      add_fileset_file vgr_pkg.vhd                      VHDL PATH  $HDL_PATH/vgr_pkg.vhd                
      add_fileset_file vgr_chunk.vhd                    VHDL PATH  $HDL_PATH/vgr_chunk.vhd                 
      # vgr path                                                          
      add_fileset_file pkg_tools.vhd                    VHDL PATH  $HDL_PATH/pkg_tools.vhd            
      add_fileset_file ram.vhd                          VHDL PATH  $HDL_PATH/ram.vhd                  
      add_fileset_file fifo_sc.vhd                      VHDL PATH  $HDL_PATH/fifo_sc.vhd              
      add_fileset_file merge_sort.vhd                   VHDL PATH  $HDL_PATH/merge_sort.vhd           
      add_fileset_file vgr_bezier_split.vhd             VHDL PATH  $HDL_PATH/vgr_bezier_split.vhd               
      add_fileset_file vgr_raster_arc2line.vhd          VHDL PATH  $HDL_PATH/vgr_raster_arc2line.vhd                  
      add_fileset_file vgr_line2cell_pkg.vhd            VHDL PATH  $HDL_PATH/vgr_line2cell_pkg.vhd                    
      add_fileset_file vgr_line2cell_setup2.vhd         VHDL PATH  $HDL_PATH/vgr_line2cell_setup2.vhd                 
      add_fileset_file vgr_line2cell_raster.vhd         VHDL PATH  $HDL_PATH/vgr_line2cell_raster.vhd                 
      add_fileset_file vgr_raster_line2cell4.vhd        VHDL PATH  $HDL_PATH/vgr_raster_line2cell4.vhd                
      add_fileset_file vgr_raster_cell_sort2.vhd        VHDL PATH  $HDL_PATH/vgr_raster_cell_sort2.vhd               
      add_fileset_file vgr_raster_cell2gray.vhd         VHDL PATH  $HDL_PATH/vgr_raster_cell2gray.vhd               
      add_fileset_file vgr_path_raster.vhd              VHDL PATH  $HDL_PATH/vgr_path_raster.vhd              
      add_fileset_file vgr_path_bias.vhd                VHDL PATH  $HDL_PATH/vgr_path_bias.vhd                   
      add_fileset_file vgr_path_transform2.vhd          VHDL PATH  $HDL_PATH/vgr_path_transform2.vhd              
      add_fileset_file vgr_path_bbox.vhd                VHDL PATH  $HDL_PATH/vgr_path_bbox.vhd                   
      add_fileset_file vgr_path_stroke.vhd              VHDL PATH  $HDL_PATH/vgr_path_stroke.vhd                 
      add_fileset_file vgr_path.vhd                     VHDL PATH  $HDL_PATH/vgr_path.vhd                   
      # vgr_render      
      add_fileset_file paint_spreading.vhd              VHDL PATH  $HDL_PATH/paint_spreading.vhd                
      add_fileset_file paint_colorramp.vhd              VHDL PATH  $HDL_PATH/paint_colorramp.vhd            
      add_fileset_file paint_mapping7.vhd               VHDL PATH  $HDL_PATH/paint_mapping7.vhd        
      add_fileset_file paint_pattern4.vhd               VHDL PATH  $HDL_PATH/paint_pattern4.vhd            
      add_fileset_file paint_bitmap.vhd                 VHDL PATH  $HDL_PATH/paint_bitmap.vhd            
      add_fileset_file paint_render_gradient.vhd        VHDL PATH  $HDL_PATH/paint_render_gradient.vhd            
      add_fileset_file paint_render_bitmap.vhd          VHDL PATH  $HDL_PATH/paint_render_bitmap.vhd            
      add_fileset_file vgr_gray_buffer.vhd              VHDL PATH  $HDL_PATH/vgr_gray_buffer.vhd               
      add_fileset_file vgr_gray2span.vhd                VHDL PATH  $HDL_PATH/vgr_gray2span.vhd               
      add_fileset_file vgr_span_buffer2.vhd             VHDL PATH  $HDL_PATH/vgr_span_buffer2.vhd                 
      add_fileset_file vgr_span_optimizer.vhd           VHDL PATH  $HDL_PATH/vgr_span_optimizer.vhd                 
      add_fileset_file vgr_span_sync2.vhd               VHDL PATH  $HDL_PATH/vgr_span_sync2.vhd                 
      add_fileset_file vgr_composer.vhd                 VHDL PATH  $HDL_PATH/vgr_composer.vhd                  
      add_fileset_file vgr_painting.vhd                 VHDL PATH  $HDL_PATH/vgr_painting.vhd               
      add_fileset_file vgr_masking.vhd                  VHDL PATH  $HDL_PATH/vgr_masking.vhd                
      add_fileset_file vgr_blending.vhd                 VHDL PATH  $HDL_PATH/vgr_blending.vhd               
      add_fileset_file vgr_render.vhd                   VHDL PATH  $HDL_PATH/vgr_render.vhd                   
      add_fileset_file vgr_reg2ctx.vhd                  VHDL PATH  $HDL_PATH/vgr_reg2ctx.vhd                           
      add_fileset_file vgr_float2fix.vhd                VHDL PATH  $HDL_PATH/vgr_float2fix.vhd                           
      add_fileset_file vgr_context.vhd                  VHDL PATH  $HDL_PATH/vgr_context.vhd                           
      add_fileset_file vgr_rect3.vhd                    VHDL PATH  $HDL_PATH/vgr_rect3.vhd                 
      # vgr stroker                                                  
      add_fileset_file buff.vhd                          VHDL PATH  $HDL_PATH/buff.vhd                         
      add_fileset_file cordic.vhd                        VHDL PATH  $HDL_PATH/cordic.vhd                       
      add_fileset_file cordic_trigo.vhd                  VHDL PATH  $HDL_PATH/cordic_trigo.vhd                 
      add_fileset_file cordic_vector.vhd                 VHDL PATH  $HDL_PATH/cordic_vector.vhd                
      add_fileset_file div.vhd                           VHDL PATH  $HDL_PATH/div.vhd                          
      add_fileset_file fifo_sc.vhd                       VHDL PATH  $HDL_PATH/fifo_sc.vhd                      
      add_fileset_file lifo.vhd                          VHDL PATH  $HDL_PATH/lifo.vhd                         
      add_fileset_file pkg_tools.vhd                     VHDL PATH  $HDL_PATH/pkg_tools.vhd                    
      add_fileset_file ram.vhd                           VHDL PATH  $HDL_PATH/ram.vhd                          
      add_fileset_file vgr_casteljau2.vhd                VHDL PATH  $HDL_PATH/vgr_casteljau2.vhd                
      add_fileset_file vgr_stroker.vhd                   VHDL PATH  $HDL_PATH/vgr_stroker.vhd                  
      add_fileset_file vgr_stroker_arc2.vhd              VHDL PATH  $HDL_PATH/vgr_stroker_arc2.vhd              
      add_fileset_file vgr_stroker_cap_butt.vhd          VHDL PATH  $HDL_PATH/vgr_stroker_cap_butt.vhd         
      add_fileset_file vgr_stroker_cap_square.vhd        VHDL PATH  $HDL_PATH/vgr_stroker_cap_square.vhd       
      add_fileset_file vgr_stroker_dash2.vhd             VHDL PATH  $HDL_PATH/vgr_stroker_dash2.vhd             
      add_fileset_file vgr_stroker_join_bevel.vhd        VHDL PATH  $HDL_PATH/vgr_stroker_join_bevel.vhd       
      add_fileset_file vgr_stroker_join_inside.vhd       VHDL PATH  $HDL_PATH/vgr_stroker_join_inside.vhd      
      add_fileset_file vgr_stroker_join_miter2.vhd       VHDL PATH  $HDL_PATH/vgr_stroker_join_miter2.vhd       
      add_fileset_file vgr_stroker_offset2.vhd           VHDL PATH  $HDL_PATH/vgr_stroker_offset2.vhd           
      add_fileset_file vgr_stroker_close.vhd             VHDL PATH  $HDL_PATH/vgr_stroker_close.vhd           
    }
  }




