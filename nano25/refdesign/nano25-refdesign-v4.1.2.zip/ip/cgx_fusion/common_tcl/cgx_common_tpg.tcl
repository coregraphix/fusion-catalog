

namespace eval cgx_tpg {

  variable tpg_pattern_back_range {"0:all" "1:off" "2:gradient H" "3:gradient V" "4:gradient H+V" "5:colorbar" "6:checker"}   
  variable tpg_pattern_fore_range {"0:all" "1:off" "2:bounds" "3:scrollbar H" "4:scrollbar V "}                               

}

 
# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- General                                                                                --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc tpg_add_pattern {ctrl_name inst_gui_name} {
 
    set param_name "PATTERN"
    set param_name ${ctrl_name}_${param_name} 

    set PATTERN_BACK   ${param_name}_BACK
    set PATTERN_FORE   ${param_name}_FORE
 
    add_parameter          $PATTERN_BACK INTEGER 2
    set_parameter_property $PATTERN_BACK DISPLAY_NAME "background test pattern"
    set_parameter_property $PATTERN_BACK ALLOWED_RANGES ${::cgx_tpg::tpg_pattern_back_range}    
    set_parameter_property $PATTERN_BACK HDL_PARAMETER true      
                           
    add_parameter          $PATTERN_FORE INTEGER 3
    set_parameter_property $PATTERN_FORE DISPLAY_NAME "foreground test pattern"
    set_parameter_property $PATTERN_FORE ALLOWED_RANGES ${::cgx_tpg::tpg_pattern_fore_range}    
    set_parameter_property $PATTERN_FORE HDL_PARAMETER true      

    add_display_item $inst_gui_name $PATTERN_BACK  PARAMETER
    add_display_item $inst_gui_name $PATTERN_FORE  PARAMETER

  }

 
  proc tpg_enable_pattern {ctrl_name enable} {
 
    set param_name "PATTERN"
    set param_name ${ctrl_name}_${param_name} 

    set PATTERN_BACK   ${param_name}_BACK
    set PATTERN_FORE   ${param_name}_FORE

    if { $enable == 0 } {
      set_parameter_property $PATTERN_BACK  ENABLED false
      set_parameter_property $PATTERN_FORE  ENABLED false    
    } else {
      set_parameter_property $PATTERN_BACK  ENABLED true
      set_parameter_property $PATTERN_FORE  ENABLED true
    }

  }


