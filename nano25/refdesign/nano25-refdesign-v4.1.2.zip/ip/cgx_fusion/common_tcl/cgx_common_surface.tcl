

  
package require -exact qsys 13.1



#  set MAX_SYNC 2; 
  

namespace eval imt_surface {

  variable surface_pool  

# variable pool_num 0  

  variable surface_colorformat_range {XRGB_8888 ARGB_8888 ARGB_8888_PRE RGB_888 RGB_565 ARGB_1555 ARGB_4444 AL_88 L_8 A_8 RAW};

  # stream formats is a subset of surface formats
  variable stream_colorformat_range {ARGB_8888 RGB_888 RGB_565 ARGB_1555 ARGB_4444 AL_88 L_8 A_8 RAW};

  # public/released stream formats for video (used by Video/Display)
  variable video_colorformat_range {ARGB_8888 RGB_888 RGB_565 ARGB_1555 ARGB_4444 AL_88 L_8 A_8, RAW};  


}
 
  proc surface_pool_add { sfc_class sfc_idx sfc_name sfc_size8 } {

# set sfc_idx ${::imt_surface::pool_num}                                                      

#  set sfc "${sfc_class}${sfc_idx}"
#  set ::imt_surface::surface_pool($sfc,name)   $sfc_name                                                   
#  set ::imt_surface::surface_pool($sfc,base8)  -1                                                      
#  set ::imt_surface::surface_pool($sfc,size8)  $sfc_size8                                                     

   set ::imt_surface::surface_pool($sfc_class,$sfc_idx,name)   $sfc_name                                                   
   set ::imt_surface::surface_pool($sfc_class,$sfc_idx,base8)  -1                                                      
   set ::imt_surface::surface_pool($sfc_class,$sfc_idx,size8)  $sfc_size8                                                     

# set ::imt_surface::pool_num [ expr $sfc_idx + 1 ]

# return $sfc_idx 
  
#   set sfc_name $param_name
#   
#   set ::imt_surface::surface_pool($sfc_name,base)          $base                                                      
#   set ::imt_surface::surface_pool($sfc_name,color)         $color                                                     
#   set ::imt_surface::surface_pool($sfc_name,color_depth)   $color_depth                                                     
#   set ::imt_surface::surface_pool($sfc_name,width)         $width                                                     
#   set ::imt_surface::surface_pool($sfc_name,height)        $height                                                    
#   set ::imt_surface::surface_pool($sfc_name,stride)        $stride                                                    
#   set ::imt_surface::surface_pool($sfc_name,nb_buffer)     $nb_buffer                                                 
#   set ::imt_surface::surface_pool($sfc_name,stride_buffer) $stride_buffer                                             

  }



  proc colorformat_get_info { color color_hw color_depth color_num color_size } {

    # create a local reference for the array
    upvar $color_hw    var_color_hw
    upvar $color_depth var_color_depth
    upvar $color_num   var_color_num
    upvar $color_size  var_color_size
   #upvar $color_raw   var_color_raw

    switch $color {
      "XRGB_8888" {
        set var_color_hw     0; # DEF_PIXCOLOR_XRGB_8888
        set var_color_depth  32
        set var_color_size   8
        set var_color_num    4
        set var_color_raw    1        
      }                                              
      "ARGB_8888" {
        set var_color_hw     1; # DEF_PIXCOLOR_ARGB_8888
        set var_color_depth  32
        set var_color_size   8
        set var_color_num    4
        set var_color_raw    1        
      }                                              
      "ARGB_8888_PRE" {
        set var_color_hw     2; # DEF_PIXCOLOR_ARGB_8888_PRE
        set var_color_depth  32
        set var_color_size   8
        set var_color_num    4
        set var_color_raw    1        
      }                                              
      "RGB_888" {
        set var_color_hw     3; # DEF_PIXCOLOR_RGB_888
        set var_color_depth  24
        set var_color_size   8
        set var_color_num    3
        set var_color_raw    1        
      }                                              
      "RGB_565" {
        set var_color_hw     4; # DEF_PIXCOLOR_RGB_565
        set var_color_depth  16
        set var_color_size   16
        set var_color_num    1
        set var_color_raw    1        
      }                                              
      "ARGB_1555" {
        set var_color_hw     5; # DEF_PIXCOLOR_ARGB_1555
        set var_color_depth  16
        set var_color_size   16
        set var_color_num    1
        set var_color_raw    1        
      }                                              
      "ARGB_4444" {
        set var_color_hw     6; # DEF_PIXCOLOR_ARGB_4444
        set var_color_depth  16
        set var_color_size   4
        set var_color_num    4
        set var_color_raw    1        
      }                                              
      "AL_88" {
        set var_color_hw     7; # DEF_PIXCOLOR_AL_88
        set var_color_depth  16
        set var_color_size   8
        set var_color_num    2
        set var_color_raw    1        
      }                                              
      "L_8" {
        set var_color_hw     8; # DEF_PIXCOLOR_L_8
        set var_color_depth  8
        set var_color_size   8
        set var_color_num    1
        set var_color_raw    1        
      }                                              
      "A_8" {
        set var_color_hw     12; # DEF_PIXCOLOR_A_8
        set var_color_depth  8
        set var_color_size   8
        set var_color_num    1
        set var_color_raw    1        
      }                                              
      "RAW" {
        set var_color_hw     255; # DEF_PIXCOLOR_UNDEFINED
        set var_color_raw    0        
      }                                              
    }
  }


  

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Surface                                                                                    --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------


  proc surface_ctrl_add_parameters_opt { inst_gui_name } {

    set param_name "WZD_SFC" 

    set MAX_WIDTH                 ${param_name}_MAX_WIDTH            
    set MAX_HEIGHT                ${param_name}_MAX_HEIGHT           
    set MAX_BUFFER                ${param_name}_MAX_BUFFER  
    set COLOR_ENABLE_EXTENDED     ${param_name}_COLOR_ENABLE_EXTENDED   
  # set COLOR_ENABLE_BPP124       ${param_name}_COLOR_ENABLE_BPP124       
    set COLOR_ENABLE_BPP8         ${param_name}_COLOR_ENABLE_BPP8       
    set COLOR_ENABLE_BPP16        ${param_name}_COLOR_ENABLE_BPP16      
    set COLOR_ENABLE_BPP24        ${param_name}_COLOR_ENABLE_BPP24      
    set COLOR_ENABLE_BPP32        ${param_name}_COLOR_ENABLE_BPP32      

    
    add_parameter          $MAX_WIDTH INTEGER 2048
    set_parameter_property $MAX_WIDTH DISPLAY_NAME "Max width" 
    set_parameter_property $MAX_WIDTH DISPLAY_UNITS "pixels"
    set_parameter_property $MAX_WIDTH ALLOWED_RANGES {1:16384}
    set_parameter_property $MAX_WIDTH DESCRIPTION "  ";
    set_parameter_property $MAX_WIDTH AFFECTS_ELABORATION true        
    set_parameter_property $MAX_WIDTH VISIBLE true      
    set_parameter_property $MAX_WIDTH HDL_PARAMETER true
  
    add_parameter          $MAX_HEIGHT INTEGER 2048
    set_parameter_property $MAX_HEIGHT DISPLAY_NAME "Max height" 
    set_parameter_property $MAX_HEIGHT DISPLAY_UNITS "pixels"
    set_parameter_property $MAX_HEIGHT ALLOWED_RANGES {1:16384}
    set_parameter_property $MAX_HEIGHT DESCRIPTION "  ";
    set_parameter_property $MAX_HEIGHT AFFECTS_ELABORATION true        
    set_parameter_property $MAX_HEIGHT VISIBLE true      
    set_parameter_property $MAX_HEIGHT HDL_PARAMETER true
  
    add_parameter          $MAX_BUFFER INTEGER 3
    set_parameter_property $MAX_BUFFER DISPLAY_NAME "Max buffers" 
    set_parameter_property $MAX_BUFFER ALLOWED_RANGES {1:256}
    set_parameter_property $MAX_BUFFER DESCRIPTION "  ";
    set_parameter_property $MAX_BUFFER AFFECTS_ELABORATION true        
    set_parameter_property $MAX_BUFFER VISIBLE true      
    set_parameter_property $MAX_BUFFER HDL_PARAMETER true
  
    add_parameter          $COLOR_ENABLE_EXTENDED INTEGER 0
    set_parameter_property $COLOR_ENABLE_EXTENDED DISPLAY_NAME "Support for extended color formats" 
    set_parameter_property $COLOR_ENABLE_EXTENDED DISPLAY_HINT boolean
    set_parameter_property $COLOR_ENABLE_EXTENDED DESCRIPTION "extend default {A,X}RGB support to {A,X}BGR, RGB{A,X} and BGR{A,X} color channels orderings" 
  # set_parameter_property $COLOR_ENABLE_EXTENDED VISIBLE false        
    set_parameter_property $COLOR_ENABLE_EXTENDED HDL_PARAMETER true

  # add_parameter          $COLOR_ENABLE_BPP124 INTEGER       0
  # set_parameter_property $COLOR_ENABLE_BPP124 DISPLAY_NAME  "Support <8 bpp" 
  # set_parameter_property $COLOR_ENABLE_BPP124 DISPLAY_HINT  boolean 
  # set_parameter_property $COLOR_ENABLE_BPP124 HDL_PARAMETER true
                                                
    add_parameter          $COLOR_ENABLE_BPP8   INTEGER       1
    set_parameter_property $COLOR_ENABLE_BPP8   DISPLAY_NAME  "Support  8 bpp" 
    set_parameter_property $COLOR_ENABLE_BPP8   DISPLAY_HINT  boolean 
    set_parameter_property $COLOR_ENABLE_BPP8   HDL_PARAMETER true
                            
    add_parameter          $COLOR_ENABLE_BPP16  INTEGER       1
    set_parameter_property $COLOR_ENABLE_BPP16  DISPLAY_NAME  "Support 16 bpp" 
    set_parameter_property $COLOR_ENABLE_BPP16  DISPLAY_HINT  boolean 
    set_parameter_property $COLOR_ENABLE_BPP16  HDL_PARAMETER true
                            
    add_parameter          $COLOR_ENABLE_BPP24  INTEGER       1
    set_parameter_property $COLOR_ENABLE_BPP24  DISPLAY_NAME  "Support 24 bpp" 
    set_parameter_property $COLOR_ENABLE_BPP24  DISPLAY_HINT  boolean 
    set_parameter_property $COLOR_ENABLE_BPP24  HDL_PARAMETER true
                             
    add_parameter          $COLOR_ENABLE_BPP32  INTEGER       1
    set_parameter_property $COLOR_ENABLE_BPP32  DISPLAY_NAME  "support 32 bpp" 
    set_parameter_property $COLOR_ENABLE_BPP32  DISPLAY_HINT  boolean 
    set_parameter_property $COLOR_ENABLE_BPP32  HDL_PARAMETER true
  
        
    add_display_item "${inst_gui_name}" $MAX_WIDTH              PARAMETER
    add_display_item "${inst_gui_name}" $MAX_HEIGHT             PARAMETER
    add_display_item "${inst_gui_name}" $MAX_BUFFER             PARAMETER
  # add_display_item "${inst_gui_name}" $COLOR_ENABLE_BPP124    PARAMETER
    add_display_item "${inst_gui_name}" $COLOR_ENABLE_BPP8      PARAMETER
    add_display_item "${inst_gui_name}" $COLOR_ENABLE_BPP16     PARAMETER
    add_display_item "${inst_gui_name}" $COLOR_ENABLE_BPP24     PARAMETER
    add_display_item "${inst_gui_name}" $COLOR_ENABLE_BPP32     PARAMETER
    add_display_item "${inst_gui_name}" $COLOR_ENABLE_EXTENDED  PARAMETER
  
  }
  
  
  
  
  
  proc surface_add_parameters { is_core ctrl_name inst_gui_name } {
  
    if {$is_core == 0} { 
      
      set SFC_CTRL_EXTERN ${ctrl_name}_SFC_CTRL_EXTERN             
      
      add_parameter          $SFC_CTRL_EXTERN INTEGER 0
      set_parameter_property $SFC_CTRL_EXTERN DISPLAY_NAME "External controller" 
      set_parameter_property $SFC_CTRL_EXTERN DISPLAY_HINT boolean
      set_parameter_property $SFC_CTRL_EXTERN DESCRIPTION " ";
      set_parameter_property $SFC_CTRL_EXTERN AFFECTS_ELABORATION true        
      set_parameter_property $SFC_CTRL_EXTERN ENABLED false
      
      add_display_item $inst_gui_name $SFC_CTRL_EXTERN PARAMETER
      
      } 
  }
  


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Controller                                                                                 --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#  # <ctrl_id> used to dissociate group name when several controllers are instantiated
#  proc surface_ctrl_add_parameters {is_core ctrl_name ctrl_id inst_gui_name ctrl_v_major ctrl_v_minor } {
#
#    surface_add_parameters $is_core $ctrl_name $inst_gui_name
#    
#  # if {$is_core == 1} { 
#  #   surface_ctrl_add_parameters_main 1 "WZD" $inst_gui_name
#  # } else {
#  #   surface_ctrl_add_parameters_main $is_core $ctrl_name $inst_gui_name
#  # }
#
#    surface_ctrl_add_parameters_main     $is_core   $ctrl_name $inst_gui_name $ctrl_v_major $ctrl_v_minor
#
#  # set grp_label_main            Main${ctrl_id}         
#    set grp_label_primary         Primary${ctrl_id}         
#  # set grp_label_memory          Memory${ctrl_id}         
#  # set grp_label_dma             DMA${ctrl_id}    
#    set grp_label_dma_rd          "DMA Read${ctrl_id}"     
#    set grp_label_dma_wr          "DMA Write${ctrl_id}"    
#    set grp_label_optimizations   Optimizations${ctrl_id}
#    
#  # add_display_item $inst_gui_name $grp_label_main          GROUP       
#    add_display_item $inst_gui_name $grp_label_primary       GROUP; # tab  
#  # add_display_item $inst_gui_name $grp_label_memory        GROUP; # tab  
#    add_display_item $inst_gui_name $grp_label_dma_rd        GROUP      
#    add_display_item $inst_gui_name $grp_label_dma_wr        GROUP      
#    add_display_item $inst_gui_name $grp_label_optimizations GROUP; # tab    
#
#
#   #add_display_item $grp_label_memory $grp_label_dma    GROUP    
#   #add_display_item $grp_label_memory $grp_label_dma_rd GROUP      
#   #add_display_item $grp_label_memory $grp_label_dma_wr GROUP      
#
#   #surface_ctrl_add_parameters_main     $is_core   $ctrl_name $grp_label_main $ctrl_v_major $ctrl_v_minor
#    surface_ctrl_add_parameters_primary $is_core   $ctrl_name $ctrl_id $grp_label_primary
#    surface_ctrl_add_parameters_opti    $is_core   $ctrl_name $ctrl_id $grp_label_optimizations  
#    surface_ctrl_add_parameters_dma     $is_core 0 $ctrl_name $grp_label_dma_rd 
#    surface_ctrl_add_parameters_dma     $is_core 1 $ctrl_name $grp_label_dma_wr 
# 
#  }
#
#
#  # used by IP core (ex: imt_vsc_core_hw.tcl)
#  # every interface properties can be set individually (cf: surface_ipcore_set_interface_ ) 
#  # optionnaly restrict somes interfaces in case where HDL core does not contain all of them 
#  proc surface_ipcore_add_interface { ctrl_name use_csr use_rd use_wr } {
#   
#    if { ${use_csr} == 1 } {     
#      surface_csr_add_interface $ctrl_name                                              
#    }  
#
#      surface_exp_add_interface $ctrl_name                                              
#
#    if { ${use_rd} == 1 } {     
#      surface_dma_add_interface 0 $ctrl_name                                              
#    # surface_vsync_add_interface_core 0 $ctrl_name                         
#    }  
#
#    if { ${use_wr} == 1 } {     
#      surface_dma_add_interface 1 $ctrl_name                                                     
#    # surface_vsync_add_interface_core 1 $ctrl_name                         
#    }  
#
#  }
#
#  
#  proc surface_ctrl_connect_parameters_rw { ctrl_name is_write } {
#
#    if { ${is_write} == 0 } {     
#      set param_name "RD"
#    } else {
#      set param_name "WR"
#    } 
#
#    # stream  
#   #set_instance_parameter ${ctrl_name} WZD_${param_name}_NB_MUX             [ get_parameter_value ${ctrl_name}_${param_name}_NB_MUX ]  
#    set_instance_parameter ${ctrl_name} WZD_${param_name}_NB_PIXEL           [ get_parameter_value ${ctrl_name}_${param_name}_NB_PIXEL ]  
#
#    # memory  
#    set_instance_parameter ${ctrl_name} WZD_${param_name}_HAS_DEDICATED_CLK  [ get_parameter_value ${ctrl_name}_${param_name}_HAS_DEDICATED_CLK ] 
#    set_instance_parameter ${ctrl_name} WZD_${param_name}_ADDRESS8_SIZE         [ get_parameter_value ${ctrl_name}_${param_name}_ADDRESS8_SIZE        ] 
#    set_instance_parameter ${ctrl_name} WZD_${param_name}_DATA_WIDTH         [ get_parameter_value ${ctrl_name}_${param_name}_DATA_WIDTH        ] 
#    set_instance_parameter ${ctrl_name} WZD_${param_name}_FIFODEPTH          [ get_parameter_value ${ctrl_name}_${param_name}_FIFODEPTH         ] 
#    set_instance_parameter ${ctrl_name} WZD_${param_name}_BURSTLENGTH        [ get_parameter_value ${ctrl_name}_${param_name}_BURSTLENGTH       ] 
#   #set_instance_parameter ${ctrl_name} WZD_${param_name}_FIFODEPTH_LOG2     [ expr int(ceil((log([ get_parameter_value $FIFODEPTH ])/(log(2))))) ]     
#   #set_instance_parameter ${ctrl_name} WZD_${param_name}_BURSTLENGTH_LOG2   [ expr int(ceil((log([ get_parameter_value $BURSTLENGTH ])/(log(2))))) ] 
# 
#  }
# 
# 
#  proc surface_ctrl_connect_parameters { ctrl_name } {
#
#    # main    
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_CSR               [ get_parameter_value ${ctrl_name}_ENABLE_CSR       ]  
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_READER            [ get_parameter_value ${ctrl_name}_ENABLE_READER    ]  
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_WRITER            [ get_parameter_value ${ctrl_name}_ENABLE_WRITER    ]  
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_PRIMARY           [ get_parameter_value ${ctrl_name}_ENABLE_PRIMARY   ]  
#    set_instance_parameter ${ctrl_name} WZD_MAX_WIDTH                [ get_parameter_value ${ctrl_name}_MAX_WIDTH        ]  
#    set_instance_parameter ${ctrl_name} WZD_MAX_HEIGHT               [ get_parameter_value ${ctrl_name}_MAX_HEIGHT       ]  
#    set_instance_parameter ${ctrl_name} WZD_MAX_BUFFER_NUM           [ get_parameter_value ${ctrl_name}_MAX_BUFFER_NUM   ]  
#    set_instance_parameter ${ctrl_name} WZD_STREAM_PIXEL_SIZE        [ get_parameter_value ${ctrl_name}_STREAM_PIXEL_SIZE   ]
#    set_instance_parameter ${ctrl_name} WZD_STREAM_PIXEL_FORMAT      [ get_parameter_value ${ctrl_name}_STREAM_PIXEL_FORMAT ]
#      
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_COLOR             [ get_parameter_value ${ctrl_name}_ENABLE_COLOR     ]
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_DEBUG             [ get_parameter_value ${ctrl_name}_ENABLE_DEBUG     ]
#    # primary                                                        
#    set_instance_parameter ${ctrl_name} WZD_PRIMARY_IMPORT           [ get_parameter_value ${ctrl_name}_PRIMARY_IMPORT ]    
#    set_instance_parameter ${ctrl_name} WZD_PRIMARY_EXPORT           [ get_parameter_value ${ctrl_name}_PRIMARY_EXPORT ]    
#    set_instance_parameter ${ctrl_name} WZD_PRIMARY_ENABLE_RUNTIME   [ get_parameter_value ${ctrl_name}_PRIMARY_ENABLE_RUNTIME ]    
#    set_instance_parameter ${ctrl_name} WZD_PRIMARY_NUMBER           [ get_parameter_value ${ctrl_name}_PRIMARY_NUMBER         ]  
#    # primary def                                                    
#    set_instance_parameter ${ctrl_name} WZD_FRAME_PIXEL_FORMAT          [ get_parameter_value ${ctrl_name}_FRAME_PIXEL_FORMAT  ]  
#    set_instance_parameter ${ctrl_name} WZD_ADDRESS8                 [ get_parameter_value ${ctrl_name}_ADDRESS8         ]  
#    set_instance_parameter ${ctrl_name} WZD_use_auto_stride          [ get_parameter_value ${ctrl_name}_use_auto_stride  ]  
#    set_instance_parameter ${ctrl_name} WZD_hstride8_user            [ get_parameter_value ${ctrl_name}_hstride8_user    ]  
#    set_instance_parameter ${ctrl_name} WZD_vstride8_user            [ get_parameter_value ${ctrl_name}_vstride8_user    ]      
#    # primary sync                                                   
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_ANIM         [ get_parameter_value ${ctrl_name}_ENABLE_ANIM  ]
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_LOCK         [ get_parameter_value ${ctrl_name}_ENABLE_LOCK  ]
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_RATE         [ get_parameter_value ${ctrl_name}_ENABLE_RATE  ]
#    set_instance_parameter ${ctrl_name} WZD_LOCK_MODE           [ get_parameter_value ${ctrl_name}_LOCK_MODE    ]
#    set_instance_parameter ${ctrl_name} WZD_LOCK_GENE           [ get_parameter_value ${ctrl_name}_LOCK_GENE    ]
#    set_instance_parameter ${ctrl_name} WZD_LOCK_DELAY          [ get_parameter_value ${ctrl_name}_LOCK_DELAY   ]
#    set_instance_parameter ${ctrl_name} WZD_RATE_BUFFER         [ get_parameter_value ${ctrl_name}_RATE_BUFFER  ]
#    set_instance_parameter ${ctrl_name} WZD_RATE_REPEAT         [ get_parameter_value ${ctrl_name}_RATE_REPEAT  ]
#    set_instance_parameter ${ctrl_name} WZD_RATE_TOTAL          [ get_parameter_value ${ctrl_name}_RATE_TOTAL   ]
#    # optimizations              
#    set_instance_parameter ${ctrl_name} WZD_CMD_ENABLE_LOOPBACK      [ get_parameter_value ${ctrl_name}_CMD_ENABLE_LOOPBACK      ]
#    set_instance_parameter ${ctrl_name} WZD_CMD_ENABLE_FILLCOLOR     [ get_parameter_value ${ctrl_name}_CMD_ENABLE_FILLCOLOR     ]
#    set_instance_parameter ${ctrl_name} WZD_CMD_ENABLE_SPAN2D        [ get_parameter_value ${ctrl_name}_CMD_ENABLE_SPAN2D        ]
#    set_instance_parameter ${ctrl_name} WZD_CMD_ENABLE_SPAN_POSITION [ get_parameter_value ${ctrl_name}_CMD_ENABLE_SPAN_POSITION ]
#    set_instance_parameter ${ctrl_name} WZD_CMD_ENABLE_SPAN_CLIPPING [ get_parameter_value ${ctrl_name}_CMD_ENABLE_SPAN_CLIPPING ]
#    set_instance_parameter ${ctrl_name} WZD_CMD_ENABLE_SPAN_OVERLAP  [ get_parameter_value ${ctrl_name}_CMD_ENABLE_SPAN_OVERLAP  ]
#    set_instance_parameter ${ctrl_name} WZD_CMD_MAX_PENDING_LOG2     [ get_parameter_value ${ctrl_name}_CMD_MAX_PENDING_LOG2     ]
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_ALIGN_SPAN        [ get_parameter_value ${ctrl_name}_ENABLE_ALIGN_SPAN        ]
#    set_instance_parameter ${ctrl_name} WZD_ENABLE_ALIGN_MEMORY      [ get_parameter_value ${ctrl_name}_ENABLE_ALIGN_MEMORY      ]
#    set_instance_parameter ${ctrl_name} WZD_COLOR_ENABLE_EXTENDED    [ get_parameter_value ${ctrl_name}_COLOR_ENABLE_EXTENDED    ]
#    set_instance_parameter ${ctrl_name} WZD_COLOR_ENABLE_LUT         [ get_parameter_value ${ctrl_name}_COLOR_ENABLE_LUT         ]
#    set_instance_parameter ${ctrl_name} WZD_CLUT_COLOR_NUM           [ get_parameter_value ${ctrl_name}_CLUT_COLOR_NUM           ]
#    set_instance_parameter ${ctrl_name} WZD_COLOR_ENABLE_PREMULTIPLY [ get_parameter_value ${ctrl_name}_COLOR_ENABLE_PREMULTIPLY ]
#    set_instance_parameter ${ctrl_name} WZD_COLOR_ENABLE_BPP124      [ get_parameter_value ${ctrl_name}_COLOR_ENABLE_BPP124      ]
#    set_instance_parameter ${ctrl_name} WZD_COLOR_ENABLE_BPP8        [ get_parameter_value ${ctrl_name}_COLOR_ENABLE_BPP8        ] 
#    set_instance_parameter ${ctrl_name} WZD_COLOR_ENABLE_BPP16       [ get_parameter_value ${ctrl_name}_COLOR_ENABLE_BPP16       ]
#    set_instance_parameter ${ctrl_name} WZD_COLOR_ENABLE_BPP24       [ get_parameter_value ${ctrl_name}_COLOR_ENABLE_BPP24       ]
#    set_instance_parameter ${ctrl_name} WZD_COLOR_ENABLE_BPP32       [ get_parameter_value ${ctrl_name}_COLOR_ENABLE_BPP32       ]
#
#    # dma              
#    surface_ctrl_connect_parameters_rw $ctrl_name 0
#    surface_ctrl_connect_parameters_rw $ctrl_name 1
# 
#  }
#
#
#  proc surface_ctrl_add_parameters_color { is_core ctrl_name inst_gui_name } {
#
#    if {$is_core == 1} { 
#      set param_name "WZD"
#    } else { 
#      set param_name ${ctrl_name} 
#    }
#
#    set COLOR_ENABLE_EXTENDED     ${param_name}_COLOR_ENABLE_EXTENDED   
#    set COLOR_ENABLE_LUT          ${param_name}_COLOR_ENABLE_LUT   
#    set CLUT_COLOR_NUM            ${param_name}_CLUT_COLOR_NUM   
#    set COLOR_ENABLE_PREMULTIPLY  ${param_name}_COLOR_ENABLE_PREMULTIPLY
#    set COLOR_ENABLE_BPP124       ${param_name}_COLOR_ENABLE_BPP124       
#    set COLOR_ENABLE_BPP8         ${param_name}_COLOR_ENABLE_BPP8       
#    set COLOR_ENABLE_BPP16        ${param_name}_COLOR_ENABLE_BPP16      
#    set COLOR_ENABLE_BPP24        ${param_name}_COLOR_ENABLE_BPP24      
#    set COLOR_ENABLE_BPP32        ${param_name}_COLOR_ENABLE_BPP32      
#
#    add_parameter          $COLOR_ENABLE_PREMULTIPLY  INTEGER             1
#    set_parameter_property $COLOR_ENABLE_PREMULTIPLY  DISPLAY_NAME        "Use alpha-premultiplied normalization (Reader only)" 
#    set_parameter_property $COLOR_ENABLE_PREMULTIPLY  DISPLAY_HINT        boolean 
#  # set_parameter_property $COLOR_ENABLE_PREMULTIPLY  AFFECTS_ELABORATION true        
#    set_parameter_property $COLOR_ENABLE_PREMULTIPLY  HDL_PARAMETER true
#
#    add_parameter          $COLOR_ENABLE_EXTENDED INTEGER 0
#    set_parameter_property $COLOR_ENABLE_EXTENDED DISPLAY_NAME "Support for extended color formats" 
#    set_parameter_property $COLOR_ENABLE_EXTENDED DISPLAY_HINT boolean
#    set_parameter_property $COLOR_ENABLE_EXTENDED DESCRIPTION "extend default {A,X}RGB support to {A,X}BGR, RGB{A,X} and BGR{A,X} color channels orderings" 
#  # set_parameter_property $COLOR_ENABLE_EXTENDED VISIBLE false        
#    set_parameter_property $COLOR_ENABLE_EXTENDED HDL_PARAMETER true
#
#    add_parameter          $COLOR_ENABLE_LUT INTEGER 0
#    set_parameter_property $COLOR_ENABLE_LUT DISPLAY_NAME "Support for indexed color format (Reader only)";
#    set_parameter_property $COLOR_ENABLE_LUT DISPLAY_HINT boolean
#    set_parameter_property $COLOR_ENABLE_LUT DESCRIPTION "Turn on to enable support for color formats using color palettes";
#    set_parameter_property $COLOR_ENABLE_LUT HDL_PARAMETER true
#
#    add_parameter          $CLUT_COLOR_NUM INTEGER 256
#    set_parameter_property $CLUT_COLOR_NUM DISPLAY_NAME "Number of LUT colors";
#    set_parameter_property $CLUT_COLOR_NUM ALLOWED_RANGES {16,32,64,128,256,512,1024,2048}
#    set_parameter_property $CLUT_COLOR_NUM DESCRIPTION "Palette capacity in number of 24-bits colors";
##   set_parameter_property $CLUT_COLOR_NUM VISIBLE true 
#    set_parameter_property $CLUT_COLOR_NUM ENABLED true
#    set_parameter_property $CLUT_COLOR_NUM HDL_PARAMETER true
#                                                                                                        
#    add_parameter          $COLOR_ENABLE_BPP124 INTEGER       0
#    set_parameter_property $COLOR_ENABLE_BPP124 DISPLAY_NAME  "Support <8 bpp" 
#    set_parameter_property $COLOR_ENABLE_BPP124 DISPLAY_HINT  boolean 
#    set_parameter_property $COLOR_ENABLE_BPP124 HDL_PARAMETER true
#                                                
#    add_parameter          $COLOR_ENABLE_BPP8   INTEGER       1
#    set_parameter_property $COLOR_ENABLE_BPP8   DISPLAY_NAME  "Support  8 bpp" 
#    set_parameter_property $COLOR_ENABLE_BPP8   DISPLAY_HINT  boolean 
#    set_parameter_property $COLOR_ENABLE_BPP8   HDL_PARAMETER true
#                            
#    add_parameter          $COLOR_ENABLE_BPP16  INTEGER       1
#    set_parameter_property $COLOR_ENABLE_BPP16  DISPLAY_NAME  "Support 16 bpp" 
#    set_parameter_property $COLOR_ENABLE_BPP16  DISPLAY_HINT  boolean 
#    set_parameter_property $COLOR_ENABLE_BPP16  HDL_PARAMETER true
#                            
#    add_parameter          $COLOR_ENABLE_BPP24  INTEGER       1
#    set_parameter_property $COLOR_ENABLE_BPP24  DISPLAY_NAME  "Support 24 bpp" 
#    set_parameter_property $COLOR_ENABLE_BPP24  DISPLAY_HINT  boolean 
#    set_parameter_property $COLOR_ENABLE_BPP24  HDL_PARAMETER true
#                             
#    add_parameter          $COLOR_ENABLE_BPP32  INTEGER       1
#    set_parameter_property $COLOR_ENABLE_BPP32  DISPLAY_NAME  "support 32 bpp" 
#    set_parameter_property $COLOR_ENABLE_BPP32  DISPLAY_HINT  boolean 
#    set_parameter_property $COLOR_ENABLE_BPP32  HDL_PARAMETER true
#
#    add_display_item $inst_gui_name $COLOR_ENABLE_PREMULTIPLY PARAMETER
#    add_display_item $inst_gui_name $COLOR_ENABLE_EXTENDED    PARAMETER
#    add_display_item $inst_gui_name $COLOR_ENABLE_LUT         PARAMETER
#    add_display_item $inst_gui_name $CLUT_COLOR_NUM           PARAMETER    
#    add_display_item $inst_gui_name $COLOR_ENABLE_BPP124      PARAMETER
#    add_display_item $inst_gui_name $COLOR_ENABLE_BPP8        PARAMETER
#    add_display_item $inst_gui_name $COLOR_ENABLE_BPP16       PARAMETER
#    add_display_item $inst_gui_name $COLOR_ENABLE_BPP24       PARAMETER
#    add_display_item $inst_gui_name $COLOR_ENABLE_BPP32       PARAMETER
#
#  }
#
#
#  proc surface_ctrl_add_parameters_opti { is_core ctrl_name ctrl_id inst_gui_name } {
#
#    if {$is_core == 1} { 
#      set param_name "WZD"
#    } else { 
#      set param_name ${ctrl_name} 
#    }
#
#    set CMD_ENABLE_LOOPBACK       ${param_name}_CMD_ENABLE_LOOPBACK    
#    set CMD_ENABLE_FILLCOLOR      ${param_name}_CMD_ENABLE_FILLCOLOR     
#    set CMD_ENABLE_SPAN2D         ${param_name}_CMD_ENABLE_SPAN2D
#    set CMD_ENABLE_SPAN_POSITION  ${param_name}_CMD_ENABLE_SPAN_POSITION
#    set CMD_ENABLE_SPAN_CLIPPING  ${param_name}_CMD_ENABLE_SPAN_CLIPPING
#    set CMD_ENABLE_SPAN_OVERLAP   ${param_name}_CMD_ENABLE_SPAN_OVERLAP
#    set CMD_MAX_PENDING_LOG2      ${param_name}_CMD_MAX_PENDING_LOG2
#    set ENABLE_ALIGN_SPAN         ${param_name}_ENABLE_ALIGN_SPAN
#    set ENABLE_ALIGN_MEMORY       ${param_name}_ENABLE_ALIGN_MEMORY
#
#
#    add_parameter          $CMD_ENABLE_LOOPBACK  INTEGER             1
#    set_parameter_property $CMD_ENABLE_LOOPBACK  DISPLAY_NAME        "support for loopback" 
#    set_parameter_property $CMD_ENABLE_LOOPBACK  DISPLAY_HINT        boolean 
#  # set_parameter_property $CMD_ENABLE_LOOPBACK  VISIBLE             false        
#  # set_parameter_property $CMD_ENABLE_LOOPBACK  AFFECTS_ELABORATION true        
#    set_parameter_property $CMD_ENABLE_LOOPBACK  HDL_PARAMETER true
#
#    add_parameter          $CMD_ENABLE_FILLCOLOR INTEGER             1
#    set_parameter_property $CMD_ENABLE_FILLCOLOR DISPLAY_NAME        "support for fillcolor" 
#    set_parameter_property $CMD_ENABLE_FILLCOLOR DISPLAY_HINT        boolean 
#  # set_parameter_property $CMD_ENABLE_FILLCOLOR VISIBLE             false        
#  # set_parameter_property $CMD_ENABLE_FILLCOLOR AFFECTS_ELABORATION true        
#    set_parameter_property $CMD_ENABLE_FILLCOLOR HDL_PARAMETER true
#                                     
#    add_parameter          $CMD_ENABLE_SPAN2D  INTEGER             1
#    set_parameter_property $CMD_ENABLE_SPAN2D  DISPLAY_NAME        "support for 2d transfers" 
#    set_parameter_property $CMD_ENABLE_SPAN2D  DISPLAY_HINT        boolean 
#  # set_parameter_property $CMD_ENABLE_SPAN2D  VISIBLE             false        
#  # set_parameter_property $CMD_ENABLE_SPAN2D  AFFECTS_ELABORATION true        
#    set_parameter_property $CMD_ENABLE_SPAN2D  HDL_PARAMETER true
#
#    add_parameter          $CMD_ENABLE_SPAN_POSITION  INTEGER       1
#    set_parameter_property $CMD_ENABLE_SPAN_POSITION  DISPLAY_NAME  "support for span position" 
#    set_parameter_property $CMD_ENABLE_SPAN_POSITION  DISPLAY_HINT  boolean 
#    set_parameter_property $CMD_ENABLE_SPAN_POSITION  HDL_PARAMETER true
#
#    add_parameter          $CMD_ENABLE_SPAN_CLIPPING  INTEGER       1
#    set_parameter_property $CMD_ENABLE_SPAN_CLIPPING  DISPLAY_NAME  "support for span clipping" 
#    set_parameter_property $CMD_ENABLE_SPAN_CLIPPING  DISPLAY_HINT  boolean 
#    set_parameter_property $CMD_ENABLE_SPAN_CLIPPING  HDL_PARAMETER true
#
#    add_parameter          $CMD_ENABLE_SPAN_OVERLAP  INTEGER       1
#    set_parameter_property $CMD_ENABLE_SPAN_OVERLAP  DISPLAY_NAME  "support for span overlap" 
#    set_parameter_property $CMD_ENABLE_SPAN_OVERLAP  DISPLAY_HINT  boolean 
#    set_parameter_property $CMD_ENABLE_SPAN_OVERLAP  HDL_PARAMETER true
#  
#    add_parameter          $CMD_MAX_PENDING_LOG2  INTEGER             1
#    set_parameter_property $CMD_MAX_PENDING_LOG2  DISPLAY_NAME        "max number of pending commands" 
#    set_parameter_property $CMD_MAX_PENDING_LOG2  ALLOWED_RANGES     {0:8} 
#  # set_parameter_property $CMD_MAX_PENDING_LOG2  VISIBLE             false        
#  # set_parameter_property $CMD_MAX_PENDING_LOG2  AFFECTS_ELABORATION true        
#    set_parameter_property $CMD_MAX_PENDING_LOG2  HDL_PARAMETER true
#
#    add_parameter          $ENABLE_ALIGN_SPAN   INTEGER       1
#    set_parameter_property $ENABLE_ALIGN_SPAN   DISPLAY_NAME  "support for stream data alignment" 
#    set_parameter_property $ENABLE_ALIGN_SPAN   DISPLAY_HINT  boolean 
#    set_parameter_property $ENABLE_ALIGN_SPAN   HDL_PARAMETER true
#                            
#    add_parameter          $ENABLE_ALIGN_MEMORY INTEGER       1
#    set_parameter_property $ENABLE_ALIGN_MEMORY DISPLAY_NAME  "support for memory data alignment" 
#    set_parameter_property $ENABLE_ALIGN_MEMORY DISPLAY_HINT  boolean 
#    set_parameter_property $ENABLE_ALIGN_MEMORY HDL_PARAMETER true
#
#                              
#    add_display_item $inst_gui_name $CMD_ENABLE_LOOPBACK      PARAMETER
#    add_display_item $inst_gui_name $CMD_ENABLE_FILLCOLOR     PARAMETER                            
#    add_display_item $inst_gui_name $CMD_ENABLE_SPAN2D        PARAMETER
#    add_display_item $inst_gui_name $CMD_ENABLE_SPAN_POSITION PARAMETER
#    add_display_item $inst_gui_name $CMD_ENABLE_SPAN_CLIPPING PARAMETER
#    add_display_item $inst_gui_name $CMD_ENABLE_SPAN_OVERLAP  PARAMETER
#    add_display_item $inst_gui_name $CMD_MAX_PENDING_LOG2     PARAMETER
#    add_display_item $inst_gui_name $ENABLE_ALIGN_SPAN        PARAMETER
#    add_display_item $inst_gui_name $ENABLE_ALIGN_MEMORY      PARAMETER
# 
# 
#    set grp_label_color           Colors${ctrl_id}
#
#    add_display_item $inst_gui_name $grp_label_color GROUP        
# 
#    surface_ctrl_add_parameters_color   $is_core   $ctrl_name $grp_label_color
#
#  }
#
# 
#
#  proc surface_ctrl_add_instance { ctrl_name ctrl_id } {
#
#   #set ctrl_name ${ctrl_name}${inst_id}
#    set ctrl_name ${ctrl_name} 
#
#    add_instance  $ctrl_name  imt_surface_ctrl 
#
#    add_connection   cb_inst.out_clk     $ctrl_name.clock  clock ""
#    add_connection   rst_inst.out_reset  $ctrl_name.reset          
#
#    surface_ctrl_connect_parameters $ctrl_name
#
#  }
#
#
# 
#  proc surface_ctrl_validation { is_core ctrl_name ctrl_id } {
#
#
#    set grp_label_primary         Primary${ctrl_id}        
#    set grp_label_definition      Definition${ctrl_id}         
#  # set grp_label_synchronization Synchronization${ctrl_id}
#  # set grp_label_memory          Memory${ctrl_id}         
#  # set grp_label_dma             DMA${ctrl_id}    
#    set grp_label_dma_rd          "DMA Read${ctrl_id}"     
#    set grp_label_dma_wr          "DMA Write${ctrl_id}"    
#    set grp_label_optimizations   Optimizations${ctrl_id}
#  # set grp_label_sync_rd         "Read Buffer${ctrl_id}"    
#  # set grp_label_sync_wr         "Write Buffer${ctrl_id}"  
#
#
#    if {$is_core == 1} { 
#      set param_name "WZD"
#    } else {
#      set param_name $ctrl_name
#    }
# 
#    set ENABLE_PRIMARY           [get_parameter_value ${param_name}_ENABLE_PRIMARY ]               
#  # set PRIMARY_ENABLE_SYNC      [get_parameter_value ${param_name}_PRIMARY_ENABLE_SYNC ]              
#    set ENABLE_READER            [get_parameter_value ${param_name}_ENABLE_READER ]            
#    set ENABLE_WRITER            [get_parameter_value ${param_name}_ENABLE_WRITER ]                   
#    set ENABLE_CSR               [get_parameter_value ${param_name}_ENABLE_CSR ]      
#    set PRIMARY_ENABLE_RUNTIME   [get_parameter_value ${param_name}_PRIMARY_ENABLE_RUNTIME ]            
#  # set PRIMARY_REDUCED_READBACK [get_parameter_value ${param_name}_PRIMARY_REDUCED_READBACK ]            
#    set PRIMARY_IMPORT           [get_parameter_value ${param_name}_PRIMARY_IMPORT ]               
#    set PRIMARY_EXPORT           [get_parameter_value ${param_name}_PRIMARY_EXPORT ]              
#    set PRIMARY_NUMBER           [get_parameter_value ${param_name}_PRIMARY_NUMBER ]            
#                                   
#
#    if { ${ENABLE_PRIMARY} == 1 } {
#      set_display_item_property $grp_label_primary VISIBLE true    
#    } else { 
#      set_display_item_property $grp_label_primary VISIBLE false    
#    }
#
#
#    if { $PRIMARY_IMPORT == 1 } {
#      set_parameter_property ${param_name}_PRIMARY_EXPORT      VISIBLE false     
#      set_parameter_property ${param_name}_PRIMARY_NUMBER      VISIBLE false     
#    # set_parameter_property ${param_name}_PRIMARY_ENABLE_SYNC VISIBLE false     
#    } else { 
#      set_parameter_property ${param_name}_PRIMARY_EXPORT      VISIBLE true    
#      set_parameter_property ${param_name}_PRIMARY_NUMBER      VISIBLE true    
#    # set_parameter_property ${param_name}_PRIMARY_ENABLE_SYNC VISIBLE true    
#    }
#
#
#    set_parameter_property ${param_name}_LOCK_DELAY     VISIBLE false
#
#    # sync imported     
#    if { $PRIMARY_IMPORT == 1 } {
#
#      set_parameter_property ${param_name}_ENABLE_ANIM    VISIBLE false  
#      set_parameter_property ${param_name}_ENABLE_LOCK    VISIBLE false
#      set_parameter_property ${param_name}_ENABLE_RATE    VISIBLE false
#      set_parameter_property ${param_name}_LOCK_MODE      VISIBLE false
#      set_parameter_property ${param_name}_LOCK_GENE      VISIBLE false
#    # set_parameter_property ${param_name}_LOCK_DELAY     VISIBLE false
#      set_parameter_property ${param_name}_RATE_BUFFER    VISIBLE false
#      set_parameter_property ${param_name}_RATE_REPEAT    VISIBLE false
#      set_parameter_property ${param_name}_RATE_TOTAL     VISIBLE false
#
#    } else { 
#
#      set_parameter_property ${param_name}_ENABLE_ANIM    VISIBLE true  
#      set_parameter_property ${param_name}_ENABLE_LOCK    VISIBLE true
#      set_parameter_property ${param_name}_ENABLE_RATE    VISIBLE true
#
#
#      if { [ get_parameter_value ${param_name}_LOCK_MODE ] == 3 } {
#        set_parameter_property ${param_name}_LOCK_DELAY ENABLED true        
#      } else {
#        set_parameter_property ${param_name}_LOCK_DELAY ENABLED false        
#      }
#
#      # lock parameters
#      if { [ get_parameter_value ${param_name}_ENABLE_LOCK ] == 1 && [ get_parameter_value ${param_name}_PRIMARY_ENABLE_RUNTIME ] == 0 } {        
#        set_parameter_property ${param_name}_LOCK_MODE    VISIBLE true
#        set_parameter_property ${param_name}_LOCK_GENE    VISIBLE true
#      # set_parameter_property ${param_name}_LOCK_DELAY   VISIBLE true        
#      } else {                                                 
#        set_parameter_property ${param_name}_LOCK_MODE    VISIBLE false
#        set_parameter_property ${param_name}_LOCK_GENE    VISIBLE false
#      # set_parameter_property ${param_name}_LOCK_DELAY   VISIBLE false        
#      }
#
#      # rate used by animations or genlocking
#      if { [ get_parameter_value ${param_name}_ENABLE_ANIM ] == 0 && [ get_parameter_value ${param_name}_ENABLE_LOCK ] == 0 } {        
#        set_parameter_property ${param_name}_ENABLE_RATE   ENABLED false	
#        set_parameter_property ${param_name}_RATE_BUFFER   VISIBLE false
#        set_parameter_property ${param_name}_RATE_REPEAT   VISIBLE false
#        set_parameter_property ${param_name}_RATE_TOTAL    VISIBLE false
#      } else {                                                  
#        set_parameter_property ${param_name}_ENABLE_RATE   ENABLED true
#        
#        if { [ get_parameter_value ${param_name}_PRIMARY_ENABLE_RUNTIME ] == 0 && [ get_parameter_value ${param_name}_ENABLE_RATE ] == 1 } {
#          set_parameter_property ${param_name}_RATE_BUFFER VISIBLE true
#          set_parameter_property ${param_name}_RATE_REPEAT VISIBLE true
#          set_parameter_property ${param_name}_RATE_TOTAL  VISIBLE true
#        } else {
#          set_parameter_property ${param_name}_RATE_BUFFER VISIBLE false
#          set_parameter_property ${param_name}_RATE_REPEAT VISIBLE false
#          set_parameter_property ${param_name}_RATE_TOTAL  VISIBLE false
#        }
#      }
#
#    }
#                	    	
#    if { ${ENABLE_READER} == 0 } {
#      set_display_item_property $grp_label_dma_rd  VISIBLE false   
#    } else {
#      set_display_item_property $grp_label_dma_rd  VISIBLE true   
#    }
#
#    if { ${ENABLE_WRITER} == 0 } {
#      set_display_item_property $grp_label_dma_wr  VISIBLE false   
#    } else {
#      set_display_item_property $grp_label_dma_wr  VISIBLE true   
#    }
#
#    surface_def_validation  $is_core $ctrl_name $ctrl_id 
#
#    if { $ENABLE_CSR == 0 && $PRIMARY_ENABLE_RUNTIME == 1 } {
#      send_message error "You have to turn On Run-time control in order to enable Run-time configuration"
#    }
#
#    if { $PRIMARY_ENABLE_RUNTIME == 0 && $PRIMARY_NUMBER > 1 } {
#      send_message error "Turn On Run-time configuration to support more than 1 primary surface"
#    }  
#
#  }



# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- DMA                                                                                        --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------


#  proc surface_add_parameters {gui_group_name} {
#
#    add_parameter          WZD_SFC_CTRL_EXTERN INTEGER 0
#    set_parameter_property WZD_SFC_CTRL_EXTERN DISPLAY_NAME "Shared dma" 
#    set_parameter_property WZD_SFC_CTRL_EXTERN DISPLAY_HINT boolean
#    set_parameter_property WZD_SFC_CTRL_EXTERN DESCRIPTION " ";
#    set_parameter_property WZD_SFC_CTRL_EXTERN AFFECTS_ELABORATION true        
#    set_parameter_property WZD_SFC_CTRL_EXTERN ENABLED false
#  
#    add_display_item $gui_group_name WZD_SFC_CTRL_EXTERN PARAMETER
#
#  }
#

# proc add_surface_dma_parameters_groups {is_write inst_name inst_gui_name} {
# 
#   add_display_item "Surfaces" $inst_gui_name GROUP tab 
# 
#   # dma Read 
#   if { ${is_write} == 0 } {  
# 
#     add_display_item $inst_gui_name "Data2Color#" GROUP
#     add_display_item $inst_gui_name "Memory2Stream#" GROUP
#   
#   # dma Write 
#   } else {
# 
#     add_display_item $inst_gui_name "Color2Data#" GROUP
#     add_display_item $inst_gui_name "Stream2Memory#" GROUP
#   
#   } 
# }


# # <is_core>  0=host / 1=surface controller
# # <is_write> 0=read / 1=write
# proc surface_dma_add_parameters_st {is_core is_write ctrl_name inst_name inst_gui_name} {
#
#  #set inst_name ${ctrl_name}_${inst_name}${inst_id}
#   set inst_name ${ctrl_name}_${inst_name}
# 
# # set NB_MUX      ${inst_name}_NB_MUX
#   set NB_PIXEL    ${inst_name}_NB_PIXEL
# # set COLOR_NUM   ${inst_name}_COLOR_NUM
# # set COLOR_SIZE  ${inst_name}_COLOR_SIZE
#
# # add_parameter          $NB_MUX INTEGER 1
# # set_parameter_property $NB_MUX ALLOWED_RANGES {1:4}
# # set_parameter_property $NB_MUX DISPLAY_NAME "number of channels" 
# # set_parameter_property $NB_MUX DESCRIPTION "  ";
# # set_parameter_property $NB_MUX AFFECTS_ELABORATION true        
# # set_parameter_property $NB_MUX TYPE INTEGER
# # set_parameter_property $NB_MUX UNITS None
# # set_parameter_property $NB_MUX VISIBLE false
# # set_parameter_property $NB_MUX HDL_PARAMETER true
# 
#   add_parameter          $NB_PIXEL INTEGER 1
#   set_parameter_property $NB_PIXEL ALLOWED_RANGES {1,2,4,8,16,32}
#   set_parameter_property $NB_PIXEL DISPLAY_NAME "number of pixels in parallel" 
#   set_parameter_property $NB_PIXEL DESCRIPTION "  ";
#   set_parameter_property $NB_PIXEL AFFECTS_ELABORATION true        
# # set_parameter_property $NB_PIXEL TYPE INTEGER
#   set_parameter_property $NB_PIXEL UNITS None
#   set_parameter_property $NB_PIXEL HDL_PARAMETER true
# 
# # add_parameter          $COLOR_NUM INTEGER 4
# # set_parameter_property $COLOR_NUM ALLOWED_RANGES {1:4} 
# # set_parameter_property $COLOR_NUM DISPLAY_NAME "number of color planes" 
# # set_parameter_property $COLOR_NUM DESCRIPTION "  ";
# # set_parameter_property $COLOR_NUM AFFECTS_ELABORATION true        
# # set_parameter_property $COLOR_NUM TYPE INTEGER
# # set_parameter_property $COLOR_NUM UNITS None
# # set_parameter_property $COLOR_NUM HDL_PARAMETER true
# #
# # add_parameter          $COLOR_SIZE INTEGER 8
# # set_parameter_property $COLOR_SIZE ALLOWED_RANGES {1:32} 
# # set_parameter_property $COLOR_SIZE DISPLAY_NAME "bits per color planes" 
# # set_parameter_property $COLOR_SIZE DESCRIPTION "  ";
# # set_parameter_property $COLOR_SIZE AFFECTS_ELABORATION true        
# # set_parameter_property $COLOR_SIZE TYPE INTEGER
# # set_parameter_property $COLOR_SIZE UNITS None
# # set_parameter_property $COLOR_SIZE HDL_PARAMETER true
#
# # add_display_item $inst_gui_name $NB_MUX     PARAMETER
#   add_display_item $inst_gui_name $NB_PIXEL   PARAMETER
# # add_display_item $inst_gui_name $COLOR_NUM  PARAMETER
# # add_display_item $inst_gui_name $COLOR_SIZE PARAMETER
#
# }



  # <is_core>  0=host / 1=surface controller
  # <is_write> 0=read / 1=write
  proc surface_ctrl_add_parameters_dma {is_core is_write ctrl_name inst_gui_name} {
  
    if {$is_write == 1} { 
      set param_name "WR"
    } else {
      set param_name "RD"
    }
    
    if {$is_core == 1} { 
      set ctrl_name "WZD"
    }  

   #set inst_name ${ctrl_name}_${inst_name}${inst_id}
    set param_name ${ctrl_name}_${param_name} 

   #set ENABLE                ${param_name}_ENABLE  
    set NB_PIXEL              ${param_name}_NB_PIXEL

    set HAS_DEDICATED_CLK     ${param_name}_HAS_DEDICATED_CLK
    set DATA_WIDTH            ${param_name}_DATA_WIDTH
    set ADDRESS8_SIZE            ${param_name}_ADDRESS8_SIZE
    set FIFODEPTH             ${param_name}_FIFODEPTH
    set BURSTLENGTH           ${param_name}_BURSTLENGTH
    set FIFODEPTH_LOG2        ${param_name}_FIFODEPTH_LOG2
    set BURSTLENGTH_LOG2      ${param_name}_BURSTLENGTH_LOG2


  # add_parameter          $ENABLE INTEGER             0
  # set_parameter_property $ENABLE DISPLAY_NAME        "dma enable" 
  # set_parameter_property $ENABLE DISPLAY_HINT        boolean 
  # set_parameter_property $ENABLE AFFECTS_ELABORATION true        
  # if {$is_core == 0} { 
  # set_parameter_property $ENABLE VISIBLE false        
  # }
  # set_parameter_property $ENABLE HDL_PARAMETER true

    add_parameter          $NB_PIXEL INTEGER 1
    set_parameter_property $NB_PIXEL ALLOWED_RANGES {1,2,4,8,16,32}
    set_parameter_property $NB_PIXEL DISPLAY_NAME "number of pixels in parallel" 
    set_parameter_property $NB_PIXEL DESCRIPTION "  ";
    set_parameter_property $NB_PIXEL AFFECTS_ELABORATION true        
  # set_parameter_property $NB_PIXEL TYPE INTEGER
    set_parameter_property $NB_PIXEL UNITS None
    set_parameter_property $NB_PIXEL HDL_PARAMETER true
  
    add_parameter          $HAS_DEDICATED_CLK  INTEGER             1
    set_parameter_property $HAS_DEDICATED_CLK  DISPLAY_NAME        "Dedicated clock domain" 
    set_parameter_property $HAS_DEDICATED_CLK  DISPLAY_HINT        boolean 
    set_parameter_property $HAS_DEDICATED_CLK  AFFECTS_ELABORATION true        
    set_parameter_property $HAS_DEDICATED_CLK  HDL_PARAMETER true
  
    add_parameter          $DATA_WIDTH INTEGER             32
    set_parameter_property $DATA_WIDTH DISPLAY_NAME        "Data width" 
    set_parameter_property $DATA_WIDTH ALLOWED_RANGES      {"32" "64" "128" "256" "512" "1024"}  
    set_parameter_property $DATA_WIDTH AFFECTS_ELABORATION true        
    set_parameter_property $DATA_WIDTH HDL_PARAMETER true
    
    add_parameter          $ADDRESS8_SIZE INTEGER             30
    set_parameter_property $ADDRESS8_SIZE DISPLAY_NAME        "Address width" 
    set_parameter_property $ADDRESS8_SIZE ALLOWED_RANGES      {1:64} 
    set_parameter_property $ADDRESS8_SIZE AFFECTS_ELABORATION true        
    set_parameter_property $ADDRESS8_SIZE HDL_PARAMETER true
    
    add_parameter          $FIFODEPTH INTEGER             256
    set_parameter_property $FIFODEPTH DISPLAY_NAME        "Fifo depth" 
                                                          # !!! do not decrease depth min (=32) due to dcfifo margin
    set_parameter_property $FIFODEPTH ALLOWED_RANGES      {"32" "64" "128" "256" "512" "1024" "2048" "4096"}
    set_parameter_property $FIFODEPTH AFFECTS_ELABORATION true        
  # set_parameter_property $FIFODEPTH HDL_PARAMETER true
        
    add_parameter          $BURSTLENGTH INTEGER           64
    set_parameter_property $BURSTLENGTH DISPLAY_NAME      "Maximum burst length" 
    set_parameter_property $BURSTLENGTH ALLOWED_RANGES    {"2" "4" "8" "16" "32" "64" "128" "256" "512" "1024"}
    set_parameter_property $BURSTLENGTH AFFECTS_ELABORATION true        
  # set_parameter_property $BURSTLENGTH HDL_PARAMETER true
  
    add_parameter          $FIFODEPTH_LOG2 INTEGER        1
    set_parameter_property $FIFODEPTH_LOG2 DISPLAY_NAME   "Fifo depth (log2)" 
    set_parameter_property $FIFODEPTH_LOG2 DERIVED true   
    set_parameter_property $FIFODEPTH_LOG2 HDL_PARAMETER true
    set_parameter_property $FIFODEPTH_LOG2 VISIBLE false
        
    add_parameter          $BURSTLENGTH_LOG2 INTEGER      1
    set_parameter_property $BURSTLENGTH_LOG2 DISPLAY_NAME "Maximum burst length (log2)" 
    set_parameter_property $BURSTLENGTH_LOG2 DERIVED      true        
    set_parameter_property $BURSTLENGTH_LOG2 HDL_PARAMETER true
    set_parameter_property $BURSTLENGTH_LOG2 VISIBLE false
 

  # # dma global 
  # add_display_item $inst_gui_name $ST_NB_PIXEL PARAMETER 
  # add_display_item $inst_gui_name $ST_NB_MUX   PARAMETER 

  # add_display_item $inst_gui_name $COLOR_ENABLE_EXTENDED PARAMETER 

  # if { ${is_write} == 0 } {     
  #   add_display_item $inst_gui_name $ENABLE_PREMULTIPLIED  PARAMETER
  # } 


  # # dma Read 
  # if { ${is_write} == 0 } {     
  #  #set memory_name "Memory Read#${inst_id}"        
  #   set memory_name "Memory Read#${inst_id}"        
  # # dma Write 
  # } else {
  #  #set memory_name "Memory Write#${inst_id}"  
  #   set memory_name "Memory Write#${inst_id}"  
  # } 
     
   #add_display_item $inst_gui_name $memory_name GROUP

   #add_display_item $inst_gui_name $ENABLE             PARAMETER
    add_display_item $inst_gui_name $NB_PIXEL           PARAMETER
    add_display_item $inst_gui_name $HAS_DEDICATED_CLK  PARAMETER
    add_display_item $inst_gui_name $DATA_WIDTH         PARAMETER
    add_display_item $inst_gui_name $ADDRESS8_SIZE         PARAMETER
    add_display_item $inst_gui_name $FIFODEPTH          PARAMETER
    add_display_item $inst_gui_name $FIFODEPTH_LOG2     PARAMETER
    add_display_item $inst_gui_name $BURSTLENGTH        PARAMETER
    add_display_item $inst_gui_name $BURSTLENGTH_LOG2   PARAMETER

  }

 

  
# # set core features restrictions (default is full-features)
# proc surface_dma_set_optimisations { ctrl_name dma_name ena_color cmd_ena_span2d cmd_ena_span_position cmd_max_pending_log2 dat_ena_align_stream dat_ena_align_memory } {
#
#  #set inst_name ${ctrl_name}_${dma_name}${inst_id}
#   set inst_name ${ctrl_name}_${dma_name} 
#
#   set param_name "WZD"
#         
#   set_instance_parameter $inst_name ENABLE_COLOR2             $ena_color 
#   set_instance_parameter $inst_name CMD_ENABLE_SPAN2D        $cmd_ena_span2d 
#   set_instance_parameter $inst_name CMD_ENABLE_SPAN_POSITION $cmd_ena_span_position 
#   set_instance_parameter $inst_name CMD_MAX_PENDING_LOG2     $cmd_max_pending_log2 
#   set_instance_parameter $inst_name ENABLE_ALIGN_SPAN        $dat_ena_align_stream 
#   set_instance_parameter $inst_name ENABLE_ALIGN_MEMORY      $dat_ena_align_memory 
#
# }

  

#  # set color restrictions (default is full-features)
#  # assuming color feature is turned On
#  proc surface_dma_set_color { inst_name inst_id \
#  	                           ena_extended \
#  	                           ena_premultiplied \
#  	                           ena_bpp1  \
#  	                           ena_bpp2  \
#  	                           ena_bpp4  \
#  	                           ena_bpp8  \
#  	                           ena_bpp16 \
#  	                           ena_bpp24 \
#  	                           ena_bpp32 \
#  	                           } {
#
#    set inst_name ${inst_name}${inst_id}
#              
#    set_instance_parameter $inst_name COLOR_ENABLE_EXTENDED    $ena_extended 
#    set_instance_parameter $inst_name COLOR_ENABLE_PREMULTIPLY $ena_premultiplied 
#    set_instance_parameter $inst_name COLOR_ENABLE_BPP1        $ena_bpp1  
#    set_instance_parameter $inst_name COLOR_ENABLE_BPP2        $ena_bpp2  
#    set_instance_parameter $inst_name COLOR_ENABLE_BPP4        $ena_bpp4  
#    set_instance_parameter $inst_name COLOR_ENABLE_BPP8        $ena_bpp8  
#    set_instance_parameter $inst_name COLOR_ENABLE_BPP16       $ena_bpp16 
#    set_instance_parameter $inst_name COLOR_ENABLE_BPP24       $ena_bpp24 
#    set_instance_parameter $inst_name COLOR_ENABLE_BPP32       $ena_bpp32 
# 
#  }


# proc surface_dma_validation {inst_name inst_id} {
#
#   set inst_name ${inst_name}${inst_id}
#
#   set FIFODEPTH   ${inst_name}_FIFODEPTH
#   set BURSTLENGTH ${inst_name}_BURSTLENGTH
#
#   set min_burstlength [ expr int( 2 * [ get_parameter_value $BURSTLENGTH ] ) ]
#   
#   if { [get_parameter_value $FIFODEPTH ] < $min_burstlength} {
#     send_message error "fifo depth must be >= $min_burstlength (must be at least twice the burst length) "
#   }
#
# }


  proc surface_dma_add_interface {is_write ctrl_name } {

    if { ${is_write} == 0 } {  
      set dma_name ${ctrl_name}_rd 
    } else {
      set dma_name ${ctrl_name}_wr 
    }

   #set dma_name ${ctrl_name}_${dma_name} 

    set cmd_name ${dma_name}_cmd 

    add_interface          $cmd_name avalon_streaming start
    set_interface_property $cmd_name dataBitsPerSymbol 384
    set_interface_property $cmd_name errorDescriptor ""
    set_interface_property $cmd_name maxChannel 0
    set_interface_property $cmd_name readyLatency 0
    set_interface_property $cmd_name symbolsPerBeat 1
    set_interface_property $cmd_name ASSOCIATED_CLOCK clock
    set_interface_property $cmd_name ENABLED true
    
    add_interface_port $cmd_name ${cmd_name}_data  data  Output 384
    add_interface_port $cmd_name ${cmd_name}_valid valid Output 1
    add_interface_port $cmd_name ${cmd_name}_ready ready Input  1


    set rsp_name ${dma_name}_rsp 

    add_interface          $rsp_name avalon_streaming end
    set_interface_property $rsp_name dataBitsPerSymbol 256
    set_interface_property $rsp_name errorDescriptor ""
    set_interface_property $rsp_name maxChannel 0
    set_interface_property $rsp_name readyLatency 0
    set_interface_property $rsp_name symbolsPerBeat 1
    set_interface_property $rsp_name ASSOCIATED_CLOCK clock
    set_interface_property $rsp_name ENABLED true
    
    add_interface_port $rsp_name ${rsp_name}_data  data  Input  256
    add_interface_port $rsp_name ${rsp_name}_valid valid Input  1
  # add_interface_port $rsp_name ${rsp_name}_ready ready Output 1


    set dat_name ${dma_name}_dat

    # dma Read 
    if { ${is_write} == 0 } {  

    # set dat_name ${dma_name}_din

      add_interface          $dat_name avalon_streaming end
      set_interface_property $dat_name dataBitsPerSymbol 40
      set_interface_property $dat_name errorDescriptor ""
      set_interface_property $dat_name maxChannel 0
      set_interface_property $dat_name readyLatency 0
      set_interface_property $dat_name symbolsPerBeat -1
      set_interface_property $dat_name ASSOCIATED_CLOCK clock
      
      add_interface_port $dat_name ${dat_name}_data  data          Input  -1
      add_interface_port $dat_name ${dat_name}_valid valid         Input   1
      add_interface_port $dat_name ${dat_name}_ready ready         Output  1
      add_interface_port $dat_name ${dat_name}_sop   startofpacket Input   1
      add_interface_port $dat_name ${dat_name}_eop   endofpacket   Input   1
     #add_interface_port $dat_name ${dat_name}_empty empty         Input  -1
     #add_interface_port $dat_name ${dat_name}_error error         Input  -1

    # dma Write 
    } else {

    # set dat_name ${dma_name}_dout

      add_interface          $dat_name avalon_streaming start
      set_interface_property $dat_name dataBitsPerSymbol 40
      set_interface_property $dat_name errorDescriptor ""
      set_interface_property $dat_name maxChannel 0
      set_interface_property $dat_name readyLatency 0
      set_interface_property $dat_name symbolsPerBeat -1
      set_interface_property $dat_name ASSOCIATED_CLOCK clock
      
      add_interface_port $dat_name ${dat_name}_data    data          Output -1
      add_interface_port $dat_name ${dat_name}_valid   valid         Output  1
      add_interface_port $dat_name ${dat_name}_ready   ready         Input   1
      add_interface_port $dat_name ${dat_name}_sop     startofpacket Output  1
      add_interface_port $dat_name ${dat_name}_eop     endofpacket   Output  1
     #add_interface_port $dat_name ${dat_name}_empty   empty         Output -1
     #add_interface_port $dat_name ${dat_name}_error   error         Output -1
     #add_interface_port $dat_name ${dat_name}_channel channel       Output -1
 
    } 
      
  }


# proc surface_ipcore_dma_set_enable { is_write ctrl_name enable} {  
#
#   if { ${is_write} == 0 } {     
#     set sig_name "rd"
#   } else {
#     set sig_name "wr"
#   } 
#
#   set_interface_property ${ctrl_name}_${sig_name}_cmd ENABLED $enable
#   set_interface_property ${ctrl_name}_${sig_name}_dat ENABLED $enable
#
# }


# # set dma streaming interface
# proc surface_dma_set_interface { ctrl_name is_write channel_num pixel_num color_num color_size } {  
#
#   if { ${is_write} == 0 } {     
#     set sig_name "rd"
#     set param_name "WZD_RD"
#   } else {
#     set sig_name "wr"
#     set param_name "WZD_WR"
#   } 
#
# # set ctrl_name ${ctrl_name}${inst_id}
#
#   set_instance_parameter $ctrl_name ${param_name}_NB_MUX     $channel_num 
#   set_instance_parameter $ctrl_name ${param_name}_NB_PIXEL   $pixel_num  
# # set_instance_parameter $ctrl_name ${param_name}_COLOR_NUM  $color_num  
# # set_instance_parameter $ctrl_name ${param_name}_COLOR_SIZE $color_size  
#
# }

 

  # set host streaming interface
                                                     # color_num color_size NOT USED 

  # <cmp_name> : core name
  # <inst_name>: core dma interface name
  proc connect_extern_dma { is_write cmp_name inst_name } {

    add_interface          ${inst_name}_cmd avalon_streaming start
    set_interface_property ${inst_name}_cmd EXPORT_OF ${cmp_name}.${inst_name}_cmd

  # add_interface          ${inst_name}_rsp avalon_streaming end
  # set_interface_property ${inst_name}_rsp EXPORT_OF ${cmp_name}.${inst_name}_rsp
  
    # dma Read 
    if { ${is_write} == 0 } {  
      add_interface           ${inst_name}_dat  avalon_streaming end
    # add_interface           ${inst_name}_din  avalon_streaming end
    # set_interface_property  ${inst_name}_din  EXPORT_OF ${cmp_name}.${inst_name}_din
    # dma Write                    
    } else {                       
      add_interface           ${inst_name}_dat  avalon_streaming start
    # add_interface           ${inst_name}_dout  avalon_streaming start
    # set_interface_property  ${inst_name}_dout  EXPORT_OF ${cmp_name}.${inst_name}_dout
    } 

    set_interface_property  ${inst_name}_dat  EXPORT_OF ${cmp_name}.${inst_name}_dat
     
  }
  

  proc connect_intern_dma { is_write cmp_name ctrl_name } {

    if { ${is_write} == 0 } {     
      set sig_name "rd"
      set param_name "RD"
     #set master_name "master_read"

    } else {
      set sig_name "wr"
      set param_name "WR"
     #set master_name "master_write"
    } 


  # set cmp_name2       ${cmp_name}.${inst_name}

   #set inst_name       ${ctrl_name}_${inst_name}${inst_id}
   #set inst_name       ${ctrl_name}_${dma_name}
    
    set cmp_param_name ${ctrl_name}_${param_name}
          
    set HAS_DEDICATED_CLK     ${cmp_param_name}_HAS_DEDICATED_CLK
  # set DATA_WIDTH            ${cmp_param_name}_DATA_WIDTH
  # set ADDRESS8_SIZE            ${cmp_param_name}_ADDRESS8_SIZE
    set FIFODEPTH             ${cmp_param_name}_FIFODEPTH
    set BURSTLENGTH           ${cmp_param_name}_BURSTLENGTH
  # set FIFODEPTH_LOG2        ${cmp_param_name}_FIFODEPTH_LOG2
  # set BURSTLENGTH_LOG2      ${cmp_param_name}_BURSTLENGTH_LOG2

    set min_burstlength [ expr int( 2 * [ get_parameter_value $BURSTLENGTH ] ) ]
    
    if { [get_parameter_value $FIFODEPTH ] < $min_burstlength} {
      send_message error "fifo depth must be >= $min_burstlength (must be at least twice the burst length) "
    }
  # if { [get_parameter_value $FIFODEPTH_LOG2 ] < [get_parameter_value $BURSTLENGTH_LOG2 ] } {
  #   send_message error "fifo depth must be at least twice the burst length "
  # }

  # add_instance  $inst_name  imt_surface_dma_core 

     
   #surface_dma_set_interface $ctrl_name $is_write 1 $st_pixel_num $st_color_num $st_color_size  
    	   
    # ex: sfc_rd_dma
    set cmp_dma_if_name ${ctrl_name}_${sig_name}

    # host to sfctrl
    add_connection $cmp_name.${cmp_dma_if_name}_cmd  $ctrl_name.${sig_name}_cmd  
    # sfctrl to host  
    add_connection $ctrl_name.${sig_name}_rsp $cmp_name.${cmp_dma_if_name}_rsp    

    if {[ get_parameter_value $HAS_DEDICATED_CLK ] == 1} {  
      add_interface          $ctrl_name\_${sig_name}_dma_clock clock end
      set_interface_property $ctrl_name\_${sig_name}_dma_clock EXPORT_OF $ctrl_name.${sig_name}_dma_clock
    } else {
      add_connection cb_inst.out_clk $ctrl_name.${sig_name}_dma_clock clock ""
    } 

    add_interface          $ctrl_name\_${sig_name}_dma  avalon start
    set_interface_property $ctrl_name\_${sig_name}_dma  EXPORT_OF $ctrl_name.${sig_name}_dma


    if { ${is_write} == 0 } {  
      # read dout => from surface_ctrl to ip_core 
      add_connection $ctrl_name.${sig_name}_dat $cmp_name.${cmp_dma_if_name}_dat   
    } else {
      # write din => from ip_core to surface_ctrl   
      add_connection $cmp_name.${cmp_dma_if_name}_dat $ctrl_name.${sig_name}_dat                  
    } 
      
  }
            



# # ------------------------------------------------------------------------------------------------
# # --                                                                                            --
# # -- CSR                                                                                 --
# # --                                                                                            --
# # ------------------------------------------------------------------------------------------------
# 
# 
#   # used by ip_core to address the surface controller
#   proc surface_csr_add_interface { ctrl_name } {
# 
#     set csr_name ${ctrl_name}_csr 
# 
#     add_interface $csr_name avalon start
#   # set_interface_property $csr_name addressAlignment DYNAMIC
#     set_interface_property $csr_name addressUnits WORDS
#     set_interface_property $csr_name associatedClock clock
#     set_interface_property $csr_name associatedReset reset
#     set_interface_property $csr_name burstOnBurstBoundariesOnly false
#   # set_interface_property $csr_name explicitAddressSpan 0
#     set_interface_property $csr_name holdTime 0
#   # set_interface_property $csr_name isMemoryDevice false
#   # set_interface_property $csr_name isNonVolatileStorage false
#     set_interface_property $csr_name linewrapBursts false
#     set_interface_property $csr_name maximumPendingReadTransactions 0
#   # set_interface_property $csr_name printableDevice false
#     set_interface_property $csr_name readLatency 0
#     set_interface_property $csr_name readWaitTime 1
#     set_interface_property $csr_name setupTime 0
#     set_interface_property $csr_name timingUnits Cycles
#     set_interface_property $csr_name writeWaitTime 0
#     
#     set_interface_property $csr_name ENABLED true
#     
#     add_interface_port $csr_name ${csr_name}_readdata      readdata      Input  32
#     add_interface_port $csr_name ${csr_name}_writedata     writedata     Output 32
#     add_interface_port $csr_name ${csr_name}_address       address       Output 5
#     add_interface_port $csr_name ${csr_name}_waitrequest_n waitrequest_n Input  1
#     add_interface_port $csr_name ${csr_name}_write         write         Output 1
#     add_interface_port $csr_name ${csr_name}_read          read          Output 1
# 
#   }
#   
#  
#   proc connect_csr { cmp_name ctrl_name } {
# 
#     add_connection $cmp_name.${ctrl_name}_csr $ctrl_name.csr      
# 
#   }
# 
# 
# 
#   proc surface_exp_add_interface { ctrl_name } {
# 
#     set exp_name ${ctrl_name}_exp 
# 
#     add_interface $exp_name conduit end   
#     # direction suffixes are relatively to the surface controller
#     add_interface_port $exp_name ${exp_name}_i export Output 32 
#     add_interface_port $exp_name ${exp_name}_o export Input  32 
# 
#   }
# 
# 
#   proc connect_exp { cmp_name ctrl_name } {
# 
#     add_connection $cmp_name.${ctrl_name}_exp $ctrl_name.exp      
# 
#   }
# 
 

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Video Synchronization                                                                              --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------


#  proc surface_ctrl_add_parameters_sync_rw { is_core is_write ctrl_name inst_gui_name } {
#  
#    if {$is_core == 1} { 
#      set param_name "WZD"
#    } else {
#      set param_name $ctrl_name
#    }
#  
#    if { ${is_write} == 0 } {     
#      set param_name ${param_name}_RD
#    } else {
#      set param_name ${param_name}_WR
#    } 
#  
#  # set EXT_ENABLE   ${param_name}_EXT_ENABLE           
#  # set EXT_NUMBER   ${param_name}_EXT_NUMBER           
#    set REPEAT       ${param_name}_REPEAT           
#    set TOTAL        ${param_name}_TOTAL           
#  
#  
#  # add_parameter          $EXT_ENABLE INTEGER 1
#  # set_parameter_property $EXT_ENABLE DISPLAY_NAME "use external lock" 
#  # set_parameter_property $EXT_ENABLE DISPLAY_HINT boolean 
#  # set_parameter_property $EXT_ENABLE DESCRIPTION " ";
#  # set_parameter_property $EXT_ENABLE AFFECTS_ELABORATION true        
#  # set_parameter_property $EXT_ENABLE VISIBLE true      
#  # set_parameter_property $EXT_ENABLE HDL_PARAMETER true
#  #
#  # global MAX_SYNC
#  # set val_range "{1:$MAX_SYNC}"
#  #
#  # add_parameter          $EXT_NUMBER INTEGER 1
#  # set_parameter_property $EXT_NUMBER DISPLAY_NAME "Number of interfaces" 
#  # set_parameter_property $EXT_NUMBER ALLOWED_RANGES $val_range
#  # set_parameter_property $EXT_NUMBER DESCRIPTION "  ";
#  # set_parameter_property $EXT_NUMBER AFFECTS_ELABORATION true        
#  # set_parameter_property $EXT_NUMBER VISIBLE true      
#  # set_parameter_property $EXT_NUMBER HDL_PARAMETER true
#  
#    add_parameter          $REPEAT INTEGER 0
#    set_parameter_property $REPEAT DISPLAY_NAME "Repeat count" 
#    set_parameter_property $REPEAT ALLOWED_RANGES {0:255}
#    set_parameter_property $REPEAT DESCRIPTION "  ";
#    set_parameter_property $REPEAT AFFECTS_ELABORATION true        
#    set_parameter_property $REPEAT VISIBLE true      
#    set_parameter_property $REPEAT HDL_PARAMETER true
#  
#    add_parameter          $TOTAL INTEGER 1
#    set_parameter_property $TOTAL DISPLAY_NAME "Total count" 
#    set_parameter_property $TOTAL ALLOWED_RANGES {1:255}
#    set_parameter_property $TOTAL DESCRIPTION "  ";
#    set_parameter_property $TOTAL AFFECTS_ELABORATION true        
#    set_parameter_property $TOTAL VISIBLE true      
#    set_parameter_property $TOTAL HDL_PARAMETER true
#  
#  # add_display_item "${inst_gui_name}" $EXT_ENABLE  PARAMETER
#  # add_display_item "${inst_gui_name}" $EXT_NUMBER  PARAMETER
#    add_display_item "${inst_gui_name}" $REPEAT      PARAMETER
#    add_display_item "${inst_gui_name}" $TOTAL       PARAMETER
#     
#  }

   
 
#  proc surface_ctrl_add_parameters_sync { is_core ctrl_name ctrl_id inst_gui_name } {
# 
#    if {$is_core == 1} { 
#      set param_name "WZD"
#    } else {
#      set param_name $ctrl_name
#    }
#    
#    set ENABLE_ANIM     ${param_name}_ENABLE_ANIM           
#    set ENABLE_LOCK     ${param_name}_ENABLE_LOCK  
#    set LOCK_MODE       ${param_name}_LOCK_MODE 
#    set LOCK_GENE       ${param_name}_LOCK_GENE
#    set LOCK_DELAY      ${param_name}_LOCK_DELAY 
#    set ENABLE_RATE     ${param_name}_ENABLE_RATE           
#    set RATE_BUFFER     ${param_name}_RATE_BUFFER           
#    set RATE_REPEAT     ${param_name}_RATE_REPEAT           
#    set RATE_TOTAL      ${param_name}_RATE_TOTAL           
#
#    add_parameter          $ENABLE_ANIM INTEGER 1
#    set_parameter_property $ENABLE_ANIM DISPLAY_NAME "Support for buffers animation" 
#    set_parameter_property $ENABLE_ANIM DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_ANIM DESCRIPTION " Turn ON to support R/W buffers animations based on circular buffer increment";
#    set_parameter_property $ENABLE_ANIM AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_ANIM VISIBLE true      
#    set_parameter_property $ENABLE_ANIM HDL_PARAMETER true
# 
#    add_parameter          $ENABLE_LOCK INTEGER 1
#    set_parameter_property $ENABLE_LOCK DISPLAY_NAME "Support for buffers genlock" 
#    set_parameter_property $ENABLE_LOCK DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_LOCK DESCRIPTION " Turn ON to support R/W buffers synchronization preventing Surface Reader and Surface Writer operating on the same buffer at the same time";
#    set_parameter_property $ENABLE_LOCK AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_LOCK VISIBLE true      
#    set_parameter_property $ENABLE_LOCK HDL_PARAMETER true
#
#    add_parameter          $LOCK_MODE INTEGER 0
#    set_parameter_property $LOCK_MODE DISPLAY_NAME "Lock mode";
#    set_parameter_property $LOCK_MODE ALLOWED_RANGES {"0:free" "1:rate-controlled" "2:master" "3:master-delay"}
#  # set_parameter_property $LOCK_MODE DISPLAY_HINT radio
#    set_parameter_property $LOCK_MODE DESCRIPTION " ";
#    set_parameter_property $LOCK_MODE AFFECTS_ELABORATION true        
#    set_parameter_property $LOCK_MODE VISIBLE true      
#    set_parameter_property $LOCK_MODE HDL_PARAMETER true
#
#    add_parameter          $LOCK_GENE INTEGER 1
#    set_parameter_property $LOCK_GENE DISPLAY_NAME "Lock generator";
#    set_parameter_property $LOCK_GENE ALLOWED_RANGES {"0:reader" "1:writer"}
#  # set_parameter_property $LOCK_GENE DISPLAY_HINT radio
#    set_parameter_property $LOCK_GENE DESCRIPTION " select the surface producer";
#    set_parameter_property $LOCK_GENE AFFECTS_ELABORATION true        
#    set_parameter_property $LOCK_GENE VISIBLE true      
#    set_parameter_property $LOCK_GENE HDL_PARAMETER true
#
#    add_parameter          $LOCK_DELAY INTEGER 0
#    set_parameter_property $LOCK_DELAY DISPLAY_NAME "Lock delay" 
#    set_parameter_property $LOCK_DELAY ALLOWED_RANGES {0:255}
#    set_parameter_property $LOCK_DELAY DESCRIPTION "Configure the delay in number of buffers";
#    set_parameter_property $LOCK_DELAY AFFECTS_ELABORATION true        
#    set_parameter_property $LOCK_DELAY VISIBLE false      
#    set_parameter_property $LOCK_DELAY HDL_PARAMETER true
# 
#    add_parameter          $ENABLE_RATE INTEGER 1
#    set_parameter_property $ENABLE_RATE DISPLAY_NAME "Support for controlled repeat rate" 
#    set_parameter_property $ENABLE_RATE DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_RATE DESCRIPTION " Turn on to support controlled repeat rate during buffer animations or rate-controlled genlocking";
#    set_parameter_property $ENABLE_RATE AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_RATE VISIBLE true      
#    set_parameter_property $ENABLE_RATE HDL_PARAMETER true
#
#    add_parameter          $RATE_BUFFER INTEGER 0
#    set_parameter_property $RATE_BUFFER DISPLAY_NAME "Rate-control, Target buffer";
#    set_parameter_property $RATE_BUFFER ALLOWED_RANGES {"0:Read" "1:Write"}
#  # set_parameter_property $RATE_BUFFER DISPLAY_HINT radio
#    set_parameter_property $RATE_BUFFER DESCRIPTION " ";
#    set_parameter_property $RATE_BUFFER AFFECTS_ELABORATION true        
#    set_parameter_property $RATE_BUFFER HDL_PARAMETER true
#
#    add_parameter          $RATE_REPEAT INTEGER 1
#    set_parameter_property $RATE_REPEAT DISPLAY_NAME "Rate-control, Repeat count" 
#    set_parameter_property $RATE_REPEAT ALLOWED_RANGES {0:255}
#    set_parameter_property $RATE_REPEAT DESCRIPTION "  ";
#    set_parameter_property $RATE_REPEAT AFFECTS_ELABORATION true        
#    set_parameter_property $RATE_REPEAT VISIBLE true      
#    set_parameter_property $RATE_REPEAT HDL_PARAMETER true
#  
#    add_parameter          $RATE_TOTAL INTEGER 2
#    set_parameter_property $RATE_TOTAL DISPLAY_NAME "Rate-control, Total count" 
#    set_parameter_property $RATE_TOTAL ALLOWED_RANGES {1:255}
#    set_parameter_property $RATE_TOTAL DESCRIPTION "  ";
#    set_parameter_property $RATE_TOTAL AFFECTS_ELABORATION true        
#    set_parameter_property $RATE_TOTAL VISIBLE true      
#    set_parameter_property $RATE_TOTAL HDL_PARAMETER true
#  
#    add_display_item "${inst_gui_name}" $ENABLE_ANIM     PARAMETER
#    add_display_item "${inst_gui_name}" $ENABLE_LOCK     PARAMETER
#    add_display_item "${inst_gui_name}" $ENABLE_RATE     PARAMETER
#    add_display_item "${inst_gui_name}" $LOCK_MODE       PARAMETER
#    add_display_item "${inst_gui_name}" $LOCK_GENE       PARAMETER
#    add_display_item "${inst_gui_name}" $LOCK_DELAY      PARAMETER
#    add_display_item "${inst_gui_name}" $RATE_BUFFER     PARAMETER
#    add_display_item "${inst_gui_name}" $RATE_REPEAT     PARAMETER
#    add_display_item "${inst_gui_name}" $RATE_TOTAL      PARAMETER
# 
#  # set grp_label_sync_rd   "Read Buffer${ctrl_id}"    
#  # set grp_label_sync_wr   "Write Buffer${ctrl_id}"  
#  #
#  # add_display_item $inst_gui_name $grp_label_sync_rd GROUP      
#  # add_display_item $inst_gui_name $grp_label_sync_wr GROUP      
#  #
#  # surface_ctrl_add_parameters_sync_rw $is_core 0 $ctrl_name $grp_label_sync_rd 
#  # surface_ctrl_add_parameters_sync_rw $is_core 1 $ctrl_name $grp_label_sync_wr
#
#  # surface_ctrl_add_parameters_sync_rw $is_core 0 $ctrl_name $inst_gui_name 
#  # surface_ctrl_add_parameters_sync_rw $is_core 1 $ctrl_name $inst_gui_name
#
#  }
#



#  proc surface_sync_validation_rw { is_core is_write ctrl_name } {
#  
#    if {$is_core == 1} { 
#      set param_name "WZD"
#    } else {
#      set param_name $ctrl_name
#    }
#  
#    if { ${is_write} == 0 } {     
#      set rw_name ${param_name}_RD
#    } else {
#      set rw_name ${param_name}_WR
#    } 
#
#  # if { [ get_parameter_value ${param_name}_ENABLE_LOCK ] == 1 } {
#  #   set_parameter_property ${rw_name}_EXT_ENABLE ENABLED true
#  # } else {
#  #   set_parameter_property ${rw_name}_EXT_ENABLE ENABLED false
#  # }
#  #
#  # if { [ get_parameter_value ${rw_name}_EXT_ENABLE ] == 1 } {
#  #   set_parameter_property ${rw_name}_EXT_NUMBER ENABLED true
#  # } else {
#  #   set_parameter_property ${rw_name}_EXT_NUMBER ENABLED false
#  # }
#
#    if { [ get_parameter_value ${param_name}_ENABLE_RATE ] == 1 } {
#      set_parameter_property ${rw_name}_REPEAT ENABLED true
#      set_parameter_property ${rw_name}_TOTAL  ENABLED true
#    } else {
#      set_parameter_property ${rw_name}_REPEAT ENABLED false
#      set_parameter_property ${rw_name}_TOTAL  ENABLED false
#    }
#
#    if { [ get_parameter_value ${param_name}_PRIMARY_ENABLE_RUNTIME ] == 1 } {
#      set_parameter_property ${rw_name}_REPEAT VISIBLE false
#      set_parameter_property ${rw_name}_TOTAL  VISIBLE false
#    } else {
#      set_parameter_property ${rw_name}_REPEAT VISIBLE true
#      set_parameter_property ${rw_name}_TOTAL  VISIBLE true
#    }
#
#
#  } 



#    proc surface_sync_validation { is_core ctrl_name  } {
#  
#      if {$is_core == 1} { 
#        set param_name "WZD"
#      } else {
#        set param_name $ctrl_name
#      }
#  
#      if { [ get_parameter_value ${param_name}_ENABLE_ANIM ] == 0 } {
#        set_parameter_property ${param_name}_ENABLE_LOCK ENABLED false 
#        set_parameter_property ${param_name}_ENABLE_RATE    ENABLED false
#      } else {
#        set_parameter_property ${param_name}_ENABLE_LOCK ENABLED true
#  
#        if { [ get_parameter_value ${param_name}_ENABLE_LOCK ] == 0 } {
#          set_parameter_property ${param_name}_ENABLE_RATE    ENABLED false
#        } else {
#          set_parameter_property ${param_name}_ENABLE_RATE    ENABLED true
#        }
#      }
#  
#  
#  #   # slave interfaces active 
#  #   if { [ get_parameter_value ${param_name}_RD_ENABLE_CONTROL ] == 0 && [ get_parameter_value ${param_name}_ENABLE_READER ] == 1 } {
#  #     set_parameter_property ${param_name}_RD_MASTER_NUM ENABLED true
#  #   } else {
#  #     set_parameter_property ${param_name}_RD_MASTER_NUM ENABLED false
#  #   }
#  #
#  #   if { [ get_parameter_value ${param_name}_WR_ENABLE_CONTROL ] == 0 && [ get_parameter_value ${param_name}_ENABLE_WRITER ] == 1 } {
#  #     set_parameter_property ${param_name}_WR_MASTER_NUM ENABLED true
#  #   } else {
#  #     set_parameter_property ${param_name}_WR_MASTER_NUM ENABLED false
#  #   }
#  #
#  #
#  #   if { [ get_parameter_value ${param_name}_RD_ENABLE_CONTROL ] == 1 && [ get_parameter_value ${param_name}_WR_ENABLE_CONTROL ] == 1 } {
#  #     set_parameter_property ${param_name}_ENABLE_LOCK ENABLED true
#  # #   set_parameter_property ${param_name}_ENABLE_RATE    ENABLED true
#  #   } else {
#  #     set_parameter_property ${param_name}_ENABLE_LOCK ENABLED false
#  # #   set_parameter_property ${param_name}_ENABLE_RATE    ENABLED false
#  #   }
#  
#    }
 
 

# proc surface_vsync_add_interface_core { is_write ctrl_name } {
#   
#   if { ${is_write} == 0 } {     
#     set sig_name "rd"
#   } else {
#     set sig_name "wr"
#   } 
# 
#   set if_name ${ctrl_name}_${sig_name}_exp 
# 
#   add_interface $if_name conduit start
# 
#   # direction suffixes are relatively to surface controller
#   add_interface_port $if_name ${if_name}_i export Output 32  
#   add_interface_port $if_name ${if_name}_o export Input  32  
#         
# } 
#    
#    
#  proc surface_ipcore_set_interface_csr { ctrl_name enable } {  
#
#    set cmp_if_name ${ctrl_name}_csr
#    set_interface_property ${cmp_if_name} ENABLED $enable
#
#  }
#      
#
#  proc surface_ipcore_set_interface_exp { ctrl_name enable } {  
#
#    set cmp_if_name ${ctrl_name}_exp
#    set_interface_property ${cmp_if_name} ENABLED $enable
#
#  }
#
#
    
# proc surface_ipcore_set_interface_exp { is_write ctrl_name enable } {  
#
#   if { ${is_write} == 0 } {     
#     set sig_name "rd"
#   } else {
#     set sig_name "wr"
#   } 
#
# # set cmp_sync_if_name ${ctrl_name}_${sig_name}_sync_slv
#
#   set cmp_sync_if_name ${ctrl_name}_${sig_name}_exp
#
#   set_interface_property ${cmp_sync_if_name} ENABLED $enable
#
# }
    
    
  proc surface_ipcore_set_interface_dma { ctrl_name is_write enable pixel_num pixel_size } {    

    if { ${is_write} == 0 } {     
      set sig_name "rd"
    } else {
      set sig_name "wr"
    } 

    set_interface_property ${ctrl_name}_${sig_name}_cmd ENABLED $enable
    set_interface_property ${ctrl_name}_${sig_name}_rsp ENABLED $enable
    set_interface_property ${ctrl_name}_${sig_name}_dat ENABLED $enable

  # !!! necessary to set data size even if interface is disabled 
  # if { ${enable} == 1 } {     

     #set pixel_size  [ expr $color_num * $color_size + 2 ]
      set pixel_size  [ expr $pixel_size + 2 ]

      set dat_name ${ctrl_name}_${sig_name}_dat
          
      set_interface_property ${dat_name} dataBitsPerSymbol $pixel_size          
      set_interface_property ${dat_name} symbolsPerBeat    $pixel_num
      set_port_property      ${dat_name}_data WIDTH_EXPR [ expr $pixel_num * $pixel_size ]

  # } 

  }

  
#  proc surface_vsync_add_interface { is_write } {
#
#    if { ${is_write} == 0 } {     
#      set sig_name "rd"
#    } else {
#      set sig_name "wr"
#    } 
#
##   global MAX_SYNC
##
##   # Slave interface(s) 
##   for {set i 0} {$i<$MAX_SYNC} {incr i} {
##
##     set if_name     ${sig_name}_sync${i} 
##     set sfc_if_name ${sig_name}_sync
##
##     add_interface $if_name conduit end
##
## #   add_interface_port $if_name ${if_name}_${in_name}  export Input  18  
## #   add_interface_port $if_name ${if_name}_${out_name} export Output 18  
## # # add_interface_port $if_name ${if_name}_rq  export Output  1   
## # # add_interface_port $if_name ${if_name}_ack export Input   1   
## #   
## #   set_port_property ${if_name}_${in_name}  FRAGMENT_LIST " ${sfc_if_name}_${in_name}([expr 18*($i+1)-1]:[expr 18*$i]) "
## #   set_port_property ${if_name}_${out_name} FRAGMENT_LIST " ${sfc_if_name}_${out_name}([expr 18*($i+1)-1]:[expr 18*$i]) "
## # # set_port_property ${if_name}_rq  FRAGMENT_LIST " ${sfc_if_name}_rq([expr $i]) "
## # # set_port_property ${if_name}_ack FRAGMENT_LIST " ${sfc_if_name}_ack([expr $i]) "
##
##     # connection between 2 export interfaces requires to respect the connection order into the below declaration (r2w, w2r) 
##     if { ${is_write} == 0 } {     
##       add_interface_port $if_name ${if_name}_r2w export Output 18        
##       add_interface_port $if_name ${if_name}_w2r export Input  18  
##     } else {
##       add_interface_port $if_name ${if_name}_r2w export Input  18  
##       add_interface_port $if_name ${if_name}_w2r export Output 18  
##     } 
##
##     set_port_property ${if_name}_w2r  FRAGMENT_LIST " ${sfc_if_name}_w2r([expr 18*($i+1)-1]:[expr 18*$i]) "
##     set_port_property ${if_name}_r2w  FRAGMENT_LIST " ${sfc_if_name}_r2w([expr 18*($i+1)-1]:[expr 18*$i]) "
##
##
##   }
#
#    # Export interface      
#
#    set if_name ${sig_name}_exp 
#
#    add_interface $if_name conduit end
#   
#    add_interface_port $if_name ${if_name}_i export Input  32  
#    add_interface_port $if_name ${if_name}_o export Output 32  
#
#  }
#
#  # # Slave interface(s) 
#  # for {set i 0} {$i<$MAX_SYNC} {incr i} {
#  #
#  #   set if_name     ${sig_name}_sync_slv${i} 
#  #   set sfc_if_name ${sig_name}_sync_slv
#  #
#  #   add_interface $if_name conduit end
#  #
#  #   add_interface_port $if_name ${if_name}_ctl export Input  18  
#  #   add_interface_port $if_name ${if_name}_sts export Output 18  
#  #   add_interface_port $if_name ${if_name}_rq  export Output  1   
#  #   add_interface_port $if_name ${if_name}_ack export Input   1   
#  #   
#  #   set_port_property ${if_name}_ctl FRAGMENT_LIST " ${sfc_if_name}_ctl([expr 18*($i+1)-1]:[expr 18*$i]) "
#  #   set_port_property ${if_name}_sts FRAGMENT_LIST " ${sfc_if_name}_sts([expr 18*($i+1)-1]:[expr 18*$i]) "
#  #   set_port_property ${if_name}_rq  FRAGMENT_LIST " ${sfc_if_name}_rq([expr $i]) "
#  #   set_port_property ${if_name}_ack FRAGMENT_LIST " ${sfc_if_name}_ack([expr $i]) "
#  #
#  # }
#  #       
#  # # Master interface      
#  # set if_name ${sig_name}_sync_mst 
#  #
#  # add_interface $if_name conduit start
#  #
#  # add_interface_port $if_name ${if_name}_ctl export Output 18  
#  # add_interface_port $if_name ${if_name}_sts export Input  18  
#  # add_interface_port $if_name ${if_name}_rq  export Input   1   
#  # add_interface_port $if_name ${if_name}_ack export Output  1   
#  #
#  #
#          
#    
#
#
#
#
#  # sfctrl: enable/disable interfaces
#  # host: export interface
#  proc surface_primary_elaborate { is_core ctrl_name cmp_name } {
#
#    if {$is_core == 1} { 
#      set param_name "WZD"
#    } else {
#      set param_name $ctrl_name
#    }
#
#    set PRIMARY_IMPORT      ${param_name}_PRIMARY_IMPORT 
#    set PRIMARY_EXPORT      ${param_name}_PRIMARY_EXPORT 
#  # set PRIMARY_ENABLE_SYNC ${param_name}_PRIMARY_ENABLE_SYNC 
#
#    # Primary import 
#    set if_name primary_import
#    
#    set if_used 1
#    if { [ get_parameter_value $PRIMARY_IMPORT ] == 0 } { 
#      set if_used 0
#    } 
#    
#    if {$is_core == 1} { 
#    
#      if { $if_used == 1 } {
#        set_interface_property $if_name ENABLED true
#      } else {
#        set_interface_property $if_name ENABLED false
#      }      
#    
#    } else {
#    	    
#      if { $if_used == 1 } {
#        add_interface          $ctrl_name\_$if_name avalon start
#        set_interface_property $ctrl_name\_$if_name EXPORT_OF $ctrl_name.$if_name
#      }      
#    
#    }      
#
#    # Primary export
#    # irrelevant when import is Turned On 
#    set if_name primary_export
#    
#    set if_used 1
#    if { [ get_parameter_value $PRIMARY_IMPORT ] == 1 } { 
#      set if_used 0
#    } elseif { [ get_parameter_value $PRIMARY_EXPORT ] == 0 } { 
#      set if_used 0
#    } 
#    
#    if {$is_core == 1} { 
#    
#      if { $if_used == 1 } {
#        set_interface_property $if_name ENABLED true
#      } else {
#        set_interface_property $if_name ENABLED false
#      }      
#    
#    } else {
#    	    
#      if { $if_used == 1 } {
#        add_interface          $ctrl_name\_$if_name avalon end
#        set_interface_property $ctrl_name\_$if_name EXPORT_OF $ctrl_name.$if_name
#      }      
#    
#    }      
#
#  }
#
#

#  # surface ctrl elaboration 
#  # is_core is_write is_slave ctrl_name i
#  proc surface_vsync_elaborate { is_core ctrl_name is_write cmp_name } {
#
#     if {$is_core == 1} { 
#       set param_name "WZD"
#     } else {
#       set param_name $ctrl_name
#     }
# 
#     if { ${is_write} == 0 } {     
#       set sig_name "rd"
#       set rw_name ${param_name}_RD
#     } else {
#       set sig_name "wr"
#       set rw_name ${param_name}_WR
#     } 
#
#  #  set PRIMARY_ENABLE_SYNC ${param_name}_PRIMARY_ENABLE_SYNC 
#
#  #  set EXT_ENABLE     ${rw_name}_EXT_ENABLE         
#  #  set EXT_NUMBER     ${rw_name}_EXT_NUMBER
# 
#     if { ${is_write} == 0 } {     
#     # set param_name     ${param_name}_READER
#       set ENABLE_DMA     ${param_name}_ENABLE_READER         
#  
#     } else {
#      #set param_name     ${param_name}_WRITER
#       set ENABLE_DMA     ${param_name}_ENABLE_WRITER         
#     } 
#   
#
#  #  global MAX_SYNC
#  #
#  #  # Slave interface(s) 
#  #  # Slave  interface is enabled when Control is Off whereas frame processing (dma) is internal to the core  
#  #  for {set i 0} {$i<$MAX_SYNC} {incr i} {
#  #
#  #    set if_name ${sig_name}_sync${i} 
#  #
#  #    set if_used 1
#  #    if { [ get_parameter_value $PRIMARY_ENABLE_SYNC ] == 0 } {
#  #      set if_used 0
#  #    } elseif { [ get_parameter_value $ENABLE_DMA ] == 0 } { 
#  #      set if_used 0
#  #    } elseif { [ get_parameter_value $EXT_ENABLE ] == 0 } { 
#  #      set if_used 0
#  #    }
#  #
#  #    if { $i >= [ get_parameter_value $EXT_NUMBER ] } { 
#  #      set slv_num_used 0
#  #    } else {
#  #      set slv_num_used 1
#  #    } 
#  #
#  #
#  #    if {$is_core == 1} { 
#  #      if { $if_used == 1 } {
#  #        set_interface_property $if_name ENABLED true
#  #      } else {
#  #      # cannot disable partly the interface due to FRAGMENT
#  #      # set_interface_property $if_name ENABLED false
#  #      }      
#  #    } else {
#  #
#  #      if { $if_used == 1 && $slv_num_used == 1 } { 
#  #        add_interface          ${ctrl_name}_$if_name conduit start
#  #        set_interface_property ${ctrl_name}_$if_name EXPORT_OF ${ctrl_name}.$if_name   
#  #      } else {
#  #        add_instance           ${ctrl_name}_${if_name} imt_surface_vsync_dummy 
#  #
#  #        if { ${is_write} == 1 } {     
#  #          # apply a dummy read interface
#  #          set_instance_parameter ${ctrl_name}_${if_name} WZD_IS_WRITE 0     
#  #          add_connection         ${ctrl_name}_${if_name}.rd_sync ${ctrl_name}.${if_name}                 
#  #        } else {
#  #          # apply a dummy write interface
#  #          set_instance_parameter ${ctrl_name}_${if_name} WZD_IS_WRITE 1     
#  #          add_connection         ${ctrl_name}_${if_name}.wr_sync ${ctrl_name}.${if_name}        
#  #        } 
#  #
#  #      }
#  #
#  #    }
#  #
#  #  }
#
#
#
#
#    # Export 
#    # Export interface is enabled when dma is enabled
#    set if_name ${sig_name}_exp 
#
#    set if_used 1
#    if { [ get_parameter_value $ENABLE_DMA ] == 0 } { 
#      set if_used 0
#    } 
#
#    if {$is_core == 1} { 
#
#      if { $if_used == 1 } {
#        set_interface_property $if_name ENABLED true
#      } else {
#        set_interface_property $if_name ENABLED false
#      }      
#
#    } else {
#
#  #   surface_ipcore_set_interface_exp $is_write $ctrl_name $if_used
#      #TODO disable the ipcore exp interface
#
#      if { $if_used == 1 } {
#        set cmp_sync_if_name ${ctrl_name}_${sig_name}_exp
#        add_connection $ctrl_name.${sig_name}_exp $cmp_name.${cmp_sync_if_name}  
#      }      
#
#    }      
#          
#
#  }

  
#    set PRIMARY_ENABLE_SYNC    ${param_name}_PRIMARY_ENABLE_SYNC 
#
#    if { ${is_write} == 0 } {     
#    # set param_name     ${param_name}_READER
#      set ENABLE_DMA     ${param_name}_ENABLE_READER         
#      set ENABLE_CONTROL ${param_name}_RD_ENABLE_CONTROL         
#      set MASTER_NUMBER  ${param_name}_RD_MASTER_NUM
# 
#    } else {
#     #set param_name     ${param_name}_WRITER
#      set ENABLE_DMA     ${param_name}_ENABLE_WRITER         
#      set ENABLE_CONTROL ${param_name}_WR_ENABLE_CONTROL         
#      set MASTER_NUMBER  ${param_name}_WR_MASTER_NUM
#    } 
#      
#
#    global MAX_SYNC
#
#    # Slave interface(s) 
#    # Slave  interface is enabled when Control is Off whereas frame processing (dma) is internal to the core  
#    for {set i 0} {$i<$MAX_SYNC} {incr i} {
#
#      set if_name ${sig_name}_sync_slv${i} 
#
#      set if_used 1
#      if { [ get_parameter_value $PRIMARY_ENABLE_SYNC ] == 0 } {
#        set if_used 0
#      } elseif { [ get_parameter_value $ENABLE_DMA ] == 0 } { 
#        set if_used 0
#      } elseif { [ get_parameter_value $ENABLE_CONTROL ] == 1 } { 
#        set if_used 0
#      }
#
#      if { $i >= [ get_parameter_value $MASTER_NUMBER ] } { 
#        set slv_num_used 0
#      } else {
#        set slv_num_used 1
#      } 
#
#
#      if {$is_core == 1} { 
#        if { $if_used == 1 } {
#          set_interface_property $if_name ENABLED true
#        } else {
#        # cannot disable partly the interface due to FRAGMENT
#        # set_interface_property $if_name ENABLED false
#        }      
#      } else {
#
#        if { $if_used == 1 && $slv_num_used == 1 } { 
#          add_interface          ${ctrl_name}_$if_name conduit start
#          set_interface_property ${ctrl_name}_$if_name EXPORT_OF ${ctrl_name}.$if_name   
#        } else {
#          add_instance           ${ctrl_name}_${if_name} imt_surface_vsync_dummy 
#          set_instance_parameter ${ctrl_name}_${if_name} WZD_MASTER 1     
#          add_connection         ${ctrl_name}_${if_name}.mst ${ctrl_name}.${if_name}        
#        }
#
#      }
#
#    }
#      
#    
#    # Master 
#    # Master interface is enabled when Control is On and process is external (dma off) 
#    set if_name ${sig_name}_sync_mst 
#
#    set if_used 1
#    if { [ get_parameter_value $PRIMARY_ENABLE_SYNC ] == 0 } {
#      set if_used 0
#    } elseif { [ get_parameter_value $ENABLE_DMA ] == 1 } { 
#      set if_used 0
#    } elseif { [ get_parameter_value $ENABLE_CONTROL ] == 0 } { 
#      set if_used 0
#    } 
#
#    # intern not relevant
#    set mst_intern 0
#  # if { [ get_parameter_value $ENABLE_DMA ] == 1 } { 
#  #   set mst_intern 1
#  # } 
#
#    if {$is_core == 1} { 
#
#      if { $if_used == 1 } {
#        set_interface_property $if_name ENABLED true
#      } else {
#        set_interface_property $if_name ENABLED false
#      }      
#
#    } else {
#
#      if { $if_used == 1 } {
#        # internal process connexion
#        if { $mst_intern == 1 } { 
#          set cmp_sync_if_name ${ctrl_name}_${sig_name}_sync_slv
#          add_connection $ctrl_name.${sig_name}_sync_mst $cmp_name.${cmp_sync_if_name}  
#        # external process connexion
#        } else {
#          add_interface          ${ctrl_name}_$if_name conduit end
#          set_interface_property ${ctrl_name}_$if_name EXPORT_OF ${ctrl_name}.$if_name   
#        } 
#
#      } 
#
#    }
#
#





# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- COMMON                                                                                 --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#  proc surface_ctrl_add_parameters_main { is_core ctrl_name inst_gui_name ctrl_v_major ctrl_v_minor } {
# 
#    if {$is_core == 1} { 
#      set param_name "WZD"
#    } else {
#      set param_name $ctrl_name
#    }
# 
##    set RUNTIME_ENABLE ${param_name}_RUNTIME_ENABLE             
##
##    add_parameter          $RUNTIME_ENABLE INTEGER 1
##    set_parameter_property $RUNTIME_ENABLE DISPLAY_NAME "Run-time control" 
##    set_parameter_property $RUNTIME_ENABLE DISPLAY_HINT boolean 
##    set_parameter_property $RUNTIME_ENABLE DESCRIPTION " Turn ON means surface must be set by software application during runtime / Turn OFF for a static surface parameters";
##    set_parameter_property $RUNTIME_ENABLE AFFECTS_ELABORATION true        
##    set_parameter_property $RUNTIME_ENABLE VISIBLE true      
##    set_parameter_property $RUNTIME_ENABLE HDL_PARAMETER true
##
##    add_display_item "${inst_gui_name}" $RUNTIME_ENABLE PARAMETER
#
#    set VERSION_MAJOR          ${param_name}_VERSION_MAJOR
#    set VERSION_MINOR          ${param_name}_VERSION_MINOR      
#    set ENABLE_CSR             ${param_name}_ENABLE_CSR               
#    set ENABLE_READER          ${param_name}_ENABLE_READER            
#    set ENABLE_WRITER          ${param_name}_ENABLE_WRITER  
#    set ENABLE_PRIMARY         ${param_name}_ENABLE_PRIMARY               
#    set ENABLE_COLOR           ${param_name}_ENABLE_COLOR 
#    set ENABLE_DEBUG           ${param_name}_ENABLE_DEBUG                                              
#    set MAX_WIDTH              ${param_name}_MAX_WIDTH            
#    set MAX_HEIGHT             ${param_name}_MAX_HEIGHT           
#    set MAX_BUFFER_NUM         ${param_name}_MAX_BUFFER_NUM  
#    set STREAM_PIXEL_FORMAT    ${param_name}_STREAM_PIXEL_FORMAT
#    set STREAM_PIXEL_SIZE      ${param_name}_STREAM_PIXEL_SIZE         
#
#
#    add_parameter          $VERSION_MAJOR INTEGER $ctrl_v_major
#    set_parameter_property $VERSION_MAJOR DISPLAY_NAME "major";
#    set_parameter_property $VERSION_MAJOR DISPLAY_HINT INTEGER
#    set_parameter_property $VERSION_MAJOR DESCRIPTION " "
#    set_parameter_property $VERSION_MAJOR VISIBLE false 
#  # set_parameter_property $VERSION_MAJOR DERIVED true 
#    set_parameter_property $VERSION_MAJOR ENABLED false
#    set_parameter_property $VERSION_MAJOR HDL_PARAMETER true
#    
#    add_parameter          $VERSION_MINOR INTEGER $ctrl_v_minor
#    set_parameter_property $VERSION_MINOR DISPLAY_NAME "minor";
#    set_parameter_property $VERSION_MINOR DISPLAY_HINT INTEGER
#    set_parameter_property $VERSION_MINOR DESCRIPTION " "
#    set_parameter_property $VERSION_MINOR VISIBLE false 
#  # set_parameter_property $VERSION_MINOR DERIVED true 
#    set_parameter_property $VERSION_MINOR ENABLED false
#    set_parameter_property $VERSION_MINOR HDL_PARAMETER true
#
#    add_parameter          $ENABLE_CSR INTEGER 1
#    set_parameter_property $ENABLE_CSR DISPLAY_NAME "Run-time control" 
#    set_parameter_property $ENABLE_CSR DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_CSR DESCRIPTION " Turn ON to get run-time control over the Control-Status Register interface";
#    set_parameter_property $ENABLE_CSR AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_CSR VISIBLE true      
#    set_parameter_property $ENABLE_CSR HDL_PARAMETER true
#    
#    add_parameter          $ENABLE_PRIMARY INTEGER 1
#    set_parameter_property $ENABLE_PRIMARY DISPLAY_NAME "Use Primary" 
#    set_parameter_property $ENABLE_PRIMARY DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_PRIMARY DESCRIPTION " Turn ON to support Primary Surfaces";
#    set_parameter_property $ENABLE_PRIMARY AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_PRIMARY VISIBLE true      
#    set_parameter_property $ENABLE_PRIMARY HDL_PARAMETER true
#    
#    add_parameter          $ENABLE_READER INTEGER 1
#    set_parameter_property $ENABLE_READER DISPLAY_NAME "Use DMA Read" 
#    set_parameter_property $ENABLE_READER DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_READER DESCRIPTION " Turn ON to support Surfaces reading ";
#    set_parameter_property $ENABLE_READER AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_READER VISIBLE true      
#    set_parameter_property $ENABLE_READER HDL_PARAMETER true
#    
#    add_parameter          $ENABLE_WRITER INTEGER 1
#    set_parameter_property $ENABLE_WRITER DISPLAY_NAME "Use DMA Write" 
#    set_parameter_property $ENABLE_WRITER DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_WRITER DESCRIPTION " Turn ON to support Surfaces writing ";
#    set_parameter_property $ENABLE_WRITER AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_WRITER VISIBLE true      
#    set_parameter_property $ENABLE_WRITER HDL_PARAMETER true
#
#    add_parameter          $ENABLE_COLOR INTEGER 1
#    set_parameter_property $ENABLE_COLOR DISPLAY_NAME "Use color conversion"; # Use explicit color format 
#    set_parameter_property $ENABLE_COLOR DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_COLOR DESCRIPTION " Turn OFF to use raw data, Turn ON to use color format ";
#    set_parameter_property $ENABLE_COLOR AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_COLOR VISIBLE true      
#    set_parameter_property $ENABLE_COLOR HDL_PARAMETER true
#   
#    add_parameter          $ENABLE_DEBUG INTEGER 1
#    set_parameter_property $ENABLE_DEBUG DISPLAY_NAME "support for debug" 
#    set_parameter_property $ENABLE_DEBUG DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_DEBUG DESCRIPTION "  ";
#    set_parameter_property $ENABLE_DEBUG AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_DEBUG VISIBLE true      
#    set_parameter_property $ENABLE_DEBUG HDL_PARAMETER true
#
#    add_parameter          $MAX_WIDTH INTEGER 800
#    set_parameter_property $MAX_WIDTH DISPLAY_NAME "Max width" 
#    set_parameter_property $MAX_WIDTH DISPLAY_UNITS "pixels"
#    set_parameter_property $MAX_WIDTH ALLOWED_RANGES {1:16384}
#    set_parameter_property $MAX_WIDTH DESCRIPTION "  ";
#    set_parameter_property $MAX_WIDTH AFFECTS_ELABORATION true        
#    set_parameter_property $MAX_WIDTH VISIBLE true      
#    set_parameter_property $MAX_WIDTH HDL_PARAMETER true
#  
#    add_parameter          $MAX_HEIGHT INTEGER 600
#    set_parameter_property $MAX_HEIGHT DISPLAY_NAME "Max height" 
#    set_parameter_property $MAX_HEIGHT DISPLAY_UNITS "pixels"
#    set_parameter_property $MAX_HEIGHT ALLOWED_RANGES {1:16384}
#    set_parameter_property $MAX_HEIGHT DESCRIPTION "  ";
#    set_parameter_property $MAX_HEIGHT AFFECTS_ELABORATION true        
#    set_parameter_property $MAX_HEIGHT VISIBLE true      
#    set_parameter_property $MAX_HEIGHT HDL_PARAMETER true
#
#    add_parameter          $MAX_BUFFER_NUM INTEGER 3
#    set_parameter_property $MAX_BUFFER_NUM DISPLAY_NAME "Max buffers" 
#    set_parameter_property $MAX_BUFFER_NUM ALLOWED_RANGES {1:256}
#    set_parameter_property $MAX_BUFFER_NUM DESCRIPTION "  ";
#    set_parameter_property $MAX_BUFFER_NUM AFFECTS_ELABORATION true        
#    set_parameter_property $MAX_BUFFER_NUM VISIBLE true      
#    set_parameter_property $MAX_BUFFER_NUM HDL_PARAMETER true
#
#    add_parameter          $STREAM_PIXEL_FORMAT string "ARGB_8888"
#    set_parameter_property $STREAM_PIXEL_FORMAT DISPLAY_NAME "Stream Pixel color format" 
#    set_parameter_property $STREAM_PIXEL_FORMAT ALLOWED_RANGES ${::imt_surface::stream_colorformat_range}    
#    set_parameter_property $STREAM_PIXEL_FORMAT DESCRIPTION "  ";
#    set_parameter_property $STREAM_PIXEL_FORMAT AFFECTS_ELABORATION true        
#    set_parameter_property $STREAM_PIXEL_FORMAT VISIBLE true      
#    set_parameter_property $STREAM_PIXEL_FORMAT HDL_PARAMETER true
#
#    add_parameter          $STREAM_PIXEL_SIZE INTEGER 32
#    set_parameter_property $STREAM_PIXEL_SIZE DISPLAY_NAME "Stream pixel size" 
#    set_parameter_property $STREAM_PIXEL_SIZE DISPLAY_UNITS "Bits"
#    set_parameter_property $STREAM_PIXEL_SIZE ALLOWED_RANGES {1:256}
#    set_parameter_property $STREAM_PIXEL_SIZE DESCRIPTION "  ";
#    set_parameter_property $STREAM_PIXEL_SIZE AFFECTS_ELABORATION true        
#    set_parameter_property $STREAM_PIXEL_SIZE VISIBLE true      
#    set_parameter_property $STREAM_PIXEL_SIZE HDL_PARAMETER true
#      
#    add_display_item "${inst_gui_name}" $ENABLE_CSR             PARAMETER
#    add_display_item "${inst_gui_name}" $ENABLE_WRITER          PARAMETER
#    add_display_item "${inst_gui_name}" $ENABLE_READER          PARAMETER
#    add_display_item "${inst_gui_name}" $ENABLE_PRIMARY         PARAMETER
#    add_display_item "${inst_gui_name}" $ENABLE_COLOR           PARAMETER
#    add_display_item "${inst_gui_name}" $ENABLE_DEBUG           PARAMETER
#    add_display_item "${inst_gui_name}" $MAX_WIDTH              PARAMETER
#    add_display_item "${inst_gui_name}" $MAX_HEIGHT             PARAMETER
#    add_display_item "${inst_gui_name}" $MAX_BUFFER_NUM         PARAMETER
#    add_display_item "${inst_gui_name}" $STREAM_PIXEL_FORMAT    PARAMETER
#    add_display_item "${inst_gui_name}" $STREAM_PIXEL_SIZE      PARAMETER
#
#  }
#


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- DEF                                                                                 --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#   proc surface_ctrl_add_parameters_primary { is_core ctrl_name ctrl_id inst_gui_name } {
# 
#     if {$is_core == 1} { 
#       set param_name "WZD"
#     } else {
#       set param_name $ctrl_name
#     }
# 
#     set PRIMARY_IMPORT           ${param_name}_PRIMARY_IMPORT            
#     set PRIMARY_EXPORT           ${param_name}_PRIMARY_EXPORT            
#     set PRIMARY_NUMBER           ${param_name}_PRIMARY_NUMBER            
#  #  set PRIMARY_ENABLE_SYNC      ${param_name}_PRIMARY_ENABLE_SYNC                          
#     set PRIMARY_ENABLE_RUNTIME   ${param_name}_PRIMARY_ENABLE_RUNTIME                     
#  #  set PRIMARY_REDUCED_READBACK ${param_name}_PRIMARY_REDUCED_READBACK            
# 
#     add_parameter          $PRIMARY_ENABLE_RUNTIME INTEGER 1
#     set_parameter_property $PRIMARY_ENABLE_RUNTIME DISPLAY_NAME "Run-time configuration" 
#     set_parameter_property $PRIMARY_ENABLE_RUNTIME DISPLAY_HINT boolean 
#     set_parameter_property $PRIMARY_ENABLE_RUNTIME DESCRIPTION " Turn ON to support run-time configuration";
#     set_parameter_property $PRIMARY_ENABLE_RUNTIME AFFECTS_ELABORATION true        
#     set_parameter_property $PRIMARY_ENABLE_RUNTIME VISIBLE true      
#     set_parameter_property $PRIMARY_ENABLE_RUNTIME HDL_PARAMETER true
# 
#     add_parameter          $PRIMARY_IMPORT INTEGER 0
#     set_parameter_property $PRIMARY_IMPORT DISPLAY_NAME "Import" 
#     set_parameter_property $PRIMARY_IMPORT DISPLAY_HINT boolean 
#     set_parameter_property $PRIMARY_IMPORT DESCRIPTION " Turn on to import primary Surfaces from another Surface Controller instance ";
#     set_parameter_property $PRIMARY_IMPORT AFFECTS_ELABORATION true        
#     set_parameter_property $PRIMARY_IMPORT VISIBLE true      
#     set_parameter_property $PRIMARY_IMPORT HDL_PARAMETER true
# 
#     add_parameter          $PRIMARY_EXPORT INTEGER 0
#     set_parameter_property $PRIMARY_EXPORT DISPLAY_NAME "Export" 
#     set_parameter_property $PRIMARY_EXPORT DISPLAY_HINT boolean 
#     set_parameter_property $PRIMARY_EXPORT DESCRIPTION " Turn on to export primary Surfaces for another Surface Controller instance ";
#     set_parameter_property $PRIMARY_EXPORT AFFECTS_ELABORATION true        
#     set_parameter_property $PRIMARY_EXPORT VISIBLE true      
#     set_parameter_property $PRIMARY_EXPORT HDL_PARAMETER true
# 
#     add_parameter          $PRIMARY_NUMBER INTEGER 1
#     set_parameter_property $PRIMARY_NUMBER DISPLAY_NAME "Number of surfaces" 
#     set_parameter_property $PRIMARY_NUMBER DISPLAY_UNITS ""
#     set_parameter_property $PRIMARY_NUMBER ALLOWED_RANGES {1:256}
#     set_parameter_property $PRIMARY_NUMBER DESCRIPTION "  ";
#     set_parameter_property $PRIMARY_NUMBER AFFECTS_ELABORATION true        
#     set_parameter_property $PRIMARY_NUMBER VISIBLE true      
#     set_parameter_property $PRIMARY_NUMBER HDL_PARAMETER true
#             
# #   add_parameter          $PRIMARY_REDUCED_READBACK INTEGER 0
# #   set_parameter_property $PRIMARY_REDUCED_READBACK DISPLAY_NAME "Reduced configuration readback" 
# #   set_parameter_property $PRIMARY_REDUCED_READBACK DISPLAY_HINT boolean 
# #   set_parameter_property $PRIMARY_REDUCED_READBACK DESCRIPTION "Turn on to disable Control-Status Registers Readback and save ressources";
# #   set_parameter_property $PRIMARY_REDUCED_READBACK AFFECTS_ELABORATION true        
# #   set_parameter_property $PRIMARY_REDUCED_READBACK VISIBLE true      
# #   set_parameter_property $PRIMARY_REDUCED_READBACK HDL_PARAMETER true
# 
#     add_display_item "${inst_gui_name}" $PRIMARY_ENABLE_RUNTIME   PARAMETER
#     add_display_item "${inst_gui_name}" $PRIMARY_IMPORT           PARAMETER
#     add_display_item "${inst_gui_name}" $PRIMARY_EXPORT           PARAMETER
#     add_display_item "${inst_gui_name}" $PRIMARY_NUMBER           PARAMETER
#  #  add_display_item "${inst_gui_name}" $PRIMARY_REDUCED_READBACK PARAMETER
# 
#     surface_ctrl_add_parameters_sync    $is_core   $ctrl_name $ctrl_id $inst_gui_name
# 
#     set grp_label_definition      Definition${ctrl_id}         
#   # set grp_label_synchronization Synchronization${ctrl_id}
# 
#     add_display_item "${inst_gui_name}" $grp_label_definition      GROUP; # tab  
#   # add_display_item "${inst_gui_name}" $grp_label_synchronization GROUP; # tab  
# 
#     surface_data_add_parameters     $is_core   $ctrl_name $grp_label_definition
#   # surface_ctrl_add_parameters_sync    $is_core   $ctrl_name $ctrl_id $grp_label_synchronization
# 
#   }

   
#    proc surface_data_add_parameters { ctrl_name inst_gui_name } {
#      
#      set param_name ${ctrl_name}_SFCDATA
#  
#    # set POOL_IDX                ${param_name}_POOL_IDX   
#   
#      set FRAME_WIDTH             ${param_name}_FRAME_WIDTH   
#      set FRAME_HEIGHT            ${param_name}_FRAME_HEIGHT  
#      set frame_pixel_format_user ${param_name}_frame_pixel_format_user
#      set FRAME_PIXEL_FORMAT      ${param_name}_FRAME_PIXEL_FORMAT  
#    # set FRAME_PIXEL_SIZE        ${param_name}_FRAME_PIXEL_SIZE  
#                                  
#      set PIXEL_SIZE              ${param_name}_PIXEL_SIZE 
#      set BUFFER_NUM              ${param_name}_BUFFER_NUM  
#                                  
#  #   set ADDRESS8                ${param_name}_ADDRESS8         
#      set use_auto_stride         ${param_name}_use_auto_stride         
#                                  
#      set hstride8_user           ${param_name}_hstride8_user
#      set hstride8_auto           ${param_name}_hstride8_auto
#      set HSTRIDE8                ${param_name}_HSTRIDE8         
#                                  
#      set vstride8_user           ${param_name}_vstride8_user
#      set vstride8_auto           ${param_name}_vstride8_auto
#      set VSTRIDE8                ${param_name}_VSTRIDE8         
#                                  
#      set info_min_size8          ${param_name}_info_min_size8   
#  #   set info_end_addr8          ${param_name}_info_end_addr8   
#  
#  
#    # add_parameter          $POOL_IDX INTEGER -1
#    # set_parameter_property $POOL_IDX DISPLAY_NAME "pool idx" 
#    # set_parameter_property $POOL_IDX VISIBLE true      
#    # set_parameter_property $POOL_IDX DERIVED true      
#  
#      add_parameter          $FRAME_WIDTH INTEGER 800
#      set_parameter_property $FRAME_WIDTH DISPLAY_NAME "frame width" 
#      set_parameter_property $FRAME_WIDTH DISPLAY_UNITS "pixels"
#      set_parameter_property $FRAME_WIDTH ALLOWED_RANGES {1:16384}
#      set_parameter_property $FRAME_WIDTH DESCRIPTION "  ";
#      set_parameter_property $FRAME_WIDTH AFFECTS_ELABORATION true        
#      set_parameter_property $FRAME_WIDTH VISIBLE true      
#      set_parameter_property $FRAME_WIDTH HDL_PARAMETER true
#      set_parameter_property $FRAME_WIDTH DERIVED true      
#    
#      add_parameter          $FRAME_HEIGHT INTEGER 600
#      set_parameter_property $FRAME_HEIGHT DISPLAY_NAME "frame height" 
#      set_parameter_property $FRAME_HEIGHT DISPLAY_UNITS "pixels"
#      set_parameter_property $FRAME_HEIGHT ALLOWED_RANGES {1:16384}
#      set_parameter_property $FRAME_HEIGHT DESCRIPTION "  ";
#      set_parameter_property $FRAME_HEIGHT AFFECTS_ELABORATION true        
#      set_parameter_property $FRAME_HEIGHT VISIBLE true      
#      set_parameter_property $FRAME_HEIGHT HDL_PARAMETER true
#      set_parameter_property $FRAME_HEIGHT DERIVED true      
#  
#      add_parameter          $BUFFER_NUM INTEGER 3
#      set_parameter_property $BUFFER_NUM DISPLAY_NAME "frame buffers" 
#      set_parameter_property $BUFFER_NUM ALLOWED_RANGES {1:256}
#      set_parameter_property $BUFFER_NUM DESCRIPTION "  ";
#      set_parameter_property $BUFFER_NUM AFFECTS_ELABORATION true        
#      set_parameter_property $BUFFER_NUM VISIBLE true      
#      set_parameter_property $BUFFER_NUM HDL_PARAMETER true
#      set_parameter_property $BUFFER_NUM DERIVED true      
#             
#      add_parameter          $frame_pixel_format_user string "ARGB_8888"
#      set_parameter_property $frame_pixel_format_user DISPLAY_NAME "Pixel color format" 
#      set_parameter_property $frame_pixel_format_user ALLOWED_RANGES ${::imt_surface::surface_colorformat_range} 
#      set_parameter_property $frame_pixel_format_user DESCRIPTION "  ";
#      set_parameter_property $frame_pixel_format_user AFFECTS_ELABORATION true        
#      set_parameter_property $frame_pixel_format_user VISIBLE true      
#      set_parameter_property $frame_pixel_format_user DERIVED true      
#  
#      add_parameter          $FRAME_PIXEL_FORMAT integer 0
#      set_parameter_property $FRAME_PIXEL_FORMAT DISPLAY_NAME "Pixel color format (private)" 
#      set_parameter_property $FRAME_PIXEL_FORMAT ALLOWED_RANGES ${::imt_surface::surface_colorformat_range} 
#      set_parameter_property $FRAME_PIXEL_FORMAT DESCRIPTION "  ";
#      set_parameter_property $FRAME_PIXEL_FORMAT AFFECTS_ELABORATION true        
#      set_parameter_property $FRAME_PIXEL_FORMAT VISIBLE false      
#      set_parameter_property $FRAME_PIXEL_FORMAT DERIVED true      
#      set_parameter_property $FRAME_PIXEL_FORMAT HDL_PARAMETER true
#  
#      add_parameter          $PIXEL_SIZE INTEGER 32
#      set_parameter_property $PIXEL_SIZE DISPLAY_NAME "Pixel size" 
#      set_parameter_property $PIXEL_SIZE DISPLAY_UNITS "Bits"
#      set_parameter_property $PIXEL_SIZE DESCRIPTION "  ";
#      set_parameter_property $PIXEL_SIZE AFFECTS_ELABORATION true        
#      set_parameter_property $PIXEL_SIZE DERIVED true 
#      set_parameter_property $PIXEL_SIZE VISIBLE true      
#      set_parameter_property $PIXEL_SIZE HDL_PARAMETER true
#    
#  #   add_parameter          $ADDRESS8 INTEGER 0x0
#  #   set_parameter_property $ADDRESS8 DISPLAY_NAME "Base address" 
#  #   set_parameter_property $ADDRESS8 DISPLAY_HINT hexadecimal
#  #   set_parameter_property $ADDRESS8 DISPLAY_UNITS "Bytes"
#  # # set_parameter_property $ADDRESS8 ALLOWED_RANGES {0:0x8FFFFFFF}
#  #   set_parameter_property $ADDRESS8 DESCRIPTION "  ";
#  #   set_parameter_property $ADDRESS8 HDL_PARAMETER true
#  
#      add_parameter          $use_auto_stride INTEGER 1
#      set_parameter_property $use_auto_stride DISPLAY_NAME "Use default strides" 
#      set_parameter_property $use_auto_stride DISPLAY_HINT boolean 
#      set_parameter_property $use_auto_stride DESCRIPTION " Turn ON to select minimum row and buffer strides values";
#      set_parameter_property $use_auto_stride AFFECTS_ELABORATION true        
#      set_parameter_property $use_auto_stride VISIBLE true      
#    # set_parameter_property $use_auto_stride HDL_PARAMETER true
#    
#      add_parameter          $hstride8_user INTEGER 0
#      set_parameter_property $hstride8_user DISPLAY_NAME "Row stride" 
#      set_parameter_property $hstride8_user DISPLAY_UNITS "Bytes"
#    # set_parameter_property $hstride8_user DISPLAY_HINT hexadecimal
#    # set_parameter_property $hstride8_user ALLOWED_RANGES {0:0x8FFFFFFF}
#    # set_parameter_property $hstride8_user DERIVED true
#      set_parameter_property $hstride8_user DESCRIPTION "  ";
#      set_parameter_property $hstride8_user VISIBLE true      
#     
#      add_parameter          $hstride8_auto INTEGER 0
#      set_parameter_property $hstride8_auto DISPLAY_NAME "Info: minimum row stride" 
#      set_parameter_property $hstride8_auto DISPLAY_UNITS "Bytes"
#    # set_parameter_property $hstride8_auto DISPLAY_HINT hexadecimal
#    # set_parameter_property $hstride8_auto ALLOWED_RANGES {0:0x8FFFFFFF}
#      set_parameter_property $hstride8_auto DERIVED true
#      set_parameter_property $hstride8_auto DESCRIPTION "  ";
#      set_parameter_property $hstride8_auto VISIBLE true      
#     
#      add_parameter          $HSTRIDE8 INTEGER 0
#      set_parameter_property $HSTRIDE8 DISPLAY_NAME "Row stride" 
#    # set_parameter_property $HSTRIDE8 DISPLAY_HINT hexadecimal
#      set_parameter_property $HSTRIDE8 DISPLAY_UNITS "Bytes"
#    # set_parameter_property $HSTRIDE8 ALLOWED_RANGES {0:0x8FFFFFFF}
#      set_parameter_property $HSTRIDE8 AFFECTS_ELABORATION true        
#      set_parameter_property $HSTRIDE8 DERIVED true
#      set_parameter_property $HSTRIDE8 DESCRIPTION "  ";
#      set_parameter_property $HSTRIDE8 HDL_PARAMETER true
#      set_parameter_property $HSTRIDE8 VISIBLE false      
#    
#      add_parameter          $vstride8_user INTEGER 0
#      set_parameter_property $vstride8_user DISPLAY_NAME "Buffer stride" 
#      set_parameter_property $vstride8_user DISPLAY_UNITS "Bytes"
#    # set_parameter_property $vstride8_user DISPLAY_HINT hexadecimal
#      set_parameter_property $vstride8_user DESCRIPTION "  ";
#      set_parameter_property $vstride8_user VISIBLE true      
#    
#      add_parameter          $vstride8_auto INTEGER 0
#      set_parameter_property $vstride8_auto DISPLAY_NAME "Info: minimum buffer stride"
#      set_parameter_property $vstride8_auto DISPLAY_UNITS "Bytes"
#    # set_parameter_property $vstride8_auto DISPLAY_HINT hexadecimal
#    # set_parameter_property $vstride8_auto ALLOWED_RANGES {0:0x8FFFFFFF}
#      set_parameter_property $vstride8_auto DERIVED true
#      set_parameter_property $vstride8_auto DESCRIPTION "  ";
#      set_parameter_property $vstride8_auto VISIBLE true      
#  
#      add_parameter          $VSTRIDE8 INTEGER 0
#      set_parameter_property $VSTRIDE8 DISPLAY_NAME "Buffer stride" 
#    # set_parameter_property $VSTRIDE8 DISPLAY_HINT hexadecimal
#      set_parameter_property $VSTRIDE8 DISPLAY_UNITS "Bytes"
#    # set_parameter_property $VSTRIDE8 ALLOWED_RANGES {0:0x8FFFFFFF}
#      set_parameter_property $VSTRIDE8 DERIVED true
#      set_parameter_property $VSTRIDE8 DESCRIPTION "  ";
#      set_parameter_property $VSTRIDE8 HDL_PARAMETER true
#      set_parameter_property $VSTRIDE8 VISIBLE false      
#     
#      add_parameter          $info_min_size8 INTEGER 0
#      set_parameter_property $info_min_size8 DISPLAY_NAME "Info: Size required" 
#      set_parameter_property $info_min_size8 DISPLAY_HINT hexadecimal
#      set_parameter_property $info_min_size8 DISPLAY_UNITS "Bytes"
#      set_parameter_property $info_min_size8 DISPLAY_HINT hexadecimal
#      set_parameter_property $info_min_size8 DERIVED true 
#      set_parameter_property $info_min_size8 VISIBLE true      
#   
#  #   add_parameter          $info_end_addr8 INTEGER 0
#  #   set_parameter_property $info_end_addr8 DISPLAY_NAME "Info: End address" 
#  #   set_parameter_property $info_end_addr8 DISPLAY_HINT hexadecimal
#  #   set_parameter_property $info_end_addr8 DISPLAY_UNITS "Bytes"
#  #   set_parameter_property $info_end_addr8 DISPLAY_HINT hexadecimal
#  #   set_parameter_property $info_end_addr8 DERIVED true 
#  #   set_parameter_property $info_end_addr8 VISIBLE true      
#    
#    
#    # add_display_item "${inst_gui_name}" $POOL_IDX                PARAMETER
#      add_display_item "${inst_gui_name}" $FRAME_WIDTH             PARAMETER
#      add_display_item "${inst_gui_name}" $FRAME_HEIGHT            PARAMETER
#      add_display_item "${inst_gui_name}" $BUFFER_NUM              PARAMETER
#      add_display_item "${inst_gui_name}" $frame_pixel_format_user PARAMETER
#      add_display_item "${inst_gui_name}" $FRAME_PIXEL_FORMAT      PARAMETER
#      add_display_item "${inst_gui_name}" $PIXEL_SIZE              PARAMETER
#  #   add_display_item "${inst_gui_name}" $ADDRESS8                PARAMETER
#      add_display_item "${inst_gui_name}" $use_auto_stride         PARAMETER
#      add_display_item "${inst_gui_name}" $hstride8_user           PARAMETER
#      add_display_item "${inst_gui_name}" $vstride8_user           PARAMETER
#      add_display_item "${inst_gui_name}" $HSTRIDE8                PARAMETER
#      add_display_item "${inst_gui_name}" $VSTRIDE8                PARAMETER
#      add_display_item "${inst_gui_name}" $hstride8_auto           PARAMETER
#      add_display_item "${inst_gui_name}" $vstride8_auto           PARAMETER
#      add_display_item "${inst_gui_name}" $info_min_size8          PARAMETER
#  #   add_display_item "${inst_gui_name}" $info_end_addr8          PARAMETER
#  
#    }


#    proc surface_sync_add_parameters { ctrl_name inst_gui_name } {
#      
#      set param_name ${ctrl_name}_SYNC
#       
#    # set ENABLE_ANIM     ${param_name}_ENABLE_ANIM           
#      set ENABLE_LOCK     ${param_name}_ENABLE_LOCK  
#    # set LOCK_MODE       ${param_name}_LOCK_MODE 
#    # set LOCK_GENE       ${param_name}_LOCK_GENE
#    # set LOCK_DELAY      ${param_name}_LOCK_DELAY 
#      set ENABLE_RATE     ${param_name}_ENABLE_RATE           
#    # set RATE_BUFFER     ${param_name}_RATE_BUFFER           
#      set RATE_REPEAT     ${param_name}_RATE_REPEAT           
#      set RATE_TOTAL      ${param_name}_RATE_TOTAL           
#  
#    # add_parameter          $ENABLE_ANIM INTEGER 1
#    # set_parameter_property $ENABLE_ANIM DISPLAY_NAME "Support for buffers animation" 
#    # set_parameter_property $ENABLE_ANIM DISPLAY_HINT boolean 
#    # set_parameter_property $ENABLE_ANIM DESCRIPTION " Turn ON to support R/W buffers animations based on circular buffer increment";
#    # set_parameter_property $ENABLE_ANIM AFFECTS_ELABORATION true        
#    # set_parameter_property $ENABLE_ANIM VISIBLE true      
#    # set_parameter_property $ENABLE_ANIM HDL_PARAMETER true
#   
#      add_parameter          $ENABLE_LOCK INTEGER 1
#      set_parameter_property $ENABLE_LOCK DISPLAY_NAME "Support for buffers genlock" 
#      set_parameter_property $ENABLE_LOCK DISPLAY_HINT boolean 
#      set_parameter_property $ENABLE_LOCK DESCRIPTION " Turn ON to support R/W buffers synchronization preventing Surface Reader and Surface Writer operating on the same buffer at the same time";
#      set_parameter_property $ENABLE_LOCK AFFECTS_ELABORATION true        
#      set_parameter_property $ENABLE_LOCK VISIBLE true      
#      set_parameter_property $ENABLE_LOCK HDL_PARAMETER true
#      set_parameter_property $ENABLE_LOCK DERIVED true      
#  
#  #   add_parameter          $LOCK_MODE INTEGER 0
#  #   set_parameter_property $LOCK_MODE DISPLAY_NAME "Lock mode";
#  #   set_parameter_property $LOCK_MODE ALLOWED_RANGES {"0:free" "1:rate-controlled" "2:master" "3:master-delay"}
#  # # set_parameter_property $LOCK_MODE DISPLAY_HINT radio
#  #   set_parameter_property $LOCK_MODE DESCRIPTION " ";
#  #   set_parameter_property $LOCK_MODE AFFECTS_ELABORATION true        
#  #   set_parameter_property $LOCK_MODE VISIBLE true      
#  #   set_parameter_property $LOCK_MODE HDL_PARAMETER true
#  
#  #   add_parameter          $LOCK_GENE INTEGER 1
#  #   set_parameter_property $LOCK_GENE DISPLAY_NAME "Lock generator";
#  #   set_parameter_property $LOCK_GENE ALLOWED_RANGES {"0:reader" "1:writer"}
#  # # set_parameter_property $LOCK_GENE DISPLAY_HINT radio
#  #   set_parameter_property $LOCK_GENE DESCRIPTION " select the surface producer";
#  #   set_parameter_property $LOCK_GENE AFFECTS_ELABORATION true        
#  #   set_parameter_property $LOCK_GENE VISIBLE true      
#  #   set_parameter_property $LOCK_GENE HDL_PARAMETER true
#  
#  #   add_parameter          $LOCK_DELAY INTEGER 0
#  #   set_parameter_property $LOCK_DELAY DISPLAY_NAME "Lock delay" 
#  #   set_parameter_property $LOCK_DELAY ALLOWED_RANGES {0:255}
#  #   set_parameter_property $LOCK_DELAY DESCRIPTION "Configure the delay in number of buffers";
#  #   set_parameter_property $LOCK_DELAY AFFECTS_ELABORATION true        
#  #   set_parameter_property $LOCK_DELAY VISIBLE false      
#  #   set_parameter_property $LOCK_DELAY HDL_PARAMETER true
#   
#      add_parameter          $ENABLE_RATE INTEGER 1
#      set_parameter_property $ENABLE_RATE DISPLAY_NAME "Support for controlled repeat rate" 
#      set_parameter_property $ENABLE_RATE DISPLAY_HINT boolean 
#      set_parameter_property $ENABLE_RATE DESCRIPTION " Turn on to support controlled repeat rate during buffer animations or rate-controlled genlocking";
#      set_parameter_property $ENABLE_RATE AFFECTS_ELABORATION true        
#      set_parameter_property $ENABLE_RATE VISIBLE true      
#      set_parameter_property $ENABLE_RATE HDL_PARAMETER true
#      set_parameter_property $ENABLE_RATE DERIVED true      
#  
#  #   add_parameter          $RATE_BUFFER INTEGER 0
#  #   set_parameter_property $RATE_BUFFER DISPLAY_NAME "Rate-control, Target buffer";
#  #   set_parameter_property $RATE_BUFFER ALLOWED_RANGES {"0:Read" "1:Write"}
#  # # set_parameter_property $RATE_BUFFER DISPLAY_HINT radio
#  #   set_parameter_property $RATE_BUFFER DESCRIPTION " ";
#  #   set_parameter_property $RATE_BUFFER AFFECTS_ELABORATION true        
#  #   set_parameter_property $RATE_BUFFER HDL_PARAMETER true
#  
#      add_parameter          $RATE_REPEAT INTEGER 1
#      set_parameter_property $RATE_REPEAT DISPLAY_NAME "Rate-control, Repeat count" 
#      set_parameter_property $RATE_REPEAT ALLOWED_RANGES {0:255}
#      set_parameter_property $RATE_REPEAT DESCRIPTION "  ";
#      set_parameter_property $RATE_REPEAT AFFECTS_ELABORATION true        
#      set_parameter_property $RATE_REPEAT VISIBLE true      
#      set_parameter_property $RATE_REPEAT HDL_PARAMETER true
#      set_parameter_property $RATE_REPEAT DERIVED true      
#    
#      add_parameter          $RATE_TOTAL INTEGER 2
#      set_parameter_property $RATE_TOTAL DISPLAY_NAME "Rate-control, Total count" 
#      set_parameter_property $RATE_TOTAL ALLOWED_RANGES {1:255}
#      set_parameter_property $RATE_TOTAL DESCRIPTION "  ";
#      set_parameter_property $RATE_TOTAL AFFECTS_ELABORATION true        
#      set_parameter_property $RATE_TOTAL VISIBLE true      
#      set_parameter_property $RATE_TOTAL HDL_PARAMETER true
#      set_parameter_property $RATE_TOTAL DERIVED true
#    
#  #   add_display_item "${inst_gui_name}" $ENABLE_ANIM     PARAMETER
#      add_display_item "${inst_gui_name}" $ENABLE_LOCK     PARAMETER
#      add_display_item "${inst_gui_name}" $ENABLE_RATE     PARAMETER
#  #   add_display_item "${inst_gui_name}" $LOCK_MODE       PARAMETER
#  #   add_display_item "${inst_gui_name}" $LOCK_GENE       PARAMETER
#  #   add_display_item "${inst_gui_name}" $LOCK_DELAY      PARAMETER
#  #   add_display_item "${inst_gui_name}" $RATE_BUFFER     PARAMETER
#      add_display_item "${inst_gui_name}" $RATE_REPEAT     PARAMETER
#      add_display_item "${inst_gui_name}" $RATE_TOTAL      PARAMETER
#   
#    }
#  
#  
#    proc surface_data_elaboration { inst_name } {
#   
#      
#    }
#  
#  
#  
#    proc surface_sync_validation { ctrl_name ctrl_id ena_lock ena_rate rate_repeat rate_total } {
#  
#      set param_name ${ctrl_name}_SYNC
#       
#      set ENABLE_LOCK     ${param_name}_ENABLE_LOCK  
#      set ENABLE_RATE     ${param_name}_ENABLE_RATE           
#      set RATE_REPEAT     ${param_name}_RATE_REPEAT           
#      set RATE_TOTAL      ${param_name}_RATE_TOTAL           
#  
#      set_parameter_value ${param_name}_ENABLE_LOCK $ena_lock  
#      set_parameter_value ${param_name}_ENABLE_RATE $ena_rate  
#      set_parameter_value ${param_name}_RATE_REPEAT $rate_repeat  
#      set_parameter_value ${param_name}_RATE_TOTAL  $rate_total  
#  
#    }
#   
#   
#    proc surface_data_validation { ctrl_name ctrl_id frame_width frame_height frame_buffers frame_pixel_format frame_pixel_size } {
#  
#      set param_name ${ctrl_name}_SFCDATA
#  
#      set var_pixel_format $frame_pixel_format; #[ get_parameter_value ${param_name}_MAX_WIDTH ]
#      set var_max_width    $frame_width;        #[ get_parameter_value ${param_name}_MAX_WIDTH ]
#      set var_max_height   $frame_height;       #[ get_parameter_value ${param_name}_MAX_HEIGHT ]
#      set var_number       $frame_buffers;      #[ get_parameter_value ${param_name}_MAX_BUFFER_NUM ]
#      
#      # raw
#      if { $frame_pixel_format == "RAW" } {
#        set var_pixel_depth $frame_pixel_size 
#        set var_color_hw    255; # DEF_PIXCOLOR_UNDEFINED   
#      # color
#      } else {
#        colorformat_get_info $var_pixel_format var_color_hw var_pixel_depth var_color_num var_color_size
#      }
#  
#      
#      # ==================================================
#      # row stride computation
#      
#      set var_hstride8_auto [expr ($var_max_width  * $var_pixel_depth) / 8]
#      
#      if { [ get_parameter_value ${param_name}_use_auto_stride ] == 1 } {
#      
#        set_parameter_property ${param_name}_hstride8_user ENABLED false 
#      
#        set var_hstride8 $var_hstride8_auto
#      
#      } else {
#      
#        set_parameter_property ${param_name}_hstride8_user ENABLED true 
#      
#        set var_hstride8 [ get_parameter_value ${param_name}_hstride8_user ]
#      
#      }
#              
#      # ==================================================
#      # buffer stride computation
#      
#      set var_vstride8_auto [expr ($var_max_height * $var_hstride8)]
#      
#      if { [ get_parameter_value ${param_name}_use_auto_stride ] == 1 } {
#       
#        set_parameter_property ${param_name}_vstride8_user ENABLED false 
#      
#        set var_vstride8 $var_vstride8_auto
#       
#      } else {
#      
#        set_parameter_property ${param_name}_vstride8_user ENABLED true
#      
#        set var_vstride8 [ get_parameter_value ${param_name}_vstride8_user ]
#      
#      }
#      
#          
#    # set var_memory_start8  [ get_parameter_value ${param_name}_ADDRESS8 ]
#      set the_memory_size8   [expr ($var_vstride8 * $var_number)]
#    # set the_memory_end8    [expr ($var_memory_start8 + $the_memory_size8)]
#      
#  
#    # frame_width frame_height frame_buffers frame_pixel_format  
#  
#      set_parameter_value ${param_name}_FRAME_WIDTH             $var_max_width  
#      set_parameter_value ${param_name}_FRAME_HEIGHT            $var_max_height  
#      set_parameter_value ${param_name}_BUFFER_NUM              $var_number  
#      set_parameter_value ${param_name}_frame_pixel_format_user $var_pixel_format  
#      set_parameter_value ${param_name}_FRAME_PIXEL_FORMAT      $var_color_hw  
#      
#      
#      set_parameter_value ${param_name}_hstride8_auto      $var_hstride8_auto  
#      set_parameter_value ${param_name}_HSTRIDE8           $var_hstride8  
#      set_parameter_value ${param_name}_vstride8_auto      $var_vstride8_auto  
#      set_parameter_value ${param_name}_VSTRIDE8           $var_vstride8  
#      set_parameter_value ${param_name}_PIXEL_SIZE         $var_pixel_depth
#      set_parameter_value ${param_name}_info_min_size8     $the_memory_size8  
#    # set_parameter_value ${param_name}_info_end_addr8     $the_memory_end8  
#  
#      # check strides value coherency if user-defined 
#      if { [ get_parameter_value ${param_name}_HSTRIDE8 ] < [ get_parameter_value ${param_name}_hstride8_auto ] } {
#        send_message warning "Surface Definition: actual row stride must be higher than minimal value"
#      }  
#      if { [ get_parameter_value ${param_name}_VSTRIDE8 ] < [ get_parameter_value ${param_name}_vstride8_auto ] } {
#        send_message warning "Surface Definition: actual buffer stride must be higher than minimal value"
#      }
#  
#  
#      return ${the_memory_size8}
#  
#       
#      
#  #   set var_memory_start8  [ get_parameter_value ${param_name}_ADDRESS8 ]
#  #   set the_memory_size8   [expr ($var_vstride8 * $var_number)]
#  #   set the_memory_end8    [expr ($var_memory_start8 + $the_memory_size8)]
#  #
#  #   set ::imt_surface::surface_pool(${param_name},base)  $base                                                      
#  #   set ::imt_surface::surface_pool(${param_name},size8) $the_memory_size8                                                      
#  #
#  #   set sfc_name $param_name
#  #   
#  #   set ::imt_surface::surface_pool($sfc_name,base)          $base                                                      
#  #   set ::imt_surface::surface_pool($sfc_name,color)         $color                                                     
#  #   set ::imt_surface::surface_pool($sfc_name,color_depth)   $color_depth                                                     
#  #   set ::imt_surface::surface_pool($sfc_name,width)         $width                                                     
#  #   set ::imt_surface::surface_pool($sfc_name,height)        $height                                                    
#  #   set ::imt_surface::surface_pool($sfc_name,stride)        $stride                                                    
#  #   set ::imt_surface::surface_pool($sfc_name,nb_buffer)     $nb_buffer                                                 
#  #   set ::imt_surface::surface_pool($sfc_name,stride_buffer) $stride_buffer                                             
#  
#  
#   #  # check static color format validity
#   #  set use_color_depth 0
#   #  if { [ get_parameter_value ${param_name}_ENABLE_COLOR ] == 1 && [ get_parameter_value ${param_name}_PRIMARY_ENABLE_RUNTIME ] == 0 } {
#   #    set use_color_depth 1
#   #  } 
#   #  if { $use_color_depth==1 && $var_pixel_depth > [ get_parameter_value ${param_name}_STREAM_PIXEL_SIZE ] } {
#   #    send_message error "Surface definition: the color depth must not exceed the maximum pixel depth. Please select another color format"
#   #  }
#  
#              
#    }

 
 

#  proc surface_def_validation { ctrl_name ctrl_id frame_width frame_height frame_buffers frame_pixel_format frame_pixel_size } {
#
#    set param_name $ctrl_name
#    
#      
# #  if { [ get_parameter_value ${param_name}_ENABLE_PRIMARY ] == 1 && [ get_parameter_value ${param_name}_PRIMARY_ENABLE_RUNTIME ] == 0 } {
# #
# #  # set_parameter_property ${param_name}_MAX_WIDTH           VISIBLE true
# #  # set_parameter_property ${param_name}_MAX_HEIGHT          VISIBLE true
# #  # set_parameter_property ${param_name}_MAX_BUFFER_NUM      VISIBLE true
# #  # set_parameter_property ${param_name}_STREAM_PIXEL_SIZE   VISIBLE true
# #  # set_parameter_property ${param_name}_ENABLE_COLOR        VISIBLE true
# #    set_parameter_property ${param_name}_FRAME_PIXEL_FORMAT     VISIBLE true
# #    set_parameter_property ${param_name}_ADDRESS8            VISIBLE true      
# #    set_parameter_property ${param_name}_use_auto_stride     VISIBLE true 
# #    set_parameter_property ${param_name}_hstride8_user       VISIBLE true
# #    set_parameter_property ${param_name}_hstride8_auto       VISIBLE true
# #    set_parameter_property ${param_name}_vstride8_user       VISIBLE true
# #    set_parameter_property ${param_name}_vstride8_auto       VISIBLE true
# #    set_parameter_property ${param_name}_PIXEL_SIZE    VISIBLE true
# #    set_parameter_property ${param_name}_info_min_size8      VISIBLE true
# #    set_parameter_property ${param_name}_info_end_addr8      VISIBLE true
# #      
# #  } else {
# #
# #    set_parameter_property ${param_name}_FRAME_PIXEL_FORMAT     VISIBLE false
# #    set_parameter_property ${param_name}_ADDRESS8            VISIBLE false 
# #    set_parameter_property ${param_name}_use_auto_stride     VISIBLE false 
# #    set_parameter_property ${param_name}_hstride8_user       VISIBLE false
# #    set_parameter_property ${param_name}_hstride8_auto       VISIBLE false
# #    set_parameter_property ${param_name}_vstride8_user       VISIBLE false
# #    set_parameter_property ${param_name}_vstride8_auto       VISIBLE false
# #    set_parameter_property ${param_name}_PIXEL_SIZE    VISIBLE false
# #    set_parameter_property ${param_name}_info_min_size8      VISIBLE false
# #    set_parameter_property ${param_name}_info_end_addr8      VISIBLE false
# #
# #  }
#
# #  if { [ get_parameter_value ${param_name}_ENABLE_COLOR ] == 1 } {
# #
# #    colorformat_get_info [get_parameter_value ${param_name}_FRAME_PIXEL_FORMAT] var_color_hw var_pixel_depth color_num color_size; # color_raw
# #              
# #  } else {
# #    # config static  => raw pixel depth  = max pixel depth  
# #    # config runtime => raw pixel depth <= max pixel depth  
# #    set var_pixel_depth [ get_parameter_value ${param_name}_STREAM_PIXEL_SIZE ]
# #  }
# #
# #  if { [ get_parameter_value ${param_name}_ENABLE_COLOR ] == 0 } {
# #  
# #    set_parameter_property ${param_name}_FRAME_PIXEL_FORMAT  ENABLED false 
# #    set_parameter_property ${param_name}_PIXEL_SIZE ENABLED false 
# #  
# #  } else {
# #  
# #    set_parameter_property ${param_name}_FRAME_PIXEL_FORMAT  ENABLED true 
# #    set_parameter_property ${param_name}_PIXEL_SIZE ENABLED true 
# #      
# #  }
#
#    colorformat_get_info [get_parameter_value ${param_name}_FRAME_PIXEL_FORMAT] var_color_hw var_pixel_depth var_color_num var_color_size
#
#
#
#    set var_max_width   $frame_width;                                                             
#    set var_max_height  $frame_height;                                                            
#    set var_number      $frame_buffers;                                                           
#    
#    
#    # ==================================================
#    # row stride computation
#    
#    set var_hstride8_auto [expr ($var_max_width  * $var_pixel_depth) / 8]
#    
#    if { [ get_parameter_value ${param_name}_use_auto_stride ] == 1 } {
#    
#      set_parameter_property ${param_name}_hstride8_user ENABLED false 
#    
#      set var_hstride8 $var_hstride8_auto
#    
#    } else {
#    
#      set_parameter_property ${param_name}_hstride8_user ENABLED true 
#    
#      set var_hstride8 [ get_parameter_value ${param_name}_hstride8_user ]
#    
#    }
#    
#     
#    # ==================================================
#    
#    
#    
#    # ==================================================
#    # buffer stride computation
#    
#    set var_vstride8_auto [expr ($var_max_height * $var_hstride8)]
#    
#    if { [ get_parameter_value ${param_name}_use_auto_stride ] == 1 } {
#     
#      set_parameter_property ${param_name}_vstride8_user ENABLED false 
#    
#      set var_vstride8 $var_vstride8_auto
#     
#    } else {
#    
#      set_parameter_property ${param_name}_vstride8_user ENABLED true
#    
#      set var_vstride8 [ get_parameter_value ${param_name}_vstride8_user ]
#    
#    }
#    
#        
#    set var_memory_start8  [ get_parameter_value ${param_name}_ADDRESS8 ]
#    set the_memory_size8   [expr ($var_vstride8 * $var_number)]
#    set the_memory_end8    [expr ($var_memory_start8 + $the_memory_size8)]
#    
#
#  # frame_width frame_height frame_buffers frame_pixel_format  
#
#    set_parameter_value ${param_name}_FRAME_WIDTH       $var_max_width  
#    set_parameter_value ${param_name}_FRAME_HEIGHT      $var_max_height  
#    set_parameter_value ${param_name}_BUFFER_NUM        $var_number  
#    
#    set_parameter_value ${param_name}_hstride8_auto     $var_hstride8_auto  
#    set_parameter_value ${param_name}_HSTRIDE8          $var_hstride8  
#    set_parameter_value ${param_name}_vstride8_auto     $var_vstride8_auto  
#    set_parameter_value ${param_name}_VSTRIDE8          $var_vstride8  
#    set_parameter_value ${param_name}_PIXEL_SIZE  $var_pixel_depth
#    set_parameter_value ${param_name}_info_min_size8    $the_memory_size8  
#    set_parameter_value ${param_name}_info_end_addr8    $the_memory_end8  
#
#
#    # check strides value coherency if user-defined 
#    if { [ get_parameter_value ${param_name}_HSTRIDE8 ] < [ get_parameter_value ${param_name}_hstride8_auto ] } {
#      send_message warning "Surface Definition: actual row stride must be higher than minimal value"
#    }  
#    if { [ get_parameter_value ${param_name}_VSTRIDE8 ] < [ get_parameter_value ${param_name}_vstride8_auto ] } {
#      send_message warning "Surface Definition: actual buffer stride must be higher than minimal value"
#    }
#
#
#    # check static color format validity
#    set use_color_depth 0
#    if { [ get_parameter_value ${param_name}_ENABLE_COLOR ] == 1 && [ get_parameter_value ${param_name}_PRIMARY_ENABLE_RUNTIME ] == 0 } {
#      set use_color_depth 1
#    } 
#    if { $use_color_depth==1 && $var_pixel_depth > [ get_parameter_value ${param_name}_STREAM_PIXEL_SIZE ] } {
#      send_message error "Surface definition: the color depth must not exceed the maximum pixel depth. Please select another color format"
#    }
#
# 
#    set grp_label_color Colors${ctrl_id}
#
#
#    if { [ get_parameter_value ${param_name}_COLOR_ENABLE_LUT ] == 0 } {
#      set_parameter_property ${param_name}_CLUT_COLOR_NUM   ENABLED false
#    } else {                                                
#      set_parameter_property ${param_name}_CLUT_COLOR_NUM   ENABLED true
#    } 
#
#  # if { [ get_parameter_value ${param_name}_ENABLE_READER ] == 0 } {
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_LUT         VISIBLE false
#  #   set_parameter_property ${param_name}_CLUT_COLOR_NUM           VISIBLE false
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_PREMULTIPLY VISIBLE false
#  # } else { 
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_LUT         VISIBLE true
#  #   set_parameter_property ${param_name}_CLUT_COLOR_NUM           VISIBLE true
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_PREMULTIPLY VISIBLE true
#  # } 
#
#    # static configuration => fixed color format 
#    if { [ get_parameter_value ${param_name}_PRIMARY_ENABLE_RUNTIME ] == 0 } {
#
#      set_display_item_property $grp_label_color VISIBLE false   
#
#    # colors disabled
#    } elseif { [ get_parameter_value ${param_name}_ENABLE_COLOR ] == 0 } {
#
#      set_display_item_property $grp_label_color VISIBLE false   
#     
#    # disable irrelevant color options
#    } else { 
#
#      set_display_item_property $grp_label_color VISIBLE true   
#
#      set max_pixel_depth [ get_parameter_value ${param_name}_STREAM_PIXEL_SIZE ]  
# 
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_BPP124 VISIBLE true 
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_BPP8   VISIBLE true 
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_BPP16  VISIBLE true 
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_BPP24  VISIBLE true 
#  #   set_parameter_property ${param_name}_COLOR_ENABLE_BPP32  VISIBLE true 
#  #
#  #   if { $max_pixel_depth < 8 } { 
#  #     set_parameter_property ${param_name}_COLOR_ENABLE_BPP8 VISIBLE false 
#  #   } 
#  #   if { $max_pixel_depth < 16 } { 
#  #     set_parameter_property ${param_name}_COLOR_ENABLE_BPP16 VISIBLE false 
#  #   } 
#  #   if { $max_pixel_depth < 24 } { 
#  #     set_parameter_property ${param_name}_COLOR_ENABLE_BPP24 VISIBLE false 
#  #   } 
#  #   if { $max_pixel_depth < 32 } { 
#  #     set_parameter_property ${param_name}_COLOR_ENABLE_BPP32 VISIBLE false 
#  #   } 
#    
#    }
#         
#  }
#  
#
#  ##################################################################################################################"
#
#
#  proc param_set_derived { ctrl_name param_name is_derived } {
#
#    if { $is_derived==1 } { 
#      set_parameter_property ${ctrl_name}_${param_name} DERIVED true                                                                        
#      set_parameter_property ${ctrl_name}_${param_name} VISIBLE 0                                                                        
#    }
#
#  }
#
#
#  proc param_set_value { ctrl_name param_name param_value } {
#
#    if { $param_value!="user" } { 
#      set_parameter_value ${ctrl_name}_${param_name} $param_value                               
#    }
#
#  }
#
#
#  # during HOST declaration  
#  # ctrl_name ena_csr ena_reader ena_writer ena_primary max_width max_height max_buffer max_pixel_size ena_color
#  proc surface_ctrl_set_derived_invisible_main { ctrl_name ena_csr ena_reader ena_writer ena_primary max_width max_height max_buffer max_pixel_size ena_color stm_pixel_format ena_debug } {
# 
#    param_set_derived $ctrl_name ENABLE_CSR             $ena_csr                                                                       
#    param_set_derived $ctrl_name ENABLE_READER          $ena_reader                                                                       
#    param_set_derived $ctrl_name ENABLE_WRITER          $ena_writer                                                                       
#    param_set_derived $ctrl_name ENABLE_PRIMARY         $ena_primary                                                                       
#    param_set_derived $ctrl_name MAX_WIDTH              $max_width                                                                       
#    param_set_derived $ctrl_name MAX_HEIGHT             $max_height                                                                       
#    param_set_derived $ctrl_name MAX_BUFFER_NUM         $max_buffer                                                                       
#    param_set_derived $ctrl_name ENABLE_COLOR           $ena_color                                                                            
#    param_set_derived $ctrl_name STREAM_PIXEL_SIZE      $max_pixel_size
#    param_set_derived $ctrl_name STREAM_PIXEL_FORMAT    $stm_pixel_format
#    param_set_derived $ctrl_name ENABLE_DEBUG           $ena_debug
#                                                                               
#  }
#  
#  proc surface_ctrl_set_derived_value_main { ctrl_name ena_csr ena_reader ena_writer ena_primary max_width max_height max_buffer max_pixel_size ena_color stm_pixel_format ena_debug } {
# 
#    param_set_value $ctrl_name ENABLE_CSR             $ena_csr                                                                       
#    param_set_value $ctrl_name ENABLE_READER          $ena_reader                                                                       
#    param_set_value $ctrl_name ENABLE_WRITER          $ena_writer                                                                       
#    param_set_value $ctrl_name ENABLE_PRIMARY         $ena_primary                                                                       
#    param_set_value $ctrl_name ENABLE_COLOR           $ena_color                                                                       
#    param_set_value $ctrl_name MAX_WIDTH              $max_width                                                                       
#    param_set_value $ctrl_name MAX_HEIGHT             $max_height                                                                       
#    param_set_value $ctrl_name MAX_BUFFER_NUM         $max_buffer                                                                       
#    param_set_value $ctrl_name STREAM_PIXEL_SIZE      $max_pixel_size                                                                       
#    param_set_value $ctrl_name STREAM_PIXEL_FORMAT    $stm_pixel_format                                                                       
#    param_set_value $ctrl_name ENABLE_DEBUG           $ena_debug
#   
#  }
#
#
#  proc surface_ctrl_set_derived_invisible_primary { ctrl_name ena_runtime num_surface ena_sync pixcolor } { 
# 
#    param_set_derived $ctrl_name PRIMARY_ENABLE_RUNTIME $ena_runtime                                                                     
#    param_set_derived $ctrl_name PRIMARY_NUMBER         $num_surface                                                             
#  # param_set_derived $ctrl_name PRIMARY_ENABLE_SYNC    $ena_sync   
#    param_set_derived $ctrl_name FRAME_PIXEL_FORMAT        $pixcolor                                                             
#                                                                    
#     
#  }
#  proc surface_ctrl_set_derived_value_primary     { ctrl_name ena_runtime num_surface ena_sync pixcolor } {
# 
#    param_set_value $ctrl_name PRIMARY_ENABLE_RUNTIME $ena_runtime                                                                       
#    param_set_value $ctrl_name PRIMARY_NUMBER         $num_surface                                                                       
#  # param_set_value $ctrl_name PRIMARY_ENABLE_SYNC    $ena_sync                                                                       
#    param_set_value $ctrl_name FRAME_PIXEL_FORMAT        $pixcolor                                                                       
#   
#  }
#
#
#  proc surface_ctrl_set_derived_invisible_optimisation { ctrl_name cmd_clipping cmd_overlap cmd_loopback cmd_fillcolor cmd_2d cmd_pos cmd_num_log2 align_st align_mm force_premultiplied color_xtd color_lut bpp124 bpp8 bpp16 bpp24 bpp32 } { 
# 
#    param_set_derived $ctrl_name CMD_ENABLE_SPAN_CLIPPING $cmd_clipping                                                                   
#    param_set_derived $ctrl_name CMD_ENABLE_SPAN_OVERLAP  $cmd_overlap                                                                   
#    param_set_derived $ctrl_name CMD_ENABLE_LOOPBACK      $cmd_loopback                                                                  
#    param_set_derived $ctrl_name CMD_ENABLE_FILLCOLOR     $cmd_fillcolor                                                                  
#    param_set_derived $ctrl_name CMD_ENABLE_SPAN2D        $cmd_2d                                                                     
#    param_set_derived $ctrl_name CMD_ENABLE_SPAN_POSITION $cmd_pos                                                             
#    param_set_derived $ctrl_name CMD_MAX_PENDING_LOG2     $cmd_num_log2                                                                     
#    param_set_derived $ctrl_name ENABLE_ALIGN_SPAN        $align_st                                                                     
#    param_set_derived $ctrl_name ENABLE_ALIGN_MEMORY      $align_mm                                                             
#    param_set_derived $ctrl_name COLOR_ENABLE_PREMULTIPLY $force_premultiplied                                                                     
#    param_set_derived $ctrl_name COLOR_ENABLE_EXTENDED    $color_xtd                                                                     
#    param_set_derived $ctrl_name COLOR_ENABLE_LUT         $color_lut                                                                     
#    param_set_derived $ctrl_name CLUT_COLOR_NUM           $color_lut; # set number invisible if fct invisible                                                             
#    param_set_derived $ctrl_name COLOR_ENABLE_BPP124      $bpp124                                                                     
#    param_set_derived $ctrl_name COLOR_ENABLE_BPP8        $bpp8                                                             
#    param_set_derived $ctrl_name COLOR_ENABLE_BPP16       $bpp16                                                                     
#    param_set_derived $ctrl_name COLOR_ENABLE_BPP24       $bpp24                                                                     
#    param_set_derived $ctrl_name COLOR_ENABLE_BPP32       $bpp32                                                             
#      
#  }
#  proc surface_ctrl_set_derived_value_optimisation { ctrl_name cmd_clipping cmd_overlap cmd_loopback cmd_fillcolor cmd_2d cmd_pos cmd_num_log2 align_st align_mm force_premultiplied color_xtd color_lut bpp124 bpp8 bpp16 bpp24 bpp32 } { 
#
#    param_set_value $ctrl_name CMD_ENABLE_SPAN_CLIPPING $cmd_clipping                                                             
#    param_set_value $ctrl_name CMD_ENABLE_SPAN_OVERLAP  $cmd_overlap                                                             
#    param_set_value $ctrl_name CMD_ENABLE_LOOPBACK      $cmd_loopback 
#    param_set_value $ctrl_name CMD_ENABLE_FILLCOLOR     $cmd_fillcolor                                                                         
#    param_set_value $ctrl_name CMD_ENABLE_SPAN2D        $cmd_2d                                                                     
#    param_set_value $ctrl_name CMD_ENABLE_SPAN_POSITION $cmd_pos                                                             
#    param_set_value $ctrl_name CMD_MAX_PENDING_LOG2     $cmd_num_log2                                                                     
#    param_set_value $ctrl_name ENABLE_ALIGN_SPAN        $align_st                                                                     
#    param_set_value $ctrl_name ENABLE_ALIGN_MEMORY      $align_mm                                                             
#    param_set_value $ctrl_name COLOR_ENABLE_PREMULTIPLY $force_premultiplied                                                                     
#    param_set_value $ctrl_name COLOR_ENABLE_EXTENDED    $color_xtd                                                                     
#    param_set_value $ctrl_name COLOR_ENABLE_LUT         $color_lut                                                                     
#  # param_set_value $ctrl_name CLUT_COLOR_NUM           $num_surface                                                             
#    param_set_value $ctrl_name COLOR_ENABLE_BPP124      $bpp124                                                                     
#    param_set_value $ctrl_name COLOR_ENABLE_BPP8        $bpp8                                                             
#    param_set_value $ctrl_name COLOR_ENABLE_BPP16       $bpp16                                                                     
#    param_set_value $ctrl_name COLOR_ENABLE_BPP24       $bpp24                                                                     
#    param_set_value $ctrl_name COLOR_ENABLE_BPP32       $bpp32                                                             
#
#  }
#
#  proc surface_ctrl_set_derived_invisible_memory { ctrl_name is_write pixel_num } { 
#
#    if { ${is_write} == 0 } {     
#      set param_name "RD"
#    } else {
#      set param_name "WR"
#    } 
#    
#    param_set_derived $ctrl_name ${param_name}_NB_PIXEL $pixel_num                                                                     
# 
#  }
#  proc surface_ctrl_set_derived_value_memory { ctrl_name is_write pixel_num } { 
#
#    if { ${is_write} == 0 } {     
#      set param_name "RD"
#    } else {
#      set param_name "WR"
#    } 
#    
#    param_set_value $ctrl_name ${param_name}_NB_PIXEL $pixel_num                                                                     
# 
#  }

 
 