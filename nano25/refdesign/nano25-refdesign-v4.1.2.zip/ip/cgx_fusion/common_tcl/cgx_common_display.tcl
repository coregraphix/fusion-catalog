
#  display_add_interface 
#  display_add_parameters_core
#  display_add_parameters_optimizations
#  display_add_parameters_descriptor 
#  display_add_parameters_overlay
#  display_add_parameters_video_out
#  
# #display_elaborate 
#  display_elaborate_interface
#  display_elaborate_video_out
#  
# #display_main 
#  display_valid  
#  display_valid_core 
#  display_valid_overlay
#  display_valid_video_out


# removed
#  display_elaborate_core  
#  display_add_parameters_sb
#  display_valid_sb



# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- sources tcl                                                                                --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

 

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Interfaces                                                                                 --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc display_add_interface { inst_name } {

    # +-----------------------------------
    # | connection point ${inst_name}_clock_out
    # | 
    add_interface ${inst_name}_clock_out conduit end
    
    set_interface_property ${inst_name}_clock_out ENABLED true
    
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_clock_i          export Input 1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_clken_i          export Input 1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_data_o           export Output -1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_mask_o           export Output -1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_de_o             export Output -1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_hsync_o          export Output -1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_vsync_o          export Output -1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_h_o              export Output -1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_v_o              export Output -1
  # add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_f_o              export Output -1
    add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_underflow_o      export Output 1
  # add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_ctl_sof        export Input  1
  # add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_ctl_sof_locked export Input  1
  # add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_sts_sof        export Output 1
  # add_interface_port ${inst_name}_clock_out ${inst_name}_cvo_sts_sof_locked export Output 1
  
  
    # | 
    # +-----------------------------------
    
    # +-----------------------------------
    # | connection point ${inst_name}_stream_out
    # | 
    add_interface ${inst_name}_stream_out axi4stream start
    
    set_interface_property ${inst_name}_stream_out associatedClock clock
    set_interface_property ${inst_name}_stream_out associatedReset reset
    
 #  set_interface_property ${inst_name}_stream_out dataBitsPerSymbol -1
 #  set_interface_property ${inst_name}_stream_out errorDescriptor ""
 #  set_interface_property ${inst_name}_stream_out maxChannel 0
 #  set_interface_property ${inst_name}_stream_out readyLatency 1
 #  set_interface_property ${inst_name}_stream_out symbolsPerBeat -1
    set_interface_property ${inst_name}_stream_out ENABLED true
    set_interface_property ${inst_name}_stream_out EXPORT_OF ""
    set_interface_property ${inst_name}_stream_out PORT_NAME_MAP ""
    set_interface_property ${inst_name}_stream_out CMSIS_SVD_VARIABLES ""
    set_interface_property ${inst_name}_stream_out SVD_ADDRESS_GROUP ""
    
    add_interface_port ${inst_name}_stream_out ${inst_name}_dat_tready_i tready Input  1
    add_interface_port ${inst_name}_stream_out ${inst_name}_dat_tvalid_o tvalid Output 1
    add_interface_port ${inst_name}_stream_out ${inst_name}_dat_tdata_o  tdata  Output -1
    add_interface_port ${inst_name}_stream_out ${inst_name}_dat_tlast_o  tlast  Output 1
    add_interface_port ${inst_name}_stream_out ${inst_name}_dat_tuser_o  tuser  Output -1
  # add_interface_port ${inst_name}_stream_out ${inst_name}_dat_tid_o    tid    Output 8
    # | 
    # +-----------------------------------

  }

 
  proc display_elaborate_interface { inst_name } {
  
    if { [ get_parameter_value WZD_DPY_VIDEO_CLOCKED ] == 1 } {
      set_interface_property ${inst_name}_clock_out  ENABLED true  
      set_interface_property ${inst_name}_stream_out ENABLED false
    } else {
      set_interface_property ${inst_name}_clock_out  ENABLED false  
      set_interface_property ${inst_name}_stream_out ENABLED true 
    }
    
 #  # empty size independent 
 #  set_interface_property ${inst_name}_stream_out dataBitsPerSymbol [ expr ( [get_parameter_value WZD_DPY_video_frame_color_size] ) ]
 #  # empty size dependent 
 #  set_interface_property ${inst_name}_stream_out symbolsPerBeat [ expr ( [get_parameter_value WZD_DPY_video_frame_color_num] * [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] * [get_parameter_value WZD_DPY_VIDEO_SCREEN_NUM] ) ]
   
   
    set pixel_size [ expr ([get_parameter_value WZD_DPY_video_frame_color_size] * [get_parameter_value WZD_DPY_video_frame_color_num]) ]
    # [0] = critical 
    # [1:8] = layer index => up to 256 layers
    
  # if { [ get_parameter_value ${inst_name}_LAYER_ENABLE_CRITICAL ] == 0 } {  
  #   set mask_size 0
  # else
  #   set mask_size [ expr (1 + 8) ]
  # }
  # set mask_size [ expr (1 + 8) ]
    set mask_size 1
        
    set_port_property ${inst_name}_dat_tdata_o    WIDTH_EXPR [ expr ( $pixel_size * [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] * [get_parameter_value WZD_DPY_VIDEO_SCREEN_NUM] ) ]    
    set_port_property ${inst_name}_dat_tuser_o    WIDTH_EXPR [ expr ( $mask_size  * [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] * [get_parameter_value WZD_DPY_VIDEO_SCREEN_NUM] + 3) ]    

    set_port_property ${inst_name}_cvo_data_o     WIDTH_EXPR [ expr ( $pixel_size * [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] * [get_parameter_value WZD_DPY_VIDEO_SCREEN_NUM] ) ]
    set_port_property ${inst_name}_cvo_mask_o     WIDTH_EXPR [ expr ( $mask_size  * [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] * [get_parameter_value WZD_DPY_VIDEO_SCREEN_NUM] ) ]

    set_port_property ${inst_name}_cvo_de_o       WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM]
    set_port_property ${inst_name}_cvo_hsync_o    WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM]
    set_port_property ${inst_name}_cvo_vsync_o    WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM]
    set_port_property ${inst_name}_cvo_h_o        WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] 
    set_port_property ${inst_name}_cvo_v_o        WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] 
  # set_port_property ${inst_name}_cvo_f_o        WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM]

  }



# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Main                                                                                       --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

# proc display_main {   } {
#
# }
#
#
# proc display_elaborate {   } {
#
# }


  proc display_valid { inst_id inst_name } {

    display_valid_overlay              ${inst_name}     
    display_valid_video_out ${inst_id} ${inst_name} 
  # display_valid_sb        ${inst_id} ${inst_name}

  }


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Core                                                                                       --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc display_add_parameters_core { inst_id inst_name parent_gui_name } {
 
#   set VERSION_MAJOR  ${inst_name}_VERSION_MAJOR
#   set VERSION_MINOR  ${inst_name}_VERSION_MINOR
    set ENABLE_LAYER   ${inst_name}_ENABLE_LAYER
    set ENABLE_SB      ${inst_name}_ENABLE_SB
 
#    add_parameter          $VERSION_MAJOR INTEGER 0
#    set_parameter_property $VERSION_MAJOR DISPLAY_NAME "major";
#    set_parameter_property $VERSION_MAJOR DISPLAY_HINT INTEGER
#    set_parameter_property $VERSION_MAJOR DESCRIPTION " "
#    set_parameter_property $VERSION_MAJOR VISIBLE false 
#  # if {$is_core == 0} { 
#    set_parameter_property $VERSION_MAJOR DERIVED true 
#  # }
#    set_parameter_property $VERSION_MAJOR HDL_PARAMETER true
# 
#    add_parameter          $VERSION_MINOR INTEGER 0
#    set_parameter_property $VERSION_MINOR DISPLAY_NAME "minor";
#    set_parameter_property $VERSION_MINOR DISPLAY_HINT INTEGER
#    set_parameter_property $VERSION_MINOR DESCRIPTION " "
#    set_parameter_property $VERSION_MINOR VISIBLE false 
#  # if {$is_core == 0} { 
#    set_parameter_property $VERSION_MINOR DERIVED true 
#  # }
#    set_parameter_property $VERSION_MINOR HDL_PARAMETER true
 

    add_parameter          $ENABLE_LAYER INTEGER 1
    set_parameter_property $ENABLE_LAYER DISPLAY_HINT boolean
    set_parameter_property $ENABLE_LAYER DISPLAY_NAME "use Layers composition (=Overlay)" 
    set_parameter_property $ENABLE_LAYER AFFECTS_ELABORATION true  
    set_parameter_property $ENABLE_LAYER HDL_PARAMETER true
    set_parameter_property $ENABLE_LAYER VISIBLE false;  # always On 

    add_parameter          $ENABLE_SB INTEGER 0
    set_parameter_property $ENABLE_SB DISPLAY_HINT boolean
    set_parameter_property $ENABLE_SB DISPLAY_NAME "use Screen-Buffer" 
    set_parameter_property $ENABLE_SB AFFECTS_ELABORATION true  
    set_parameter_property $ENABLE_SB HDL_PARAMETER true

  # add_display_item $parent_gui_name $VERSION_MAJOR  PARAMETER
  # add_display_item $parent_gui_name $VERSION_MINOR  PARAMETER
    add_display_item $parent_gui_name $ENABLE_LAYER   PARAMETER
    add_display_item $parent_gui_name $ENABLE_SB      PARAMETER
 
  }
  
  
#  proc display_elaborate_core { inst_name v_major v_minor } {
#
#    set VERSION_MAJOR  ${inst_name}_VERSION_MAJOR
#    set VERSION_MINOR  ${inst_name}_VERSION_MINOR
#   
#    set_parameter_value $VERSION_MAJOR  $v_major 
#    set_parameter_value $VERSION_MINOR  $v_minor 
# 
#  }


  proc display_valid_core { inst_name } {

    set ENABLE_LAYER ${inst_name}_ENABLE_LAYER
    set ENABLE_SB    ${inst_name}_ENABLE_SB

    if {[ get_parameter_value $ENABLE_LAYER] == 1} {
      set_display_item_property "Overlay"       VISIBLE true  
    } else {
      set_display_item_property "Overlay"       VISIBLE false
    }

 #  if {[ get_parameter_value $ENABLE_SB] == 1} {
 #    set_display_item_property "Screen-Buffer" VISIBLE true  
 #  } else {
 #    set_display_item_property "Screen-Buffer" VISIBLE false
 #  }
 
  }
 
   
    
# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Optimizations                                                                              --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc display_add_parameters_optimizations { inst_id inst_name parent_gui_name } {

    set ENABLE_DEBUG                ${inst_name}_ENABLE_DEBUG
    set ENABLE_CSR_READBACK_REDUCED ${inst_name}_ENABLE_CSR_READBACK_REDUCED

    add_parameter          $ENABLE_DEBUG INTEGER 0
    set_parameter_property $ENABLE_DEBUG DISPLAY_NAME "Debug";
    set_parameter_property $ENABLE_DEBUG DISPLAY_HINT boolean
    set_parameter_property $ENABLE_DEBUG DESCRIPTION "Turn on to support debug"
    set_parameter_property $ENABLE_DEBUG VISIBLE true 
    set_parameter_property $ENABLE_DEBUG HDL_PARAMETER true

    add_parameter          $ENABLE_CSR_READBACK_REDUCED INTEGER 0
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED DISPLAY_NAME "Reduced CSR Readback";
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED DISPLAY_HINT boolean
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED DESCRIPTION "Turn on to disable Control-Status Registers Readback and save ressources"
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED VISIBLE true 
    set_parameter_property $ENABLE_CSR_READBACK_REDUCED HDL_PARAMETER true

    add_display_item $parent_gui_name "Optimizations${inst_id}" GROUP tab
 
    add_display_item "Optimizations${inst_id}" $ENABLE_DEBUG         PARAMETER
    add_display_item "Optimizations${inst_id}" $ENABLE_CSR_READBACK_REDUCED  PARAMETER

  }


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Descriptor                                                                                --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc display_add_parameters_descriptor { inst_id inst_name parent_gui_name } {

    set DESC_ADDR8_SIZE          ${inst_name}_DESC_ADDR8_SIZE
    set DESC_HAS_DEDICATED_CLK   ${inst_name}_DESC_HAS_DEDICATED_CLK

    # invisible
    add_parameter          $DESC_ADDR8_SIZE INTEGER 30
    set_parameter_property $DESC_ADDR8_SIZE DISPLAY_NAME "Address width" 
    set_parameter_property $DESC_ADDR8_SIZE ALLOWED_RANGES {1:64} 
  # set_parameter_property $DESC_ADDR8_SIZE system_info {ADDRESS_WIDTH descriptor_read}
    set_parameter_property $DESC_ADDR8_SIZE VISIBLE true
    set_parameter_property $DESC_ADDR8_SIZE HDL_PARAMETER true
       
    add_parameter          $DESC_HAS_DEDICATED_CLK INTEGER 1
    set_parameter_property $DESC_HAS_DEDICATED_CLK DISPLAY_NAME "Dedicated clock domain" 
  # set_parameter_property $DESC_HAS_DEDICATED_CLK VISIBLE true
    set_parameter_property $DESC_HAS_DEDICATED_CLK DISPLAY_HINT boolean
    set_parameter_property $DESC_HAS_DEDICATED_CLK HDL_PARAMETER true
  
    add_display_item $parent_gui_name "Memory Descriptor${inst_id}" GROUP tab

    add_display_item "Memory Descriptor${inst_id}" $DESC_HAS_DEDICATED_CLK       PARAMETER
    add_display_item "Memory Descriptor${inst_id}" $DESC_ADDR8_SIZE              PARAMETER

  }

   
# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Overlay                                                                                --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------
 
  proc display_add_parameters_overlay { inst_id inst_name parent_gui_name MAX_VIDEO } {

    set LAYER_MAX_NUMBER                  ${inst_name}_LAYER_MAX_NUMBER
  # set ENABLE_VIDEO_SYNC                 ${inst_name}_ENABLE_VIDEO_SYNC
  # set NUMBER_OF_VIDEO_SYNC              ${inst_name}_NUMBER_OF_VIDEO_SYNC
  # set LAYER_ENABLE_STREAM               ${inst_name}_LAYER_ENABLE_STREAM
  # set LAYER_STREAM_NUM                  ${inst_name}_LAYER_STREAM_NUM
  
    set LAYER_ENABLE_CRITICAL             ${inst_name}_LAYER_ENABLE_CRITICAL
  # set LAYER_ENABLE_ALPHA_GLOBAL         ${inst_name}_LAYER_ENABLE_ALPHA_GLOBAL
  # set LAYER_ENABLE_WINDOWING            ${inst_name}_LAYER_ENABLE_WINDOWING        
    set LAYER_ENABLE_RESIZING             ${inst_name}_LAYER_ENABLE_RESIZING         
    set LAYER_ENABLE_FILTERING_H          ${inst_name}_LAYER_ENABLE_FILTERING_H      
    set LAYER_ENABLE_FILTERING_V          ${inst_name}_LAYER_ENABLE_FILTERING_V      
  # set ENABLE_COLOR_PALETTE              ${inst_name}_ENABLE_COLOR_PALETTE 
    set LAYER_ENABLE_BANDWIDTH_VIEWER     ${inst_name}_LAYER_ENABLE_BANDWIDTH_VIEWER 
  # set NUMBER_OF_PALETTE_COLORS          ${inst_name}_NUMBER_OF_PALETTE_COLORS
  # set ENABLE_COLOR_EXTENDED             ${inst_name}_ENABLE_COLOR_EXTENDED  
    set LAYER_ENABLE_COLORTRANSFORM       ${inst_name}_LAYER_ENABLE_COLORTRANSFORM  
  # set LAYER_ENABLE_CHROMA_KEYING        ${inst_name}_LAYER_ENABLE_CHROMA_KEYING
  # set LAYER_ENABLE_MASKING              ${inst_name}_LAYER_ENABLE_MASKING  
    set LAYER_ENABLE_CSR_BKG_COLOR        ${inst_name}_LAYER_ENABLE_CSR_BKG_COLOR      
    set LAYER_BKG_COLOR                   ${inst_name}_LAYER_BKG_COLOR      
    set LAYER_PIXEL_NUM                   ${inst_name}_LAYER_PIXEL_NUM 
    set LAYER_VIDEO_ENABLE_FLIP_H         ${inst_name}_LAYER_VIDEO_ENABLE_FLIP_H  
    set LAYER_VIDEO_ENABLE_FLIP_V         ${inst_name}_LAYER_VIDEO_ENABLE_FLIP_V  
    set LAYER_VIDEO_ENABLE_ROTATE         ${inst_name}_LAYER_VIDEO_ENABLE_ROTATE  
                                                 
                                                 
    ####################
    # Overlay
    ####################

    add_parameter          $LAYER_MAX_NUMBER INTEGER 16
    set_parameter_property $LAYER_MAX_NUMBER DISPLAY_NAME "Number of layers";
    set_parameter_property $LAYER_MAX_NUMBER ALLOWED_RANGES {1,2,4,8,16,32,64,128,256}
    set_parameter_property $LAYER_MAX_NUMBER DESCRIPTION "Specify the maximum number of layers supported by the core";
    set_parameter_property $LAYER_MAX_NUMBER HDL_PARAMETER true

    add_parameter          $LAYER_PIXEL_NUM INTEGER 1
    set_parameter_property $LAYER_PIXEL_NUM DISPLAY_NAME "Number of pixels in parallel";
    set_parameter_property $LAYER_PIXEL_NUM ALLOWED_RANGES {1,2,4,8,16,32}
    set_parameter_property $LAYER_PIXEL_NUM DESCRIPTION "Choose the number of pixels in parallel for composition. Set 2, 4, 8, 16 or 32 to increase internal composition throughput by 2, 4, 8, 16 or 32 respectively . Note that resources increase with parallelism. 1 = small resources / 32 = high performance.";
    set_parameter_property $LAYER_PIXEL_NUM DISPLAY_UNITS "Pixels"
    set_parameter_property $LAYER_PIXEL_NUM AFFECTS_ELABORATION true   
    set_parameter_property $LAYER_PIXEL_NUM HDL_PARAMETER true

  # add_parameter          $ENABLE_VIDEO_SYNC INTEGER 0
  # set_parameter_property $ENABLE_VIDEO_SYNC DISPLAY_NAME "Video surface";
  # set_parameter_property $ENABLE_VIDEO_SYNC DISPLAY_HINT boolean
  # set_parameter_property $ENABLE_VIDEO_SYNC DESCRIPTION "Turn on to support Video surfaces"
  # set_parameter_property $ENABLE_VIDEO_SYNC AFFECTS_ELABORATION true        
  # set_parameter_property $ENABLE_VIDEO_SYNC VISIBLE true 
  # set_parameter_property $ENABLE_VIDEO_SYNC HDL_PARAMETER true
  #
  # add_parameter          $NUMBER_OF_VIDEO_SYNC INTEGER 1
  # set_parameter_property $NUMBER_OF_VIDEO_SYNC DISPLAY_NAME "Number of videos synchronizations";
  # set vsync_range "{1:$MAX_VIDEO}"
  # set_parameter_property $NUMBER_OF_VIDEO_SYNC ALLOWED_RANGES $vsync_range
  # set_parameter_property $NUMBER_OF_VIDEO_SYNC DESCRIPTION "Specify the maximum number of video synchronizations";
  # set_parameter_property $NUMBER_OF_VIDEO_SYNC AFFECTS_ELABORATION true        
  # set_parameter_property $NUMBER_OF_VIDEO_SYNC HDL_PARAMETER true


  # add_parameter          $LAYER_ENABLE_STREAM INTEGER 0
  # set_parameter_property $LAYER_ENABLE_STREAM DISPLAY_NAME "Video Stream (Avalon-ST)";
  # set_parameter_property $LAYER_ENABLE_STREAM DISPLAY_HINT boolean
  # set_parameter_property $LAYER_ENABLE_STREAM DESCRIPTION "Turn on to support Video streams"
  # set_parameter_property $LAYER_ENABLE_STREAM AFFECTS_ELABORATION true        
  # set_parameter_property $LAYER_ENABLE_STREAM ENABLED false 
  # set_parameter_property $LAYER_ENABLE_STREAM VISIBLE false 
  # set_parameter_property $LAYER_ENABLE_STREAM HDL_PARAMETER false
  #
  # add_parameter          $LAYER_STREAM_NUM INTEGER 1
  # set_parameter_property $LAYER_STREAM_NUM DISPLAY_NAME "Number of stream";
  # set_parameter_property $LAYER_STREAM_NUM ALLOWED_RANGES {1:16}
  # set_parameter_property $LAYER_STREAM_NUM DESCRIPTION "Specify the maximum number of streams";
  # set_parameter_property $LAYER_STREAM_NUM VISIBLE false 
  # set_parameter_property $LAYER_STREAM_NUM HDL_PARAMETER false

   #add_parameter          $layer_depth_enable INTEGER 1
   #set_parameter_property $layer_depth_enable DISPLAY_NAME "Explicit layer depth";
   #set_parameter_property $layer_depth_enable DISPLAY_HINT boolean
   #set_parameter_property $layer_depth_enable DESCRIPTION "0/1: implicit/explicit layers stacking order";
   #set_parameter_property $layer_depth_enable VISIBLE false

   #add_parameter          $number_of_layerdepths INTEGER 8
   #set_parameter_property $number_of_layerdepths DISPLAY_NAME "Number of layer depths";
   #set_parameter_property $number_of_layerdepths ALLOWED_RANGES {2,4,8,16,32,64}
   #set_parameter_property $number_of_layerdepths DESCRIPTION "Specify the maximum number of depths supported by explicit layers stacking order";
   #set_parameter_property $number_of_layerdepths VISIBLE false

    #set_parameter_property $windowing_enable DISPLAY_NAME "Windowing";
    #set_parameter_property $windowing_enable DISPLAY_HINT boolean
    #set_parameter_property $windowing_enable DESCRIPTION "dynamic selection of the usefull part of object data (cf: ATHLET User Manual)";

    add_parameter          $LAYER_ENABLE_CRITICAL INTEGER 0
    set_parameter_property $LAYER_ENABLE_CRITICAL DISPLAY_NAME "Safety critical";
    set_parameter_property $LAYER_ENABLE_CRITICAL DISPLAY_HINT boolean
    set_parameter_property $LAYER_ENABLE_CRITICAL DESCRIPTION " ";
    set_parameter_property $LAYER_ENABLE_CRITICAL HDL_PARAMETER true
    set_parameter_property $LAYER_ENABLE_CRITICAL VISIBLE false; # not yet released

  # add_parameter          $LAYER_ENABLE_ALPHA_GLOBAL INTEGER 1
  # set_parameter_property $LAYER_ENABLE_ALPHA_GLOBAL DISPLAY_NAME "Transparency";
  # set_parameter_property $LAYER_ENABLE_ALPHA_GLOBAL DISPLAY_HINT boolean
  # set_parameter_property $LAYER_ENABLE_ALPHA_GLOBAL DESCRIPTION "Run-time control over layers transparency";
  # set_parameter_property $LAYER_ENABLE_ALPHA_GLOBAL HDL_PARAMETER true

  # add_parameter          $LAYER_ENABLE_WINDOWING INTEGER 1
  # set_parameter_property $LAYER_ENABLE_WINDOWING DISPLAY_NAME "Windowing";
  # set_parameter_property $LAYER_ENABLE_WINDOWING DISPLAY_HINT boolean
  # set_parameter_property $LAYER_ENABLE_WINDOWING DESCRIPTION "Run-time control over layers transparency";
  # set_parameter_property $LAYER_ENABLE_WINDOWING VISIBLE false
  # set_parameter_property $LAYER_ENABLE_WINDOWING HDL_PARAMETER true

    add_parameter          $LAYER_ENABLE_RESIZING INTEGER 1
    set_parameter_property $LAYER_ENABLE_RESIZING DISPLAY_NAME "Resizing";
    set_parameter_property $LAYER_ENABLE_RESIZING DISPLAY_HINT boolean
    set_parameter_property $LAYER_ENABLE_RESIZING DESCRIPTION "Turn on to enable run-time csr over layers up/down resizing";
    set_parameter_property $LAYER_ENABLE_RESIZING HDL_PARAMETER true
    
    add_parameter          $LAYER_ENABLE_FILTERING_H INTEGER 0
    set_parameter_property $LAYER_ENABLE_FILTERING_H DISPLAY_NAME "Horizontal filtering";
    set_parameter_property $LAYER_ENABLE_FILTERING_H DISPLAY_HINT boolean
    set_parameter_property $LAYER_ENABLE_FILTERING_H DESCRIPTION "Turn on to enable horizontal filtering (2nd order polyphase filter)";
    set_parameter_property $LAYER_ENABLE_FILTERING_H HDL_PARAMETER true
    
    add_parameter          $LAYER_ENABLE_FILTERING_V INTEGER 0
    set_parameter_property $LAYER_ENABLE_FILTERING_V DISPLAY_NAME "Vertical filtering";
    set_parameter_property $LAYER_ENABLE_FILTERING_V DISPLAY_HINT boolean
    set_parameter_property $LAYER_ENABLE_FILTERING_V DESCRIPTION "Turn on to enable vertical filtering (2nd order polyphase filter)";
    set_parameter_property $LAYER_ENABLE_FILTERING_V HDL_PARAMETER true
    
#   add_parameter          $ENABLE_COLOR_PALETTE INTEGER 0
#   set_parameter_property $ENABLE_COLOR_PALETTE DISPLAY_NAME "Color palette";
#   set_parameter_property $ENABLE_COLOR_PALETTE DISPLAY_HINT boolean
#   set_parameter_property $ENABLE_COLOR_PALETTE DESCRIPTION "Turn on to enable support for color formats using color palettes";
#   set_parameter_property $ENABLE_COLOR_PALETTE HDL_PARAMETER true

    add_parameter          $LAYER_ENABLE_BANDWIDTH_VIEWER INTEGER 0
    set_parameter_property $LAYER_ENABLE_BANDWIDTH_VIEWER DISPLAY_NAME "Bandwidth viewer";
    set_parameter_property $LAYER_ENABLE_BANDWIDTH_VIEWER DISPLAY_HINT boolean
    set_parameter_property $LAYER_ENABLE_BANDWIDTH_VIEWER DESCRIPTION "Turn on to enable support for composition bandwidth viewer";
    set_parameter_property $LAYER_ENABLE_BANDWIDTH_VIEWER HDL_PARAMETER true

#    add_parameter          $NUMBER_OF_PALETTE_COLORS INTEGER 256
#    set_parameter_property $NUMBER_OF_PALETTE_COLORS DISPLAY_NAME "Number of LUT colors";
#    set_parameter_property $NUMBER_OF_PALETTE_COLORS ALLOWED_RANGES {16,32,64,128,256,512,1024,2048}
#    set_parameter_property $NUMBER_OF_PALETTE_COLORS DESCRIPTION "Palette capacity in number of 24-bits colors";
##   set_parameter_property $NUMBER_OF_PALETTE_COLORS VISIBLE true 
#    set_parameter_property $NUMBER_OF_PALETTE_COLORS ENABLED false
#    set_parameter_property $NUMBER_OF_PALETTE_COLORS HDL_PARAMETER true

  # add_parameter          $ENABLE_COLOR_EXTENDED INTEGER 1
  # set_parameter_property $ENABLE_COLOR_EXTENDED DISPLAY_NAME "Extended color formats" 
  # set_parameter_property $ENABLE_COLOR_EXTENDED DISPLAY_HINT boolean
  # set_parameter_property $ENABLE_COLOR_EXTENDED DESCRIPTION "extend default {A,X}RGB support to {A,X}BGR, RGB{A,X} and BGR{A,X} color channels orderings" 
  # set_parameter_property $ENABLE_COLOR_EXTENDED HDL_PARAMETER true

    add_parameter          $LAYER_ENABLE_COLORTRANSFORM INTEGER 0
    set_parameter_property $LAYER_ENABLE_COLORTRANSFORM DISPLAY_NAME "Color transforms";
    set_parameter_property $LAYER_ENABLE_COLORTRANSFORM DISPLAY_HINT boolean
    set_parameter_property $LAYER_ENABLE_COLORTRANSFORM DESCRIPTION "Turn on to enable support for color transformations" 
    set_parameter_property $LAYER_ENABLE_COLORTRANSFORM ENABLED true
    set_parameter_property $LAYER_ENABLE_COLORTRANSFORM HDL_PARAMETER true

  # add_parameter          $LAYER_ENABLE_CHROMA_KEYING INTEGER 0
  # set_parameter_property $LAYER_ENABLE_CHROMA_KEYING DISPLAY_NAME "Chroma keying";
  # set_parameter_property $LAYER_ENABLE_CHROMA_KEYING DISPLAY_HINT boolean
  # set_parameter_property $LAYER_ENABLE_CHROMA_KEYING DESCRIPTION "Turn on to enable support for chroma keying" 
  # set_parameter_property $LAYER_ENABLE_CHROMA_KEYING ENABLED true
  # set_parameter_property $LAYER_ENABLE_CHROMA_KEYING HDL_PARAMETER true
  #
  # add_parameter          $LAYER_ENABLE_MASKING INTEGER 0
  # set_parameter_property $LAYER_ENABLE_MASKING DISPLAY_NAME "Alpha masking";
  # set_parameter_property $LAYER_ENABLE_MASKING DISPLAY_HINT boolean
  # set_parameter_property $LAYER_ENABLE_MASKING DESCRIPTION "Turn on to enable support for alpha masks" 
  # set_parameter_property $LAYER_ENABLE_MASKING ENABLED true
  # set_parameter_property $LAYER_ENABLE_MASKING HDL_PARAMETER true
    
    add_parameter          $LAYER_ENABLE_CSR_BKG_COLOR INTEGER 1
    set_parameter_property $LAYER_ENABLE_CSR_BKG_COLOR DISPLAY_NAME "Background color runtime control"
    set_parameter_property $LAYER_ENABLE_CSR_BKG_COLOR DISPLAY_HINT boolean
    set_parameter_property $LAYER_ENABLE_CSR_BKG_COLOR DESCRIPTION " "
    set_parameter_property $LAYER_ENABLE_CSR_BKG_COLOR AFFECTS_ELABORATION true        
    set_parameter_property $LAYER_ENABLE_CSR_BKG_COLOR ENABLED true
    set_parameter_property $LAYER_ENABLE_CSR_BKG_COLOR HDL_PARAMETER true
    
    add_parameter          $LAYER_BKG_COLOR INTEGER 0xFFFFFF
    set_parameter_property $LAYER_BKG_COLOR DISPLAY_NAME "Background solid color"
    set_parameter_property $LAYER_BKG_COLOR DISPLAY_HINT hexadecimal
    set_parameter_property $LAYER_BKG_COLOR ALLOWED_RANGES {0:0xFFFFFF}
    set_parameter_property $LAYER_BKG_COLOR DESCRIPTION "Default solid color in {R,G,B} format. Not relevant when output pixel format is ARGB_8888_PRE meaning that background is transparent" 
    set_parameter_property $LAYER_BKG_COLOR HDL_PARAMETER true
    
  # add_parameter          $LAYER_BKG_COLOR_R INTEGER 0
 #  set_parameter_property $LAYER_BKG_COLOR_R DISPLAY_NAME "Red"
 #  set_parameter_property $LAYER_BKG_COLOR_R ALLOWED_RANGES {0:255}
 #  set_parameter_property $LAYER_BKG_COLOR_R DESCRIPTION " 0 < Red < 256";
 #  set_parameter_property $LAYER_BKG_COLOR_R AFFECTS_ELABORATION false        
 #  set_parameter_property $LAYER_BKG_COLOR_R ENABLED true
 #  
  # add_parameter          $LAYER_BKG_COLOR_G INTEGER 0
 #  set_parameter_property $LAYER_BKG_COLOR_G DISPLAY_NAME "Green"
 #  set_parameter_property $LAYER_BKG_COLOR_G ALLOWED_RANGES {0:255}
 #  set_parameter_property $LAYER_BKG_COLOR_G DESCRIPTION " 0 < Green < 256";
 #  set_parameter_property $LAYER_BKG_COLOR_G AFFECTS_ELABORATION false        
 #  set_parameter_property $LAYER_BKG_COLOR_G ENABLED true
 #  
  # add_parameter          $LAYER_BKG_COLOR_B INTEGER 0
 #  set_parameter_property $LAYER_BKG_COLOR_B DISPLAY_NAME "Blue"
 #  set_parameter_property $LAYER_BKG_COLOR_B ALLOWED_RANGES {0:255}
 #  set_parameter_property $LAYER_BKG_COLOR_B DESCRIPTION " 0 < Blue < 256";
 #  set_parameter_property $LAYER_BKG_COLOR_B AFFECTS_ELABORATION false        
 #  set_parameter_property $LAYER_BKG_COLOR_B ENABLED true


    add_parameter          $LAYER_VIDEO_ENABLE_FLIP_H INTEGER 0
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_H DISPLAY_NAME "Horizontal flip";
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_H DISPLAY_HINT boolean
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_H DESCRIPTION "Turn on to support horizontal flip";
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_H AFFECTS_ELABORATION true        
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_H HDL_PARAMETER true
    
    add_parameter          $LAYER_VIDEO_ENABLE_FLIP_V INTEGER 0
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_V DISPLAY_NAME "Vertical flip";
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_V DISPLAY_HINT boolean
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_V DESCRIPTION "Turn on to support vertical flip";
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_V AFFECTS_ELABORATION true        
    set_parameter_property $LAYER_VIDEO_ENABLE_FLIP_V HDL_PARAMETER true
    
    add_parameter          $LAYER_VIDEO_ENABLE_ROTATE INTEGER 0
    set_parameter_property $LAYER_VIDEO_ENABLE_ROTATE DISPLAY_NAME "90� Rotation (requires Screen-buffer) ";
    set_parameter_property $LAYER_VIDEO_ENABLE_ROTATE DISPLAY_HINT boolean
    set_parameter_property $LAYER_VIDEO_ENABLE_ROTATE DESCRIPTION "Turn on to support 90� screen rotation. This feature requires the screen-buffer mode";
    set_parameter_property $LAYER_VIDEO_ENABLE_ROTATE AFFECTS_ELABORATION true        
    set_parameter_property $LAYER_VIDEO_ENABLE_ROTATE HDL_PARAMETER true


    #Parameter Adding

    add_display_item $parent_gui_name "Overlay${inst_id}" GROUP tab

    add_display_item "Overlay${inst_id}" $LAYER_MAX_NUMBER                 PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_PIXEL_NUM                  PARAMETER
  # add_display_item "Overlay${inst_id}" $ENABLE_VIDEO_SYNC                PARAMETER
  # add_display_item "Overlay${inst_id}" $NUMBER_OF_VIDEO_SYNC             PARAMETER
  # add_display_item "Overlay${inst_id}" $LAYER_ENABLE_STREAM              PARAMETER
  # add_display_item "Overlay${inst_id}" $LAYER_STREAM_NUM                 PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_ENABLE_CRITICAL            PARAMETER
  # add_display_item "Overlay${inst_id}" $LAYER_ENABLE_ALPHA_GLOBAL        PARAMETER
  # add_display_item "Overlay${inst_id}" $LAYER_ENABLE_WINDOWING           PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_ENABLE_RESIZING            PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_ENABLE_FILTERING_H         PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_ENABLE_FILTERING_V         PARAMETER
  # add_display_item "Overlay${inst_id}" $ENABLE_COLOR_PALETTE             PARAMETER
  # add_display_item "Overlay${inst_id}" $NUMBER_OF_PALETTE_COLORS         PARAMETER
  # add_display_item "Overlay${inst_id}" $ENABLE_COLOR_EXTENDED            PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_ENABLE_COLORTRANSFORM      PARAMETER
  # add_display_item "Overlay${inst_id}" $LAYER_ENABLE_CHROMA_KEYING       PARAMETER
  # add_display_item "Overlay${inst_id}" $LAYER_ENABLE_MASKING             PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_ENABLE_CSR_BKG_COLOR       PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_BKG_COLOR                  PARAMETER
    add_display_item "Overlay${inst_id}" $LAYER_ENABLE_BANDWIDTH_VIEWER    PARAMETER    
  # add_display_item "Overlay${inst_id}" $LAYER_BKG_COLOR_r                PARAMETER
  # add_display_item "Overlay${inst_id}" $LAYER_BKG_COLOR_g                PARAMETER
  # add_display_item "Overlay${inst_id}" $LAYER_BKG_COLOR_b                PARAMETER

    add_display_item "Overlay${inst_id}" "Layout${inst_id}" GROUP  

    add_display_item "Layout${inst_id}" $LAYER_VIDEO_ENABLE_FLIP_H   PARAMETER
    add_display_item "Layout${inst_id}" $LAYER_VIDEO_ENABLE_FLIP_V   PARAMETER
    add_display_item "Layout${inst_id}" $LAYER_VIDEO_ENABLE_ROTATE   PARAMETER


    # Overlay.end
    ####################
 
  }


  proc display_valid_overlay { inst_name } {

    set LAYER_ENABLE_CSR_BKG_COLOR ${inst_name}_LAYER_ENABLE_CSR_BKG_COLOR      
    set LAYER_BKG_COLOR                  ${inst_name}_LAYER_BKG_COLOR      
    set ENABLE_SB                        ${inst_name}_ENABLE_SB
    set LAYER_VIDEO_ENABLE_ROTATE        ${inst_name}_LAYER_VIDEO_ENABLE_ROTATE  

    if {[ get_parameter_value $LAYER_ENABLE_CSR_BKG_COLOR] == 1} {
      set_parameter_property $LAYER_BKG_COLOR ENABLED false
    } else {                            
      set_parameter_property $LAYER_BKG_COLOR ENABLED true
    }


    if {[ get_parameter_value $ENABLE_SB] == 1} {
      set_parameter_property $LAYER_VIDEO_ENABLE_ROTATE ENABLED true
    } else {                            
      set_parameter_property $LAYER_VIDEO_ENABLE_ROTATE ENABLED false
    }


  # set ENABLE_COLOR_PALETTE      ${inst_name}_ENABLE_COLOR_PALETTE    
  # set NUMBER_OF_PALETTE_COLORS  ${inst_name}_NUMBER_OF_PALETTE_COLORS
  #
  # if {[ get_parameter_value $ENABLE_COLOR_PALETTE] == 1} {
  #   # ENABLING
  #   set_parameter_property $NUMBER_OF_PALETTE_COLORS ENABLED true
  # } else {
  #   #DISABLING
  #   set_parameter_property $NUMBER_OF_PALETTE_COLORS ENABLED false
  # }

  }


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Screen Buffer                                                                              --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#    proc display_add_parameters_sb { inst_id inst_name parent_gui_name } {
#  
#      set param_name ${inst_name}_SB
#  
#      add_display_item $parent_gui_name "Screen-Buffer${inst_id}" GROUP tab
#   
#      surface_data_add_parameters ${param_name} "Screen-Buffer${inst_id}"  
#      surface_sync_add_parameters ${param_name} "Screen-Buffer${inst_id}"  
#  
#  #   set SB_FRAME_REPEAT  ${param_name}_FRAME_REPEAT                    
#  #   set VIDEO_ENABLE_SCREENBUFFER        ${inst_name}_VIDEO_ENABLE_SCREENBUFFER
#  #   set VIDEO_SB_ENABLE_ROTATE ${inst_name}_VIDEO_SB_ENABLE_ROTATE                 
#    # set VIDEO_SB_ROTATE_ANGLE  ${inst_name}_VIDEO_SB_ROTATE_ANGLE                  
#    # set VIDEO_SB_MEM_ADDR8     ${inst_name}_VIDEO_SB_MEM_ADDR8                    
#    # set VIDEO_SB_MEM_SIZE8     ${inst_name}_VIDEO_SB_MEM_SIZE8   
#    # set VIDEO_SB_MEM_STRIDE8   ${inst_name}_VIDEO_SB_MEM_STRIDE8  
#    # set VIDEO_SB_MEM_ALIGNED   ${inst_name}_VIDEO_SB_MEM_ALIGNED  
#   
#   
#  #   add_parameter          $VIDEO_SB_ENABLE_ROTATE INTEGER 0
#  #   set_parameter_property $VIDEO_SB_ENABLE_ROTATE DISPLAY_NAME "90� Rotation (requires Screen-Buffer) ";
#  #   set_parameter_property $VIDEO_SB_ENABLE_ROTATE DISPLAY_HINT boolean
#  #   set_parameter_property $VIDEO_SB_ENABLE_ROTATE DESCRIPTION "Turn on to support 90� screen rotation. This feature requires the screen-buffer mode";
#  #   set_parameter_property $VIDEO_SB_ENABLE_ROTATE AFFECTS_ELABORATION true        
#  #   set_parameter_property $VIDEO_SB_ENABLE_ROTATE HDL_PARAMETER true
#  
#  #   add_parameter          $SB_FRAME_REPEAT INTEGER 0
#  #   set_parameter_property $SB_FRAME_REPEAT DISPLAY_NAME "Frame repeating";
#  #   set_parameter_property $SB_FRAME_REPEAT DISPLAY_HINT INTEGER
#  #   set_parameter_property $SB_FRAME_REPEAT ALLOWED_RANGES {0:255}
#  #   set_parameter_property $SB_FRAME_REPEAT DESCRIPTION "Specify the number of video frames to repeat for each frame composition. Choose 0 to disable frame repeating";
#  #   set_parameter_property $SB_FRAME_REPEAT AFFECTS_ELABORATION true        
#  #   set_parameter_property $SB_FRAME_REPEAT HDL_PARAMETER true
#  
#  
#  
#  
#  #    add_parameter          $VIDEO_SB_MEM_ADDR8 INTEGER 0x0
#  #    set_parameter_property $VIDEO_SB_MEM_ADDR8 DISPLAY_NAME "Memory base address";
#  #    set_parameter_property $VIDEO_SB_MEM_ADDR8 DISPLAY_HINT hexadecimal 
#  #    set_parameter_property $VIDEO_SB_MEM_ADDR8 DISPLAY_UNITS "Bytes"
#  #   #set_parameter_property $VIDEO_SB_MEM_ADDR8 ALLOWED_RANGES {0x0:0xFFFFFFFF}
#  #    set_parameter_property $VIDEO_SB_MEM_ADDR8 DESCRIPTION "Specify the memory base address in Bytes for the screen buffer";
#  #    set_parameter_property $VIDEO_SB_MEM_ADDR8 AFFECTS_ELABORATION true        
#  #    set_parameter_property $VIDEO_SB_MEM_ADDR8 HDL_PARAMETER true
#  #
#  #    add_parameter          $VIDEO_SB_MEM_STRIDE8 INTEGER 0x0
#  #    set_parameter_property $VIDEO_SB_MEM_STRIDE8 DISPLAY_NAME "Memory stride";
#  #    set_parameter_property $VIDEO_SB_MEM_STRIDE8 DISPLAY_HINT hexadecimal 
#  #    set_parameter_property $VIDEO_SB_MEM_STRIDE8 DISPLAY_UNITS "Bytes"
#  #   #set_parameter_property $VIDEO_SB_MEM_STRIDE8 ALLOWED_RANGES {0x0:0xFFFFFFFF}
#  #    set_parameter_property $VIDEO_SB_MEM_STRIDE8 DESCRIPTION "Return the screen buffer stride";
#  #   #set_parameter_property $VIDEO_SB_MEM_STRIDE8 AFFECTS_ELABORATION true
#  #    set_parameter_property $VIDEO_SB_MEM_STRIDE8 VISIBLE false  
#  #  # if {$is_core == 0} { 
#  #    set_parameter_property $VIDEO_SB_MEM_STRIDE8 DERIVED true  
#  #  # }
#  #  # set_parameter_property $VIDEO_SB_MEM_STRIDE8 HDL_PARAMETER true
#  #
#  #  # if {$is_core == 0} { 
#  #      add_parameter          $VIDEO_SB_MEM_ALIGNED INTEGER 0
#  #      set_parameter_property $VIDEO_SB_MEM_ALIGNED DISPLAY_NAME "Memory aligned ?";
#  #      set_parameter_property $VIDEO_SB_MEM_ALIGNED DISPLAY_HINT boolean
#  #      set_parameter_property $VIDEO_SB_MEM_ALIGNED DESCRIPTION "Turned on if memory transfers always aligned (with memory words), implying reduced resources";
#  #      set_parameter_property $VIDEO_SB_MEM_ALIGNED AFFECTS_ELABORATION true 
#  #      set_parameter_property $VIDEO_SB_MEM_ALIGNED VISIBLE false  
#  #      set_parameter_property $VIDEO_SB_MEM_ALIGNED DERIVED true         
#  #  # }
#  #        
#  #    add_parameter          $VIDEO_SB_MEM_SIZE8 INTEGER 0x0
#  #    set_parameter_property $VIDEO_SB_MEM_SIZE8 DISPLAY_NAME "Memory required size";
#  #    set_parameter_property $VIDEO_SB_MEM_SIZE8 DISPLAY_HINT hexadecimal 
#  #    set_parameter_property $VIDEO_SB_MEM_SIZE8 DISPLAY_UNITS "Bytes"
#  #   #set_parameter_property $VIDEO_SB_MEM_SIZE8 ALLOWED_RANGES {0x0:0xFFFFFFFF}
#  #    set_parameter_property $VIDEO_SB_MEM_SIZE8 DESCRIPTION "Return the memory size used by the screen buffer";
#  #   #set_parameter_property $VIDEO_SB_MEM_SIZE8 AFFECTS_ELABORATION true
#  #  # if {$is_core == 0} { 
#  #    set_parameter_property $VIDEO_SB_MEM_SIZE8 DERIVED true  
#  #  # }
#  #  # set_parameter_property $VIDEO_SB_MEM_SIZE8 HDL_PARAMETER true
#  #
#  
#  #   add_display_item "Screen-Buffer${inst_id}" $VIDEO_SB_ENABLE_ROTATE PARAMETER
#  #   add_display_item "Screen-Buffer${inst_id}" $VIDEO_SB_ROTATE_ANGLE  PARAMETER
#  #   add_display_item "Screen-Buffer${inst_id}" $SB_FRAME_REPEAT  PARAMETER
#  #   add_display_item "Screen-Buffer${inst_id}" $VIDEO_SB_MEM_ADDR8     PARAMETER
#  #   add_display_item "Screen-Buffer${inst_id}" $VIDEO_SB_MEM_SIZE8     PARAMETER
#  #   add_display_item "Screen-Buffer${inst_id}" $VIDEO_SB_MEM_STRIDE8   PARAMETER
#  #   add_display_item "Screen-Buffer${inst_id}" $VIDEO_SB_MEM_ALIGNED   PARAMETER
#  
#   
#                                                                  
#    }                                  




# # compute stride/size in order to handle aligned memory transfer
# # todo
# proc display_elaborate_sb { inst_name screen_dma_rd_data_size screen_dma_wr_data_size } {
#
#   set VIDEO_ENABLE_CSR               ${inst_name}_VIDEO_ENABLE_CSR      
#   set VIDEO_SCREEN_NUM        ${inst_name}_VIDEO_SCREEN_NUM            
#   set video_frame_color_size               ${inst_name}_video_frame_color_size                    
#   set video_frame_color_num                ${inst_name}_video_frame_color_num                    
#   set VIDEO_FRAME_WIDTH                ${inst_name}_VIDEO_FRAME_WIDTH                    
#   set VIDEO_FRAME_HEIGHT               ${inst_name}_VIDEO_FRAME_HEIGHT                     
#   set VIDEO_SB_MEM_SIZE8   ${inst_name}_VIDEO_SB_MEM_SIZE8  
#   set VIDEO_SB_MEM_ADDR8   ${inst_name}_VIDEO_SB_MEM_ADDR8 
#   set VIDEO_SB_MEM_STRIDE8 ${inst_name}_VIDEO_SB_MEM_STRIDE8               
#   set VIDEO_SB_MEM_ALIGNED ${inst_name}_VIDEO_SB_MEM_ALIGNED              
#                           
#   # the wider screen dma data width  
#   if {$screen_dma_rd_data_size > $screen_dma_wr_data_size} {
#     set screen_dma_max_data_size8 [ expr $screen_dma_rd_data_size / 8]
#   } else {
#     set screen_dma_max_data_size8 [ expr $screen_dma_wr_data_size / 8]
#  	}
#
#   # compute the sceenbuffer memory stride/size 
#   # the pixel size in bits
#   set the_pixel_size [ expr [ get_parameter_value $VIDEO_SCREEN_NUM ] * [ get_parameter_value $video_frame_color_size ] * [ get_parameter_value $video_frame_color_num ] ]
#   # the line stride in bytes 
#   set the_mem_stride8 [ expr (($the_pixel_size * [ get_parameter_value $VIDEO_FRAME_WIDTH ] + 7) / 8) ]
#
#   # the line stride modulo the "screen_dma_max_data_size8"
#   set the_mem_stride8_aligned_dma [ expr ((($the_mem_stride8 + $screen_dma_max_data_size8 - 1) / $screen_dma_max_data_size8) * $screen_dma_max_data_size8) ]
#  
#   # the total size (including 2 frame buffers)
#   set the_mem_size8 [ expr ($the_mem_stride8_aligned_dma * [ get_parameter_value $VIDEO_FRAME_HEIGHT ] * 2) ]
#  
#   # default is non-aligned
#   set is_aligned 0
#
#   if {[get_parameter_value $VIDEO_ENABLE_CSR] == 0} {
#
#     # the base address 
#     set the_mem_addr8 [get_parameter_value $VIDEO_SB_MEM_ADDR8]
#
#     # the base address modulo the "screen_dma_max_data_size8"
#     set the_mem_addr8_aligned [ expr ((($the_mem_addr8 + $screen_dma_max_data_size8-1) / $screen_dma_max_data_size8) * $screen_dma_max_data_size8) ]
#     
#     if {$the_mem_addr8 == $the_mem_addr8_aligned} {
#       # assert if memory base is aligned
#       set is_aligned 1
#  	  }
#     	    
#  	}
#   	
#   set_parameter_value $VIDEO_SB_MEM_STRIDE8 $the_mem_stride8_aligned_dma  
#   set_parameter_value $VIDEO_SB_MEM_SIZE8   $the_mem_size8  
#   set_parameter_value $VIDEO_SB_MEM_ALIGNED $is_aligned  
#
#
# }                                  

                                   
  proc display_valid_sb { inst_id inst_name } {
  
    set ENABLE_LAYER              ${inst_name}_ENABLE_LAYER
    set ENABLE_SB                 ${inst_name}_ENABLE_SB

    set VIDEO_SCREEN_NUM          ${inst_name}_VIDEO_SCREEN_NUM            
    set video_frame_color_format  ${inst_name}_video_frame_color_format                   
    set VIDEO_FRAME_WIDTH         ${inst_name}_VIDEO_FRAME_WIDTH                    
    set VIDEO_FRAME_HEIGHT        ${inst_name}_VIDEO_FRAME_HEIGHT                     

    set param_name ${inst_name}_SB

    set buffer_num 2  

    # get the pixel_depth from the video_frame_color_format 
    colorformat_get_info [get_parameter_value $video_frame_color_format] color_hw pixel_depth color_num color_size

    # raw data because the custom pixel is the concatenation of screens pixels  
    set sb_pixel_size [ expr [get_parameter_value $VIDEO_SCREEN_NUM] * $pixel_depth ]
 
#   set sfc_alloc_size8 [ surface_data_validation $param_name $inst_id [get_parameter_value $VIDEO_FRAME_WIDTH]        \
#                                                                      [get_parameter_value $VIDEO_FRAME_HEIGHT]       \
#                                                                      $buffer_num                                     \
#                                                                      [get_parameter_value $video_frame_color_format] \
#                                                                      0 ]

    set sfc_alloc_size8 [ surface_data_validation $param_name $inst_id [get_parameter_value $VIDEO_FRAME_WIDTH]        \
                                                                       [get_parameter_value $VIDEO_FRAME_HEIGHT]       \
                                                                       $buffer_num                                     \
                                                                       "RAW"                                           \
                                                                       $sb_pixel_size ]


    surface_pool_add "screen" $inst_id $param_name $sfc_alloc_size8 

    if {[ get_parameter_value $ENABLE_LAYER] == 1} {
      set ena_lock    1
    } else {
      set ena_lock    0
    }
    
    set ena_rate    0; # tmp   
    set rate_repeat 0; # tmp
    set rate_total  1; # tmp
    
    surface_sync_validation $param_name $inst_id $ena_lock $ena_rate $rate_repeat $rate_total                                 

  }


    
#    set VIDEO_FRAME_WIDTH                  ${inst_name}_VIDEO_FRAME_WIDTH                    
#    set VIDEO_FRAME_HEIGHT                 ${inst_name}_VIDEO_FRAME_HEIGHT                     
#    set SB_FRAME_REPEAT  ${inst_name}_SB_FRAME_REPEAT                    
#    set VIDEO_SB_MEM_ADDR8     ${inst_name}_VIDEO_SB_MEM_ADDR8                    
#    set VIDEO_SB_MEM_STRIDE8   ${inst_name}_VIDEO_SB_MEM_STRIDE8  
#    set VIDEO_SB_MEM_ALIGNED   ${inst_name}_VIDEO_SB_MEM_ALIGNED 
#    set VIDEO_SB_MEM_SIZE8     ${inst_name}_VIDEO_SB_MEM_SIZE8  
#    set VIDEO_SB_ENABLE_ROTATE ${inst_name}_VIDEO_SB_ENABLE_ROTATE                 
#
#
#    if {[get_parameter_value $VIDEO_ENABLE_CSR] == 1} {
#      set_parameter_property $SB_FRAME_REPEAT  ENABLED false
#      set_parameter_property $VIDEO_SB_MEM_ADDR8     ENABLED false    
#    # set_parameter_property $VIDEO_SB_MEM_SIZE8     ENABLED false
#    } else {
#      set_parameter_property $SB_FRAME_REPEAT  ENABLED true
#      set_parameter_property $VIDEO_SB_MEM_ADDR8     ENABLED true
#    # set_parameter_property $VIDEO_SB_MEM_SIZE8     ENABLED true
#    }
#
#    if {[ get_parameter_value $VIDEO_ENABLE_SCREENBUFFER] == 1} {
#      set_parameter_property $SB_FRAME_REPEAT   VISIBLE true
#      set_parameter_property $VIDEO_SB_MEM_ADDR8      VISIBLE true    
#      set_parameter_property $VIDEO_SB_MEM_SIZE8      VISIBLE true    
#      set_parameter_property $VIDEO_SB_ENABLE_ROTATE  ENABLED true
#    # set_parameter_property $VIDEO_SB_MEM_STRIDE8    VISIBLE true
#    # set_parameter_property $VIDEO_SB_MEM_ALIGNED    VISIBLE true   
#    # set_display_item_property "Screen Buffer${inst_id}" VISIBLE true
#    } else {
#      set_parameter_property $SB_FRAME_REPEAT   VISIBLE false
#      set_parameter_property $VIDEO_SB_MEM_ADDR8      VISIBLE false    
#      set_parameter_property $VIDEO_SB_MEM_SIZE8      VISIBLE false    
#      set_parameter_property $VIDEO_SB_ENABLE_ROTATE  ENABLED false
#    # set_parameter_property $VIDEO_SB_MEM_STRIDE8    VISIBLE false
#    # set_parameter_property $VIDEO_SB_MEM_ALIGNED    VISIBLE false  
#    # set_display_item_property "Screen Buffer${inst_id}" VISIBLE false
#    }
#
# 
#  # # compute the sceenbuffer memory stride/size 
#  # # the pixel size in bits
#  # set the_pixel_size [ expr [ get_parameter_value $VIDEO_SCREEN_NUM ] * [ get_parameter_value $video_frame_color_size ] * [ get_parameter_value $video_frame_color_num ] ]
#  # # the line stride in bytes (modulo "pixel size")
#  # set the_mem_stride8 [ expr ( ($the_pixel_size * [ get_parameter_value $VIDEO_FRAME_WIDTH ] + 7) / 8) ]
#  # # the total size
#  # set the_mem_size8 [ expr ($the_mem_stride8 * [ get_parameter_value $VIDEO_FRAME_HEIGHT ] * 2) ]
#  #
#  # set_parameter_value $VIDEO_SB_MEM_STRIDE8 $the_mem_stride8  
#  # set_parameter_value $VIDEO_SB_MEM_SIZE8   $the_mem_size8  




# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Video-out                                                                                  --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------
 
     
  proc display_add_parameters_video_out { inst_id inst_name parent_gui_name } {

    set VIDEO_ENABLE_CSR                 ${inst_name}_VIDEO_ENABLE_CSR               
    set VIDEO_ENABLE_TPG                 ${inst_name}_VIDEO_ENABLE_TPG              
    set VIDEO_TPG_PATTERN_BACK           ${inst_name}_VIDEO_TPG_PATTERN_BACK   
    set VIDEO_TPG_PATTERN_FORE           ${inst_name}_VIDEO_TPG_PATTERN_FORE			        

    set VIDEO_CLOCKED                    ${inst_name}_VIDEO_CLOCKED 
    set VIDEO_SCREEN_NUM                 ${inst_name}_VIDEO_SCREEN_NUM            
    set VIDEO_PIXEL_NUM                  ${inst_name}_VIDEO_PIXEL_NUM                      

    set VIDEO_FRAME_PIXEL_FORMAT         ${inst_name}_VIDEO_FRAME_PIXEL_FORMAT                   
    set VIDEO_FRAME_WIDTH                ${inst_name}_VIDEO_FRAME_WIDTH                    
    set VIDEO_FRAME_HEIGHT               ${inst_name}_VIDEO_FRAME_HEIGHT                     
    set video_frame_color_format         ${inst_name}_video_frame_color_format                  
    set video_frame_color_size           ${inst_name}_video_frame_color_size                    
    set video_frame_color_num            ${inst_name}_video_frame_color_num                    
                                         
    set VIDEO_TIMINGS_HRES               ${inst_name}_VIDEO_TIMINGS_HRES                            
    set VIDEO_TIMINGS_HFPW               ${inst_name}_VIDEO_TIMINGS_HFPW                            
    set VIDEO_TIMINGS_HSW                ${inst_name}_VIDEO_TIMINGS_HSW                             
    set VIDEO_TIMINGS_HBPW               ${inst_name}_VIDEO_TIMINGS_HBPW                            
    set VIDEO_TIMINGS_VRES               ${inst_name}_VIDEO_TIMINGS_VRES                            
    set VIDEO_TIMINGS_VFPW               ${inst_name}_VIDEO_TIMINGS_VFPW                            
    set VIDEO_TIMINGS_VSW                ${inst_name}_VIDEO_TIMINGS_VSW                             
    set VIDEO_TIMINGS_VBPW               ${inst_name}_VIDEO_TIMINGS_VBPW                            
    set timings_info_freq_pixel          ${inst_name}_timings_info_freq_pixel                 
    set timings_info_freq_horizontal     ${inst_name}_timings_info_freq_horizontal            
    set timings_info_freq_vertical       ${inst_name}_timings_info_freq_vertical              

 
#   set VIDEO_ENABLE_SCREENBUFFER        ${inst_name}_VIDEO_ENABLE_SCREENBUFFER
#   set VIDEO_SB_ENABLE_ROTATE ${inst_name}_VIDEO_SB_ENABLE_ROTATE                 
# # set VIDEO_SB_ROTATE_ANGLE  ${inst_name}_VIDEO_SB_ROTATE_ANGLE                  
#   set SB_FRAME_REPEAT  ${inst_name}_SB_FRAME_REPEAT                    
#   set VIDEO_SB_MEM_ADDR8     ${inst_name}_VIDEO_SB_MEM_ADDR8                    
#   set VIDEO_SB_MEM_SIZE8     ${inst_name}_VIDEO_SB_MEM_SIZE8   
#   set VIDEO_SB_MEM_STRIDE8   ${inst_name}_VIDEO_SB_MEM_STRIDE8  
#   set VIDEO_SB_MEM_ALIGNED   ${inst_name}_VIDEO_SB_MEM_ALIGNED  
#   set VIDEO_ENABLE_FLIP_H              ${inst_name}_VIDEO_ENABLE_FLIP_H    
#   set VIDEO_ENABLE_FLIP_V              ${inst_name}_VIDEO_ENABLE_FLIP_V   
                                                                                                       

    ####################
    # Video-out
    #
 
    add_parameter          $VIDEO_ENABLE_CSR INTEGER 1
    set_parameter_property $VIDEO_ENABLE_CSR DISPLAY_NAME "Run-time control"
    set_parameter_property $VIDEO_ENABLE_CSR DISPLAY_HINT boolean
    set_parameter_property $VIDEO_ENABLE_CSR DESCRIPTION "Turn on to enable run-time csr over video parameters";
    set_parameter_property $VIDEO_ENABLE_CSR AFFECTS_ELABORATION true        
    set_parameter_property $VIDEO_ENABLE_CSR HDL_PARAMETER true

    add_parameter          $VIDEO_ENABLE_TPG INTEGER 1
    set_parameter_property $VIDEO_ENABLE_TPG DISPLAY_NAME "use Test Pattern Generator"
    set_parameter_property $VIDEO_ENABLE_TPG DISPLAY_HINT boolean
    set_parameter_property $VIDEO_ENABLE_TPG DESCRIPTION "Turn on to support Test Pattern Generator";
    set_parameter_property $VIDEO_ENABLE_TPG AFFECTS_ELABORATION true        
    set_parameter_property $VIDEO_ENABLE_TPG HDL_PARAMETER true

    add_parameter          $VIDEO_TPG_PATTERN_BACK INTEGER 2
    set_parameter_property $VIDEO_TPG_PATTERN_BACK DISPLAY_NAME "background test pattern"
    set_parameter_property $VIDEO_TPG_PATTERN_BACK ALLOWED_RANGES ${::cgx_tpg::tpg_pattern_back_range} 
    set_parameter_property $VIDEO_TPG_PATTERN_BACK HDL_PARAMETER true      
                           
    add_parameter          $VIDEO_TPG_PATTERN_FORE INTEGER 3
    set_parameter_property $VIDEO_TPG_PATTERN_FORE DISPLAY_NAME "foreground test pattern"
    set_parameter_property $VIDEO_TPG_PATTERN_FORE ALLOWED_RANGES ${::cgx_tpg::tpg_pattern_fore_range}
    set_parameter_property $VIDEO_TPG_PATTERN_FORE HDL_PARAMETER true      
       
    add_parameter          $VIDEO_CLOCKED INTEGER 1
    set_parameter_property $VIDEO_CLOCKED DISPLAY_NAME "interface";
    set_parameter_property $VIDEO_CLOCKED ALLOWED_RANGES {"1:clocked" "0:streamed (AXIS video)"}
    set_parameter_property $VIDEO_CLOCKED DISPLAY_HINT radio
    set_parameter_property $VIDEO_CLOCKED AFFECTS_ELABORATION true        
    set_parameter_property $VIDEO_CLOCKED HDL_PARAMETER true
        
    add_parameter          $VIDEO_SCREEN_NUM INTEGER 1
    set_parameter_property $VIDEO_SCREEN_NUM DISPLAY_NAME "Number of screens";
    set_parameter_property $VIDEO_SCREEN_NUM ALLOWED_RANGES {1:8}
    set_parameter_property $VIDEO_SCREEN_NUM DESCRIPTION "Choose the number of screens";
    set_parameter_property $VIDEO_SCREEN_NUM DISPLAY_UNITS "Screens"
    set_parameter_property $VIDEO_SCREEN_NUM AFFECTS_ELABORATION true 
    set_parameter_property $VIDEO_SCREEN_NUM HDL_PARAMETER true
    
    add_parameter          $VIDEO_PIXEL_NUM INTEGER 1
    set_parameter_property $VIDEO_PIXEL_NUM DISPLAY_NAME "Number of pixels in parallel";
    set_parameter_property $VIDEO_PIXEL_NUM ALLOWED_RANGES {1,2,4,8}
    set_parameter_property $VIDEO_PIXEL_NUM DISPLAY_UNITS "Pixels"
    set_parameter_property $VIDEO_PIXEL_NUM AFFECTS_ELABORATION true
    set_parameter_property $VIDEO_PIXEL_NUM ENABLED true
    set_parameter_property $VIDEO_PIXEL_NUM HDL_PARAMETER true
    
    add_parameter          $video_frame_color_format string "RGB_888"
    set_parameter_property $video_frame_color_format DISPLAY_NAME "Pixel Format"
    set_parameter_property $video_frame_color_format ALLOWED_RANGES ${::imt_surface::video_colorformat_range} ; # {"RGB_666" "RGB_888" "ARGB_8888_PRE"}
    set_parameter_property $video_frame_color_format DESCRIPTION "Choose the output pixel format. Premultiplied format automatically set transparent background"
    set_parameter_property $video_frame_color_format AFFECTS_ELABORATION true        

    add_parameter          $VIDEO_FRAME_PIXEL_FORMAT integer 0
    set_parameter_property $VIDEO_FRAME_PIXEL_FORMAT DISPLAY_NAME "Private Pixel Format"
    set_parameter_property $VIDEO_FRAME_PIXEL_FORMAT DERIVED true 
    set_parameter_property $VIDEO_FRAME_PIXEL_FORMAT HDL_PARAMETER true
    set_parameter_property $VIDEO_FRAME_PIXEL_FORMAT VISIBLE false 
    
    # derived
    add_parameter          $video_frame_color_size INTEGER 8
    set_parameter_property $video_frame_color_size DISPLAY_NAME "Bits per pixel per color plane";
    set_parameter_property $video_frame_color_size DISPLAY_UNITS "Bits"
    set_parameter_property $video_frame_color_size DERIVED true 
        
    # derived
    add_parameter          $video_frame_color_num INTEGER 3
    set_parameter_property $video_frame_color_num DISPLAY_NAME "Number of color planes in parallel";
    set_parameter_property $video_frame_color_num DISPLAY_UNITS "Planes"
    set_parameter_property $video_frame_color_num DERIVED true 
        
    add_parameter          $VIDEO_FRAME_WIDTH INTEGER 800
    set_parameter_property $VIDEO_FRAME_WIDTH DISPLAY_NAME "maximum frame width" 
    set_parameter_property $VIDEO_FRAME_WIDTH ALLOWED_RANGES {0:16384}
    set_parameter_property $VIDEO_FRAME_WIDTH DESCRIPTION "  ";
    set_parameter_property $VIDEO_FRAME_WIDTH AFFECTS_ELABORATION true        
    set_parameter_property $VIDEO_FRAME_WIDTH VISIBLE true      
    set_parameter_property $VIDEO_FRAME_WIDTH HDL_PARAMETER true
    
    add_parameter          $VIDEO_FRAME_HEIGHT INTEGER 600
    set_parameter_property $VIDEO_FRAME_HEIGHT DISPLAY_NAME "maximum frame height" 
    set_parameter_property $VIDEO_FRAME_HEIGHT ALLOWED_RANGES {0:16384}
    set_parameter_property $VIDEO_FRAME_HEIGHT DESCRIPTION "  ";
    set_parameter_property $VIDEO_FRAME_HEIGHT AFFECTS_ELABORATION true        
    set_parameter_property $VIDEO_FRAME_HEIGHT VISIBLE true      
    set_parameter_property $VIDEO_FRAME_HEIGHT HDL_PARAMETER true
    
        
 #  add_parameter $timings_preset   string "Custom"
 #  add_parameter $timings_external INTEGER 0
 #  add_parameter $timings_max_hres INTEGER 1024
 #  add_parameter $timings_max_vres INTEGER 1024
 #  set_parameter_property $timings_preset DISPLAY_NAME "Timings Preset"
 #  set_parameter_property $timings_preset ALLOWED_RANGES $ListOfPreset
                                   
    add_parameter          $VIDEO_TIMINGS_HRES INTEGER 800
    set_parameter_property $VIDEO_TIMINGS_HRES DISPLAY_NAME "Horizontal active resolution"
    set_parameter_property $VIDEO_TIMINGS_HRES DISPLAY_HINT INTEGER
    set_parameter_property $VIDEO_TIMINGS_HRES ALLOWED_RANGES {1:16384}
  # if {$is_core == 0} { 
    set_parameter_property $VIDEO_TIMINGS_HRES DERIVED true 
  # }
  # set_parameter_property $VIDEO_TIMINGS_HRES VISIBLE false 
    
    add_parameter          $VIDEO_TIMINGS_HFPW INTEGER 40
    set_parameter_property $VIDEO_TIMINGS_HFPW DISPLAY_NAME "Horizontal frontporch width"
    set_parameter_property $VIDEO_TIMINGS_HFPW DISPLAY_HINT INTEGER
    set_parameter_property $VIDEO_TIMINGS_HFPW ALLOWED_RANGES {1:16384}
    set_parameter_property $VIDEO_TIMINGS_HFPW HDL_PARAMETER true
                                   
    add_parameter          $VIDEO_TIMINGS_HSW INTEGER 128
    set_parameter_property $VIDEO_TIMINGS_HSW DISPLAY_NAME "Horizontal synchro width"
    set_parameter_property $VIDEO_TIMINGS_HSW DISPLAY_HINT INTEGER
    set_parameter_property $VIDEO_TIMINGS_HSW ALLOWED_RANGES {1:16384}
    set_parameter_property $VIDEO_TIMINGS_HSW HDL_PARAMETER true
    
    add_parameter          $VIDEO_TIMINGS_HBPW INTEGER 88
    set_parameter_property $VIDEO_TIMINGS_HBPW DISPLAY_NAME "Horizontal backporch width"
    set_parameter_property $VIDEO_TIMINGS_HBPW DISPLAY_HINT INTEGER
    set_parameter_property $VIDEO_TIMINGS_HBPW ALLOWED_RANGES {1:16384}
    set_parameter_property $VIDEO_TIMINGS_HBPW HDL_PARAMETER true
    
    add_parameter          $VIDEO_TIMINGS_VRES INTEGER 600
    set_parameter_property $VIDEO_TIMINGS_VRES DISPLAY_NAME "Vertical active resolution"
    set_parameter_property $VIDEO_TIMINGS_VRES DISPLAY_HINT INTEGER
    set_parameter_property $VIDEO_TIMINGS_VRES ALLOWED_RANGES {1:16384}
  # if {$is_core == 0} { 
    set_parameter_property $VIDEO_TIMINGS_VRES DERIVED true 
  # }
  # set_parameter_property $VIDEO_TIMINGS_VRES VISIBLE false 
    
    add_parameter          $VIDEO_TIMINGS_VFPW INTEGER 1
    set_parameter_property $VIDEO_TIMINGS_VFPW DISPLAY_NAME "Vertical frontporch width"
    set_parameter_property $VIDEO_TIMINGS_VFPW DISPLAY_HINT INTEGER
    set_parameter_property $VIDEO_TIMINGS_VFPW ALLOWED_RANGES {1:16384}
    set_parameter_property $VIDEO_TIMINGS_VFPW HDL_PARAMETER true
                                    
    add_parameter          $VIDEO_TIMINGS_VSW INTEGER 4
    set_parameter_property $VIDEO_TIMINGS_VSW DISPLAY_NAME "Vertical synchro width"
    set_parameter_property $VIDEO_TIMINGS_VSW DISPLAY_HINT INTEGER
    set_parameter_property $VIDEO_TIMINGS_VSW ALLOWED_RANGES {1:16384}
    set_parameter_property $VIDEO_TIMINGS_VSW HDL_PARAMETER true
                                    
    add_parameter          $VIDEO_TIMINGS_VBPW INTEGER 23
    set_parameter_property $VIDEO_TIMINGS_VBPW DISPLAY_NAME "Vertical backporch width"
    set_parameter_property $VIDEO_TIMINGS_VBPW DISPLAY_HINT INTEGER
    set_parameter_property $VIDEO_TIMINGS_VBPW ALLOWED_RANGES {1:16384}
    set_parameter_property $VIDEO_TIMINGS_VBPW HDL_PARAMETER true
    
    add_parameter          $timings_info_freq_pixel INTEGER 40
    set_parameter_property $timings_info_freq_pixel DISPLAY_NAME "info - pixel clock frequency"
    set_parameter_property $timings_info_freq_pixel DISPLAY_HINT INTEGER
 #  set_parameter_property $timings_info_freq_pixel ALLOWED_RANGES {1:1024}
    set_parameter_property $timings_info_freq_pixel UNITS Megahertz
    set_parameter_property $timings_info_freq_pixel DESCRIPTION "Enter the pixel clock frequency value applied on video-out port / clock signal to learn about line/frame frequencies generated by default timings parameters"
    
    add_parameter          $timings_info_freq_horizontal INTEGER 0
    set_parameter_property $timings_info_freq_horizontal DISPLAY_NAME "info - line frequency"
    set_parameter_property $timings_info_freq_horizontal DISPLAY_UNITS "kHz"
    set_parameter_property $timings_info_freq_horizontal DISPLAY_HINT INTEGER
    set_parameter_property $timings_info_freq_horizontal AFFECTS_ELABORATION false        
  # if {$is_core == 0} { 
    set_parameter_property $timings_info_freq_horizontal DERIVED true 
  # }
  # set_parameter_property $timings_info_freq_horizontal ENABLED true
    
    add_parameter          $timings_info_freq_vertical INTEGER 0
    set_parameter_property $timings_info_freq_vertical DISPLAY_NAME "info - frame frequency"
    set_parameter_property $timings_info_freq_vertical DISPLAY_UNITS "Hz"
    set_parameter_property $timings_info_freq_vertical DISPLAY_HINT INTEGER
    set_parameter_property $timings_info_freq_vertical AFFECTS_ELABORATION false        
  # if {$is_core == 0} { 
    set_parameter_property $timings_info_freq_vertical DERIVED true  
  # }
  # set_parameter_property $timings_info_freq_vertical ENABLED true

    
#   set_parameter_property $timings_external DISPLAY_NAME "Support for external csr"
#   set_parameter_property $timings_external DISPLAY_HINT boolean
#   set_parameter_property $timings_external DESCRIPTION "Turn on to enable support for synchronisation from external video signals";
#   set_parameter_property $timings_external AFFECTS_ELABORATION true        
#   
#   set_parameter_property $timings_max_hres DISPLAY_NAME "Maximum active width"
#   set_parameter_property $timings_max_hres DISPLAY_HINT INTEGER
#   set_parameter_property $timings_max_hres ALLOWED_RANGES {1:16384}
#   set_parameter_property $timings_max_hres DESCRIPTION "Specify the maximum active width of the video stream";
#   
#   set_parameter_property $timings_max_vres DISPLAY_NAME "Maximum active height"
#   set_parameter_property $timings_max_vres DISPLAY_HINT INTEGER
#   set_parameter_property $timings_max_vres ALLOWED_RANGES {1:16384}
#   set_parameter_property $timings_max_vres DESCRIPTION "Specify the maximum active height of the video stream";


#        add_parameter          $VIDEO_ENABLE_SCREENBUFFER INTEGER 0
#        set_parameter_property $VIDEO_ENABLE_SCREENBUFFER DISPLAY_NAME "Support for Screen buffer";
#        set_parameter_property $VIDEO_ENABLE_SCREENBUFFER DISPLAY_HINT boolean
#        set_parameter_property $VIDEO_ENABLE_SCREENBUFFER DESCRIPTION "Turn on to support Screen buffer";
#        set_parameter_property $VIDEO_ENABLE_SCREENBUFFER AFFECTS_ELABORATION true        
#        set_parameter_property $VIDEO_ENABLE_SCREENBUFFER HDL_PARAMETER true
#    
#    #   add_parameter          $VIDEO_SB_ROTATE_ANGLE INTEGER 0
#    #   set_parameter_property $VIDEO_SB_ROTATE_ANGLE DISPLAY_NAME "Rotation angle";
#    #   set_parameter_property $VIDEO_SB_ROTATE_ANGLE ALLOWED_RANGES {"0:0�" "1:90�" "2:180�" "3:270�"}
#    #   set_parameter_property $VIDEO_SB_ROTATE_ANGLE DESCRIPTION "Rotation angle, clockwise";
#    #   set_parameter_property $VIDEO_SB_ROTATE_ANGLE AFFECTS_ELABORATION true        
#    #   set_parameter_property $VIDEO_SB_ROTATE_ANGLE HDL_PARAMETER true
#    
#        add_parameter          $SB_FRAME_REPEAT INTEGER 0
#        set_parameter_property $SB_FRAME_REPEAT DISPLAY_NAME "Frame repeating";
#        set_parameter_property $SB_FRAME_REPEAT DISPLAY_HINT INTEGER
#        set_parameter_property $SB_FRAME_REPEAT ALLOWED_RANGES {0:255}
#        set_parameter_property $SB_FRAME_REPEAT DESCRIPTION "Specify the number of video frames to repeat for each frame composition. Choose 0 to disable frame repeating";
#        set_parameter_property $SB_FRAME_REPEAT AFFECTS_ELABORATION true        
#        set_parameter_property $SB_FRAME_REPEAT HDL_PARAMETER true
#    
#        add_parameter          $VIDEO_SB_MEM_ADDR8 INTEGER 0x0
#        set_parameter_property $VIDEO_SB_MEM_ADDR8 DISPLAY_NAME "Memory base address";
#        set_parameter_property $VIDEO_SB_MEM_ADDR8 DISPLAY_HINT hexadecimal 
#        set_parameter_property $VIDEO_SB_MEM_ADDR8 DISPLAY_UNITS "Bytes"
#       #set_parameter_property $VIDEO_SB_MEM_ADDR8 ALLOWED_RANGES {0x0:0xFFFFFFFF}
#        set_parameter_property $VIDEO_SB_MEM_ADDR8 DESCRIPTION "Specify the memory base address in Bytes for the screen buffer";
#        set_parameter_property $VIDEO_SB_MEM_ADDR8 AFFECTS_ELABORATION true        
#        set_parameter_property $VIDEO_SB_MEM_ADDR8 HDL_PARAMETER true
#    
#        add_parameter          $VIDEO_SB_MEM_STRIDE8 INTEGER 0x0
#        set_parameter_property $VIDEO_SB_MEM_STRIDE8 DISPLAY_NAME "Memory stride";
#        set_parameter_property $VIDEO_SB_MEM_STRIDE8 DISPLAY_HINT hexadecimal 
#        set_parameter_property $VIDEO_SB_MEM_STRIDE8 DISPLAY_UNITS "Bytes"
#       #set_parameter_property $VIDEO_SB_MEM_STRIDE8 ALLOWED_RANGES {0x0:0xFFFFFFFF}
#        set_parameter_property $VIDEO_SB_MEM_STRIDE8 DESCRIPTION "Return the screen buffer stride";
#       #set_parameter_property $VIDEO_SB_MEM_STRIDE8 AFFECTS_ELABORATION true
#        set_parameter_property $VIDEO_SB_MEM_STRIDE8 VISIBLE false  
#      # if {$is_core == 0} { 
#        set_parameter_property $VIDEO_SB_MEM_STRIDE8 DERIVED true  
#      # }
#      # set_parameter_property $VIDEO_SB_MEM_STRIDE8 HDL_PARAMETER true
#    
#      # if {$is_core == 0} { 
#          add_parameter          $VIDEO_SB_MEM_ALIGNED INTEGER 0
#          set_parameter_property $VIDEO_SB_MEM_ALIGNED DISPLAY_NAME "Memory aligned ?";
#          set_parameter_property $VIDEO_SB_MEM_ALIGNED DISPLAY_HINT boolean
#          set_parameter_property $VIDEO_SB_MEM_ALIGNED DESCRIPTION "Turned on if memory transfers always aligned (with memory words), implying reduced resources";
#          set_parameter_property $VIDEO_SB_MEM_ALIGNED AFFECTS_ELABORATION true 
#          set_parameter_property $VIDEO_SB_MEM_ALIGNED VISIBLE false  
#          set_parameter_property $VIDEO_SB_MEM_ALIGNED DERIVED true         
#      # }
#            
#        add_parameter          $VIDEO_SB_MEM_SIZE8 INTEGER 0x0
#        set_parameter_property $VIDEO_SB_MEM_SIZE8 DISPLAY_NAME "Memory required size";
#        set_parameter_property $VIDEO_SB_MEM_SIZE8 DISPLAY_HINT hexadecimal 
#        set_parameter_property $VIDEO_SB_MEM_SIZE8 DISPLAY_UNITS "Bytes"
#       #set_parameter_property $VIDEO_SB_MEM_SIZE8 ALLOWED_RANGES {0x0:0xFFFFFFFF}
#        set_parameter_property $VIDEO_SB_MEM_SIZE8 DESCRIPTION "Return the memory size used by the screen buffer";
#       #set_parameter_property $VIDEO_SB_MEM_SIZE8 AFFECTS_ELABORATION true
#      # if {$is_core == 0} { 
#        set_parameter_property $VIDEO_SB_MEM_SIZE8 DERIVED true  
#      # }
#      # set_parameter_property $VIDEO_SB_MEM_SIZE8 HDL_PARAMETER true
#    
#        add_parameter          $VIDEO_ENABLE_FLIP_H INTEGER 0
#        set_parameter_property $VIDEO_ENABLE_FLIP_H DISPLAY_NAME "Horizontal flip";
#        set_parameter_property $VIDEO_ENABLE_FLIP_H DISPLAY_HINT boolean
#        set_parameter_property $VIDEO_ENABLE_FLIP_H DESCRIPTION "Turn on to support screen horizontal flip";
#        set_parameter_property $VIDEO_ENABLE_FLIP_H AFFECTS_ELABORATION true        
#        set_parameter_property $VIDEO_ENABLE_FLIP_H HDL_PARAMETER true
#    
#        add_parameter          $VIDEO_ENABLE_FLIP_V INTEGER 0
#        set_parameter_property $VIDEO_ENABLE_FLIP_V DISPLAY_NAME "Vertical flip";
#        set_parameter_property $VIDEO_ENABLE_FLIP_V DISPLAY_HINT boolean
#        set_parameter_property $VIDEO_ENABLE_FLIP_V DESCRIPTION "Turn on to support screen vertical flip";
#        set_parameter_property $VIDEO_ENABLE_FLIP_V AFFECTS_ELABORATION true        
#        set_parameter_property $VIDEO_ENABLE_FLIP_V HDL_PARAMETER true
#     
#        add_parameter          $VIDEO_SB_ENABLE_ROTATE INTEGER 0
#        set_parameter_property $VIDEO_SB_ENABLE_ROTATE DISPLAY_NAME "90� Rotation (requires Screen buffer) ";
#        set_parameter_property $VIDEO_SB_ENABLE_ROTATE DISPLAY_HINT boolean
#        set_parameter_property $VIDEO_SB_ENABLE_ROTATE DESCRIPTION "Turn on to support 90� screen rotation. This feature requires the screen-buffer mode";
#        set_parameter_property $VIDEO_SB_ENABLE_ROTATE AFFECTS_ELABORATION true        
#        set_parameter_property $VIDEO_SB_ENABLE_ROTATE HDL_PARAMETER true


    add_display_item $parent_gui_name "Video-out${inst_id}" GROUP tab

    add_display_item "Video-out${inst_id}" $VIDEO_ENABLE_CSR          PARAMETER
    add_display_item "Video-out${inst_id}" $VIDEO_ENABLE_TPG          PARAMETER
    add_display_item "Video-out${inst_id}" $VIDEO_TPG_PATTERN_BACK    PARAMETER
    add_display_item "Video-out${inst_id}" $VIDEO_TPG_PATTERN_FORE    PARAMETER    
    add_display_item "Video-out${inst_id}" $VIDEO_CLOCKED             PARAMETER
    add_display_item "Video-out${inst_id}" $VIDEO_SCREEN_NUM          PARAMETER
    add_display_item "Video-out${inst_id}" $VIDEO_PIXEL_NUM           PARAMETER    
    add_display_item "Video-out${inst_id}" $video_frame_color_format  PARAMETER    
    add_display_item "Video-out${inst_id}" $VIDEO_FRAME_PIXEL_FORMAT  PARAMETER    
    add_display_item "Video-out${inst_id}" $video_frame_color_size    PARAMETER   
    add_display_item "Video-out${inst_id}" $video_frame_color_num     PARAMETER
    add_display_item "Video-out${inst_id}" $VIDEO_FRAME_WIDTH         PARAMETER
    add_display_item "Video-out${inst_id}" $VIDEO_FRAME_HEIGHT        PARAMETER    
    
    add_display_item "Video-out${inst_id}" "Clocked Timings${inst_id}" GROUP  

#   add_display_item "Clocked Timings${inst_id}" "Internal" GROUP tab
#   add_display_item "Clocked Timings${inst_id}" "External" GROUP tab    
#   add_display_item "Clocked Timings${inst_id}" $timings_preset               PARAMETER
    add_display_item "Clocked Timings${inst_id}" $VIDEO_TIMINGS_HRES           PARAMETER
    add_display_item "Clocked Timings${inst_id}" $VIDEO_TIMINGS_HFPW           PARAMETER
    add_display_item "Clocked Timings${inst_id}" $VIDEO_TIMINGS_HSW            PARAMETER
    add_display_item "Clocked Timings${inst_id}" $VIDEO_TIMINGS_HBPW           PARAMETER
    add_display_item "Clocked Timings${inst_id}" $VIDEO_TIMINGS_VRES           PARAMETER
    add_display_item "Clocked Timings${inst_id}" $VIDEO_TIMINGS_VFPW           PARAMETER
    add_display_item "Clocked Timings${inst_id}" $VIDEO_TIMINGS_VSW            PARAMETER
    add_display_item "Clocked Timings${inst_id}" $VIDEO_TIMINGS_VBPW           PARAMETER
    add_display_item "Clocked Timings${inst_id}" $timings_info_freq_pixel      PARAMETER
    add_display_item "Clocked Timings${inst_id}" $timings_info_freq_horizontal PARAMETER
    add_display_item "Clocked Timings${inst_id}" $timings_info_freq_vertical   PARAMETER
#   add_display_item "Clocked Timings${inst_id}" $VIDEO_ENABLE_CSR             PARAMETER
#   add_display_item "Clocked Timings${inst_id}" $timings_external             PARAMETER
#   add_display_item "Clocked Timings${inst_id}" $timings_max_hres             PARAMETER
#   add_display_item "Clocked Timings${inst_id}" $timings_max_vres             PARAMETER


#   add_display_item "Video-out${inst_id}" "Testt Pattern Generator${inst_id}" GROUP  

#   tpg_add_pattern  "${inst_name}_VIDEO_TPG" "Testt Pattern Generator${inst_id}"  


#    add_display_item "Video-out${inst_id}" "Screen Buffer${inst_id}" GROUP  
#
#    add_display_item "Screen Buffer${inst_id}" $VIDEO_ENABLE_SCREENBUFFER        PARAMETER
##   add_display_item "Screen Buffer${inst_id}" $VIDEO_SB_ROTATE_ANGLE  PARAMETER
#    add_display_item "Screen Buffer${inst_id}" $SB_FRAME_REPEAT  PARAMETER
#    add_display_item "Screen Buffer${inst_id}" $VIDEO_SB_MEM_ADDR8     PARAMETER
#    add_display_item "Screen Buffer${inst_id}" $VIDEO_SB_MEM_SIZE8     PARAMETER
#    add_display_item "Screen Buffer${inst_id}" $VIDEO_SB_MEM_STRIDE8   PARAMETER
#    add_display_item "Screen Buffer${inst_id}" $VIDEO_SB_MEM_ALIGNED   PARAMETER
#
#
#    add_display_item "Video-out${inst_id}" "Screen Layout${inst_id}" GROUP  
#
#    add_display_item "Screen Layout${inst_id}" $VIDEO_ENABLE_FLIP_H              PARAMETER
#    add_display_item "Screen Layout${inst_id}" $VIDEO_ENABLE_FLIP_V              PARAMETER
#    add_display_item "Screen Layout${inst_id}" $VIDEO_SB_ENABLE_ROTATE PARAMETER
                                                                
  }                                  


  # compute stride/size in order to handle aligned memory transfer
  # todo
  proc display_elaborate_video_out { inst_name } {

#    set VIDEO_ENABLE_CSR               ${inst_name}_VIDEO_ENABLE_CSR      
#    set VIDEO_SCREEN_NUM        ${inst_name}_VIDEO_SCREEN_NUM            
#    set video_frame_color_size               ${inst_name}_video_frame_color_size                    
#    set video_frame_color_num                ${inst_name}_video_frame_color_num                    
#    set VIDEO_FRAME_WIDTH                ${inst_name}_VIDEO_FRAME_WIDTH                    
#    set VIDEO_FRAME_HEIGHT               ${inst_name}_VIDEO_FRAME_HEIGHT                     
#  # set VIDEO_SB_MEM_SIZE8   ${inst_name}_VIDEO_SB_MEM_SIZE8  
#  # set VIDEO_SB_MEM_ADDR8   ${inst_name}_VIDEO_SB_MEM_ADDR8 
#  # set VIDEO_SB_MEM_STRIDE8 ${inst_name}_VIDEO_SB_MEM_STRIDE8               
#  # set VIDEO_SB_MEM_ALIGNED ${inst_name}_VIDEO_SB_MEM_ALIGNED              
#                            
#    # the wider screen dma data width  
#    if {$screen_dma_rd_data_size > $screen_dma_wr_data_size} {
#      set screen_dma_max_data_size8 [ expr $screen_dma_rd_data_size / 8]
#    } else {
#      set screen_dma_max_data_size8 [ expr $screen_dma_wr_data_size / 8]
#   	}
# 
#    # compute the sceenbuffer memory stride/size 
#    # the pixel size in bits
#    set the_pixel_size [ expr [ get_parameter_value $VIDEO_SCREEN_NUM ] * [ get_parameter_value $video_frame_color_size ] * [ get_parameter_value $video_frame_color_num ] ]
#    # the line stride in bytes 
#    set the_mem_stride8 [ expr (($the_pixel_size * [ get_parameter_value $VIDEO_FRAME_WIDTH ] + 7) / 8) ]
#
#    # the line stride modulo the "screen_dma_max_data_size8"
#    set the_mem_stride8_aligned_dma [ expr ((($the_mem_stride8 + $screen_dma_max_data_size8 - 1) / $screen_dma_max_data_size8) * $screen_dma_max_data_size8) ]
#   
#    # the total size (including 2 frame buffers)
#    set the_mem_size8 [ expr ($the_mem_stride8_aligned_dma * [ get_parameter_value $VIDEO_FRAME_HEIGHT ] * 2) ]
#   
#    # default is non-aligned
#    set is_aligned 0
#
#    if {[get_parameter_value $VIDEO_ENABLE_CSR] == 0} {
#
#      # the base address 
#      set the_mem_addr8 [get_parameter_value $VIDEO_SB_MEM_ADDR8]
#
#      # the base address modulo the "screen_dma_max_data_size8"
#      set the_mem_addr8_aligned [ expr ((($the_mem_addr8 + $screen_dma_max_data_size8-1) / $screen_dma_max_data_size8) * $screen_dma_max_data_size8) ]
#      
#      if {$the_mem_addr8 == $the_mem_addr8_aligned} {
#        # assert if memory base is aligned
#        set is_aligned 1
#   	  }
#      	    
#   	}
#    	
#    set_parameter_value $VIDEO_SB_MEM_STRIDE8 $the_mem_stride8_aligned_dma  
#    set_parameter_value $VIDEO_SB_MEM_SIZE8   $the_mem_size8  
#    set_parameter_value $VIDEO_SB_MEM_ALIGNED $is_aligned  

 
  }                                  

                                   

  proc display_valid_video_out { inst_id inst_name } {


    set VIDEO_ENABLE_CSR                ${inst_name}_VIDEO_ENABLE_CSR               
    set VIDEO_ENABLE_TPG                ${inst_name}_VIDEO_ENABLE_TPG              
    set VIDEO_TPG_PATTERN_BACK          ${inst_name}_VIDEO_TPG_PATTERN_BACK   
    set VIDEO_TPG_PATTERN_FORE          ${inst_name}_VIDEO_TPG_PATTERN_FORE			        
                                        
    set VIDEO_CLOCKED                   ${inst_name}_VIDEO_CLOCKED                      
    set VIDEO_SCREEN_NUM                ${inst_name}_VIDEO_SCREEN_NUM            
    set VIDEO_PIXEL_NUM                 ${inst_name}_VIDEO_PIXEL_NUM                      
    set video_frame_color_format        ${inst_name}_video_frame_color_format              
    set VIDEO_FRAME_PIXEL_FORMAT        ${inst_name}_VIDEO_FRAME_PIXEL_FORMAT                   
    set video_frame_color_size          ${inst_name}_video_frame_color_size                    
    set video_frame_color_num           ${inst_name}_video_frame_color_num                    
    set VIDEO_FRAME_WIDTH               ${inst_name}_VIDEO_FRAME_WIDTH                    
    set VIDEO_FRAME_HEIGHT              ${inst_name}_VIDEO_FRAME_HEIGHT                     
                                        
    set VIDEO_TIMINGS_HRES              ${inst_name}_VIDEO_TIMINGS_HRES                            
    set VIDEO_TIMINGS_HFPW              ${inst_name}_VIDEO_TIMINGS_HFPW                            
    set VIDEO_TIMINGS_HSW               ${inst_name}_VIDEO_TIMINGS_HSW                             
    set VIDEO_TIMINGS_HBPW              ${inst_name}_VIDEO_TIMINGS_HBPW                            
    set VIDEO_TIMINGS_VRES              ${inst_name}_VIDEO_TIMINGS_VRES                            
    set VIDEO_TIMINGS_VFPW              ${inst_name}_VIDEO_TIMINGS_VFPW                            
    set VIDEO_TIMINGS_VSW               ${inst_name}_VIDEO_TIMINGS_VSW                             
    set VIDEO_TIMINGS_VBPW              ${inst_name}_VIDEO_TIMINGS_VBPW                            
    set timings_info_freq_pixel         ${inst_name}_timings_info_freq_pixel                 
    set timings_info_freq_horizontal    ${inst_name}_timings_info_freq_horizontal            
    set timings_info_freq_vertical      ${inst_name}_timings_info_freq_vertical              
        
    set LAYER_ENABLE_CSR_BKG_COLOR      ${inst_name}_LAYER_ENABLE_CSR_BKG_COLOR      
    set LAYER_BKG_COLOR                 ${inst_name}_LAYER_BKG_COLOR      

  # set VIDEO_ENABLE_SCREENBUFFER    ${inst_name}_VIDEO_ENABLE_SCREENBUFFER

    colorformat_get_info [get_parameter_value $video_frame_color_format] color_hw pixel_depth color_num color_size

    set_parameter_value $VIDEO_FRAME_PIXEL_FORMAT $color_hw
    set_parameter_value $video_frame_color_size   $color_size
    set_parameter_value $video_frame_color_num    $color_num

  # switch [get_parameter_value $VIDEO_FRAME_PIXEL_FORMAT] {
  #   "RGB_666" {
  #     set_parameter_value $video_frame_color_size 6
  #     set_parameter_value $video_frame_color_num 3
  #   }                                              
  #   "RGB_888" {
  #     set_parameter_value $video_frame_color_size 8
  #     set_parameter_value $video_frame_color_num 3
  #   }                                              
  #   "ARGB_8888_PRE" {
  #     set_parameter_value $video_frame_color_size 8
  #     set_parameter_value $video_frame_color_num 4
  #   }                                              
  # }


  # # ARGB8888_PRE implies that background is transparent
  # if {[ get_parameter_value $VIDEO_FRAME_PIXEL_FORMAT] == "ARGB_8888_PRE"} {
  # 
  #   set_parameter_property $LAYER_ENABLE_CSR_BKG_COLOR ENABLED false
  #   set_parameter_property $LAYER_BKG_COLOR            ENABLED false
  # # set_parameter_property $LAYER_BKG_COLOR_r          ENABLED false
  # # set_parameter_property $LAYER_BKG_COLOR_g          ENABLED false
  # # set_parameter_property $LAYER_BKG_COLOR_b          ENABLED false
  # 
  # } else {
  # 
  #   set_parameter_property $LAYER_ENABLE_CSR_BKG_COLOR ENABLED true
  #   set_parameter_property $LAYER_BKG_COLOR            ENABLED true
  # # set_parameter_property $LAYER_BKG_COLOR_r          ENABLED true
  # # set_parameter_property $LAYER_BKG_COLOR_g          ENABLED true
  # # set_parameter_property $LAYER_BKG_COLOR_b          ENABLED true
  # }
    
        
    # not supported with streamed interface
    if { [ get_parameter_value $VIDEO_CLOCKED ] == 1 } {
      set_parameter_property $VIDEO_SCREEN_NUM ENABLED true  
      set_display_item_property "Clocked Timings${inst_id}" VISIBLE true
    } else {
      set_parameter_property $VIDEO_SCREEN_NUM ENABLED false  
      set_display_item_property "Clocked Timings${inst_id}" VISIBLE false
    }
    
        
    if {[get_parameter_value $VIDEO_ENABLE_CSR] == 1 || [ get_parameter_value $VIDEO_CLOCKED ] == 0 } {
    # set_parameter_property $VIDEO_TIMINGS_HRES ENABLED false
      set_parameter_property $VIDEO_TIMINGS_HFPW ENABLED false
      set_parameter_property $VIDEO_TIMINGS_HSW  ENABLED false
      set_parameter_property $VIDEO_TIMINGS_HBPW ENABLED false
    # set_parameter_property $VIDEO_TIMINGS_VRES ENABLED false
      set_parameter_property $VIDEO_TIMINGS_VFPW ENABLED false
      set_parameter_property $VIDEO_TIMINGS_VSW  ENABLED false
      set_parameter_property $VIDEO_TIMINGS_VBPW ENABLED false
      set_parameter_property $timings_info_freq_pixel ENABLED false
    
    } else {
    # set_parameter_property $VIDEO_TIMINGS_HRES ENABLED true
      set_parameter_property $VIDEO_TIMINGS_HFPW ENABLED true
      set_parameter_property $VIDEO_TIMINGS_HSW  ENABLED true
      set_parameter_property $VIDEO_TIMINGS_HBPW ENABLED true
    # set_parameter_property $VIDEO_TIMINGS_VRES ENABLED true
      set_parameter_property $VIDEO_TIMINGS_VFPW ENABLED true
      set_parameter_property $VIDEO_TIMINGS_VSW  ENABLED true
      set_parameter_property $VIDEO_TIMINGS_VBPW ENABLED true
      set_parameter_property $timings_info_freq_pixel ENABLED true
    }
    
    # active resolution defined by frame size
    set_parameter_value $VIDEO_TIMINGS_HRES [ get_parameter_value $VIDEO_FRAME_WIDTH ]
    set_parameter_value $VIDEO_TIMINGS_VRES [ get_parameter_value $VIDEO_FRAME_HEIGHT ]
    
    
#     if {[ get_parameter_value $timings_external ] == 1 || [ get_parameter_value $VIDEO_ENABLE_CSR ] == 1 } {
#       set_parameter_property $timings_max_hres ENABLED true
#       set_parameter_property $timings_max_vres ENABLED true
#     } else {
#       set_parameter_property $timings_max_hres ENABLED false
#       set_parameter_property $timings_max_vres ENABLED false
#     }
#   
      set the_frequency [get_parameter_value $timings_info_freq_pixel]
    
    set the_hres  [get_parameter_value $VIDEO_TIMINGS_HRES]
    set the_hfpw  [get_parameter_value $VIDEO_TIMINGS_HFPW]
    set the_hsw   [get_parameter_value $VIDEO_TIMINGS_HSW]
    set the_hbpw  [get_parameter_value $VIDEO_TIMINGS_HBPW]
    
    set the_vres  [get_parameter_value $VIDEO_TIMINGS_VRES]
    set the_vfpw  [get_parameter_value $VIDEO_TIMINGS_VFPW]
    set the_vsw   [get_parameter_value $VIDEO_TIMINGS_VSW]
    set the_vbpw  [get_parameter_value $VIDEO_TIMINGS_VBPW]
  
    set the_h_total [expr ($the_hres + $the_hfpw + $the_hsw + $the_hbpw)]
    set the_v_total [expr ($the_vres + $the_vfpw + $the_vsw + $the_vbpw)]
    
  # set the_pixel_frequency [expr  $the_frequency / $the_pixel_ratio]
    set the_pixel_frequency $the_frequency  
    set the_h_frequency [expr ($the_pixel_frequency * 1000) / $the_h_total]
    set the_v_frequency [expr ($the_pixel_frequency * 1000000) / ($the_v_total * $the_h_total)]
    
  # set_parameter_value $timings_info_freq_pixel      $the_pixel_frequency  
    set_parameter_value $timings_info_freq_horizontal $the_h_frequency  
    set_parameter_value $timings_info_freq_vertical   $the_v_frequency  
  

    if { [ get_parameter_value $VIDEO_ENABLE_CSR ] == 0 && [ get_parameter_value $VIDEO_ENABLE_TPG ] == 1} {
      set_parameter_property $VIDEO_TPG_PATTERN_BACK VISIBLE true
      set_parameter_property $VIDEO_TPG_PATTERN_FORE VISIBLE true 
    } else {
      set_parameter_property $VIDEO_TPG_PATTERN_BACK VISIBLE false
      set_parameter_property $VIDEO_TPG_PATTERN_FORE VISIBLE false 
    }


#   if { [ get_parameter_value $VIDEO_ENABLE_TPG ] == 1 } {
#     set_display_item_property "Testt Pattern Generator${inst_id}" VISIBLE true
#   } else {
#     set_display_item_property "Testt Pattern Generator${inst_id}" VISIBLE false
#   }

#
    # disable values if runtime-controlled 
#   tpg_enable_pattern "${inst_name}_VIDEO_TPG" [get_parameter_value $VIDEO_ENABLE_CSR]

    
#    set VIDEO_FRAME_WIDTH                  ${inst_name}_VIDEO_FRAME_WIDTH                    
#    set VIDEO_FRAME_HEIGHT                 ${inst_name}_VIDEO_FRAME_HEIGHT                     
#    set SB_FRAME_REPEAT  ${inst_name}_SB_FRAME_REPEAT                    
#    set VIDEO_SB_MEM_ADDR8     ${inst_name}_VIDEO_SB_MEM_ADDR8                    
#    set VIDEO_SB_MEM_STRIDE8   ${inst_name}_VIDEO_SB_MEM_STRIDE8  
#    set VIDEO_SB_MEM_ALIGNED   ${inst_name}_VIDEO_SB_MEM_ALIGNED 
#    set VIDEO_SB_MEM_SIZE8     ${inst_name}_VIDEO_SB_MEM_SIZE8  
#    set VIDEO_SB_ENABLE_ROTATE ${inst_name}_VIDEO_SB_ENABLE_ROTATE                 
#
#
#    if {[get_parameter_value $VIDEO_ENABLE_CSR] == 1} {
#      set_parameter_property $SB_FRAME_REPEAT  ENABLED false
#      set_parameter_property $VIDEO_SB_MEM_ADDR8     ENABLED false    
#    # set_parameter_property $VIDEO_SB_MEM_SIZE8     ENABLED false
#    } else {
#      set_parameter_property $SB_FRAME_REPEAT  ENABLED true
#      set_parameter_property $VIDEO_SB_MEM_ADDR8     ENABLED true
#    # set_parameter_property $VIDEO_SB_MEM_SIZE8     ENABLED true
#    }
#
#    if {[ get_parameter_value $VIDEO_ENABLE_SCREENBUFFER] == 1} {
#      set_parameter_property $SB_FRAME_REPEAT   VISIBLE true
#      set_parameter_property $VIDEO_SB_MEM_ADDR8      VISIBLE true    
#      set_parameter_property $VIDEO_SB_MEM_SIZE8      VISIBLE true    
#      set_parameter_property $VIDEO_SB_ENABLE_ROTATE  ENABLED true
#    # set_parameter_property $VIDEO_SB_MEM_STRIDE8    VISIBLE true
#    # set_parameter_property $VIDEO_SB_MEM_ALIGNED    VISIBLE true   
#    # set_display_item_property "Screen Buffer${inst_id}" VISIBLE true
#    } else {
#      set_parameter_property $SB_FRAME_REPEAT   VISIBLE false
#      set_parameter_property $VIDEO_SB_MEM_ADDR8      VISIBLE false    
#      set_parameter_property $VIDEO_SB_MEM_SIZE8      VISIBLE false    
#      set_parameter_property $VIDEO_SB_ENABLE_ROTATE  ENABLED false
#    # set_parameter_property $VIDEO_SB_MEM_STRIDE8    VISIBLE false
#    # set_parameter_property $VIDEO_SB_MEM_ALIGNED    VISIBLE false  
#    # set_display_item_property "Screen Buffer${inst_id}" VISIBLE false
#    }
#
# 
#  # # compute the sceenbuffer memory stride/size 
#  # # the pixel size in bits
#  # set the_pixel_size [ expr [ get_parameter_value $VIDEO_SCREEN_NUM ] * [ get_parameter_value $video_frame_color_size ] * [ get_parameter_value $video_frame_color_num ] ]
#  # # the line stride in bytes (modulo "pixel size")
#  # set the_mem_stride8 [ expr ( ($the_pixel_size * [ get_parameter_value $VIDEO_FRAME_WIDTH ] + 7) / 8) ]
#  # # the total size
#  # set the_mem_size8 [ expr ($the_mem_stride8 * [ get_parameter_value $VIDEO_FRAME_HEIGHT ] * 2) ]
#  #
#  # set_parameter_value $VIDEO_SB_MEM_STRIDE8 $the_mem_stride8  
#  # set_parameter_value $VIDEO_SB_MEM_SIZE8   $the_mem_size8  

  }





#  proc display_connect_parameters { core_name } {
#
#  # set_instance_parameter ${ctrl_name} WZD_RUNTIME_ENABLE    [ get_parameter_value ${ctrl_name}_RUNTIME_ENABLE ]  
#    
#    set_instance_parameter ${core_name} WZD_CORE_CLOCK_RATE                   [ get_parameter_value  WZD_CORE_CLOCK_RATE                  ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_PIXEL_NUM_PARALLEL           [ get_parameter_value  WZD_LAYER_PIXEL_NUM_PARALLEL          ]                                                                                     
#    set_instance_parameter ${core_name} WZD_DESC_HAS_DEDICATED_CLK            [ get_parameter_value  WZD_DESC_HAS_DEDICATED_CLK           ]                                                                                     
#    set_instance_parameter ${core_name} WZD_DESC_ADDR8_SIZE                   [ get_parameter_value  WZD_DESC_ADDR8_SIZE                  ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_MAX_NUMBER                  [ get_parameter_value  WZD_LAYER_MAX_NUMBER                 ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_STREAM_NUM                  [ get_parameter_value  WZD_LAYER_STREAM_NUM                 ]                                                                                     
#  # set_instance_parameter ${core_name} WZD_NUMBER_OF_VIDEO_SYNC              [ get_parameter_value  WZD_NUMBER_OF_VIDEO_SYNC             ]                                                                                     
#    set_instance_parameter ${core_name} WZD_ENABLE_DEBUG                      [ get_parameter_value  WZD_ENABLE_DEBUG                     ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_STREAM                     [ get_parameter_value  WZD_LAYER_ENABLE_STREAM                    ]                                                                                     
#  # set_instance_parameter ${core_name} WZD_ENABLE_VIDEO_SYNC                 [ get_parameter_value  WZD_ENABLE_VIDEO_SYNC                ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_ENABLE_CSR                  [ get_parameter_value  WZD_VIDEO_ENABLE_CSR                 ]                                                                                     
#    set_instance_parameter ${core_name} WZD_ENABLE_CSR_READBACK_REDUCED       [ get_parameter_value  WZD_ENABLE_CSR_READBACK_REDUCED      ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_ALPHA_GLOBAL               [ get_parameter_value  WZD_LAYER_ENABLE_ALPHA_GLOBAL              ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_WINDOWING                  [ get_parameter_value  WZD_LAYER_ENABLE_WINDOWING                 ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_RESIZING                   [ get_parameter_value  WZD_LAYER_ENABLE_RESIZING                  ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_FILTERING_H                [ get_parameter_value  WZD_LAYER_ENABLE_FILTERING_H               ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_FILTERING_V                [ get_parameter_value  WZD_LAYER_ENABLE_FILTERING_V               ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_COLORTRANSFORM             [ get_parameter_value  WZD_LAYER_ENABLE_COLORTRANSFORM            ]   
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_CHROMA_KEYING              [ get_parameter_value  WZD_LAYER_ENABLE_CHROMA_KEYING             ]                                                                                         
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_MASKING                    [ get_parameter_value  WZD_LAYER_ENABLE_MASKING                   ]                                                                                         
#  # set_instance_parameter ${core_name} WZD_ENABLE_COLOR_EXTENDED             [ get_parameter_value  WZD_ENABLE_COLOR_EXTENDED            ]                                                                                     
#  # set_instance_parameter ${core_name} WZD_ENABLE_COLOR_PALETTE              [ get_parameter_value  WZD_ENABLE_COLOR_PALETTE             ]   
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_BANDWIDTH_VIEWER           [ get_parameter_value  WZD_LAYER_ENABLE_BANDWIDTH_VIEWER          ]                                                                                        
#  # set_instance_parameter ${core_name} WZD_NUMBER_OF_PALETTE_COLORS          [ get_parameter_value  WZD_NUMBER_OF_PALETTE_COLORS         ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_ENABLE_CSR_BKG_COLOR              [ get_parameter_value  WZD_LAYER_ENABLE_CSR_BKG_COLOR             ]                                                                                     
#    set_instance_parameter ${core_name} WZD_LAYER_BKG_COLOR                         [ get_parameter_value  WZD_LAYER_BKG_COLOR                        ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_CLOCKED                     [ get_parameter_value  WZD_VIDEO_CLOCKED                    ] 
#    set_instance_parameter ${core_name} WZD_VIDEO_ENABLE_SCREENBUFFER         [ get_parameter_value  WZD_VIDEO_ENABLE_SCREENBUFFER        ] 
#    set_instance_parameter ${core_name} WZD_VIDEO_SB_ENABLE_ROTATE  [ get_parameter_value  WZD_VIDEO_SB_ENABLE_ROTATE ] 
#  # set_instance_parameter ${core_name} WZD_VIDEO_SB_ROTATE_ANGLE   [ get_parameter_value  WZD_VIDEO_SB_ROTATE_ANGLE  ] 
#    set_instance_parameter ${core_name} WZD_SB_FRAME_REPEAT   [ get_parameter_value  WZD_SB_FRAME_REPEAT  ] 
#    set_instance_parameter ${core_name} WZD_VIDEO_SB_MEM_ADDR8      [ get_parameter_value  WZD_VIDEO_SB_MEM_ADDR8     ] 
#    set_instance_parameter ${core_name} WZD_VIDEO_SB_MEM_SIZE8      [ get_parameter_value  WZD_VIDEO_SB_MEM_SIZE8     ]                                                                                         
#    set_instance_parameter ${core_name} WZD_VIDEO_SB_MEM_STRIDE8    [ get_parameter_value  WZD_VIDEO_SB_MEM_STRIDE8   ]                                                                                         
#    set_instance_parameter ${core_name} WZD_VIDEO_ENABLE_FLIP_H               [ get_parameter_value  WZD_VIDEO_ENABLE_FLIP_H              ] 
#    set_instance_parameter ${core_name} WZD_VIDEO_ENABLE_FLIP_V               [ get_parameter_value  WZD_VIDEO_ENABLE_FLIP_V              ] 
#    set_instance_parameter ${core_name} WZD_VIDEO_SCREEN_NUM           [ get_parameter_value  WZD_VIDEO_SCREEN_NUM          ]                                                                                     
#    set_instance_parameter ${core_name} WZD_video_frame_color_size                  [ get_parameter_value  WZD_video_frame_color_size                 ]                                                                                     
#    set_instance_parameter ${core_name} WZD_video_frame_color_num                   [ get_parameter_value  WZD_video_frame_color_num                  ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_PIXEL_NUM                   [ get_parameter_value  WZD_VIDEO_PIXEL_NUM                  ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_FRAME_WIDTH                   [ get_parameter_value  WZD_VIDEO_FRAME_WIDTH                  ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_FRAME_HEIGHT                  [ get_parameter_value  WZD_VIDEO_FRAME_HEIGHT                 ]                                                                                     
#  # set_instance_parameter ${core_name} WZD_VIDEO_TIMINGS_HRES                      [ get_parameter_value  WZD_VIDEO_TIMINGS_HRES                     ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_TIMINGS_HFPW                      [ get_parameter_value  WZD_VIDEO_TIMINGS_HFPW                     ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_TIMINGS_HSW                       [ get_parameter_value  WZD_VIDEO_TIMINGS_HSW                      ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_TIMINGS_HBPW                      [ get_parameter_value  WZD_VIDEO_TIMINGS_HBPW                     ]                                                                                     
#  # set_instance_parameter ${core_name} WZD_VIDEO_TIMINGS_VRES                      [ get_parameter_value  WZD_VIDEO_TIMINGS_VRES                     ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_TIMINGS_VFPW                      [ get_parameter_value  WZD_VIDEO_TIMINGS_VFPW                     ]                                                                                     
#    set_instance_parameter ${core_name} WZD_VIDEO_TIMINGS_VSW                       [ get_parameter_value  WZD_VIDEO_TIMINGS_VSW                      ]
#    set_instance_parameter ${core_name} WZD_VIDEO_TIMINGS_VBPW                      [ get_parameter_value  WZD_VIDEO_TIMINGS_VBPW                     ]
#
#  }
#