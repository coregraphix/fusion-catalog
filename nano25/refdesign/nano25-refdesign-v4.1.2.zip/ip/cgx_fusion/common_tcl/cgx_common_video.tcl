

# video_add_parameters_core  
# video_elaborate_core


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Macro                                                                                       --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  # core instance name
  # core parameters prefix
# proc vsc_get_name { is_writer inst_id } 
  proc vsc_get_name { inst_id } {

  # if {$is_writer == 0} { 
  #   set vsc_name vsc_reader
  # } else {
  #   set vsc_name vsc_writer
  # } 
        
  # set vsc_name ${vsc_name}${inst_id}

    set vsc_name "vsc"
    
    return $vsc_name 
        
  }




# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Interfaces                                                                                 --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc video_add_interface { if_name } {

    # +-----------------------------------
    # | connection point ${if_name}_clock_in
    # | 
    add_interface ${if_name}_clock_in conduit start
    
    set_interface_property ${if_name}_clock_in ENABLED true
    
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_clock_i     export Input 1
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_clken_i     export Input 1
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_data_i      export Input -1
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_de_i        export Input  1
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_hsync_i     export Input  1
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_vsync_i     export Input  1
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_f_i         export Input  1
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_locked_i    export Input  1
    add_interface_port ${if_name}_clock_in ${if_name}_cvi_overflow_o  export Output 1
    
    # | 
    # +-----------------------------------
    
#   # +-----------------------------------
#   # | connection point ${if_name}_stream_in
#   # | 
#   add_interface ${if_name}_stream_in avalon_streaming end
#   
#   set_interface_property ${if_name}_stream_in associatedClock clock
#   set_interface_property ${if_name}_stream_in associatedReset reset
#   
#   set_interface_property ${if_name}_stream_in dataBitsPerSymbol -1
#   set_interface_property ${if_name}_stream_in errorDescriptor ""
#   set_interface_property ${if_name}_stream_in maxChannel 0
#   set_interface_property ${if_name}_stream_in readyLatency 1
#   set_interface_property ${if_name}_stream_in symbolsPerBeat -1
#   
#   add_interface_port ${if_name}_stream_in ${if_name}_dat_ready ready         Output 1
#   add_interface_port ${if_name}_stream_in ${if_name}_dat_valid valid         Input  1
#   add_interface_port ${if_name}_stream_in ${if_name}_dat_data  data          Input -1
#   add_interface_port ${if_name}_stream_in ${if_name}_dat_sop   startofpacket Input  1
#   add_interface_port ${if_name}_stream_in ${if_name}_dat_eop   endofpacket   Input  1
#
#   # | 
#   # +-----------------------------------


    # +-----------------------------------
    # | connection point ${if_name}_stream_in
    # | 
    add_interface ${if_name}_stream_in axi4stream end
    
    set_interface_property ${if_name}_stream_in associatedClock clock
    set_interface_property ${if_name}_stream_in associatedReset reset
  
    set_interface_property ${if_name}_stream_in ENABLED true
    set_interface_property ${if_name}_stream_in EXPORT_OF ""
    set_interface_property ${if_name}_stream_in PORT_NAME_MAP ""
    set_interface_property ${if_name}_stream_in CMSIS_SVD_VARIABLES ""
    set_interface_property ${if_name}_stream_in SVD_ADDRESS_GROUP ""
    
    add_interface_port ${if_name}_stream_in ${if_name}_dat_tready_o tready  Output   1
    add_interface_port ${if_name}_stream_in ${if_name}_dat_tvalid_i tvalid  Input 1
    add_interface_port ${if_name}_stream_in ${if_name}_dat_tdata_i  tdata   Input -1
    add_interface_port ${if_name}_stream_in ${if_name}_dat_tlast_i  tlast   Input 1
    add_interface_port ${if_name}_stream_in ${if_name}_dat_tuser_i  tuser   Input 1

    # | 



#    # +-----------------------------------
#    # | connection point ${if_name}_ext_din
#    # | 
#
#    add_interface ${if_name}_ext_din avalon_streaming end
#    
#    set_interface_property ${if_name}_ext_din associatedClock clock
#    set_interface_property ${if_name}_ext_din associatedReset reset
#    
#    set_interface_property ${if_name}_ext_din dataBitsPerSymbol 8 
#    set_interface_property ${if_name}_ext_din errorDescriptor ""
#    set_interface_property ${if_name}_ext_din maxChannel 0
#    set_interface_property ${if_name}_ext_din readyLatency 1
#    set_interface_property ${if_name}_ext_din symbolsPerBeat 4 
#    
#    add_interface_port ${if_name}_ext_din ${if_name}_xin_ready_o ready         Output 1
#    add_interface_port ${if_name}_ext_din ${if_name}_xin_valid_i valid         Input  1
#    add_interface_port ${if_name}_ext_din ${if_name}_xin_data_i  data          Input 32
#    add_interface_port ${if_name}_ext_din ${if_name}_xin_sop_i   startofpacket Input  1
#    add_interface_port ${if_name}_ext_din ${if_name}_xin_eop_i   endofpacket   Input  1
#
#    # | 
#    # +-----------------------------------
#
#
#    # +-----------------------------------
#    # | connection point ${if_name}_ext_dout
#    # | 
#
#    add_interface ${if_name}_ext_dout avalon_streaming start
#    
#    set_interface_property ${if_name}_ext_dout associatedClock clock
#    set_interface_property ${if_name}_ext_dout associatedReset reset
#    
#    set_interface_property ${if_name}_ext_dout dataBitsPerSymbol 8 
#    set_interface_property ${if_name}_ext_dout errorDescriptor ""
#    set_interface_property ${if_name}_ext_dout maxChannel 0
#    set_interface_property ${if_name}_ext_dout readyLatency 1
#    set_interface_property ${if_name}_ext_dout symbolsPerBeat 4 
#    
#    add_interface_port ${if_name}_ext_dout ${if_name}_xout_ready_i ready         Input  1
#    add_interface_port ${if_name}_ext_dout ${if_name}_xout_valid_o valid         Output 1
#    add_interface_port ${if_name}_ext_dout ${if_name}_xout_data_o  data          Output 32 
#    add_interface_port ${if_name}_ext_dout ${if_name}_xout_sop_o   startofpacket Output 1
#    add_interface_port ${if_name}_ext_dout ${if_name}_xout_eop_o   endofpacket   Output 1
#
#    # | 
#    # +-----------------------------------


  }
 
 
  proc video_elaborate_interface { if_name if_enabled param_name } {
  
    set param_name ${param_name}_PORT

    set CLOCKED              ${param_name}_CLOCKED 
    set PIXEL_NUM            ${param_name}_PIXEL_NUM                      
  # set ENABLE_SCL           ${param_name}_ENABLE_SCL                                                
    set cvi_format           ${param_name}_cvi_format                 
    set CVI_PIXEL_MODE       ${param_name}_CVI_PIXEL_MODE
    set CVI_PIXEL_SIZE       ${param_name}_CVI_PIXEL_SIZE    
    set frame_color_format   ${param_name}_frame_color_format                  
    set FRAME_PIXEL_FORMAT   ${param_name}_FRAME_PIXEL_FORMAT                   
    set FRAME_WIDTH          ${param_name}_FRAME_WIDTH                    
    set FRAME_HEIGHT         ${param_name}_FRAME_HEIGHT                     
    set frame_color_size     ${param_name}_frame_color_size                    
    set frame_color_num      ${param_name}_frame_color_num                    

    if { $if_enabled == 0 } {
      set_interface_property ${if_name}_clock_in  ENABLED false  
      set_interface_property ${if_name}_stream_in ENABLED false
    # none
    } elseif { [ get_parameter_value $CLOCKED ] == 2 } {
      set_interface_property ${if_name}_clock_in  ENABLED false  
      set_interface_property ${if_name}_stream_in ENABLED false
    # clocked
    } elseif { [ get_parameter_value $CLOCKED ] == 1 } {
      set_interface_property ${if_name}_clock_in  ENABLED true  
      set_interface_property ${if_name}_stream_in ENABLED false
    # streamed
    } else {
      set_interface_property ${if_name}_clock_in  ENABLED false  
      set_interface_property ${if_name}_stream_in ENABLED true 
    }


 #  if { $if_enabled == 0 } {
 #    set_interface_property ${if_name}_ext_din  ENABLED false  
 #    set_interface_property ${if_name}_ext_dout ENABLED false
 #  } elseif { [get_parameter_value $ENABLE_SCL] == 0 } {
 #    set_interface_property ${if_name}_ext_din  ENABLED false  
 #    set_interface_property ${if_name}_ext_dout ENABLED false
 #  } else {
 #    set_interface_property ${if_name}_ext_din  ENABLED true  
 #    set_interface_property ${if_name}_ext_dout ENABLED true
 #  }


  # set_interface_property ${if_name}_ext_din dataBitsPerSymbol 8
  # set_interface_property ${if_name}_ext_din symbolsPerBeat 3
  # set_port_property      ${if_name}_dat_data  WIDTH_EXPR 24


    set color_hw    0 
    set color_depth 0 
    set color_num   0 
    set color_size  0

    colorformat_get_info [get_parameter_value $frame_color_format] color_hw color_depth color_num color_size    

 #  set cvi_color_num   color_num 
 #  set cvi_color_size  color_size
 
    switch [get_parameter_value $cvi_format] {
      "parallel RGB" {
        set_parameter_value $CVI_PIXEL_MODE 0; # DEF_CVI_ARGBp  
        set cvi_color_num   $color_num 
        set cvi_color_size  $color_size      
      }                                              
      "BT656" {                               
        set_parameter_value $CVI_PIXEL_MODE 1; # DEF_CVI_BT656  
        set cvi_color_num   1 
        set cvi_color_size  8
      }                                            
      "BAYER" {                               
        set_parameter_value $CVI_PIXEL_MODE 2; # DEF_CVI_BAYER  
        set cvi_color_num   1 
        set cvi_color_size  8   
      }                                            
    }

    set_parameter_value $FRAME_PIXEL_FORMAT $color_hw  
 
    set_parameter_value $frame_color_num  $color_num
    set_parameter_value $frame_color_size $color_size
    set_parameter_value $CVI_PIXEL_SIZE [ expr ( $cvi_color_size * $cvi_color_num ) ] 
   
  # # empty size independent 
  # set_interface_property ${if_name}_stream_in dataBitsPerSymbol [ expr ( [get_parameter_value $frame_color_size] ) ]
  # # empty size dependent 
  # set_interface_property ${if_name}_stream_in symbolsPerBeat [ expr ( [get_parameter_value $frame_color_num] * [get_parameter_value $PIXEL_NUM] ) ]
    
  # set_port_property ${if_name}_dat_data_i     WIDTH_EXPR [ expr ( [get_parameter_value $frame_color_size] * [get_parameter_value $frame_color_num] * [get_parameter_value $PIXEL_NUM] ) ]
    set_port_property ${if_name}_dat_tdata_i    WIDTH_EXPR [ expr ( [get_parameter_value $frame_color_size] * [get_parameter_value $frame_color_num] * [get_parameter_value $PIXEL_NUM] ) ]
    
  # set_port_property ${if_name}_cvi_data_i     WIDTH_EXPR [ expr ( [get_parameter_value $CVI_PIXEL_SIZE] * [get_parameter_value $PIXEL_NUM] ) ]
    set_port_property ${if_name}_cvi_data_i     WIDTH_EXPR [ expr ( [get_parameter_value $CVI_PIXEL_SIZE] * 1 ) ]
  # set_port_property ${if_name}_cvi_de_i       WIDTH_EXPR [get_parameter_value $PIXEL_NUM]
  # set_port_property ${if_name}_cvi_hsync_i    WIDTH_EXPR [get_parameter_value $PIXEL_NUM]
  # set_port_property ${if_name}_cvi_vsync_i    WIDTH_EXPR [get_parameter_value $PIXEL_NUM]
  # set_port_property ${if_name}_cvi_f_i        WIDTH_EXPR [get_parameter_value $PIXEL_NUM]

  }



 

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Main                                                                                       --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------
 
  proc video_add { inst_name gui_group_name gui_id } {

    set param_name ${inst_name}

  # video_add_parameters      ${param_name} ${gui_group_name} ${gui_id} 
 
    video_add_parameters_port ${param_name} ${gui_group_name} ${gui_id} 

  # video_add_parameters_sfc  ${param_name} ${gui_group_name} ${gui_id} 
 
  }


  proc video_valid { inst_name video_idx } {

    set param_name ${inst_name}

    video_valid_port ${param_name}
  # video_valid_sfc  ${param_name} ${video_idx}
 
  }
 

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Port                                                                                       --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc video_add_parameters_port {inst_name parent_gui_name gui_id} {

    set param_name ${inst_name}_PORT

  # set VERSION_MAJOR           ${param_name}_VERSION_MAJOR               
  # set VERSION_MINOR           ${param_name}_VERSION_MINOR              
    set ENABLE_CSR              ${param_name}_ENABLE_CSR               
    set ENABLE_TPG              ${param_name}_ENABLE_TPG                                                 
    set ENABLE_BAND             ${param_name}_ENABLE_BAND                                                
    set ENABLE_CRP              ${param_name}_ENABLE_CRP                                                
    set ENABLE_SCL              ${param_name}_ENABLE_SCL                                                
    set ENABLE_ROT              ${param_name}_ENABLE_ROT                                                
    set CLOCKED                 ${param_name}_CLOCKED 
    set PIXEL_NUM               ${param_name}_PIXEL_NUM                      
    set frame_color_format      ${param_name}_frame_color_format                  
    set FRAME_PIXEL_FORMAT      ${param_name}_FRAME_PIXEL_FORMAT                   
    set FRAME_WIDTH             ${param_name}_FRAME_WIDTH                    
    set FRAME_HEIGHT            ${param_name}_FRAME_HEIGHT                     
    set frame_color_size        ${param_name}_frame_color_size                    
    set frame_color_num         ${param_name}_frame_color_num                    

    set cvi_format              ${param_name}_cvi_format                 
    set CVI_PIXEL_MODE          ${param_name}_CVI_PIXEL_MODE                      
    set CVI_PIXEL_SIZE          ${param_name}_CVI_PIXEL_SIZE    
    set CVI_HAS_DEDICATED_CLK   ${param_name}_CVI_HAS_DEDICATED_CLK                   
    set CVI_BAYER_ENABLE_LINEAR ${param_name}_CVI_BAYER_ENABLE_LINEAR                 
    set TPG_PATTERN_BACK        ${param_name}_TPG_PATTERN_BACK   
    set TPG_PATTERN_FORE        ${param_name}_TPG_PATTERN_FORE			        

  # add_parameter          $VERSION_MAJOR INTEGER 0
  # set_parameter_property $VERSION_MAJOR DISPLAY_NAME "major";
  # set_parameter_property $VERSION_MAJOR DISPLAY_HINT INTEGER
  # set_parameter_property $VERSION_MAJOR DESCRIPTION " "
  # set_parameter_property $VERSION_MAJOR VISIBLE false 
  # set_parameter_property $VERSION_MAJOR DERIVED true 
  # set_parameter_property $VERSION_MAJOR HDL_PARAMETER true
  # 
  # add_parameter          $VERSION_MINOR INTEGER 0
  # set_parameter_property $VERSION_MINOR DISPLAY_NAME "minor";
  # set_parameter_property $VERSION_MINOR DISPLAY_HINT INTEGER
  # set_parameter_property $VERSION_MINOR DESCRIPTION " "
  # set_parameter_property $VERSION_MINOR VISIBLE false 
  # set_parameter_property $VERSION_MINOR DERIVED true 
  # set_parameter_property $VERSION_MINOR HDL_PARAMETER true

    add_parameter          $ENABLE_CSR INTEGER 1
    set_parameter_property $ENABLE_CSR DISPLAY_NAME "Run-time control"
    set_parameter_property $ENABLE_CSR DISPLAY_HINT boolean
    set_parameter_property $ENABLE_CSR DESCRIPTION "Turn on to enable run-time control ";
    set_parameter_property $ENABLE_CSR AFFECTS_ELABORATION true        
    set_parameter_property $ENABLE_CSR HDL_PARAMETER true

    add_parameter          $ENABLE_TPG INTEGER 1
    set_parameter_property $ENABLE_TPG DISPLAY_NAME "Test Pattern Generator"
    set_parameter_property $ENABLE_TPG DISPLAY_HINT boolean
    set_parameter_property $ENABLE_TPG DESCRIPTION "Turn on to support video built-in Test Pattern Generator";
    set_parameter_property $ENABLE_TPG AFFECTS_ELABORATION true        
    set_parameter_property $ENABLE_TPG HDL_PARAMETER true

    add_parameter          $ENABLE_BAND INTEGER 0
    set_parameter_property $ENABLE_BAND DISPLAY_NAME "Banding"
    set_parameter_property $ENABLE_BAND DISPLAY_HINT boolean
    set_parameter_property $ENABLE_BAND DESCRIPTION "Turn on to support video banding";
    set_parameter_property $ENABLE_BAND AFFECTS_ELABORATION true        
    set_parameter_property $ENABLE_BAND HDL_PARAMETER true

    add_parameter          $ENABLE_CRP INTEGER 0
    set_parameter_property $ENABLE_CRP DISPLAY_NAME "Cropping"
    set_parameter_property $ENABLE_CRP DISPLAY_HINT boolean
    set_parameter_property $ENABLE_CRP DESCRIPTION "Turn on to support video cropping";
    set_parameter_property $ENABLE_CRP AFFECTS_ELABORATION true        
    set_parameter_property $ENABLE_CRP HDL_PARAMETER true

    add_parameter          $ENABLE_SCL INTEGER 0
    set_parameter_property $ENABLE_SCL DISPLAY_NAME "Scaling"
    set_parameter_property $ENABLE_SCL DISPLAY_HINT boolean
    set_parameter_property $ENABLE_SCL DESCRIPTION "Turn on to support video scaling";
    set_parameter_property $ENABLE_SCL AFFECTS_ELABORATION true        
    set_parameter_property $ENABLE_SCL HDL_PARAMETER true

    add_parameter          $ENABLE_ROT INTEGER 0
    set_parameter_property $ENABLE_ROT DISPLAY_NAME "Rotation"
    set_parameter_property $ENABLE_ROT DISPLAY_HINT boolean
    set_parameter_property $ENABLE_ROT DESCRIPTION "Turn on to support video rotation";
    set_parameter_property $ENABLE_ROT AFFECTS_ELABORATION true        
    set_parameter_property $ENABLE_ROT HDL_PARAMETER true
       
    add_parameter          $CLOCKED INTEGER 1
    set_parameter_property $CLOCKED DISPLAY_NAME "Interface";
  # set_parameter_property $CLOCKED ALLOWED_RANGES {"1:clocked" "0:streamed (Avalon ST video)"}; # "2:none"
    set_parameter_property $CLOCKED ALLOWED_RANGES {"1:clocked" "0:streamed (AXIS video)"}; # "2:none"
    set_parameter_property $CLOCKED DISPLAY_HINT radio
    set_parameter_property $CLOCKED AFFECTS_ELABORATION true        
    set_parameter_property $CLOCKED HDL_PARAMETER true
        
    add_parameter          $PIXEL_NUM INTEGER 1
    set_parameter_property $PIXEL_NUM DISPLAY_NAME "Number of pixels in parallel";
    set_parameter_property $PIXEL_NUM ALLOWED_RANGES {1,2,4,8}
    set_parameter_property $PIXEL_NUM DISPLAY_UNITS "Pixels"
    set_parameter_property $PIXEL_NUM AFFECTS_ELABORATION true
    set_parameter_property $PIXEL_NUM ENABLED true
    set_parameter_property $PIXEL_NUM HDL_PARAMETER true
    
    add_parameter          $frame_color_format string "RGB_888"
    set_parameter_property $frame_color_format DISPLAY_NAME "Pixel Format"
    set_parameter_property $frame_color_format ALLOWED_RANGES ${::imt_surface::video_colorformat_range} ; # {"RGB_666" "RGB_888" "ARGB_8888_PRE"}
    set_parameter_property $frame_color_format DESCRIPTION "Choose the output pixel format. Premultiplied format automatically set transparent background"
    set_parameter_property $frame_color_format AFFECTS_ELABORATION true        

    add_parameter          $FRAME_PIXEL_FORMAT integer 0
    set_parameter_property $FRAME_PIXEL_FORMAT DISPLAY_NAME "Private Pixel Format"
    set_parameter_property $FRAME_PIXEL_FORMAT DERIVED true 
    set_parameter_property $FRAME_PIXEL_FORMAT HDL_PARAMETER true
    set_parameter_property $FRAME_PIXEL_FORMAT VISIBLE false 
    
    # derived
    add_parameter          $frame_color_size INTEGER 8
    set_parameter_property $frame_color_size DISPLAY_NAME "Bits per pixel per color plane";
    set_parameter_property $frame_color_size DISPLAY_UNITS "Bits"
    set_parameter_property $frame_color_size DERIVED true 
    set_parameter_property $frame_color_size VISIBLE false      
        
    # derived
    add_parameter          $frame_color_num INTEGER 3
    set_parameter_property $frame_color_num DISPLAY_NAME "Number of color planes in parallel";
    set_parameter_property $frame_color_num DISPLAY_UNITS "Planes"
    set_parameter_property $frame_color_num DERIVED true 
    set_parameter_property $frame_color_num VISIBLE false      
        
    add_parameter          $FRAME_WIDTH INTEGER 800
    set_parameter_property $FRAME_WIDTH DISPLAY_NAME "Maximum frame width" 
    set_parameter_property $FRAME_WIDTH ALLOWED_RANGES {0:16384}
    set_parameter_property $FRAME_WIDTH DESCRIPTION "  ";
    set_parameter_property $FRAME_WIDTH AFFECTS_ELABORATION true        
    set_parameter_property $FRAME_WIDTH VISIBLE true      
    set_parameter_property $FRAME_WIDTH HDL_PARAMETER true
    
    add_parameter          $FRAME_HEIGHT INTEGER 600
    set_parameter_property $FRAME_HEIGHT DISPLAY_NAME "Maximum frame height" 
    set_parameter_property $FRAME_HEIGHT ALLOWED_RANGES {0:16384}
    set_parameter_property $FRAME_HEIGHT DESCRIPTION "  ";
    set_parameter_property $FRAME_HEIGHT AFFECTS_ELABORATION true        
    set_parameter_property $FRAME_HEIGHT VISIBLE true      
    set_parameter_property $FRAME_HEIGHT HDL_PARAMETER true

    add_parameter          $cvi_format string "parallel RGB"
    set_parameter_property $cvi_format DISPLAY_NAME "Clocked Pixel mode"
    set_parameter_property $cvi_format ALLOWED_RANGES {"parallel RGB" "BT656" "BAYER"};
    set_parameter_property $cvi_format DESCRIPTION "Pixel format of input pixels";
    set_parameter_property $cvi_format AFFECTS_ELABORATION true        

    add_parameter          $CVI_PIXEL_MODE integer 0
    set_parameter_property $CVI_PIXEL_MODE DISPLAY_NAME "Private Clocked Pixel mode"
  # set_parameter_property $CVI_PIXEL_MODE ALLOWED_RANGES {"parallel RGB" "BT656" "BAYER"}; 
  # set_parameter_property $CVI_PIXEL_MODE AFFECTS_ELABORATION true 
    set_parameter_property $CVI_PIXEL_MODE DERIVED true 
    set_parameter_property $CVI_PIXEL_MODE VISIBLE false      
    set_parameter_property $CVI_PIXEL_MODE HDL_PARAMETER true

    # derived
    add_parameter          $CVI_PIXEL_SIZE INTEGER 24
    set_parameter_property $CVI_PIXEL_SIZE DISPLAY_NAME "Pixel size";
    set_parameter_property $CVI_PIXEL_SIZE DISPLAY_UNITS "Bits"
    set_parameter_property $CVI_PIXEL_SIZE DERIVED true 
    set_parameter_property $CVI_PIXEL_SIZE VISIBLE false      
    set_parameter_property $CVI_PIXEL_SIZE HDL_PARAMETER true

    add_parameter          $CVI_HAS_DEDICATED_CLK INTEGER 1
    set_parameter_property $CVI_HAS_DEDICATED_CLK DISPLAY_NAME "Dedicated video clock" 
    set_parameter_property $CVI_HAS_DEDICATED_CLK DISPLAY_HINT boolean 
    set_parameter_property $CVI_HAS_DEDICATED_CLK DESCRIPTION "Turn ON if video and core clock signals have different clock domains ";
    set_parameter_property $CVI_HAS_DEDICATED_CLK AFFECTS_ELABORATION false        
    set_parameter_property $CVI_HAS_DEDICATED_CLK VISIBLE true      
    set_parameter_property $CVI_HAS_DEDICATED_CLK HDL_PARAMETER true
    
    add_parameter          $CVI_BAYER_ENABLE_LINEAR INTEGER 1
    set_parameter_property $CVI_BAYER_ENABLE_LINEAR DISPLAY_NAME "Bayer linear interpolation" 
    set_parameter_property $CVI_BAYER_ENABLE_LINEAR DISPLAY_HINT boolean 
    set_parameter_property $CVI_BAYER_ENABLE_LINEAR DESCRIPTION "Turn Off for interpolation to the nearest neighbor (lower quality, smaller resources), Turn On for correlation-adjusted linear interpolation (higher quality, higher resources) ";
    set_parameter_property $CVI_BAYER_ENABLE_LINEAR AFFECTS_ELABORATION false        
    set_parameter_property $CVI_BAYER_ENABLE_LINEAR VISIBLE true      
    set_parameter_property $CVI_BAYER_ENABLE_LINEAR HDL_PARAMETER true

    add_parameter          $TPG_PATTERN_BACK INTEGER 2
    set_parameter_property $TPG_PATTERN_BACK DISPLAY_NAME "background test pattern"
    set_parameter_property $TPG_PATTERN_BACK ALLOWED_RANGES ${::cgx_tpg::tpg_pattern_back_range} 
    set_parameter_property $TPG_PATTERN_BACK HDL_PARAMETER true      
                           
    add_parameter          $TPG_PATTERN_FORE INTEGER 3
    set_parameter_property $TPG_PATTERN_FORE DISPLAY_NAME "foreground test pattern"
    set_parameter_property $TPG_PATTERN_FORE ALLOWED_RANGES ${::cgx_tpg::tpg_pattern_fore_range}
    set_parameter_property $TPG_PATTERN_FORE HDL_PARAMETER true      

                 
#   add_parameter          ${param_name}_OUT_PIXEL_FORMAT string "RGB_888"
#   set_parameter_property ${param_name}_OUT_PIXEL_FORMAT DISPLAY_NAME "Output pixel format"     
#   set_parameter_property ${param_name}_OUT_PIXEL_FORMAT ALLOWED_RANGES ${::imt_surface::video_colorformat_range}
#   set_parameter_property ${param_name}_OUT_PIXEL_FORMAT DESCRIPTION " stream pixel format";
#   set_parameter_property ${param_name}_OUT_PIXEL_FORMAT AFFECTS_ELABORATION true 
#   set_parameter_property ${param_name}_OUT_PIXEL_FORMAT HDL_PARAMETER true
#   
#   add_parameter          ${param_name}_OUT_PIXEL_NUM INTEGER 1
#   set_parameter_property ${param_name}_OUT_PIXEL_NUM DISPLAY_NAME "Output pixels in parallel";
#   set_parameter_property ${param_name}_OUT_PIXEL_NUM ALLOWED_RANGES {1,2,4,8}
#   set_parameter_property ${param_name}_OUT_PIXEL_NUM DISPLAY_UNITS "Pixels"
#   set_parameter_property ${param_name}_OUT_PIXEL_NUM AFFECTS_ELABORATION true   
#   set_parameter_property ${param_name}_OUT_PIXEL_NUM HDL_PARAMETER true
#   
#   add_parameter          ${param_name}_OUT_COLOR_SIZE INTEGER 8
#   set_parameter_property ${param_name}_OUT_COLOR_SIZE DISPLAY_NAME "Bits per pixel per color plane";
#   set_parameter_property ${param_name}_OUT_COLOR_SIZE DISPLAY_UNITS "Bits"
#   set_parameter_property ${param_name}_OUT_COLOR_SIZE DERIVED true 
#   set_parameter_property ${param_name}_OUT_COLOR_SIZE HDL_PARAMETER true
#     
#   add_parameter          ${param_name}_OUT_COLOR_NUM INTEGER 3
#   set_parameter_property ${param_name}_OUT_COLOR_NUM DISPLAY_NAME "Number of color planes in parallel";
#   set_parameter_property ${param_name}_OUT_COLOR_NUM DISPLAY_UNITS "Planes"
#   set_parameter_property ${param_name}_OUT_COLOR_NUM DERIVED true 
#   set_parameter_property ${param_name}_OUT_COLOR_NUM HDL_PARAMETER true
#   
#   add_parameter          ${param_name}_IN_ENABLE_INTERLACED INTEGER 1
#   set_parameter_property ${param_name}_IN_ENABLE_INTERLACED DISPLAY_NAME "support for interlaced stream" 
#   set_parameter_property ${param_name}_IN_ENABLE_INTERLACED DISPLAY_HINT boolean 
#   set_parameter_property ${param_name}_IN_ENABLE_INTERLACED DESCRIPTION " turned ON to support interlaced stream ";
#   set_parameter_property ${param_name}_IN_ENABLE_INTERLACED AFFECTS_ELABORATION false        
#   set_parameter_property ${param_name}_IN_ENABLE_INTERLACED VISIBLE true      
#   set_parameter_property ${param_name}_IN_ENABLE_INTERLACED HDL_PARAMETER true
#   
#   add_parameter          ${param_name}_PIXEL_FIFO_DEPTH INTEGER 256
#   set_parameter_property ${param_name}_PIXEL_FIFO_DEPTH DISPLAY_NAME "pixel fifo depth" 
#   set_parameter_property ${param_name}_PIXEL_FIFO_DEPTH ALLOWED_RANGES {"128" "256" "512" "1024" "2048" "4096" "8192"}
#   set_parameter_property ${param_name}_PIXEL_FIFO_DEPTH DESCRIPTION " ";
#   set_parameter_property ${param_name}_PIXEL_FIFO_DEPTH AFFECTS_ELABORATION false        
#   set_parameter_property ${param_name}_PIXEL_FIFO_DEPTH VISIBLE true      
#   set_parameter_property ${param_name}_PIXEL_FIFO_DEPTH HDL_PARAMETER true
    
    
#   # invisible, derived
#   add_parameter          ${param_name}_IN_DATA_SIZE INTEGER
#   set_parameter_property ${param_name}_IN_DATA_SIZE DISPLAY_NAME "Input data width";
#   set_parameter_property ${param_name}_IN_DATA_SIZE DERIVED true 
#   set_parameter_property ${param_name}_IN_DATA_SIZE VISIBLE false      
#   set_parameter_property ${param_name}_IN_DATA_SIZE HDL_PARAMETER true
    
    
  # add_display_item $parent_gui_name $VERSION_MAJOR            PARAMETER                 
  # add_display_item $parent_gui_name $VERSION_MINOR            PARAMETER            
    add_display_item $parent_gui_name $ENABLE_CSR               PARAMETER
    add_display_item $parent_gui_name $CLOCKED                  PARAMETER         
    add_display_item $parent_gui_name $frame_color_format       PARAMETER
    add_display_item $parent_gui_name $FRAME_PIXEL_FORMAT       PARAMETER                   
    add_display_item $parent_gui_name $FRAME_WIDTH              PARAMETER                   
    add_display_item $parent_gui_name $FRAME_HEIGHT             PARAMETER                   
    add_display_item $parent_gui_name $frame_color_size         PARAMETER                    
    add_display_item $parent_gui_name $frame_color_num          PARAMETER                    
    add_display_item $parent_gui_name $PIXEL_NUM                PARAMETER
    add_display_item $parent_gui_name $cvi_format               PARAMETER
    add_display_item $parent_gui_name $CVI_PIXEL_MODE           PARAMETER
    add_display_item $parent_gui_name $CVI_PIXEL_SIZE           PARAMETER
    add_display_item $parent_gui_name $CVI_HAS_DEDICATED_CLK    PARAMETER                    
    add_display_item $parent_gui_name $CVI_BAYER_ENABLE_LINEAR  PARAMETER                    
    add_display_item $parent_gui_name $ENABLE_TPG               PARAMETER         
    add_display_item $parent_gui_name $ENABLE_BAND              PARAMETER         
    add_display_item $parent_gui_name $ENABLE_CRP               PARAMETER         
    add_display_item $parent_gui_name $ENABLE_SCL               PARAMETER         
    add_display_item $parent_gui_name $ENABLE_ROT               PARAMETER             
    add_display_item $parent_gui_name $TPG_PATTERN_BACK         PARAMETER                    
    add_display_item $parent_gui_name $TPG_PATTERN_FORE         PARAMETER                    
   
  }


  proc video_valid_port {inst_name} {

    set param_name ${inst_name}_PORT

  # set VERSION_MAJOR           ${param_name}_VERSION_MAJOR               
  # set VERSION_MINOR           ${param_name}_VERSION_MINOR              
    set ENABLE_CSR              ${param_name}_ENABLE_CSR               
    set ENABLE_TPG              ${param_name}_ENABLE_TPG                                                 
  # set ENABLE_SCL              ${param_name}_ENABLE_SCL                                                   
    set CLOCKED                 ${param_name}_CLOCKED 
    set PIXEL_NUM               ${param_name}_PIXEL_NUM                      
    set cvi_format              ${param_name}_cvi_format                      
    set CVI_PIXEL_MODE          ${param_name}_CVI_PIXEL_MODE                      
    set frame_color_format      ${param_name}_frame_color_format                  
    set FRAME_PIXEL_FORMAT      ${param_name}_FRAME_PIXEL_FORMAT                   
    set FRAME_WIDTH             ${param_name}_FRAME_WIDTH                    
    set FRAME_HEIGHT            ${param_name}_FRAME_HEIGHT                     
    set frame_color_size        ${param_name}_frame_color_size                    
    set frame_color_num         ${param_name}_frame_color_num                    
    set CVI_HAS_DEDICATED_CLK   ${param_name}_CVI_HAS_DEDICATED_CLK                   
    set CVI_BAYER_ENABLE_LINEAR ${param_name}_CVI_BAYER_ENABLE_LINEAR                 
    set TPG_PATTERN_BACK        ${param_name}_TPG_PATTERN_BACK   
    set TPG_PATTERN_FORE        ${param_name}_TPG_PATTERN_FORE			        


    # image resolution is implicit in BT656 => edition must be disabled  
    if { [get_parameter_value $CLOCKED] == 1 } { 
    
      set_parameter_property $cvi_format            VISIBLE true
      set_parameter_property $CVI_HAS_DEDICATED_CLK VISIBLE true

      # image resolution is implicit in BT656 => edition must be disabled  
      if { [get_parameter_value $cvi_format] == "BAYER" } { 
        set_parameter_property $CVI_BAYER_ENABLE_LINEAR VISIBLE true
      } else {
        set_parameter_property $CVI_BAYER_ENABLE_LINEAR VISIBLE false
      }

      if { [get_parameter_value $cvi_format] != "parallel RGB" && [get_parameter_value $PIXEL_NUM] > 1 } { 
        send_message error "Input pixels in parallel must be set to 1 for BT656 or BAYER pixel mode"
      } 
          
    } else {
    
      set_parameter_property $cvi_format              VISIBLE false
      set_parameter_property $CVI_HAS_DEDICATED_CLK   VISIBLE false
      set_parameter_property $CVI_BAYER_ENABLE_LINEAR VISIBLE false

    }    


    if { [get_parameter_value $ENABLE_CSR] == 0 && [get_parameter_value $ENABLE_TPG] == 1 } { 
      set_parameter_property $TPG_PATTERN_BACK VISIBLE true
      set_parameter_property $TPG_PATTERN_FORE VISIBLE true
    } else {
      set_parameter_property $TPG_PATTERN_BACK VISIBLE false
      set_parameter_property $TPG_PATTERN_FORE VISIBLE false
    }


  }

 

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Channels                                                                                      --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------


#  proc video_add_parameters_sfc { inst_name parent_gui_name gui_id } {
#
#    set param_name ${inst_name}_CHAN
#
#    add_display_item $parent_gui_name "Buffer${gui_id}" GROUP tab
# 
#    surface_data_add_parameters ${param_name} "Buffer${gui_id}"  
#    surface_sync_add_parameters ${param_name} "Buffer${gui_id}"  
#
#  }
 

#  proc video_valid_sfc { inst_name video_idx } {
#
#    set port_name ${inst_name}_PORT
#   
#    set video_frame_color_format  ${port_name}_frame_color_format                  
#    set VIDEO_FRAME_WIDTH         ${port_name}_FRAME_WIDTH                   
#    set VIDEO_FRAME_HEIGHT        ${port_name}_FRAME_HEIGHT                   
#
#    set param_name ${inst_name}_CHAN
# 
#    set sfc_alloc_size8 [ surface_data_validation $param_name "" [get_parameter_value $VIDEO_FRAME_WIDTH]        \
#                                                                 [get_parameter_value $VIDEO_FRAME_HEIGHT]       \
#                                                                 3                                               \
#                                                                 [get_parameter_value $video_frame_color_format] \
#                                                                 0 ]
#
#    surface_pool_add "video" $video_idx $param_name $sfc_alloc_size8 
#
#    set ena_lock    1
#    set ena_rate    0          
#    set rate_repeat 0       
#    set rate_total  1           
#    surface_sync_validation $param_name "" $ena_lock $ena_rate $rate_repeat $rate_total                                 
#
#  }

 
# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Core                                                                                       --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------


# proc video_add_parameters_core { inst_name parent_gui_name } {
#
#   set VERSION_MAJOR  ${inst_name}_VERSION_MAJOR
#   set VERSION_MINOR  ${inst_name}_VERSION_MINOR
#
#   add_parameter          $VERSION_MAJOR INTEGER 0
#   set_parameter_property $VERSION_MAJOR DISPLAY_NAME "major";
#   set_parameter_property $VERSION_MAJOR DISPLAY_HINT INTEGER
#   set_parameter_property $VERSION_MAJOR DESCRIPTION " "
#   set_parameter_property $VERSION_MAJOR VISIBLE true 
#   set_parameter_property $VERSION_MAJOR DERIVED true 
#   set_parameter_property $VERSION_MAJOR HDL_PARAMETER true
#
#   add_parameter          $VERSION_MINOR INTEGER 0
#   set_parameter_property $VERSION_MINOR DISPLAY_NAME "minor";
#   set_parameter_property $VERSION_MINOR DISPLAY_HINT INTEGER
#   set_parameter_property $VERSION_MINOR DESCRIPTION " "
#   set_parameter_property $VERSION_MINOR VISIBLE true 
#   set_parameter_property $VERSION_MINOR DERIVED true 
#   set_parameter_property $VERSION_MINOR HDL_PARAMETER true
#
#   add_display_item $parent_gui_name $VERSION_MAJOR  PARAMETER
#   add_display_item $parent_gui_name $VERSION_MINOR  PARAMETER
#
# }
  
  
#  proc video_elaborate_core { inst_name v_major v_minor } {
#
#    set VERSION_MAJOR  ${inst_name}_VERSION_MAJOR
#    set VERSION_MINOR  ${inst_name}_VERSION_MINOR
#   
#    set_parameter_value $VERSION_MAJOR  $v_major 
#    set_parameter_value $VERSION_MINOR  $v_minor 
# 
#  }
 
  
# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- General                                                                                    --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#  proc video_add_parameters { inst_name gui_group_name gui_id } {
#
#    set param_name ${inst_name}_VID
#    
#    set CFG_ENABLE_RUNTIME  ${param_name}_CFG_ENABLE_RUNTIME
#               
#    add_parameter          $CFG_ENABLE_RUNTIME INTEGER 1
#    set_parameter_property $CFG_ENABLE_RUNTIME DISPLAY_NAME "Run-time configuration" 
#    set_parameter_property $CFG_ENABLE_RUNTIME DISPLAY_HINT boolean 
#    set_parameter_property $CFG_ENABLE_RUNTIME DESCRIPTION " Turn ON to support run-time configuration";
#    set_parameter_property $CFG_ENABLE_RUNTIME AFFECTS_ELABORATION true        
#    set_parameter_property $CFG_ENABLE_RUNTIME VISIBLE true      
#    set_parameter_property $CFG_ENABLE_RUNTIME HDL_PARAMETER true
#
#
#    add_display_item $gui_group_name $CFG_ENABLE_RUNTIME   PARAMETER
#
#    set vid_group_name "Input"
#  # set vid_group_name ${vid_group_name}${inst_id}
#    
#    set wtr_group_name "Writer"
#  # set wtr_group_name ${wtr_group_name}${inst_id}
#
#    add_display_item $gui_group_name $vid_group_name GROUP
#    add_display_item $gui_group_name $wtr_group_name GROUP
#
##   video_add_parameters_video   $param_name $vid_group_name
##   video_add_parameters_rw    1 $param_name $wtr_group_name
#
#  }

  proc vsc_add_parameters { is_core gui_group_name } {

    if { $is_core == 0 } {
      set vsc_name [ vsc_get_name -1 ]
    } else { 
      set vsc_name WZD
    }
    
    set IS_WRITER                   ${vsc_name}_IS_WRITER
    set IS_READER                   ${vsc_name}_IS_READER
    set ENABLE_CSR                  ${vsc_name}_ENABLE_CSR
    set CFG_ENABLE_RUNTIME          ${vsc_name}_CFG_ENABLE_RUNTIME
  # set CSR_ENABLE_READBACK_REDUCED ${vsc_name}_CSR_ENABLE_READBACK_REDUCED
    set ENABLE_DEBUG                ${vsc_name}_ENABLE_DEBUG
    set FRAME_PRIMARY_IDX           ${vsc_name}_FRAME_PRIMARY_IDX
               
    add_parameter          $IS_WRITER INTEGER 0
    set_parameter_property $IS_WRITER DISPLAY_NAME "Use writer";
  # set_parameter_property $IS_WRITER ALLOWED_RANGES {"0:Surface Reader (surface-to-video)" "1:Surface Writer (video-to-surface)"}
    set_parameter_property $IS_WRITER DISPLAY_HINT boolean
    set_parameter_property $IS_WRITER DESCRIPTION " ";
    set_parameter_property $IS_WRITER AFFECTS_ELABORATION true        
    set_parameter_property $IS_WRITER HDL_PARAMETER true
    if { $is_core == 0 } {
    set_parameter_property $IS_WRITER DERIVED true
    set_parameter_property $IS_WRITER VISIBLE false      
    }

    add_parameter          $IS_READER INTEGER 0
    set_parameter_property $IS_READER DISPLAY_NAME "Use reader";
  # set_parameter_property $IS_READER ALLOWED_RANGES {"0:Surface Reader (surface-to-video)" "1:Surface Writer (video-to-surface)"}
    set_parameter_property $IS_READER DISPLAY_HINT boolean
    set_parameter_property $IS_READER DESCRIPTION " ";
    set_parameter_property $IS_READER AFFECTS_ELABORATION true        
    set_parameter_property $IS_READER HDL_PARAMETER true
    if { $is_core == 0 } {
    set_parameter_property $IS_READER DERIVED true
    set_parameter_property $IS_READER VISIBLE false      
    }
	  
    add_parameter          $ENABLE_CSR INTEGER 1
    set_parameter_property $ENABLE_CSR DISPLAY_NAME "Run-time control" 
    set_parameter_property $ENABLE_CSR DISPLAY_HINT boolean 
    set_parameter_property $ENABLE_CSR DESCRIPTION " Turn ON to get run-time control over the Control-Status Register interface";
    set_parameter_property $ENABLE_CSR AFFECTS_ELABORATION true        
    set_parameter_property $ENABLE_CSR VISIBLE true      
    set_parameter_property $ENABLE_CSR HDL_PARAMETER true

    add_parameter          $CFG_ENABLE_RUNTIME INTEGER 1
    set_parameter_property $CFG_ENABLE_RUNTIME DISPLAY_NAME "Run-time configuration" 
    set_parameter_property $CFG_ENABLE_RUNTIME DISPLAY_HINT boolean 
    set_parameter_property $CFG_ENABLE_RUNTIME DESCRIPTION " Turn ON to support run-time configuration";
    set_parameter_property $CFG_ENABLE_RUNTIME AFFECTS_ELABORATION true        
    set_parameter_property $CFG_ENABLE_RUNTIME VISIBLE true      
    set_parameter_property $CFG_ENABLE_RUNTIME HDL_PARAMETER true

  # add_parameter          $CSR_ENABLE_READBACK_REDUCED INTEGER 0
  # set_parameter_property $CSR_ENABLE_READBACK_REDUCED DISPLAY_NAME "Reduced CSR readback" 
  # set_parameter_property $CSR_ENABLE_READBACK_REDUCED DISPLAY_HINT boolean 
  # set_parameter_property $CSR_ENABLE_READBACK_REDUCED DESCRIPTION "Turn on to disable Control-Status Registers Readback and save ressources";
  # set_parameter_property $CSR_ENABLE_READBACK_REDUCED AFFECTS_ELABORATION true        
  # set_parameter_property $CSR_ENABLE_READBACK_REDUCED VISIBLE false      
  # set_parameter_property $CSR_ENABLE_READBACK_REDUCED HDL_PARAMETER true
           
    add_parameter          $ENABLE_DEBUG INTEGER 1
    set_parameter_property $ENABLE_DEBUG DISPLAY_NAME "Debug";
    set_parameter_property $ENABLE_DEBUG DISPLAY_HINT boolean
    set_parameter_property $ENABLE_DEBUG DESCRIPTION "Turn on to enable support for debug"
    set_parameter_property $ENABLE_DEBUG VISIBLE true      
    set_parameter_property $ENABLE_DEBUG HDL_PARAMETER true

    add_parameter          $FRAME_PRIMARY_IDX INTEGER 0
    set_parameter_property $FRAME_PRIMARY_IDX DISPLAY_NAME "Primary Surface index";
    set_parameter_property $FRAME_PRIMARY_IDX DISPLAY_HINT INTEGER
    set_parameter_property $FRAME_PRIMARY_IDX DESCRIPTION "Target primary Surface within the Primary context (local or import) "
    set_parameter_property $FRAME_PRIMARY_IDX ALLOWED_RANGES {0:255} 
    set_parameter_property $FRAME_PRIMARY_IDX AFFECTS_ELABORATION true        
    set_parameter_property $FRAME_PRIMARY_IDX HDL_PARAMETER true


    add_display_item $gui_group_name $IS_WRITER                   PARAMETER
    add_display_item $gui_group_name $IS_READER                   PARAMETER
    add_display_item $gui_group_name $ENABLE_CSR                  PARAMETER
    add_display_item $gui_group_name $CFG_ENABLE_RUNTIME          PARAMETER
  # add_display_item $gui_group_name $CSR_ENABLE_READBACK_REDUCED PARAMETER
    add_display_item $gui_group_name $ENABLE_DEBUG                PARAMETER
    add_display_item $gui_group_name $FRAME_PRIMARY_IDX           PARAMETER

  # add_display_item "General${inst_id}" $ENABLE_DEBUG        PARAMETER

    set vid_group_name Video
  # set vid_group_name ${vid_group_name}${inst_id}
    
    set wtr_group_name Writer
  # set wtr_group_name ${wtr_group_name}${inst_id}

    set rdr_group_name Reader
  # set rdr_group_name ${rdr_group_name}${inst_id}

    add_display_item $gui_group_name $vid_group_name GROUP
    add_display_item $gui_group_name $wtr_group_name GROUP
    add_display_item $gui_group_name $rdr_group_name GROUP

    vsc_add_parameters_video  $is_core   $vsc_name $vid_group_name
    vsc_add_parameters_rw     $is_core 1 $vsc_name $wtr_group_name
    vsc_add_parameters_rw     $is_core 0 $vsc_name $rdr_group_name

  }
  
 
 
  proc vsc_valid { is_core } {

    if { $is_core == 0 } {
      set inst_name [ vsc_get_name -1 ]
    } else { 
      set inst_name WZD
    }

    set IS_WRITER          [ get_parameter_value ${inst_name}_IS_WRITER ]
    set IS_READER          [ get_parameter_value ${inst_name}_IS_READER ]
    set ENABLE_CSR         [ get_parameter_value ${inst_name}_ENABLE_CSR ]  
    set CFG_ENABLE_RUNTIME [ get_parameter_value ${inst_name}_CFG_ENABLE_RUNTIME ]
 
    # restrict to top to avoid twice the message (1 for top, 1 for core)
    if { $is_core == 0 && $ENABLE_CSR == 0 && $CFG_ENABLE_RUNTIME == 1 } {
      send_message error "You have to turn On Run-time control in order to enable Run-time configuration"
    }
 
    if { $IS_READER == 1} {
    	set_display_item_property "Reader" VISIBLE true
    } else {
    	set_display_item_property "Reader" VISIBLE false
    }

    if { $IS_WRITER == 1} {
    	set_display_item_property "Writer" VISIBLE true
    } else {
    	set_display_item_property "Writer" VISIBLE false
    }

    if { $CFG_ENABLE_RUNTIME == 0 } {
    	set_parameter_property ${inst_name}_FRAME_PRIMARY_IDX VISIBLE true
    } else {
    	set_parameter_property ${inst_name}_FRAME_PRIMARY_IDX VISIBLE false
    }

    vsc_valid_rw $inst_name 0
    vsc_valid_rw $inst_name 1

  }
  
   

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- R/W Cores                                                                                  --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#  proc video_add_parameters_rw { is_writer inst_name gui_group_name } {
#
#  }
 
 
  proc vsc_add_parameters_rw { is_core is_writer inst_name gui_group_name } {

    if { $is_writer == 0 } {
      set inst_name ${inst_name}_RDR
    } else { 
      set inst_name ${inst_name}_WTR
    }

    set MAX_WIDTH      ${inst_name}_MAX_WIDTH 
    set MAX_HEIGHT     ${inst_name}_MAX_HEIGHT
    set OP             ${inst_name}_OP 
    set ROTATE_90      ${inst_name}_ROTATE_90    
    set ROTATE_FLIP_H  ${inst_name}_ROTATE_FLIP_H
    set ROTATE_FLIP_V  ${inst_name}_ROTATE_FLIP_V
    set TRANSLATE_X    ${inst_name}_TRANSLATE_X
    set TRANSLATE_Y    ${inst_name}_TRANSLATE_Y

    add_parameter          $MAX_WIDTH INTEGER 800
    if { $is_writer == 0 } {
      set_parameter_property $MAX_WIDTH DISPLAY_NAME "max output width" 
    } else { 
      set_parameter_property $MAX_WIDTH DISPLAY_NAME "max input width" 
    }
    set_parameter_property $MAX_WIDTH ALLOWED_RANGES {0:16384}
    set_parameter_property $MAX_WIDTH DISPLAY_UNITS "Pixels"
    set_parameter_property $MAX_WIDTH DESCRIPTION "Maximum width in number of pixels";
    set_parameter_property $MAX_WIDTH AFFECTS_ELABORATION true        
    set_parameter_property $MAX_WIDTH ENABLED true
    set_parameter_property $MAX_WIDTH VISIBLE true
    set_parameter_property $MAX_WIDTH HDL_PARAMETER true
    
    add_parameter          $MAX_HEIGHT INTEGER 600
    if { $is_writer == 0 } {
      set_parameter_property $MAX_HEIGHT DISPLAY_NAME "max output height" 
    } else { 
      set_parameter_property $MAX_HEIGHT DISPLAY_NAME "max input height" 
    }
    set_parameter_property $MAX_HEIGHT ALLOWED_RANGES {0:16384}
    set_parameter_property $MAX_HEIGHT DISPLAY_UNITS "Lines"
    set_parameter_property $MAX_HEIGHT DESCRIPTION "Maximum height in number of lines";
    set_parameter_property $MAX_HEIGHT AFFECTS_ELABORATION true        
    set_parameter_property $MAX_HEIGHT ENABLED true
    set_parameter_property $MAX_HEIGHT VISIBLE true
    set_parameter_property $MAX_HEIGHT HDL_PARAMETER true

    add_parameter          $OP INTEGER 0
    set_parameter_property $OP DISPLAY_NAME "Transform";
   #set_parameter_property $OP ALLOWED_RANGES {"0:None" "1:Translation" "3:2D-Affine (2x3 matrix)" "4:2.5D-Perspective (3x3 matrix)" "5:Warping (remap LUT)"}
    set_parameter_property $OP ALLOWED_RANGES {"0:None" "1:Translation" "2:Rotation(0/90/180/270)"}
    if { $is_writer == 0 } {
    set_parameter_property $OP ALLOWED_RANGES {"0:None" "1:Translation"}
    } else { 
    set_parameter_property $OP ALLOWED_RANGES {"0:None" "1:Translation" "2:Rotation(0/90/180/270)"}
    }

  # set_parameter_property $OP DISPLAY_HINT radio
    set_parameter_property $OP DESCRIPTION " ";
    set_parameter_property $OP AFFECTS_ELABORATION true        
    set_parameter_property $OP HDL_PARAMETER true
    set_parameter_property $OP VISIBLE true      
 
    add_parameter          $ROTATE_FLIP_H INTEGER 0
    set_parameter_property $ROTATE_FLIP_H DISPLAY_NAME "Horizontal flip";
    set_parameter_property $ROTATE_FLIP_H DISPLAY_HINT boolean
    set_parameter_property $ROTATE_FLIP_H DESCRIPTION "Turn on to support horizontal flip";
    set_parameter_property $ROTATE_FLIP_H AFFECTS_ELABORATION true        
  # if { $is_writer == 1 } {    
    set_parameter_property $ROTATE_FLIP_H HDL_PARAMETER true
  # }

    add_parameter          $ROTATE_FLIP_V INTEGER 0
    set_parameter_property $ROTATE_FLIP_V DISPLAY_NAME "Vertical flip";
    set_parameter_property $ROTATE_FLIP_V DISPLAY_HINT boolean
    set_parameter_property $ROTATE_FLIP_V DESCRIPTION "Turn on to support vertical flip";
    set_parameter_property $ROTATE_FLIP_V AFFECTS_ELABORATION true        
  # if { $is_writer == 1 } {    
    set_parameter_property $ROTATE_FLIP_V HDL_PARAMETER true
  # }
	 
    add_parameter          $ROTATE_90 INTEGER 0
    set_parameter_property $ROTATE_90 DISPLAY_NAME "90� Rotation";
    set_parameter_property $ROTATE_90 DISPLAY_HINT boolean
    set_parameter_property $ROTATE_90 DESCRIPTION "Turn on to support 90� rotation.";
    set_parameter_property $ROTATE_90 AFFECTS_ELABORATION true        
  # if { $is_writer == 1 } {    
    set_parameter_property $ROTATE_90 HDL_PARAMETER true
  # }

    add_parameter          $TRANSLATE_X INTEGER 0
    set_parameter_property $TRANSLATE_X DISPLAY_NAME "Tx";
    set_parameter_property $TRANSLATE_X DISPLAY_HINT INTEGER
    set_parameter_property $TRANSLATE_X DESCRIPTION "Horizontal offset within the Surface";
    set_parameter_property $TRANSLATE_X ALLOWED_RANGES {0:16383} 
    set_parameter_property $TRANSLATE_X AFFECTS_ELABORATION true        
    set_parameter_property $TRANSLATE_X HDL_PARAMETER true

    add_parameter          $TRANSLATE_Y INTEGER 0
    set_parameter_property $TRANSLATE_Y DISPLAY_NAME "Ty";
    set_parameter_property $TRANSLATE_Y DISPLAY_HINT INTEGER
    set_parameter_property $TRANSLATE_Y DESCRIPTION "Vertical offset within the Surface";
    set_parameter_property $TRANSLATE_Y ALLOWED_RANGES {0:16383} 
    set_parameter_property $TRANSLATE_Y AFFECTS_ELABORATION true        
    set_parameter_property $TRANSLATE_Y HDL_PARAMETER true


    add_display_item $gui_group_name $MAX_WIDTH      PARAMETER
    add_display_item $gui_group_name $MAX_HEIGHT     PARAMETER
    add_display_item $gui_group_name $OP             PARAMETER
    add_display_item $gui_group_name $ROTATE_90      PARAMETER
    add_display_item $gui_group_name $ROTATE_FLIP_H  PARAMETER
    add_display_item $gui_group_name $ROTATE_FLIP_V  PARAMETER
    add_display_item $gui_group_name $TRANSLATE_X    PARAMETER
    add_display_item $gui_group_name $TRANSLATE_Y    PARAMETER
    
  }


  proc vsc_valid_rw { inst_name is_writer } {

    set ENABLE_CSR         ${inst_name}_ENABLE_CSR
    set CFG_ENABLE_RUNTIME ${inst_name}_CFG_ENABLE_RUNTIME


    if { $is_writer == 0 } {
      set inst_name ${inst_name}_RDR
    } else { 
      set inst_name ${inst_name}_WTR
    }
    
    set OP             ${inst_name}_OP 
    set TRANSLATE_X    ${inst_name}_TRANSLATE_X
    set TRANSLATE_Y    ${inst_name}_TRANSLATE_Y
    set ROTATE_90      ${inst_name}_ROTATE_90    
    set ROTATE_FLIP_H  ${inst_name}_ROTATE_FLIP_H
    set ROTATE_FLIP_V  ${inst_name}_ROTATE_FLIP_V
 

    if { [get_parameter_value $CFG_ENABLE_RUNTIME] == 1 } {
      set_parameter_property $ROTATE_90     VISIBLE false
      set_parameter_property $ROTATE_FLIP_H VISIBLE false
      set_parameter_property $ROTATE_FLIP_V VISIBLE false
      set_parameter_property $TRANSLATE_X   VISIBLE false
      set_parameter_property $TRANSLATE_Y   VISIBLE false
    } else { 

      if { [get_parameter_value $OP] == 1 } {
        set_parameter_property $TRANSLATE_X VISIBLE true
        set_parameter_property $TRANSLATE_Y VISIBLE true
      } else { 
        set_parameter_property $TRANSLATE_X VISIBLE false  
        set_parameter_property $TRANSLATE_Y VISIBLE false  
      }
      
      if { [get_parameter_value $OP] == 2 } {
        set_parameter_property $ROTATE_90     VISIBLE true
        set_parameter_property $ROTATE_FLIP_H VISIBLE true
        set_parameter_property $ROTATE_FLIP_V VISIBLE true
      } else { 
        set_parameter_property $ROTATE_90     VISIBLE false  
        set_parameter_property $ROTATE_FLIP_H VISIBLE false  
        set_parameter_property $ROTATE_FLIP_V VISIBLE false  
      }

    }
 
  }


  proc vsc_connect_rw { vsc_name is_writer } {

    if { $is_writer == 0 } {
      set rw_name RDR
    } else { 
      set rw_name WTR
    }

    set_instance_parameter ${vsc_name} WZD_${rw_name}_MAX_WIDTH      [ get_parameter_value ${vsc_name}_${rw_name}_MAX_WIDTH      ]  
    set_instance_parameter ${vsc_name} WZD_${rw_name}_MAX_HEIGHT     [ get_parameter_value ${vsc_name}_${rw_name}_MAX_HEIGHT     ]  
    set_instance_parameter ${vsc_name} WZD_${rw_name}_OP             [ get_parameter_value ${vsc_name}_${rw_name}_OP             ]  
    set_instance_parameter ${vsc_name} WZD_${rw_name}_TRANSLATE_X    [ get_parameter_value ${vsc_name}_${rw_name}_TRANSLATE_X    ]  
    set_instance_parameter ${vsc_name} WZD_${rw_name}_TRANSLATE_Y    [ get_parameter_value ${vsc_name}_${rw_name}_TRANSLATE_Y    ]    
    set_instance_parameter ${vsc_name} WZD_${rw_name}_ROTATE_90      [ get_parameter_value ${vsc_name}_${rw_name}_ROTATE_90      ]  
    set_instance_parameter ${vsc_name} WZD_${rw_name}_ROTATE_FLIP_H  [ get_parameter_value ${vsc_name}_${rw_name}_ROTATE_FLIP_H  ]  
    set_instance_parameter ${vsc_name} WZD_${rw_name}_ROTATE_FLIP_V  [ get_parameter_value ${vsc_name}_${rw_name}_ROTATE_FLIP_V  ]  

  }


  proc vsc_connect_parameters { vsc_name } {

  # if { $is_writer == 0 } {
  #   set inst_name vsc_reader
  # } else { 
  #   set inst_name vsc_writer
  # }
  # 
  # set inst_name ${inst_name}${inst_id}
    
  # set_instance_parameter ${vsc_name} WZD_CLOCK_RATE                  [ get_parameter_value ${vsc_name}_CLOCK_RATE                  ]                                                                                     
    set_instance_parameter ${vsc_name} WZD_IS_WRITER                   [ get_parameter_value ${vsc_name}_IS_WRITER                   ]  
    set_instance_parameter ${vsc_name} WZD_IS_READER                   [ get_parameter_value ${vsc_name}_IS_READER                   ]  
    set_instance_parameter ${vsc_name} WZD_ENABLE_CSR                  [ get_parameter_value ${vsc_name}_ENABLE_CSR                  ]  
    set_instance_parameter ${vsc_name} WZD_CFG_ENABLE_RUNTIME          [ get_parameter_value ${vsc_name}_CFG_ENABLE_RUNTIME          ]    
  # set_instance_parameter ${vsc_name} WZD_CSR_ENABLE_READBACK_REDUCED [ get_parameter_value ${vsc_name}_CSR_ENABLE_READBACK_REDUCED ]  
    set_instance_parameter ${vsc_name} WZD_ENABLE_DEBUG                [ get_parameter_value ${vsc_name}_ENABLE_DEBUG                ]  
    set_instance_parameter ${vsc_name} WZD_FRAME_PRIMARY_IDX           [ get_parameter_value ${vsc_name}_FRAME_PRIMARY_IDX           ]  
 
 
    vsc_connect_video  $vsc_name             
    vsc_connect_rw     $vsc_name 0             
    vsc_connect_rw     $vsc_name 1             

  }

 
# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Video                                                                                      --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------
  
# proc video_add_parameters_video { param_name gui_group_name } {
#
#
# }


  
  proc vsc_add_parameters_video { is_core param_name gui_group_name } {

  # if {$is_core == 1} { 
  #   set param_name "WZD"
  # } else { 
  #   set param_name "WZD"
  # }

    set VID_PIXEL_FORMAT       ${param_name}_VID_PIXEL_FORMAT  
    set VID_RAW_SIZE           ${param_name}_VID_RAW_SIZE   
    set VID_RAW_NUM            ${param_name}_VID_RAW_NUM
    set VID_COLOR_SIZE         ${param_name}_VID_COLOR_SIZE    
    set VID_COLOR_NUM          ${param_name}_VID_COLOR_NUM 
  # set VID_COLOR_ENABLE       ${param_name}_VID_COLOR_ENABLE
    set VID_PIXEL_NUM          ${param_name}_VID_PIXEL_NUM     
  # set VID_MAX_WIDTH          ${param_name}_VID_MAX_WIDTH     
  # set VID_MAX_HEIGHT         ${param_name}_VID_MAX_HEIGHT    
  # set VID_ENABLE_INTERLACED  ${param_name}_VID_ENABLE_INTERLACED
    set VID_CHANNEL_ENABLE     ${param_name}_VID_CHANNEL_ENABLE 
    set VID_CHANNEL_NUMBER     ${param_name}_VID_CHANNEL_NUMBER 

    add_parameter          $VID_PIXEL_FORMAT string "RGB_888"
    set_parameter_property $VID_PIXEL_FORMAT DISPLAY_NAME "Pixel Format"     
    set_parameter_property $VID_PIXEL_FORMAT ALLOWED_RANGES ${::imt_surface::video_colorformat_range}
    set_parameter_property $VID_PIXEL_FORMAT DESCRIPTION "Video stream pixel format";
    set_parameter_property $VID_PIXEL_FORMAT AFFECTS_ELABORATION true 
    set_parameter_property $VID_PIXEL_FORMAT HDL_PARAMETER true

    add_parameter          $VID_RAW_SIZE INTEGER 8
    set_parameter_property $VID_RAW_SIZE DISPLAY_NAME "Bits per pixel per symbol";
    set_parameter_property $VID_RAW_SIZE DISPLAY_UNITS "Bits"
      
    add_parameter          $VID_RAW_NUM INTEGER 3
    set_parameter_property $VID_RAW_NUM DISPLAY_NAME "Number of symbols in parallel";
    set_parameter_property $VID_RAW_NUM DISPLAY_UNITS "Planes"
    
    add_parameter          $VID_COLOR_SIZE INTEGER 8
    set_parameter_property $VID_COLOR_SIZE DISPLAY_NAME "Bits per pixel per color plane";
    set_parameter_property $VID_COLOR_SIZE DISPLAY_UNITS "Bits"
    if {$is_core == 0} { 
    set_parameter_property $VID_COLOR_SIZE DERIVED true 
    }
    set_parameter_property $VID_COLOR_SIZE HDL_PARAMETER true
      
    add_parameter          $VID_COLOR_NUM INTEGER 3
    set_parameter_property $VID_COLOR_NUM DISPLAY_NAME "Number of color planes in parallel";
    set_parameter_property $VID_COLOR_NUM DISPLAY_UNITS "Planes"
    if {$is_core == 0} { 
    set_parameter_property $VID_COLOR_NUM DERIVED true 
    }
    set_parameter_property $VID_COLOR_NUM HDL_PARAMETER true

#    add_parameter          $VID_COLOR_ENABLE INTEGER 0 
#    set_parameter_property $VID_COLOR_ENABLE DISPLAY_NAME "support for color conversion"
#    set_parameter_property $VID_COLOR_ENABLE DISPLAY_HINT boolean
#  # if {$is_core == 0} { 
#  # set_parameter_property $VID_COLOR_ENABLE DERIVED true 
#  # }
#    set_parameter_property $VID_COLOR_ENABLE VISIBLE false
#  # set_parameter_property $VID_COLOR_ENABLE HDL_PARAMETER true
#    set_parameter_property $VID_COLOR_ENABLE AFFECTS_ELABORATION true
    
    add_parameter          $VID_PIXEL_NUM INTEGER 1
    set_parameter_property $VID_PIXEL_NUM DISPLAY_NAME "Number of pixels in parallel";
    set_parameter_property $VID_PIXEL_NUM ALLOWED_RANGES {1,2,4,8,16,32}
    set_parameter_property $VID_PIXEL_NUM DISPLAY_UNITS "Pixels"
    set_parameter_property $VID_PIXEL_NUM AFFECTS_ELABORATION true   
    set_parameter_property $VID_PIXEL_NUM HDL_PARAMETER true
    
  # add_parameter          $VID_MAX_WIDTH INTEGER 800
  # set_parameter_property $VID_MAX_WIDTH DISPLAY_NAME "Input max width" 
  # set_parameter_property $VID_MAX_WIDTH ALLOWED_RANGES {0:16384}
  # set_parameter_property $VID_MAX_WIDTH DISPLAY_UNITS "Pixels"
  # set_parameter_property $VID_MAX_WIDTH DESCRIPTION "Maximum width in number of pixels";
  # set_parameter_property $VID_MAX_WIDTH AFFECTS_ELABORATION true        
  # set_parameter_property $VID_MAX_WIDTH ENABLED true
  # set_parameter_property $VID_MAX_WIDTH VISIBLE true
  # set_parameter_property $VID_MAX_WIDTH HDL_PARAMETER true
  # 
  # add_parameter          $VID_MAX_HEIGHT INTEGER 600
  # set_parameter_property $VID_MAX_HEIGHT DISPLAY_NAME "Input max height" 
  # set_parameter_property $VID_MAX_HEIGHT ALLOWED_RANGES {0:16384}
  # set_parameter_property $VID_MAX_HEIGHT DISPLAY_UNITS "Lines"
  # set_parameter_property $VID_MAX_HEIGHT DESCRIPTION "Maximum height in number of lines";
  # set_parameter_property $VID_MAX_HEIGHT AFFECTS_ELABORATION true        
  # set_parameter_property $VID_MAX_HEIGHT ENABLED true
  # set_parameter_property $VID_MAX_HEIGHT VISIBLE true
  # set_parameter_property $VID_MAX_HEIGHT HDL_PARAMETER true
    
  # add_parameter          $VID_ENABLE_INTERLACED INTEGER 0
  # set_parameter_property $VID_ENABLE_INTERLACED DISPLAY_NAME "support for interlaced stream" 
  # set_parameter_property $VID_ENABLE_INTERLACED DISPLAY_HINT boolean 
  # set_parameter_property $VID_ENABLE_INTERLACED DESCRIPTION " Turn ON to support interlaced stream ";
  # set_parameter_property $VID_ENABLE_INTERLACED AFFECTS_ELABORATION true        
  # set_parameter_property $VID_ENABLE_INTERLACED VISIBLE false      
  # set_parameter_property $VID_ENABLE_INTERLACED HDL_PARAMETER true

    add_parameter          $VID_CHANNEL_ENABLE INTEGER 0 
    set_parameter_property $VID_CHANNEL_ENABLE DISPLAY_NAME "support for multi-channels"
    set_parameter_property $VID_CHANNEL_ENABLE DISPLAY_HINT boolean
    set_parameter_property $VID_CHANNEL_ENABLE DERIVED false
    set_parameter_property $VID_CHANNEL_ENABLE VISIBLE false
    set_parameter_property $VID_CHANNEL_ENABLE HDL_PARAMETER true
    set_parameter_property $VID_CHANNEL_ENABLE AFFECTS_ELABORATION true
                          
    add_parameter          $VID_CHANNEL_NUMBER INTEGER 1 
    set_parameter_property $VID_CHANNEL_NUMBER ALLOWED_RANGES {1:256};      
    set_parameter_property $VID_CHANNEL_NUMBER DISPLAY_NAME "Number of channels"
    set_parameter_property $VID_CHANNEL_NUMBER DERIVED false
    set_parameter_property $VID_CHANNEL_NUMBER VISIBLE false
    set_parameter_property $VID_CHANNEL_NUMBER HDL_PARAMETER true
    set_parameter_property $VID_CHANNEL_NUMBER AFFECTS_ELABORATION true
   
         
    add_display_item $gui_group_name $VID_PIXEL_FORMAT       PARAMETER
    add_display_item $gui_group_name $VID_RAW_SIZE           PARAMETER
    add_display_item $gui_group_name $VID_RAW_NUM            PARAMETER
    add_display_item $gui_group_name $VID_COLOR_SIZE         PARAMETER
    add_display_item $gui_group_name $VID_COLOR_NUM          PARAMETER
  # add_display_item $gui_group_name $VID_COLOR_ENABLE       PARAMETER
    add_display_item $gui_group_name $VID_PIXEL_NUM          PARAMETER    
  # add_display_item $gui_group_name $VID_MAX_WIDTH          PARAMETER
  # add_display_item $gui_group_name $VID_MAX_HEIGHT         PARAMETER
  # add_display_item $gui_group_name $VID_ENABLE_INTERLACED  PARAMETER
    add_display_item $gui_group_name $VID_CHANNEL_ENABLE     PARAMETER
    add_display_item $gui_group_name $VID_CHANNEL_NUMBER     PARAMETER

  }



  proc vsc_connect_video { vsc_name } {

  # set param_name "WZD"
    set param_name $vsc_name

  # set_instance_parameter ${vsc_name} WZD_VID_MAX_WIDTH      [ get_parameter_value  ${param_name}_VID_MAX_WIDTH  ] 
  # set_instance_parameter ${vsc_name} WZD_VID_MAX_HEIGHT     [ get_parameter_value  ${param_name}_VID_MAX_HEIGHT ] 
  # set_instance_parameter ${vsc_name} WZD_VID_COLOR_ENABLE   [ get_parameter_value  ${param_name}_VID_COLOR_ENABLE] 
    set_instance_parameter ${vsc_name} WZD_VID_COLOR_NUM      [ get_parameter_value  ${param_name}_VID_COLOR_NUM  ]     
    set_instance_parameter ${vsc_name} WZD_VID_COLOR_SIZE     [ get_parameter_value  ${param_name}_VID_COLOR_SIZE ] 
    set_instance_parameter ${vsc_name} WZD_VID_PIXEL_FORMAT   [ get_parameter_value  ${param_name}_VID_PIXEL_FORMAT] 
    set_instance_parameter ${vsc_name} WZD_VID_PIXEL_NUM      [ get_parameter_value  ${param_name}_VID_PIXEL_NUM  ] 
    set_instance_parameter ${vsc_name} WZD_VID_CHANNEL_ENABLE [ get_parameter_value  ${param_name}_VID_CHANNEL_ENABLE ] 
    set_instance_parameter ${vsc_name} WZD_VID_CHANNEL_NUMBER [ get_parameter_value  ${param_name}_VID_CHANNEL_NUMBER ] 
 
  }

 

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Capture                                                                                    --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#  proc vsc_add_parameters_capture { inst_id inst_name parent_gui_name } {
#
#  # set ENABLE_FRAME_DROPPING ${inst_name}_ENABLE_CLIPPING
#    set ENABLE_CLIPPING       ${inst_name}_ENABLE_CLIPPING
#    set CLIPPING_X            ${inst_name}_CLIPPING_X     
#    set CLIPPING_Y            ${inst_name}_CLIPPING_Y     
#    set CLIPPING_WIDTH        ${inst_name}_CLIPPING_WIDTH 
#    set CLIPPING_HEIGHT       ${inst_name}_CLIPPING_HEIGHT
#
#  # add_parameter          $ENABLE_FRAME_DROPPING  INTEGER 1
#  # set_parameter_property $ENABLE_FRAME_DROPPING  DISPLAY_NAME "support for controlled frame dropping" 
#  # set_parameter_property $ENABLE_FRAME_DROPPING  DISPLAY_HINT boolean 
#  # set_parameter_property $ENABLE_FRAME_DROPPING  DESCRIPTION " Turn ON to support controlled frame dropping ";
#  # set_parameter_property $ENABLE_FRAME_DROPPING  AFFECTS_ELABORATION false        
#  # set_parameter_property $ENABLE_FRAME_DROPPING  VISIBLE true      
#
#    add_parameter          $ENABLE_CLIPPING INTEGER 1
#    set_parameter_property $ENABLE_CLIPPING DISPLAY_NAME "clipping" 
#    set_parameter_property $ENABLE_CLIPPING DISPLAY_HINT boolean 
#    set_parameter_property $ENABLE_CLIPPING DESCRIPTION " ";
#    set_parameter_property $ENABLE_CLIPPING AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_CLIPPING VISIBLE true      
#    set_parameter_property $ENABLE_CLIPPING HDL_PARAMETER true
#    
#    add_parameter          $CLIPPING_X INTEGER 0
#    set_parameter_property $CLIPPING_X DISPLAY_NAME "x" 
#    set_parameter_property $CLIPPING_X ALLOWED_RANGES {0:16384}
#    set_parameter_property $CLIPPING_X DESCRIPTION "Static window horizontal position" 
#    set_parameter_property $CLIPPING_X AFFECTS_ELABORATION true        
#    set_parameter_property $CLIPPING_X VISIBLE true      
#    set_parameter_property $CLIPPING_X HDL_PARAMETER true
#    
#    add_parameter          $CLIPPING_Y INTEGER 0
#    set_parameter_property $CLIPPING_Y DISPLAY_NAME "y" 
#    set_parameter_property $CLIPPING_Y ALLOWED_RANGES {0:16384}
#    set_parameter_property $CLIPPING_Y DESCRIPTION "Static window vertical position" 
#    set_parameter_property $CLIPPING_Y AFFECTS_ELABORATION true        
#    set_parameter_property $CLIPPING_Y VISIBLE true      
#    set_parameter_property $CLIPPING_Y HDL_PARAMETER true
#                                                  
#    add_parameter          $CLIPPING_WIDTH INTEGER 800
#    set_parameter_property $CLIPPING_WIDTH DISPLAY_NAME "width" 
#    set_parameter_property $CLIPPING_WIDTH ALLOWED_RANGES {0:16384}
#    set_parameter_property $CLIPPING_WIDTH DESCRIPTION "Static window horizontal resolution" 
#    set_parameter_property $CLIPPING_WIDTH AFFECTS_ELABORATION true        
#    set_parameter_property $CLIPPING_WIDTH VISIBLE true      
#    set_parameter_property $CLIPPING_WIDTH HDL_PARAMETER true
#    
#    add_parameter          $CLIPPING_HEIGHT INTEGER 600
#    set_parameter_property $CLIPPING_HEIGHT DISPLAY_NAME "height" 
#    set_parameter_property $CLIPPING_HEIGHT ALLOWED_RANGES {0:16384}
#    set_parameter_property $CLIPPING_HEIGHT DESCRIPTION "Static window vertical resolution" 
#    set_parameter_property $CLIPPING_HEIGHT AFFECTS_ELABORATION true        
#    set_parameter_property $CLIPPING_HEIGHT VISIBLE true      
#    set_parameter_property $CLIPPING_HEIGHT HDL_PARAMETER true
#  
#  # add_display_item "Capture${inst_id}" "enable_frame_dropping"       PARAMETER
#    add_display_item "Capture${inst_id}" $ENABLE_CLIPPING             PARAMETER
#    add_display_item "Capture${inst_id}" $CLIPPING_X                  PARAMETER
#    add_display_item "Capture${inst_id}" $CLIPPING_Y                  PARAMETER
#    add_display_item "Capture${inst_id}" $CLIPPING_WIDTH              PARAMETER
#    add_display_item "Capture${inst_id}" $CLIPPING_HEIGHT             PARAMETER
#
#  }
#
#
#
# 
#  proc vsc_valid_capture { inst_name } {
#
#    set ENABLE_CLIPPING       ${inst_name}_ENABLE_CLIPPING
#    set CLIPPING_X            ${inst_name}_CLIPPING_X     
#    set CLIPPING_Y            ${inst_name}_CLIPPING_Y     
#    set CLIPPING_WIDTH        ${inst_name}_CLIPPING_WIDTH 
#    set CLIPPING_HEIGHT       ${inst_name}_CLIPPING_HEIGHT
#
#    if { [ get_parameter_value $ENABLE_CLIPPING ] == 1 } {
#      set_parameter_property $CLIPPING_X      VISIBLE true  
#      set_parameter_property $CLIPPING_Y      VISIBLE true  
#      set_parameter_property $CLIPPING_WIDTH  VISIBLE true  
#      set_parameter_property $CLIPPING_HEIGHT VISIBLE true  
#    } else {
#      set_parameter_property $CLIPPING_X      VISIBLE false  
#      set_parameter_property $CLIPPING_Y      VISIBLE false  
#      set_parameter_property $CLIPPING_WIDTH  VISIBLE false  
#      set_parameter_property $CLIPPING_HEIGHT VISIBLE false  
#    }
#
# }


#  proc vsc_connect_core { is_reader is_writer } {
#
#    set vsc_name [ vsc_get_name -1 ]
#
#    # set derived 
#    set_parameter_value ${vsc_name}_IS_READER $is_reader
#    set_parameter_value ${vsc_name}_IS_WRITER $is_writer
# 
#  # set param_name "WZD"
#    set param_name $vsc_name
#
#
#    set color_depth 0 
#    set color_num   0 
#    set color_size  0
#    set color_raw    0
#
#    colorformat_get_info [get_parameter_value ${param_name}_VID_PIXEL_FORMAT] color_depth color_num color_size color_raw  
# 
#
#    if { $color_raw == 1 }  {    	
#
#      set_parameter_value ${param_name}_VID_COLOR_SIZE   $color_size
#      set_parameter_value ${param_name}_VID_COLOR_NUM    $color_num
#     
#      set_parameter_property ${param_name}_VID_COLOR_SIZE VISIBLE true
#      set_parameter_property ${param_name}_VID_COLOR_NUM  VISIBLE true
#      set_parameter_property ${param_name}_VID_RAW_SIZE   VISIBLE false
#      set_parameter_property ${param_name}_VID_RAW_NUM    VISIBLE false
# 
#    } else {
# 
#      set_parameter_value ${param_name}_VID_COLOR_SIZE   [get_parameter_value ${param_name}_VID_RAW_SIZE]
#      set_parameter_value ${param_name}_VID_COLOR_NUM    [get_parameter_value ${param_name}_VID_RAW_NUM ]
#
#      set_parameter_property ${param_name}_VID_COLOR_SIZE VISIBLE false 
#      set_parameter_property ${param_name}_VID_COLOR_NUM  VISIBLE false 
#      set_parameter_property ${param_name}_VID_RAW_SIZE   VISIBLE true
#      set_parameter_property ${param_name}_VID_RAW_NUM    VISIBLE true
#
#    }
# 
#
#
#    if { [get_parameter_value ${param_name}_VID_CHANNEL_ENABLE] == 1 }  {
#      set_parameter_property ${param_name}_VID_CHANNEL_NUMBER ENABLED true
#    } else {
#      set_parameter_property ${param_name}_VID_CHANNEL_NUMBER ENABLED false
#    }
#
#    
#    add_instance $vsc_name imt_vsc_core    
#    
#    vsc_connect_parameters $vsc_name 
#
#    add_connection cb_inst.out_clk     $vsc_name.clock  clock ""
#    add_connection rst_inst.out_reset  $vsc_name.reset          
#
#
#    if {[ get_parameter_value ${vsc_name}_ENABLE_CSR ] == 1} {  
#
#      add_interface          csr avalon end
#      set_interface_property csr EXPORT_OF $vsc_name.csr
#      
#      add_interface          csr_irq interrupt end
#      set_interface_property csr_irq EXPORT_OF $vsc_name.csr_irq
#
#    } 
#
#
#    # ----------------------------------------------
#    # --  Video                                   --
#    # ----------------------------------------------
#
#    # video-in
#    if { $is_writer == 1 } {
#      add_interface          video_din avalon_streaming end
#      set_interface_property video_din EXPORT_OF $vsc_name.video_din    
#    } 
#    
#    if { $is_reader == 1 } {
#      add_interface          video_dout avalon_streaming start
#      set_interface_property video_dout EXPORT_OF $vsc_name.video_dout    
#    }
#    
#
# 
# 
#  }

