
# vgr_add_parameters_features
# vgr_validation_features
# vgr_add_parameters_optimizations
 
# removed:
# vgr_add_parameters_core 
# vgr_elaborate_version 



# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Interfaces                                                                                 --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#  proc vgr_add_interface { inst_name } {
#  
#    # +-----------------------------------
#    # | connection point asg2vip
#    # | 
#  # add_interface ${inst_name}_exp conduit end
#    add_interface asg2vip conduit end
#    
#    set_interface_property asg2vip associatedClock clock
#    set_interface_property asg2vip associatedReset reset
#    set_interface_property asg2vip ENABLED true
#    
#  # add_interface_port ${inst_name}_exp ${inst_name}_i export Input  256
#  # add_interface_port ${inst_name}_exp ${inst_name}_o export Output 256
#
#    add_interface_port asg2vip asg2vip_cmd export Input  256
#    add_interface_port asg2vip asg2vip_rsp export Output 256
#
#  
#    # | 
#    # +-----------------------------------
#    
#  
#  }
 
 
#  proc vgr_elaborate_interface { inst_name } {
#  
#    if { [ get_parameter_value WZD_DPY_VIDEO_CLOCKED ] == 1 } {
#      set_interface_property ${inst_name}_clock_out  ENABLED true  
#    } else {
#      set_interface_property ${inst_name}_clock_out  ENABLED false  
#    }
#    
#    # empty size independent 
#    set_interface_property ${inst_name}_stream_out dataBitsPerSymbol [ expr ( [get_parameter_value WZD_DPY_video_frame_color_size] ) ]
#    # empty size dependent 
#    set_interface_property ${inst_name}_stream_out symbolsPerBeat [ expr ( [get_parameter_value WZD_DPY_video_frame_color_num] * [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] * [get_parameter_value WZD_DPY_VIDEO_SCREEN_NUM] ) ]
#    
#    set_port_property ${inst_name}_dat_data     WIDTH_EXPR [ expr ( [get_parameter_value WZD_DPY_video_frame_color_size] * [get_parameter_value WZD_DPY_video_frame_color_num] * [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] * [get_parameter_value WZD_DPY_VIDEO_SCREEN_NUM] ) ]
#    
#    set_port_property ${inst_name}_cvo_data     WIDTH_EXPR [ expr ( [get_parameter_value WZD_DPY_video_frame_color_size] * [get_parameter_value WZD_DPY_video_frame_color_num] * [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] * [get_parameter_value WZD_DPY_VIDEO_SCREEN_NUM] ) ]
#    set_port_property ${inst_name}_cvo_de       WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM]
#    set_port_property ${inst_name}_cvo_hsync    WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM]
#    set_port_property ${inst_name}_cvo_vsync    WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM]
#    set_port_property ${inst_name}_cvo_h        WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] 
#    set_port_property ${inst_name}_cvo_v        WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM] 
#    set_port_property ${inst_name}_cvo_f        WIDTH_EXPR [get_parameter_value WZD_DPY_VIDEO_PIXEL_NUM]
#
#  }

# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Main                                                                                       --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc vgr_add_parameters { inst_id inst_name parent_gui_name } {

  # vgr_add_parameters_core          ${inst_id} ${inst_name} ${parent_gui_name}
    vgr_add_parameters_features      ${inst_id} ${inst_name} ${parent_gui_name}
    vgr_add_parameters_optimizations ${inst_id} ${inst_name} ${parent_gui_name}      
 
  }


# proc vgr_elaborate { inst_id inst_name v_major v_minor } {
#
#   vgr_elaborate_version ${inst_id} ${inst_name} ${v_major} ${v_minor}
# 
# }


  proc vgr_valid { inst_id inst_name } {

    vgr_validation_features ${inst_id} ${inst_name}  
  
  }

 
# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Core                                                                                       --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------


# proc vgr_add_parameters_core { inst_id inst_name parent_gui_name } {
#
#   set VERSION_MAJOR  ${inst_name}_VERSION_MAJOR
#   set VERSION_MINOR  ${inst_name}_VERSION_MINOR
#
#   add_parameter          $VERSION_MAJOR INTEGER 0
#   set_parameter_property $VERSION_MAJOR DISPLAY_NAME "major";
#   set_parameter_property $VERSION_MAJOR DISPLAY_HINT INTEGER
#   set_parameter_property $VERSION_MAJOR DESCRIPTION " "
#   set_parameter_property $VERSION_MAJOR VISIBLE false 
#   set_parameter_property $VERSION_MAJOR DERIVED true 
#   set_parameter_property $VERSION_MAJOR HDL_PARAMETER true
#
#   add_parameter          $VERSION_MINOR INTEGER 0
#   set_parameter_property $VERSION_MINOR DISPLAY_NAME "minor";
#   set_parameter_property $VERSION_MINOR DISPLAY_HINT INTEGER
#   set_parameter_property $VERSION_MINOR DESCRIPTION " "
#   set_parameter_property $VERSION_MINOR VISIBLE false 
#   set_parameter_property $VERSION_MINOR DERIVED true 
#   set_parameter_property $VERSION_MINOR HDL_PARAMETER true
#
# # add_display_item "parent_gui_name" $VERSION_MAJOR  PARAMETER
# # add_display_item "parent_gui_name" $VERSION_MINOR  PARAMETER
#
# }
  
  
# proc vgr_elaborate_version { inst_id inst_name v_major v_minor } {
#
#   set VERSION_MAJOR  ${inst_name}_VERSION_MAJOR
#   set VERSION_MINOR  ${inst_name}_VERSION_MINOR
#  
#   set_parameter_value $VERSION_MAJOR  $v_major 
#   set_parameter_value $VERSION_MINOR  $v_minor 
#
# }


 
# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Interfaces                                                                                 --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#  proc vgr_add_parameters_interfaces { inst_id inst_name parent_gui_name } {
#
#    set CORE_CLOCK_RATE        ${inst_name}_CORE_CLOCK_RATE
#
#    set PATH_HAS_DEDICATED_CLK ${inst_name}_PATH_HAS_DEDICATED_CLK
#    set PATH_ADDR8_SIZE        ${inst_name}_PATH_ADDR8_SIZE       
#    set path_burstlength       ${inst_name}_path_burstlength 
#    set PATH_BURSTLENGTH_LOG2  ${inst_name}_PATH_BURSTLENGTH_LOG2 
#
#    set ENABLE_DESC            ${inst_name}_ENABLE_DESC
#    set DESC_HAS_DEDICATED_CLK ${inst_name}_DESC_HAS_DEDICATED_CLK
#    set DESC_ADDR8_SIZE        ${inst_name}_DESC_ADDR8_SIZE       
#    set desc_burstlength       ${inst_name}_desc_burstlength 
#    set DESC_BURSTLENGTH_LOG2  ${inst_name}_DESC_BURSTLENGTH_LOG2 
#
# 
#    # invisible
#    add_parameter          $CORE_CLOCK_RATE INTEGER
#    set_parameter_property $CORE_CLOCK_RATE DISPLAY_NAME "core clock rate" 
#    if { $is_top == 1 } {
#      set_parameter_property $CORE_CLOCK_RATE system_info {CLOCK_RATE clock}
#    } 
#    set_parameter_property $CORE_CLOCK_RATE VISIBLE false
#    set_parameter_property $CORE_CLOCK_RATE AFFECTS_ELABORATION true  
#    set_parameter_property $CORE_CLOCK_RATE HDL_PARAMETER true
#
#    
#  # add_parameter          $DESC_HAS_DEDICATED_CLK INTEGER 1
#  # set_parameter_property $DESC_HAS_DEDICATED_CLK DISPLAY_NAME "desc. dedicated clock domain" 
#  # set_parameter_property $DESC_HAS_DEDICATED_CLK DISPLAY_HINT boolean
#  # set_parameter_property $DESC_HAS_DEDICATED_CLK AFFECTS_ELABORATION true        
#  # set_parameter_property $DESC_HAS_DEDICATED_CLK HDL_PARAMETER true
#  #
#  # # invisible
#  # add_parameter          $DESC_ADDR8_SIZE INTEGER 32
#  # set_parameter_property $DESC_ADDR8_SIZE DISPLAY_NAME "Avalon MM Descriptor address width" 
#  # if { $is_top == 1 } {
#  #   set_parameter_property $DESC_ADDR8_SIZE system_info {ADDRESS_WIDTH descriptor_master}
#  # } 
#  # set_parameter_property $DESC_ADDR8_SIZE VISIBLE false
#  # set_parameter_property $DESC_ADDR8_SIZE AFFECTS_ELABORATION true        
#  # set_parameter_property $DESC_ADDR8_SIZE HDL_PARAMETER true        
#
#  # add_parameter          desc_data_width INTEGER 32
#  # set_parameter_property desc_data_width DISPLAY_NAME "Avalon MM Descriptor data width"
#  # set_parameter_property desc_data_width VISIBLE false 
#  # set_parameter_property desc_data_width DERIVED true 
#  
#  # add_parameter          desc_burstcount_width INTEGER 0
#  # set_parameter_property desc_burstcount_width DISPLAY_NAME "Descriptor Master burstcount width" 
#  # set_parameter_property desc_burstcount_width VISIBLE false 
#  # set_parameter_property desc_burstcount_width DERIVED true 
#  
#    add_parameter          $PATH_HAS_DEDICATED_CLK INTEGER 1
#    set_parameter_property $PATH_HAS_DEDICATED_CLK DISPLAY_NAME "Path dedicated clock domain" 
#    set_parameter_property $PATH_HAS_DEDICATED_CLK DISPLAY_HINT boolean
#    set_parameter_property $PATH_HAS_DEDICATED_CLK AFFECTS_ELABORATION true        
#    set_parameter_property $PATH_HAS_DEDICATED_CLK HDL_PARAMETER true
#    
#    add_parameter          $PATH_ADDR8_SIZE INTEGER 32
#    set_parameter_property $PATH_ADDR8_SIZE DISPLAY_NAME "Avalon MM Path address width" 
#    if { $is_top == 1 } {
#      set_parameter_property $PATH_ADDR8_SIZE system_info {ADDRESS_WIDTH path_master}
#    } 
#    set_parameter_property $PATH_ADDR8_SIZE VISIBLE false
#    set_parameter_property $PATH_ADDR8_SIZE AFFECTS_ELABORATION true        
#    set_parameter_property $PATH_ADDR8_SIZE HDL_PARAMETER true        
#
#  # add_parameter          path_data_width INTEGER 32
#  # set_parameter_property path_data_width DISPLAY_NAME "Avalon MM Path data width"
#  # set_parameter_property path_data_width VISIBLE false 
#  # set_parameter_property path_data_width DERIVED true 
#
#    add_parameter          $path_burstlength INTEGER           16
#    set_parameter_property $path_burstlength DISPLAY_NAME      "Path Maximum burst length" 
#    set_parameter_property $path_burstlength ALLOWED_RANGES    {"2" "4" "8" "16" "32" "64" "128" "256"}
#    set_parameter_property $path_burstlength AFFECTS_ELABORATION true        
#  # set_parameter_property $path_burstlength HDL_PARAMETER true
#    
#    add_parameter          $PATH_BURSTLENGTH_LOG2 INTEGER 4
#    set_parameter_property $PATH_BURSTLENGTH_LOG2 DISPLAY_NAME "Path Maximum burst length (log2)" 
#    set_parameter_property $PATH_BURSTLENGTH_LOG2 HDL_PARAMETER true
#    set_parameter_property $PATH_BURSTLENGTH_LOG2 VISIBLE false 
#    if { $is_top == 1 } {
#      set_parameter_property $PATH_BURSTLENGTH_LOG2 DERIVED true
#    } 
#
#
#    add_parameter          $ENABLE_DESC INTEGER 0
#    set_parameter_property $ENABLE_DESC DISPLAY_NAME "Support for Descriptors (draw-lists)" 
#    set_parameter_property $ENABLE_DESC DISPLAY_HINT boolean
#    set_parameter_property $ENABLE_DESC AFFECTS_ELABORATION true        
#    set_parameter_property $ENABLE_DESC HDL_PARAMETER true
#    set_parameter_property $ENABLE_DESC VISIBLE false; # not released 
#
#    add_parameter          $DESC_HAS_DEDICATED_CLK INTEGER 1
#    set_parameter_property $DESC_HAS_DEDICATED_CLK DISPLAY_NAME "Desc. dedicated clock domain" 
#    set_parameter_property $DESC_HAS_DEDICATED_CLK DISPLAY_HINT boolean
#    set_parameter_property $DESC_HAS_DEDICATED_CLK AFFECTS_ELABORATION true        
#    set_parameter_property $DESC_HAS_DEDICATED_CLK HDL_PARAMETER true
#    
#    add_parameter          $DESC_ADDR8_SIZE INTEGER 32
#    set_parameter_property $DESC_ADDR8_SIZE DISPLAY_NAME "Avalon MM Desc. address width" 
#    if { $is_top == 1 } {
#      set_parameter_property $DESC_ADDR8_SIZE system_info {ADDRESS_WIDTH descriptor_master}
#    } 
#  # set_parameter_property $DESC_ADDR8_SIZE VISIBLE false
#    set_parameter_property $DESC_ADDR8_SIZE AFFECTS_ELABORATION true        
#    set_parameter_property $DESC_ADDR8_SIZE HDL_PARAMETER true        
#
#    add_parameter          $desc_burstlength INTEGER           16
#    set_parameter_property $desc_burstlength DISPLAY_NAME      "Desc. Maximum burst length" 
#    set_parameter_property $desc_burstlength ALLOWED_RANGES    {"2" "4" "8" "16" "32" "64" "128" "256"}
#    set_parameter_property $desc_burstlength AFFECTS_ELABORATION true        
#  # set_parameter_property $desc_burstlength HDL_PARAMETER true
#    
#    add_parameter          $DESC_BURSTLENGTH_LOG2 INTEGER 4
#    set_parameter_property $DESC_BURSTLENGTH_LOG2 DISPLAY_NAME "Path Maximum burst length (log2)" 
#    set_parameter_property $DESC_BURSTLENGTH_LOG2 HDL_PARAMETER true
#    set_parameter_property $DESC_BURSTLENGTH_LOG2 VISIBLE false 
#    if { $is_top == 1 } {
#      set_parameter_property $DESC_BURSTLENGTH_LOG2 DERIVED true
#    } 
#
#  
#    add_display_item "Interfaces${inst_id}" $CORE_CLOCK_RATE        parameter
#    add_display_item "Interfaces${inst_id}" $PATH_HAS_DEDICATED_CLK parameter
#    add_display_item "Interfaces${inst_id}" $PATH_ADDR8_SIZE        parameter
#    add_display_item "Interfaces${inst_id}" $path_burstlength       parameter
#    add_display_item "Interfaces${inst_id}" $PATH_BURSTLENGTH_LOG2  parameter
#
#    add_display_item "Interfaces${inst_id}" $ENABLE_DESC            parameter
#    add_display_item "Interfaces${inst_id}" $DESC_HAS_DEDICATED_CLK parameter
#    add_display_item "Interfaces${inst_id}" $DESC_ADDR8_SIZE        parameter
#    add_display_item "Interfaces${inst_id}" $desc_burstlength       parameter
#    add_display_item "Interfaces${inst_id}" $DESC_BURSTLENGTH_LOG2  parameter
#  
#  }


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Features                                                                                   --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc vgr_add_parameters_features { inst_id inst_name parent_gui_name } {


#   set OP_ENABLE_IMAGE    ${inst_name}_OP_ENABLE_IMAGE                 
#   set OP_ENABLE_PATH     ${inst_name}_OP_ENABLE_PATH                  
#   set OP_IMAGE_COMPOSE   ${inst_name}_OP_IMAGE_COMPOSE                
#   set OP_IMAGE_TRANSFORM ${inst_name}_OP_IMAGE_TRANSFORM              
#   set OP_PATH_RASTERIZE  ${inst_name}_OP_PATH_RASTERIZE                  
#   set OP_PATH_TRANSFORM  ${inst_name}_OP_PATH_TRANSFORM                                                                              
  
#   set FCT_TRANSFORM                     ${inst_name}_FCT_TRANSFORM                                   
#   set FCT_TRANSFORM_3x3                 ${inst_name}_FCT_TRANSFORM_3x3                               
#   set FCT_CLIPPING                      ${inst_name}_FCT_CLIPPING                                                                                               
    set FCT_PATH_STROKE                   ${inst_name}_FCT_PATH_STROKE                                 
    set FCT_MASKING                       ${inst_name}_FCT_MASKING                                     
    set FCT_PAINT_GRADIENT                ${inst_name}_FCT_PAINT_GRADIENT                              
    set FCT_PAINT_BITMAP                  ${inst_name}_FCT_PAINT_BITMAP                               
#   set FCT_BLENDING                      ${inst_name}_FCT_BLENDING                                    
    set OPT_STROKE_FORCE_PAINT_COLOR      ${inst_name}_OPT_STROKE_FORCE_PAINT_COLOR                                      
    set PATH_RASTER_CACHE_MAX_CHUNKS      ${inst_name}_PATH_RASTER_CACHE_MAX_CHUNKS                       
    set GRADIENT_MAX_STOPS                ${inst_name}_GRADIENT_MAX_STOPS                              

#   set FCT_PATH_RASTER                   ${inst_name}_FCT_PATH_RASTER                                 
  # set PATH_NUM_POINTS_LOG2              ${inst_name}_PATH_NUM_POINTS_LOG2                            
#   set FCT_PAINT_PATTERN_FILTERING       ${inst_name}_FCT_PAINT_PATTERN_FILTERING                     
#   set FCT_IMAGE_INTERPOLATION           ${inst_name}_FCT_IMAGE_INTERPOLATION                         
#   set FCT_IMAGE_INTERPOLATION_FILTERING ${inst_name}_FCT_IMAGE_INTERPOLATION_FILTERING               
#   set FCT_COLOR_TRANSFORM               ${inst_name}_FCT_COLOR_TRANSFORM                             
#   set BLENDING_ENABLE_EXTENDED          ${inst_name}_BLENDING_ENABLE_EXTENDED                                

  # set scene_graph_enable  ${inst_name}_scene_graph_enable         
  # set raster_image_enable ${inst_name}_raster_image_enable 
  # set raster_path_enable  ${inst_name}_raster_path_enable  
  # set FCT_CURSOR          ${inst_name}_FCT_CURSOR      
  # set FCT_MORPHING        ${inst_name}_FCT_MORPHING    
  # set FCT_CACHE           ${inst_name}_FCT_CACHE       
  # set FCT_FILTER_BLUR     ${inst_name}_FCT_FILTER_BLUR 

  
    # ----------------------------------------------
    # --  Geometry usage                          --
    # ----------------------------------------------
  
#   # derived
#   add_parameter          $OP_ENABLE_IMAGE INTEGER 1
#   set_parameter_property $OP_ENABLE_IMAGE DISPLAY_NAME "Use bitmap Images";
#   set_parameter_property $OP_ENABLE_IMAGE DISPLAY_HINT boolean
#   set_parameter_property $OP_ENABLE_IMAGE DERIVED true
#   set_parameter_property $OP_ENABLE_IMAGE VISIBLE false
#   set_parameter_property $OP_ENABLE_IMAGE AFFECTS_ELABORATION true        
#   set_parameter_property $OP_ENABLE_IMAGE HDL_PARAMETER true
# 
#   # derived
#   add_parameter          $OP_ENABLE_PATH INTEGER 1
#   set_parameter_property $OP_ENABLE_PATH DISPLAY_NAME "Use B�zier paths";
#   set_parameter_property $OP_ENABLE_PATH DISPLAY_HINT boolean
#   set_parameter_property $OP_ENABLE_PATH DERIVED true
#   set_parameter_property $OP_ENABLE_PATH VISIBLE false
#   set_parameter_property $OP_ENABLE_PATH AFFECTS_ELABORATION true        
#   set_parameter_property $OP_ENABLE_PATH HDL_PARAMETER true
    
    # ----------------------------------------------
    # --  Geometry operations                     --
    # ----------------------------------------------
  
#    add_parameter          $OP_IMAGE_COMPOSE INTEGER 1
#    set_parameter_property $OP_IMAGE_COMPOSE DISPLAY_NAME "Images composition";
#    set_parameter_property $OP_IMAGE_COMPOSE DISPLAY_HINT boolean
#    set_parameter_property $OP_IMAGE_COMPOSE DESCRIPTION "Images drawing without transformation matrix";
#   #set_parameter_property $OP_IMAGE_COMPOSE AFFECTS_ELABORATION false        
#    set_parameter_property $OP_IMAGE_COMPOSE HDL_PARAMETER true
#  
#    add_parameter          $OP_IMAGE_TRANSFORM INTEGER 1
#    set_parameter_property $OP_IMAGE_TRANSFORM DISPLAY_NAME "Images transformation";
#    set_parameter_property $OP_IMAGE_TRANSFORM DISPLAY_HINT boolean
#    set_parameter_property $OP_IMAGE_TRANSFORM DESCRIPTION "Images drawing using transformation matrix";
#   #set_parameter_property $OP_IMAGE_TRANSFORM AFFECTS_ELABORATION false        
#    set_parameter_property $OP_IMAGE_TRANSFORM HDL_PARAMETER true
#  
#    add_parameter          $OP_PATH_RASTERIZE INTEGER 1
#    set_parameter_property $OP_PATH_RASTERIZE DISPLAY_NAME "B�zier paths composition";
#    set_parameter_property $OP_PATH_RASTERIZE DISPLAY_HINT boolean
#    set_parameter_property $OP_PATH_RASTERIZE DESCRIPTION "B�zier paths drawing without transformation matrix";
#    set_parameter_property $OP_PATH_RASTERIZE AFFECTS_ELABORATION true        
#    set_parameter_property $OP_PATH_RASTERIZE HDL_PARAMETER true
#  
#    add_parameter          $OP_PATH_TRANSFORM INTEGER 1
#    set_parameter_property $OP_PATH_TRANSFORM DISPLAY_NAME "B�zier paths transformation";
#    set_parameter_property $OP_PATH_TRANSFORM DISPLAY_HINT boolean
#    set_parameter_property $OP_PATH_TRANSFORM DESCRIPTION "B�zier paths drawing using transformation matrix";
#    set_parameter_property $OP_PATH_TRANSFORM AFFECTS_ELABORATION true        
#    set_parameter_property $OP_PATH_TRANSFORM HDL_PARAMETER true
  
  # add_parameter          $scene_graph_enable INTEGER 0
  # set_parameter_property $scene_graph_enable DISPLAY_NAME "Scene-graph" 
  # set_parameter_property $scene_graph_enable DISPLAY_HINT boolean 
  # set_parameter_property $scene_graph_enable DESCRIPTION "  ";
  # set_parameter_property $scene_graph_enable AFFECTS_ELABORATION true        
  # set_parameter_property $scene_graph_enable ENABLED true      
  ##set_parameter_property $scene_graph_enable VISIBLE true      
  # set_parameter_property $scene_graph_enable VISIBLE false      
  
    # ----------------------------------------------
    # --  Pipeline options                        --
    # ----------------------------------------------
  
#    add_parameter          $FCT_TRANSFORM INTEGER 1
#    set_parameter_property $FCT_TRANSFORM DISPLAY_NAME "Stage 1: affine transform using 3x2 matrix";
#    set_parameter_property $FCT_TRANSFORM DISPLAY_HINT boolean
#    set_parameter_property $FCT_TRANSFORM DESCRIPTION "paths / images geometry transform";
#    set_parameter_property $FCT_TRANSFORM DERIVED true
#    set_parameter_property $FCT_TRANSFORM AFFECTS_ELABORATION true        
#    set_parameter_property $FCT_TRANSFORM HDL_PARAMETER true
#    
#    add_parameter          $FCT_TRANSFORM_3x3 INTEGER 0
#    set_parameter_property $FCT_TRANSFORM_3x3 DISPLAY_NAME "Stage 1: perspective transform using 3x3 matrix (Image only)"
#    set_parameter_property $FCT_TRANSFORM_3x3 DISPLAY_HINT boolean
#    set_parameter_property $FCT_TRANSFORM_3x3 DESCRIPTION "check for perspective transform using 3x3 matrix - default is affine transform using 3x2 matrix"
##   set_parameter_property $FCT_TRANSFORM_3x3 ENABLED true
#    set_parameter_property $FCT_TRANSFORM_3x3 ENABLED false
#    set_parameter_property $FCT_TRANSFORM_3x3 VISIBLE true
#    set_parameter_property $FCT_TRANSFORM_3x3 HDL_PARAMETER true
  
  # add_parameter          $FCT_CLIPPING INTEGER 1
  # set_parameter_property $FCT_CLIPPING DISPLAY_NAME "Stage 2: User clipping";
  # set_parameter_property $FCT_CLIPPING DISPLAY_HINT boolean
  # set_parameter_property $FCT_CLIPPING ENABLED false
  # set_parameter_property $FCT_CLIPPING HDL_PARAMETER true

    add_parameter          $FCT_PATH_STROKE INTEGER 1
    set_parameter_property $FCT_PATH_STROKE DISPLAY_NAME "B�zier path stroker";
    set_parameter_property $FCT_PATH_STROKE DISPLAY_HINT boolean
    set_parameter_property $FCT_PATH_STROKE AFFECTS_ELABORATION true        
    set_parameter_property $FCT_PATH_STROKE DERIVED false
    set_parameter_property $FCT_PATH_STROKE HDL_PARAMETER true

    add_parameter          $OPT_STROKE_FORCE_PAINT_COLOR INTEGER 0
    set_parameter_property $OPT_STROKE_FORCE_PAINT_COLOR DISPLAY_NAME "stroke uses only paint color (no gradient, no pattern)";
    set_parameter_property $OPT_STROKE_FORCE_PAINT_COLOR DISPLAY_HINT boolean
    set_parameter_property $OPT_STROKE_FORCE_PAINT_COLOR HDL_PARAMETER true

  
#    add_parameter          $FCT_PATH_RASTER INTEGER 1
#    set_parameter_property $FCT_PATH_RASTER DISPLAY_NAME "Stage 3: B�zier path rasterization";
#    set_parameter_property $FCT_PATH_RASTER DISPLAY_HINT boolean
#    set_parameter_property $FCT_PATH_RASTER AFFECTS_ELABORATION true        
#    set_parameter_property $FCT_PATH_RASTER DERIVED true
#    set_parameter_property $FCT_PATH_RASTER HDL_PARAMETER true
  
    add_parameter          $PATH_RASTER_CACHE_MAX_CHUNKS INTEGER 256
    set_parameter_property $PATH_RASTER_CACHE_MAX_CHUNKS DISPLAY_NAME "path raster cache size"
    set_parameter_property $PATH_RASTER_CACHE_MAX_CHUNKS ALLOWED_RANGES {128,256,512,1024,2048,4096}
    set_parameter_property $PATH_RASTER_CACHE_MAX_CHUNKS DESCRIPTION " ";
    set_parameter_property $PATH_RASTER_CACHE_MAX_CHUNKS DISPLAY_UNITS "Chunks"
    set_parameter_property $PATH_RASTER_CACHE_MAX_CHUNKS AFFECTS_ELABORATION true        
    set_parameter_property $PATH_RASTER_CACHE_MAX_CHUNKS HDL_PARAMETER true
  
  # add_parameter          $PATH_NUM_POINTS_LOG2 INTEGER 8
  # set_parameter_property $PATH_NUM_POINTS_LOG2 DISPLAY_NAME "Stage 3: path local buffer log 2"
  # set_parameter_property $PATH_NUM_POINTS_LOG2 DESCRIPTION " ";
  # set_parameter_property $PATH_NUM_POINTS_LOG2 VISIBLE false
  # set_parameter_property $PATH_NUM_POINTS_LOG2 DERIVED true
  # set_parameter_property $PATH_NUM_POINTS_LOG2 AFFECTS_ELABORATION true        
  # set_parameter_property $PATH_NUM_POINTS_LOG2 HDL_PARAMETER true
  
    add_parameter          $FCT_MASKING INTEGER 1
    set_parameter_property $FCT_MASKING DISPLAY_NAME "Masking";
    set_parameter_property $FCT_MASKING DISPLAY_HINT boolean
    set_parameter_property $FCT_MASKING DESCRIPTION "use an image to specify alpha-masking";
  # set_parameter_property $FCT_MASKING AFFECTS_ELABORATION false        
    set_parameter_property $FCT_MASKING HDL_PARAMETER true
    
    add_parameter          $FCT_PAINT_GRADIENT INTEGER 1
    set_parameter_property $FCT_PAINT_GRADIENT DISPLAY_NAME "Painting - gradient";
    set_parameter_property $FCT_PAINT_GRADIENT DISPLAY_HINT boolean
    set_parameter_property $FCT_PAINT_GRADIENT DESCRIPTION "linear and radial)";
  # set_parameter_property $FCT_PAINT_GRADIENT AFFECTS_ELABORATION false        
    set_parameter_property $FCT_PAINT_GRADIENT HDL_PARAMETER true

    add_parameter          $GRADIENT_MAX_STOPS INTEGER 16
    set_parameter_property $GRADIENT_MAX_STOPS DISPLAY_NAME "maximum stops per gradient"
    set_parameter_property $GRADIENT_MAX_STOPS ALLOWED_RANGES {2,4,6,8,10,12,14,16}
    set_parameter_property $GRADIENT_MAX_STOPS DESCRIPTION " ";
    set_parameter_property $GRADIENT_MAX_STOPS VISIBLE true
    set_parameter_property $GRADIENT_MAX_STOPS DISPLAY_UNITS "Stops"    
    set_parameter_property $GRADIENT_MAX_STOPS HDL_PARAMETER true
    
    add_parameter          $FCT_PAINT_BITMAP INTEGER 1
    set_parameter_property $FCT_PAINT_BITMAP DISPLAY_NAME "Painting - bitmap image";
    set_parameter_property $FCT_PAINT_BITMAP DISPLAY_HINT boolean
    set_parameter_property $FCT_PAINT_BITMAP DESCRIPTION "use a bitmap image to fill a path geometry";
  # set_parameter_property $FCT_PAINT_BITMAP AFFECTS_ELABORATION false        
    set_parameter_property $FCT_PAINT_BITMAP HDL_PARAMETER true
  
#    add_parameter          $FCT_PAINT_PATTERN_FILTERING INTEGER 1
#    set_parameter_property $FCT_PAINT_PATTERN_FILTERING DISPLAY_NAME "Stage 5: painting - pattern image filtering"
#    set_parameter_property $FCT_PAINT_PATTERN_FILTERING DISPLAY_HINT boolean
#    set_parameter_property $FCT_PAINT_PATTERN_FILTERING DESCRIPTION "select to support bilinear filtering"
#    set_parameter_property $FCT_PAINT_PATTERN_FILTERING ENABLED true
#    set_parameter_property $FCT_PAINT_PATTERN_FILTERING VISIBLE true
#    set_parameter_property $FCT_PAINT_PATTERN_FILTERING HDL_PARAMETER true
  
#    add_parameter          $FCT_IMAGE_INTERPOLATION INTEGER 1
#    set_parameter_property $FCT_IMAGE_INTERPOLATION DISPLAY_NAME "Stage 6: image interpolation"
#    set_parameter_property $FCT_IMAGE_INTERPOLATION DISPLAY_HINT boolean
#    set_parameter_property $FCT_IMAGE_INTERPOLATION DESCRIPTION "image geometry pixels interpolation"
#    set_parameter_property $FCT_IMAGE_INTERPOLATION ENABLED true
#    set_parameter_property $FCT_IMAGE_INTERPOLATION VISIBLE true
#    set_parameter_property $FCT_IMAGE_INTERPOLATION DERIVED true
#    set_parameter_property $FCT_IMAGE_INTERPOLATION HDL_PARAMETER true
#  
#    add_parameter          $FCT_IMAGE_INTERPOLATION_FILTERING INTEGER 1
#    set_parameter_property $FCT_IMAGE_INTERPOLATION_FILTERING DISPLAY_NAME "Stage 6: image interpolation filtering"
#    set_parameter_property $FCT_IMAGE_INTERPOLATION_FILTERING DISPLAY_HINT boolean
#    set_parameter_property $FCT_IMAGE_INTERPOLATION_FILTERING DESCRIPTION "select to support bilinear filtering"
#    set_parameter_property $FCT_IMAGE_INTERPOLATION_FILTERING ENABLED true
#    set_parameter_property $FCT_IMAGE_INTERPOLATION_FILTERING VISIBLE true
#    set_parameter_property $FCT_IMAGE_INTERPOLATION_FILTERING HDL_PARAMETER true
#    
#    add_parameter          $FCT_COLOR_TRANSFORM INTEGER 0
#    set_parameter_property $FCT_COLOR_TRANSFORM DISPLAY_NAME "Stage 7: color transform";
#    set_parameter_property $FCT_COLOR_TRANSFORM DISPLAY_HINT boolean
#    set_parameter_property $FCT_COLOR_TRANSFORM DESCRIPTION "change the color and transparency";
#  # set_parameter_property $FCT_COLOR_TRANSFORM AFFECTS_ELABORATION false        
#    set_parameter_property $FCT_COLOR_TRANSFORM HDL_PARAMETER true
    
#   add_parameter          $FCT_BLENDING INTEGER 1
#   set_parameter_property $FCT_BLENDING DISPLAY_NAME "Blending";
#   set_parameter_property $FCT_BLENDING DISPLAY_HINT boolean
#   set_parameter_property $FCT_BLENDING DESCRIPTION "support for SRC_OVER operator";
# # set_parameter_property $FCT_BLENDING AFFECTS_ELABORATION false        
#   set_parameter_property $FCT_BLENDING HDL_PARAMETER true

#    add_parameter          $BLENDING_ENABLE_EXTENDED INTEGER 0
#    set_parameter_property $BLENDING_ENABLE_EXTENDED DISPLAY_NAME "Stage 8: extended blending modes";
#    set_parameter_property $BLENDING_ENABLE_EXTENDED DISPLAY_HINT boolean
#    set_parameter_property $BLENDING_ENABLE_EXTENDED DESCRIPTION "support for additive mode and additional Porter-Duff modes:multiply,screen,darken,lighten ";
#  # set_parameter_property $BLENDING_ENABLE_EXTENDED AFFECTS_ELABORATION false        
#    set_parameter_property $BLENDING_ENABLE_EXTENDED HDL_PARAMETER true


#   # ----------------------------------------------
#   # --  Scene Graph                             --
#   # ----------------------------------------------
# 
#   add_parameter          $raster_image_enable INTEGER 0
#   set_parameter_property $raster_image_enable DISPLAY_NAME "image"
#   set_parameter_property $raster_image_enable DISPLAY_HINT boolean
#   set_parameter_property $raster_image_enable DESCRIPTION " Bitmap image drawing using transformation matrix ";
# # set_parameter_property $raster_image_enable AFFECTS_ELABORATION false        
  
   #add_parameter          $raster_path_enable INTEGER 0
   #set_parameter_property $raster_path_enable DISPLAY_NAME "path"
   #set_parameter_property $raster_path_enable DISPLAY_HINT boolean
   #set_parameter_property $raster_path_enable DESCRIPTION " B�zier path drawing using transformation matrix ";
   #set_parameter_property $raster_path_enable AFFECTS_ELABORATION false        
  
#   #Parameters Definition
#   add_parameter          $FCT_CURSOR INTEGER 0
#   set_parameter_property $FCT_CURSOR DISPLAY_NAME "cursor"
#   set_parameter_property $FCT_CURSOR DISPLAY_HINT boolean
#   set_parameter_property $FCT_CURSOR DESCRIPTION "assert when flash animation is interactive, based on cursor parameters (X,Y,clicked/unclicked)";
# # set_parameter_property $FCT_CURSOR AFFECTS_ELABORATION false        
#   set_parameter_property $FCT_CURSOR HDL_PARAMETER true
#   
#   add_parameter          $FCT_MORPHING INTEGER 0
#   set_parameter_property $FCT_MORPHING DISPLAY_NAME "morphing";
#   set_parameter_property $FCT_MORPHING DISPLAY_HINT boolean
#   set_parameter_property $FCT_MORPHING DESCRIPTION "shape & fillstyle morphing";
# # set_parameter_property $FCT_MORPHING AFFECTS_ELABORATION false        
#   set_parameter_property $FCT_MORPHING HDL_PARAMETER true
#   
#   add_parameter          $FCT_CACHE INTEGER 0
#   set_parameter_property $FCT_CACHE DISPLAY_NAME "cache as bitmap";
#   set_parameter_property $FCT_CACHE DISPLAY_HINT boolean
#   set_parameter_property $FCT_CACHE DESCRIPTION "Improves rendering performance for static and almost-static movie-clips";
# # set_parameter_property $FCT_CACHE AFFECTS_ELABORATION false        
#   set_parameter_property $FCT_CACHE VISIBLE false
#   set_parameter_property $FCT_CACHE HDL_PARAMETER true
#  
#   add_parameter          $FCT_FILTER_BLUR INTEGER 0
#   set_parameter_property $FCT_FILTER_BLUR DISPLAY_NAME "filters (blur-based)";
#   set_parameter_property $FCT_FILTER_BLUR DISPLAY_HINT boolean
#   set_parameter_property $FCT_FILTER_BLUR DESCRIPTION "Blur, Dropshadow, Glow and Bevel without gradient color";
# # set_parameter_property $FCT_FILTER_BLUR AFFECTS_ELABORATION false        
#   set_parameter_property $FCT_FILTER_BLUR HDL_PARAMETER true
  
 
#   add_display_item $parent_gui_name "Drawing operations${inst_id}" GROUP tab
    add_display_item $parent_gui_name "Pipeline options${inst_id}" GROUP tab  
   
#   add_display_item "Drawing operations${inst_id}" $OP_ENABLE_IMAGE       PARAMETER
#   add_display_item "Drawing operations${inst_id}" $OP_ENABLE_PATH        PARAMETER
#   add_display_item "Drawing operations${inst_id}" $OP_IMAGE_COMPOSE      PARAMETER
#   add_display_item "Drawing operations${inst_id}" $OP_IMAGE_TRANSFORM    PARAMETER
#   add_display_item "Drawing operations${inst_id}" $OP_PATH_RASTERIZE     PARAMETER
#   add_display_item "Drawing operations${inst_id}" $OP_PATH_TRANSFORM     PARAMETER
# # add_display_item "Drawing operations${inst_id}" $scene_graph_enable    PARAMETER
                                                                           
#   add_display_item "Pipeline options${inst_id}" $FCT_TRANSFORM                      PARAMETER
#   add_display_item "Pipeline options${inst_id}" $FCT_TRANSFORM_3x3                  PARAMETER   
#   add_display_item "Pipeline options${inst_id}" $FCT_CLIPPING                       PARAMETER                                                               
    add_display_item "Pipeline options${inst_id}" $FCT_PATH_STROKE                    PARAMETER
    add_display_item "Pipeline options${inst_id}" $OPT_STROKE_FORCE_PAINT_COLOR       PARAMETER
#   add_display_item "Pipeline options${inst_id}" $FCT_PATH_RASTER                    PARAMETER
    add_display_item "Pipeline options${inst_id}" $PATH_RASTER_CACHE_MAX_CHUNKS       PARAMETER
  # add_display_item "Pipeline options${inst_id}" $PATH_NUM_POINTS_LOG2               PARAMETER
    add_display_item "Pipeline options${inst_id}" $FCT_MASKING                        PARAMETER
    add_display_item "Pipeline options${inst_id}" $FCT_PAINT_GRADIENT                 PARAMETER
    add_display_item "Pipeline options${inst_id}" $GRADIENT_MAX_STOPS                 PARAMETER    
    add_display_item "Pipeline options${inst_id}" $FCT_PAINT_BITMAP                  PARAMETER
#   add_display_item "Pipeline options${inst_id}" $FCT_PAINT_PATTERN_FILTERING        PARAMETER
#   add_display_item "Pipeline options${inst_id}" $FCT_IMAGE_INTERPOLATION            PARAMETER
#   add_display_item "Pipeline options${inst_id}" $FCT_IMAGE_INTERPOLATION_FILTERING  PARAMETER
#   add_display_item "Pipeline options${inst_id}" $FCT_COLOR_TRANSFORM                PARAMETER
#   add_display_item "Pipeline options${inst_id}" $FCT_BLENDING                       PARAMETER
#   add_display_item "Pipeline options${inst_id}" $BLENDING_ENABLE_EXTENDED           PARAMETER

  # add_display_item "Scene Graph${inst_id}" $raster_image_enable PARAMETER
  # add_display_item "Scene Graph${inst_id}" $raster_path_enable  PARAMETER
  # add_display_item "Scene Graph${inst_id}" $FCT_CURSOR          PARAMETER
  # add_display_item "Scene Graph${inst_id}" $FCT_MORPHING        PARAMETER
  # add_display_item "Scene Graph${inst_id}" $FCT_CACHE           PARAMETER
  # add_display_item "Scene Graph${inst_id}" $FCT_FILTER_BLUR     PARAMETER
  
  }

 

#  proc vgr_validation_desc { inst_id inst_name } {
#
#    set ENABLE_DESC            ${inst_name}_ENABLE_DESC
#    set DESC_HAS_DEDICATED_CLK ${inst_name}_DESC_HAS_DEDICATED_CLK
#    set DESC_ADDR8_SIZE        ${inst_name}_DESC_ADDR8_SIZE       
#    set desc_burstlength       ${inst_name}_desc_burstlength 
#
#    if {[ get_parameter_value $ENABLE_DESC] == 1 } {
#       set_parameter_property $DESC_HAS_DEDICATED_CLK VISIBLE true
#       set_parameter_property $DESC_ADDR8_SIZE        VISIBLE true
#       set_parameter_property $desc_burstlength       VISIBLE true
#    } else {
#       set_parameter_property $DESC_HAS_DEDICATED_CLK VISIBLE false
#       set_parameter_property $DESC_ADDR8_SIZE        VISIBLE false
#       set_parameter_property $desc_burstlength       VISIBLE false
#    }
#
#  }


  proc vgr_validation_features { inst_id inst_name } {

#   set OP_ENABLE_IMAGE    ${inst_name}_OP_ENABLE_IMAGE                 
#   set OP_ENABLE_PATH     ${inst_name}_OP_ENABLE_PATH                  
#   set OP_IMAGE_COMPOSE   ${inst_name}_OP_IMAGE_COMPOSE                
#   set OP_IMAGE_TRANSFORM ${inst_name}_OP_IMAGE_TRANSFORM              
#   set OP_PATH_RASTERIZE  ${inst_name}_OP_PATH_RASTERIZE                  
#   set OP_PATH_TRANSFORM  ${inst_name}_OP_PATH_TRANSFORM                                                                              

    set FCT_PATH_STROKE                   ${inst_name}_FCT_PATH_STROKE                                 
    set FCT_MASKING                       ${inst_name}_FCT_MASKING                                     
    set FCT_PAINT_GRADIENT                ${inst_name}_FCT_PAINT_GRADIENT                              
    set FCT_PAINT_BITMAP                  ${inst_name}_FCT_PAINT_BITMAP                               
#   set FCT_BLENDING                      ${inst_name}_FCT_BLENDING                                    
    set OPT_STROKE_FORCE_PAINT_COLOR      ${inst_name}_OPT_STROKE_FORCE_PAINT_COLOR                                      
    set PATH_RASTER_CACHE_MAX_CHUNKS      ${inst_name}_PATH_RASTER_CACHE_MAX_CHUNKS                       
    set GRADIENT_MAX_STOPS                ${inst_name}_GRADIENT_MAX_STOPS                              
  
  # set raster_image_enable ${inst_name}_raster_image_enable 
  # set raster_path_enable  ${inst_name}_raster_path_enable  
  # set FCT_CURSOR          ${inst_name}_FCT_CURSOR      
  # set FCT_MORPHING        ${inst_name}_FCT_MORPHING    
  # set FCT_CACHE           ${inst_name}_FCT_CACHE       
  # set FCT_FILTER_BLUR     ${inst_name}_FCT_FILTER_BLUR 

  # set scene_graph_enable      ${inst_name}_scene_graph_enable         


    if {[ get_parameter_value $FCT_PATH_STROKE] == 1} {
       set_parameter_property $OPT_STROKE_FORCE_PAINT_COLOR ENABLED true 
    } else {
       set_parameter_property $OPT_STROKE_FORCE_PAINT_COLOR ENABLED false 
    }

    # Stage 5
    if {[ get_parameter_value $FCT_PAINT_GRADIENT] == 1 } {
      set_parameter_property $GRADIENT_MAX_STOPS ENABLED true 
    } else {
      set_parameter_property $GRADIENT_MAX_STOPS ENABLED false 
    }
    
#   if {[ get_parameter_value $FCT_BLENDING] == 1} {
#      set_parameter_property $BLENDING_ENABLE_EXTENDED VISIBLE true 
#   } else {
#      set_parameter_property $BLENDING_ENABLE_EXTENDED VISIBLE false 
#   }


#    # Geometries
#    if {[ get_parameter_value $OP_IMAGE_COMPOSE] == 1  ||  
#        [ get_parameter_value $OP_IMAGE_TRANSFORM] == 1 } {
#       set_parameter_value $OP_ENABLE_IMAGE 1
#    } else {
#       set_parameter_value $OP_ENABLE_IMAGE 0
#    }
#
#    if {[ get_parameter_value $OP_PATH_RASTERIZE] == 1  ||  
#        [ get_parameter_value $OP_PATH_TRANSFORM] == 1 } {
#       set_parameter_value $OP_ENABLE_PATH 1
#    } else {
#       set_parameter_value $OP_ENABLE_PATH 0
#    }
#
#
#    # Stage 1
#    if {[ get_parameter_value $OP_IMAGE_TRANSFORM] == 1  ||  
#        [ get_parameter_value $OP_PATH_TRANSFORM] == 1 } {
#       set_parameter_value $FCT_TRANSFORM 1
#    } else {
#       set_parameter_value $FCT_TRANSFORM 0
#    }

  # # Stage 1
  # if {[ get_parameter_value $OP_IMAGE_TRANSFORM] == 1} {
  #    set_parameter_property $FCT_TRANSFORM_3x3 ENABLED true
  # } else {
  #    set_parameter_property $FCT_TRANSFORM_3x3 ENABLED false
  # }
    
#   # Stage 3
#   if {[ get_parameter_value $OP_ENABLE_PATH] == 1 } {
#      set_parameter_value $FCT_PATH_RASTER  1
#      set_parameter_property $PATH_RASTER_CACHE_MAX_CHUNKS ENABLED true 
#   } else {
#      set_parameter_value $FCT_PATH_RASTER  0
#      set_parameter_property $PATH_RASTER_CACHE_MAX_CHUNKS ENABLED false 
#   }

     

#   if {[ get_parameter_value $OP_ENABLE_PATH] == 1 } {
#      set_parameter_property $FCT_PAINT_GRADIENT ENABLED true
#      if {[ get_parameter_value $FCT_PAINT_GRADIENT] == 1 } {
#        set_parameter_property $GRADIENT_MAX_STOPS VISIBLE true 
#      } else {
#        set_parameter_property $GRADIENT_MAX_STOPS VISIBLE false 
#      }
#      set_parameter_property $FCT_PAINT_BITMAP  ENABLED true
#
#   } else {
#      set_parameter_property $FCT_PAINT_GRADIENT ENABLED false
#      set_parameter_property $FCT_PAINT_BITMAP   ENABLED false
#      set_parameter_property $GRADIENT_MAX_STOPS VISIBLE false 
#   }
        
#   # Stage 5
#   if {[ get_parameter_property $FCT_PAINT_BITMAP ENABLED] == 1 } {
#      set_parameter_property $FCT_PAINT_PATTERN_FILTERING ENABLED true
#   } else {
#      set_parameter_property $FCT_PAINT_PATTERN_FILTERING ENABLED false
#   }
    
#   # Stage 6
#   if {[ get_parameter_value $OP_ENABLE_IMAGE] == 1 } {
#      set_parameter_value    $FCT_IMAGE_INTERPOLATION 1
#   } else {
#      set_parameter_value    $FCT_IMAGE_INTERPOLATION 0
#   }
#
#   if {[ get_parameter_value $OP_IMAGE_TRANSFORM] == 1 } {
#      set_parameter_property $FCT_IMAGE_INTERPOLATION_FILTERING ENABLED true
#   } else {
#      set_parameter_property $FCT_IMAGE_INTERPOLATION_FILTERING ENABLED false
#   }

  # # intern only
  # if { [get_parameter_value $scene_graph_enable] == 1 } {
  #   set_display_item_property "Scene Graph${inst_id}" VISIBLE true
  # } else {
  #   set_display_item_property "Scene Graph${inst_id}" VISIBLE false
  # }

  }


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Optimization                                                                              --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

  proc vgr_add_parameters_optimizations { inst_id inst_name parent_gui_name } {

    set PIXEL_NUM    ${inst_name}_PIXEL_NUM
    set TEXEL_NUM    ${inst_name}_TEXEL_NUM
    set MEMORY_USAGE ${inst_name}_MEMORY_USAGE           
  # set FCT_DEBUG    ${inst_name}_FCT_DEBUG              
  # set ENABLE_RAM   ${inst_name}_ENABLE_RAM              

    set PATH_RASTER_NUM_ARC2LINE     ${inst_name}_PATH_RASTER_NUM_ARC2LINE                       
    set PATH_RASTER_NUM_LINE2CELL    ${inst_name}_PATH_RASTER_NUM_LINE2CELL                      
    set PATH_RASTER_NUM_SORTX        ${inst_name}_PATH_RASTER_NUM_SORTX                          

 
    add_parameter          $PIXEL_NUM INTEGER 1
    set_parameter_property $PIXEL_NUM DISPLAY_NAME "Number of pixels in parallel";
    set_parameter_property $PIXEL_NUM ALLOWED_RANGES {1,2,4,8,16,32}
    set_parameter_property $PIXEL_NUM DESCRIPTION "Choose the number of pixels in parallel for Pipeline. Set 2, 4, 8, 16 or 32 to increase internal Pipeline throughput by 2, 4, 8, 16 or 32 respectively . Note that resources increase with parallelism. 1 = small resources / 32 = high performance.";
    set_parameter_property $PIXEL_NUM DISPLAY_UNITS "Pixels"
    set_parameter_property $PIXEL_NUM AFFECTS_ELABORATION true   
    set_parameter_property $PIXEL_NUM HDL_PARAMETER true
    # not released
   #set_parameter_property $PIXEL_NUM ENABLED false      

    add_parameter          $TEXEL_NUM INTEGER 1
    set_parameter_property $TEXEL_NUM DISPLAY_NAME "Number of texels in parallel";
    set_parameter_property $TEXEL_NUM ALLOWED_RANGES {1,2,4,8,16,32}
    set_parameter_property $TEXEL_NUM DESCRIPTION "Choose the number of texels in parallel for Pipeline. Set 2, 4, 8, 16 or 32 to increase internal Pipeline throughput by 2, 4, 8, 16 or 32 respectively . Note that resources increase with parallelism. 1 = small resources / 32 = high performance.";
    set_parameter_property $TEXEL_NUM DISPLAY_UNITS "Texels"
    set_parameter_property $TEXEL_NUM AFFECTS_ELABORATION true   
    set_parameter_property $TEXEL_NUM HDL_PARAMETER true
  
    add_parameter          $MEMORY_USAGE INTEGER 0
    set_parameter_property $MEMORY_USAGE DISPLAY_NAME "Memory block usage";
    set_parameter_property $MEMORY_USAGE ALLOWED_RANGES {0,1,2,3}
    set_parameter_property $MEMORY_USAGE DESCRIPTION "performance increases with memory block usage. 0 = small resources / 3 = high performance";
    set_parameter_property $MEMORY_USAGE AFFECTS_ELABORATION true        
    set_parameter_property $MEMORY_USAGE HDL_PARAMETER true

    add_parameter          $PATH_RASTER_NUM_ARC2LINE INTEGER 1
    set_parameter_property $PATH_RASTER_NUM_ARC2LINE DISPLAY_NAME "Number of raster arc2lines in parallel";
    set_parameter_property $PATH_RASTER_NUM_ARC2LINE ALLOWED_RANGES {1,2,4}
  # set_parameter_property $PATH_RASTER_NUM_ARC2LINE DESCRIPTION " ";
    set_parameter_property $PATH_RASTER_NUM_ARC2LINE DISPLAY_UNITS "arc2lines"
    set_parameter_property $PATH_RASTER_NUM_ARC2LINE AFFECTS_ELABORATION true   
    set_parameter_property $PATH_RASTER_NUM_ARC2LINE HDL_PARAMETER true

    add_parameter          $PATH_RASTER_NUM_LINE2CELL INTEGER 1
    set_parameter_property $PATH_RASTER_NUM_LINE2CELL DISPLAY_NAME "Number of raster line2cells in parallel";
    set_parameter_property $PATH_RASTER_NUM_LINE2CELL ALLOWED_RANGES {1,2,4}
  # set_parameter_property $PATH_RASTER_NUM_LINE2CELL DESCRIPTION " ";
    set_parameter_property $PATH_RASTER_NUM_LINE2CELL DISPLAY_UNITS "line2cells"
    set_parameter_property $PATH_RASTER_NUM_LINE2CELL AFFECTS_ELABORATION true   
    set_parameter_property $PATH_RASTER_NUM_LINE2CELL HDL_PARAMETER true

    add_parameter          $PATH_RASTER_NUM_SORTX INTEGER 1
    set_parameter_property $PATH_RASTER_NUM_SORTX DISPLAY_NAME "Number of raster sort in parallel";
    set_parameter_property $PATH_RASTER_NUM_SORTX ALLOWED_RANGES {1,2,4}
  # set_parameter_property $PATH_RASTER_NUM_SORTX DESCRIPTION " ";
    set_parameter_property $PATH_RASTER_NUM_SORTX DISPLAY_UNITS "sort"
    set_parameter_property $PATH_RASTER_NUM_SORTX AFFECTS_ELABORATION true   
    set_parameter_property $PATH_RASTER_NUM_SORTX HDL_PARAMETER true
    # not used, not released
    set_parameter_property $PATH_RASTER_NUM_SORTX VISIBLE false
  
  # add_parameter          $FCT_DEBUG INTEGER 0
  # set_parameter_property $FCT_DEBUG DISPLAY_NAME "Debug" 
  # set_parameter_property $FCT_DEBUG DISPLAY_HINT boolean 
  # set_parameter_property $FCT_DEBUG DESCRIPTION "  ";
  # set_parameter_property $FCT_DEBUG HDL_PARAMETER true
  # set_parameter_property $FCT_DEBUG VISIBLE true      

  # add_parameter          $ENABLE_RAM INTEGER 0
  # set_parameter_property $ENABLE_RAM DISPLAY_NAME "Use RAM instead of ROM" 
  # set_parameter_property $ENABLE_RAM DISPLAY_HINT boolean 
  # set_parameter_property $ENABLE_RAM DESCRIPTION "  ";
  # set_parameter_property $ENABLE_RAM HDL_PARAMETER true
  # set_parameter_property $ENABLE_RAM VISIBLE true      

    add_display_item $parent_gui_name "Optimization${inst_id}" GROUP tab
 
    add_display_item "Optimization${inst_id}" $PIXEL_NUM                 PARAMETER
    add_display_item "Optimization${inst_id}" $TEXEL_NUM                 PARAMETER
    add_display_item "Optimization${inst_id}" $MEMORY_USAGE              PARAMETER
    add_display_item "Optimization${inst_id}" $PATH_RASTER_NUM_ARC2LINE  PARAMETER
    add_display_item "Optimization${inst_id}" $PATH_RASTER_NUM_LINE2CELL PARAMETER
    add_display_item "Optimization${inst_id}" $PATH_RASTER_NUM_SORTX     PARAMETER
        
  # add_display_item "Optimization${inst_id}" $FCT_DEBUG     PARAMETER
  # add_display_item "Optimization${inst_id}" $ENABLE_RAM    PARAMETER

  }


# ------------------------------------------------------------------------------------------------
# --                                                                                            --
# -- Misc.                                                                                      --
# --                                                                                            --
# ------------------------------------------------------------------------------------------------

#  proc vgr_connect_parameters { cmp_name inst_name } {
#
#    set_parameter_value ${inst_name}_DESC_BURSTLENGTH_LOG2 [ expr int(ceil((log([ get_parameter_value ${inst_name}_desc_burstlength ])/(log(2))))) ]
#    set_parameter_value ${inst_name}_PATH_BURSTLENGTH_LOG2 [ expr int(ceil((log([ get_parameter_value ${inst_name}_path_burstlength ])/(log(2))))) ]
#    set_parameter_value ${inst_name}_PATH_NUM_POINTS_LOG2  [ expr int(ceil((log([ get_parameter_value ${inst_name}_PATH_RASTER_CACHE_MAX_CHUNKS ])/(log(2))))) ]
#
#    set_instance_parameter ${cmp_name} ${inst_name}_ENABLE_DESC                       [ get_parameter_value ${inst_name}_ENABLE_DESC                      ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_DESC_HAS_DEDICATED_CLK            [ get_parameter_value ${inst_name}_DESC_HAS_DEDICATED_CLK           ]
#    set_instance_parameter ${cmp_name} ${inst_name}_DESC_ADDR8_SIZE                   [ get_parameter_value ${inst_name}_DESC_ADDR8_SIZE                  ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_DESC_BURSTLENGTH_LOG2             [ get_parameter_value ${inst_name}_DESC_BURSTLENGTH_LOG2            ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_DESC_ADDR8_SIZE                   [ get_parameter_value ${inst_name}_DESC_ADDR8_SIZE                  ] 
#
#    set_instance_parameter ${cmp_name} ${inst_name}_PATH_HAS_DEDICATED_CLK            [ get_parameter_value ${inst_name}_PATH_HAS_DEDICATED_CLK           ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_PATH_ADDR8_SIZE                   [ get_parameter_value ${inst_name}_PATH_ADDR8_SIZE                  ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_PATH_BURSTLENGTH_LOG2             [ get_parameter_value ${inst_name}_PATH_BURSTLENGTH_LOG2            ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_PATH_NUM_POINTS_LOG2              [ get_parameter_value ${inst_name}_PATH_NUM_POINTS_LOG2             ]
#    set_instance_parameter ${cmp_name} ${inst_name}_CORE_CLOCK_RATE                   [ get_parameter_value ${inst_name}_CORE_CLOCK_RATE                  ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_PIXEL_NUM           [ get_parameter_value ${inst_name}_PIXEL_NUM          ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_MEMORY_USAGE                      [ get_parameter_value ${inst_name}_MEMORY_USAGE                     ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_DEBUG                         [ get_parameter_value ${inst_name}_FCT_DEBUG                        ]
#    set_instance_parameter ${cmp_name} ${inst_name}_ENABLE_RAM                        [ get_parameter_value ${inst_name}_ENABLE_RAM                       ]
#    set_instance_parameter ${cmp_name} ${inst_name}_OP_ENABLE_IMAGE                   [ get_parameter_value ${inst_name}_OP_ENABLE_IMAGE                  ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_OP_ENABLE_PATH                    [ get_parameter_value ${inst_name}_OP_ENABLE_PATH                   ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_OP_IMAGE_COMPOSE                  [ get_parameter_value ${inst_name}_OP_IMAGE_COMPOSE                 ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_OP_IMAGE_TRANSFORM                [ get_parameter_value ${inst_name}_OP_IMAGE_TRANSFORM               ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_OP_PATH_RASTERIZE                 [ get_parameter_value ${inst_name}_OP_PATH_RASTERIZE                ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_OP_PATH_TRANSFORM                 [ get_parameter_value ${inst_name}_OP_PATH_TRANSFORM                ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_TRANSFORM                     [ get_parameter_value ${inst_name}_FCT_TRANSFORM                    ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_TRANSFORM_3x3                 [ get_parameter_value ${inst_name}_FCT_TRANSFORM_3x3                ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_PATH_RASTER                   [ get_parameter_value ${inst_name}_FCT_PATH_RASTER                  ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_MASKING                       [ get_parameter_value ${inst_name}_FCT_MASKING                      ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_PAINT_GRADIENT                [ get_parameter_value ${inst_name}_FCT_PAINT_GRADIENT               ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_PAINT_BITMAP                 [ get_parameter_value ${inst_name}_FCT_PAINT_BITMAP                ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_PAINT_PATTERN_FILTERING       [ get_parameter_value ${inst_name}_FCT_PAINT_PATTERN_FILTERING      ]
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_IMAGE_INTERPOLATION           [ get_parameter_value ${inst_name}_FCT_IMAGE_INTERPOLATION          ] 
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_IMAGE_INTERPOLATION_FILTERING [ get_parameter_value ${inst_name}_FCT_IMAGE_INTERPOLATION_FILTERING] 
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_COLOR_TRANSFORM               [ get_parameter_value ${inst_name}_FCT_COLOR_TRANSFORM              ]  
#    set_instance_parameter ${cmp_name} ${inst_name}_FCT_BLENDING                      [ get_parameter_value ${inst_name}_FCT_BLENDING                     ]
#    set_instance_parameter ${cmp_name} ${inst_name}_BLENDING_ENABLE_EXTENDED          [ get_parameter_value ${inst_name}_BLENDING_ENABLE_EXTENDED         ]
#
#  # set_instance_parameter ${cmp_name} ${inst_name}_FCT_MORPHING                      [ get_parameter_value ${inst_name}_FCT_MORPHING                     ]  
#  # set_instance_parameter ${cmp_name} ${inst_name}_FCT_FILTER_BLUR                   [ get_parameter_value ${inst_name}_FCT_FILTER_BLUR                  ]
#  # set_instance_parameter ${cmp_name} ${inst_name}_FCT_CURSOR                        [ get_parameter_value ${inst_name}_FCT_CURSOR                       ] 
#  # set_instance_parameter ${cmp_name} ${inst_name}_FCT_CACHE                         [ get_parameter_value ${inst_name}_FCT_CACHE                        ] 
#
#
#
#  }

