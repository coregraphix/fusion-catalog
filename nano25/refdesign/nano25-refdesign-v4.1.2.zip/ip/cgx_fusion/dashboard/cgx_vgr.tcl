
#  cgx_vgr::init                   { }
#  cgx_vgr::get_version            { }
#  cgx_vgr::get_caps               { }
#  cgx_vgr::set_config             { run }
#  cgx_vgr::set_config2            { path_tile_height1 }
#  cgx_vgr::get_config             { }
#  cgx_vgr::get_config2            { }
#  cgx_vgr::get_status             { }
#  cgx_vgr::clr_status             { }
#  cgx_vgr::set_interrupt          { ie_cmd_elab_error }
#  cgx_vgr::get_interrupt          { }
#  cgx_vgr::get_diag               { }
#  cgx_vgr::get_opr                { }
#  cgx_vgr::get_context            { }
#  cgx_vgr::ctx_get_param          { }
#  cgx_vgr::ctx_get_frame          { }
#  cgx_vgr::ctx_get_rect           { }
#  cgx_vgr::ctx_get_matrix         { }
#  cgx_vgr::ctx_get_colortransform { }
#  cgx_vgr::ctx_get_colorramp      { }
#  cgx_vgr::ctx_get_dash           { }
#  cgx_vgr::dump_reg32             { reg_offset32 }
#  cgx_vgr::dump_all               { }
#  cgx_vgr::dashBoard              { }

#  cgx_vgr::set_opts          { }
#  cgx_vgr::get_opts          { }


   
namespace eval cgx_vgr {

    variable IPCORE_PRODUCT 69; # = 0x45                                                                                          
    variable IPCORE_VERSION ${::cgx_fusion::IPCORE_VERSION}                                                                                           

    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    # debug mode
    # 0 => console 
    # 1 => dashboard 
    variable debug 0

    # number of colorramp stop displayed by the dashboard
    variable DASHBOARD_MAX_STOPS        4
    variable DASHBOARD_MAX_DASHPATTERNS 8

       

    #-------------------------- SYS------------------------------

    variable VGR_CSR_DEV_BASE  0x00000000
    variable initialized 0

    #-------------------------- HAL------------------------------
     
    variable VGR_CSR_REG_VERSION                0;  # /* core version                                                                   */                                                                                        
    variable VGR_CSR_REG_SURFACE                1;  # /* core configuration capabilities                                                */    
    variable VGR_CSR_REG_CAPS                   2;  # /* core configuration capabilities                                                */    
    variable VGR_CSR_REG_CAPS2                  3;  # /* core configuration capabilities #2                                             */    
    variable VGR_CSR_REG_INTERRUPT              4;  # /* core interrupt-enable                                                          */    
    variable VGR_CSR_REG_CONTROL                5;  # /* core control (includes interrupt-enable bits)                                  */    
    variable VGR_CSR_REG_STATUS                 6;  # /* core status (includes interrupt-trigger bits)                                  */    
    variable VGR_CSR_REG_DIAG                   7;  # /* core diagnostic information                                                    */    
#   variable VGR_CSR_REG_CLOCK_RATE             8;  # /*                                                                                */    
    variable VGR_CSR_REG_PATH_POOL0_MEM_ADDR64  8;  # /* path pool memory address in 64-bits words                                      */
    variable VGR_CSR_REG_PATH_POOL0_MEM_SIZE64  9;  # /* path pool size in number of points                                             */
    variable VGR_CSR_REG_PATH_POOL1_MEM_ADDR64 10;  # /* path pool memory address in 64-bits words                                      */
    variable VGR_CSR_REG_PATH_POOL1_MEM_SIZE64 11;  # /* path pool size in number in 64-bits words                                      */

    variable VGR_CSR_REG_PATH_STS_SIZE         12;  # /* path peak size in number of points, requires DEF_STATUS_BUSY_BIT=0, independant from actual pool size */
    variable VGR_CSR_REG_PATH_STS_BBOX_BASE    13;                                                                                                               
    variable VGR_CSR_REG_PATH_STS_BBOX_END     14;
    variable VGR_CSR_REG_PATH_STS_PENDING      15;
#   variable VGR_CSR_REG_PATH_CFG_PRIVATE      16;     

    variable VGR_CSR_REG_DBG_CONFIG            16                                                                                                                 

    variable VGR_CSR_REG_DESC_NEXT_MEM_ADDR8   17                                                             
    variable VGR_CSR_REG_DESC_NEXT_MEM_SIZE32  18                                                             
    variable VGR_CSR_REG_DESC_CMD              19                                                             
        
    variable VGR_CSR_REG_CMD_PUSH_ID           20                                                                                                                           
    variable VGR_CSR_REG_CMD_PUSH_DATA         21
    variable VGR_CSR_REG_CMD_STATUS            22

    variable VGR_CSR_REG_CTX_PARAM_USER        23 
                                                                                                                                
    variable VGR_CSR_REG_CMD_DBG_ID            24                                                                                                                            
    variable VGR_CSR_REG_CMD_DBG_OFST          25                                                                                                                            
    variable VGR_CSR_REG_CMD_DBG_DATA          26                                                                                                                            
    variable VGR_CSR_REG_CMD_DBG_CTL           27                                                                                                                            
    variable VGR_CSR_REG_CMD_DBG_STS           28                                                                                                                            

 #  variable DEF_CSR_REG_RAM_CTX               29                                                                                                               
 #  variable DEF_CSR_REG_RAM_ADDR              30; # write only                                                                                                               
    variable DEF_CSR_REG_CLOCK_FPS             30; # read only                                                                                                               
    variable VGR_CSR_REG_PATH_POOL1_MEM_PEAK64 31                                                                                                               
    
 #  variable VGR_CSR_REG_BASE_SFCTRL           32                                 
    
    variable VGR_CSR_REG_NUMBER                32    
  
    
 #  variable DEF_POOL_PEAK_OVERFLOW_MSK  0x80000000 
 #  variable DEF_POOL_PEAK_OVERFLOW_OFST 31

        
    #/* VGR_CSR_REG_VERSION bitfields */ 
    variable VGR_CSR_VERSION_ID_MSK     0xFF        
    variable VGR_CSR_VERSION_ID_OFST    0           
    variable VGR_CSR_VERSION_BUILD_MSK  0xFF00      
    variable VGR_CSR_VERSION_BUILD_OFST 8           
    variable VGR_CSR_VERSION_MINOR_MSK  0xFF0000    
    variable VGR_CSR_VERSION_MINOR_OFST 16          
    variable VGR_CSR_VERSION_MAJOR_MSK  0x0F000000   
    variable VGR_CSR_VERSION_MAJOR_OFST 24          
    
    
    #/* VGR_CSR_REG_CAPS bitfields */ 

    variable VGR_CSR_CAPS_ENABLE_DEBUG_MSK           0x1
    variable VGR_CSR_CAPS_ENABLE_DEBUG_OFST          0
    variable VGR_CSR_CAPS_ENABLE_SCISSORING_MSK      0x2
    variable VGR_CSR_CAPS_ENABLE_SCISSORING_OFST     1
    variable VGR_CSR_CAPS_ENABLE_PATH_STROKE_MSK     0x4
    variable VGR_CSR_CAPS_ENABLE_PATH_STROKE_OFST    2
    variable VGR_CSR_CAPS_ENABLE_MASKING_MSK         0x8
    variable VGR_CSR_CAPS_ENABLE_MASKING_OFST        3
    variable VGR_CSR_CAPS_ENABLE_PAINT_GRADIENT_MSK  0x10
    variable VGR_CSR_CAPS_ENABLE_PAINT_GRADIENT_OFST 4
    variable VGR_CSR_CAPS_ENABLE_PAINT_BITMAP_MSK    0x20
    variable VGR_CSR_CAPS_ENABLE_PAINT_BITMAP_OFST   5

    #/* VGR_CSR_REG_CAPS2 */   
    variable VGR_CSR_CAPS2_MAX_SCISSOR_RECTS_MSK    0x3F       
    variable VGR_CSR_CAPS2_MAX_SCISSOR_RECTS_OFST   0
    variable VGR_CSR_CAPS2_MAX_GRADIENT_STOPS_MSK   0xFC0       
    variable VGR_CSR_CAPS2_MAX_GRADIENT_STOPS_OFST  6
    variable VGR_CSR_CAPS2_MAX_DASH_PATTERNS_MSK    0xF000       
    variable VGR_CSR_CAPS2_MAX_DASH_PATTERNS_OFST   12

    #/* VGR_CSR_REG_INTERRUPT */   
    #/* Interrupts-enable mask to disable(default)/enable interrupts. */
    variable VGR_CSR_INTERRUPT_ENABLE_MSK  0xFF
    variable VGR_CSR_INTERRUPT_ENABLE_OFST 0
    
    #/* CONTROL & STATUS Interrupts bitfields (VGR_CSR_CONTROL_IRQ_ENABLE_MSK, VGR_CSR_STATUS_IRQ_ACTIVE_MSK)  */
        variable VGR_CSR_IRQ_BIT_DIAG_ERROR_MSK            0x1;  #/*  diagnostic (reserved usage) */                              
        variable VGR_CSR_IRQ_BIT_DIAG_ERROR_OFST           0                                 
        variable VGR_CSR_IRQ_BIT_CMD_ELAB_ERROR_MSK        0x2;  #/*  command elaboration */                              
        variable VGR_CSR_IRQ_BIT_CMD_ELAB_ERROR_OFST       1                                 
        variable VGR_CSR_IRQ_BIT_PATH_POOL0_OVERFLOW_MSK   0x4;  #/*pool0 overflow */                              
        variable VGR_CSR_IRQ_BIT_PATH_POOL0_OVERFLOW_OFST  2                                 
        variable VGR_CSR_IRQ_BIT_PATH_POOL1_OVERFLOW_MSK   0x8;  #/*pool1 overflow */                              
        variable VGR_CSR_IRQ_BIT_PATH_POOL1_OVERFLOW_OFST  3                                 
       
    #/* VGR_CSR_REG_CONTROL bitfields */ 
    variable VGR_CSR_CONTROL_RUN_MSK       0x1; #   # 0(default)/1 = frame processing Off/On
    variable VGR_CSR_CONTROL_RUN_OFST      0
 
           
    #/* VGR_CSR_REG_STATUS bitfields */ 
    variable VGR_CSR_STATUS_BUSY_MSK                  0x1         
    variable VGR_CSR_STATUS_BUSY_OFST                 0                                                          
    variable VGR_CSR_STATUS_IRQ_MSK                   0x2         
    variable VGR_CSR_STATUS_IRQ_OFST                  1                                                          
                                                     
    variable VGR_CSR_STATUS_CMD_BUSY_MSK              0x10   #/* 1 = ongoing commands execution */             
    variable VGR_CSR_STATUS_CMD_BUSY_OFST             4                                                           
    variable VGR_CSR_STATUS_CMD_ELAB_BUSY_MSK         0x20   #/* 1 = fifo command is under elaboration */     
    variable VGR_CSR_STATUS_CMD_ELAB_BUSY_OFST        5                                                          
    variable VGR_CSR_STATUS_CMD_FIFO_EMPTY_MSK        0x40         
    variable VGR_CSR_STATUS_CMD_FIFO_EMPTY_OFST       6                                                          
    variable VGR_CSR_STATUS_CMD_FIFO_FULL_MSK         0x80         
    variable VGR_CSR_STATUS_CMD_FIFO_FULL_OFST        7                                                          
    variable VGR_CSR_STATUS_CMD_FIFO_ALMOSTFULL_MSK   0x100         
    variable VGR_CSR_STATUS_CMD_FIFO_ALMOSTFULL_OFST  8                                                          

    variable VGR_CSR_STATUS_IRQ_ACTIVE_MSK            0xFF0000 # /* 0/1 = interrupt active. read the register to get information about active interrupts. write register to clears the interrupts */        
    variable VGR_CSR_STATUS_IRQ_ACTIVE_OFST           16                                                          
        
    
 #  #/* VGR_CSR_REG_PATH_CFG_PRIVATE bitfields */ 
 #  
 #    variable VGR_CSR_PATH_RASTER_TILE_HEIGHT1_MSK   0xFF; # height1 = height - 1    
 #    variable VGR_CSR_PATH_RASTER_TILE_HEIGHT1_OFST  0           
 
    
    
    #/* VGR_CSR_REG_PATH_STS_SIZE bitfields */ 

    variable VGR_CSR_PATH_PTS_MAX_SRC_MSK   0xFFFF     
    variable VGR_CSR_PATH_PTS_MAX_SRC_OFST  0          
    variable VGR_CSR_PATH_PTS_MAX_DST_MSK   0xFFFF0000 
    variable VGR_CSR_PATH_PTS_MAX_DST_OFST  16         


    #/* VGR_CSR_REG_PATH_STS_PENDING bitfields */ 

    variable VGR_CSR_PATH_PENDING_MAX_PATHDATA_MSK   0xFFFF     
    variable VGR_CSR_PATH_PENDING_MAX_PATHDATA_OFST  0          
    variable VGR_CSR_PATH_PENDING_MAX_PTS_MSK        0xFFFF0000 
    variable VGR_CSR_PATH_PENDING_MAX_PTS_OFST       16         




  # VGR_CSR_REG_CMD_STATUS reg 
  variable VGR_CSR_CMD_STS_FIFO_USED_MSK  0xFFFF                                  
  variable VGR_CSR_CMD_STS_FIFO_USED_OFST 0                                     
  variable VGR_CSR_CMD_STS_COUNT_MSK      0xFFFF0000                                 
  variable VGR_CSR_CMD_STS_COUNT_OFST     16                                    


  #  VGR_CSR_REG_CMD_DBG_ID, VGR_CSR_REG_CMD_PUSH_ID reg
# variable VGR_CSR_CMD_ID_OPR_MSK        0x1                                      
# variable VGR_CSR_CMD_ID_OPR_OFST       0                                       
  variable VGR_CSR_CMD_ID_DO_MSK         0x3                                      
  variable VGR_CSR_CMD_ID_DO_OFST        0                                       
  variable VGR_CSR_CMD_ID_REG_NUM_MSK    0xFFF0                                       
  variable VGR_CSR_CMD_ID_REG_NUM_OFST   4                                        
  variable VGR_CSR_CMD_ID_CLASS_MSK      0xF0000                                      
  variable VGR_CSR_CMD_ID_CLASS_OFST     16                                        
  variable VGR_CSR_CMD_ID_TYPE_MSK       0x1F00000                                     
  variable VGR_CSR_CMD_ID_TYPE_OFST      20 

      variable VGR_CMD_DO_NOP         0                                  
      variable VGR_CMD_DO_SET_DEFAULT 1                                 
      variable VGR_CMD_DO_SET_CONTEXT 2                                  
      variable VGR_CMD_DO_OPR         3                                 
      variable VGR_CMD_DO_NUMBER      4  


  # DEF_VGR_CSR_REG_CMD_DBG_CONTROL
  variable VGR_CSR_DBG_CTL_START_MSK     0x1                                   
  variable VGR_CSR_DBG_CTL_START_OFST    0                                     

  # DEF_VGR_CSR_REG_CMD_DBG_STATUS
  variable VGR_CSR_DBG_STS_READY_MSK     0x1                                    
  variable VGR_CSR_DBG_STS_READY_OFST    0                                      


  # VGR_CSR_REG_DBG_CONFIG
  variable VGR_CSR_DBG_OPTS_MSK   0x1FFF                                                                      
  variable VGR_CSR_DBG_OPTS_OFST  0                                                                               
 
  # VGR_CSR_REG_DESC_CMD 
  variable VGR_CSR_DESC_START_MSK  0x1
  variable VGR_CSR_DESC_START_OFST 0
 
# #  VGR_CSR_REG_DBG_BREAK                                                                                                                
# variable VGR_CSR_DBG_BREAK_EN_MSK  0x1                                                                                 
# variable VGR_CSR_DBG_BREAK_EN_OFST 0                                                                                
  
# variable OPT_FORCE_UNDO_PIPELINED_MSK   0x1                                                                               
# variable OPT_FORCE_UNDO_PIPELINED_OFST  0                                                                               
# variable OPT_FORCE_UNDO_ALL_MSK         0x2  
# variable OPT_FORCE_UNDO_ALL_OFST        1  
# variable OPT_FORCE_UNDO_RECT_MSK        0x4 
# variable OPT_FORCE_UNDO_RECT_OFST       2 
# variable OPT_FORCE_UNDO_IMAGE_MSK       0x8 
# variable OPT_FORCE_UNDO_IMAGE_OFST      3 
# variable OPT_FORCE_UNDO_PATH_MSK        0x10
# variable OPT_FORCE_UNDO_PATH_OFST       4 
# variable OPT_FORCE_UNDO_STROKED_MSK     0x20  
# variable OPT_FORCE_UNDO_STROKED_OFST    5  
# variable OPT_FORCE_UNDO_FILLED_MSK      0x40 
# variable OPT_FORCE_UNDO_FILLED_OFST     6 
# variable OPT_FORCE_UNDO_BLENDING_MSK    0x80 
# variable OPT_FORCE_UNDO_BLENDING_OFST   7 
# variable OPT_FORCE_UNDO_MASKING_MSK     0x100 
# variable OPT_FORCE_UNDO_MASKING_OFST    8 
# variable OPT_FORCE_UNDO_PAINTING_MSK    0x200 
# variable OPT_FORCE_UNDO_PAINTING_OFST   9 

  # VGR_CSR_DBG_OPTS_MSK
  variable OPT_FORCE_UNDO_PIPELINED_BIT           0                                                                               
  variable OPT_FORCE_UNDO_ALL_BIT                 1  
  variable OPT_FORCE_UNDO_RECT_BIT                2 
  variable OPT_FORCE_UNDO_IMAGE_BIT               3 
  variable OPT_FORCE_UNDO_PATH_BIT                4 
  variable OPT_FORCE_UNDO_STROKED_BIT             5  
  variable OPT_FORCE_UNDO_FILLED_BIT              6 
  variable OPT_FORCE_UNDO_BLENDING_BIT            7 
  variable OPT_FORCE_UNDO_MASKING_BIT             8 
  variable OPT_FORCE_UNDO_PAINTING_BIT            9 
  variable OPT_FORCE_UNDO_OPT_RECT_BIT           10 
  variable OPT_FORCE_UNDO_OPT_GRAY_BIT           11 
 #variable OPT_FORCE_UNDO_PAINT_MATRIX_NORM_BIT  12 


  # /*=========================== Context ===================================*/

    #  VGR_CSR_CTX_ID_CLASS_LSB field
    variable VGR_CSR_CTX_CLASS_PARAM           0                                   
    variable VGR_CSR_CTX_CLASS_FRAME           1                                   
    variable VGR_CSR_CTX_CLASS_RECT            2                                   
    variable VGR_CSR_CTX_CLASS_MATRIX          3       
    variable VGR_CSR_CTX_CLASS_COLORRAMP       4
    variable VGR_CSR_CTX_CLASS_DASHS           5
    variable VGR_CSR_CTX_CLASS_NUMBER          6                                   
#   variable VGR_CSR_CTX_CLASS_COLORTRANSFORM   


    variable VGR_CSR_CTX_CLASS_REGNUM_PARAM    1                                  
    variable VGR_CSR_CTX_CLASS_REGNUM_FRAME    8                                  
    variable VGR_CSR_CTX_CLASS_REGNUM_RECT     2                                  
    variable VGR_CSR_CTX_CLASS_REGNUM_MATRIX   9                                 

                                                                             
    #  VGR_CSR_CTX_CLASS_FRAME indexes
    variable VGR_CSR_CTX_FRAME_SURFACE         0  
    variable VGR_CSR_CTX_FRAME_MASK            1   
    variable VGR_CSR_CTX_FRAME_IMAGE           2   
    variable VGR_CSR_CTX_FRAME_FILTER          3   
    variable VGR_CSR_CTX_FRAME_PATTERN_FILL    4   
    variable VGR_CSR_CTX_FRAME_PATTERN_STROKE  5   
    variable VGR_CSR_CTX_FRAME_NUMBER          6   


    #  VGR_CSR_CTX_CLASS_RECT indexes
    variable VGR_CSR_CTX_RECT_SCISSOR_START    0 
    variable VGR_CSR_CTX_RECT_SCISSOR_END      3  
    variable VGR_CSR_CTX_RECT_NUMBER           4  
  # variable VGR_CSR_CTX_RECT_CLIP             0 
  # variable VGR_CSR_CTX_RECT_MASK             1  

 
    #  VGR_CSR_CTX_CLASS_MATRIX indexes
    variable VGR_CSR_CTX_MATRIX_SHAPE          0  
    variable VGR_CSR_CTX_MATRIX_PAINT_FILL     1   
    variable VGR_CSR_CTX_MATRIX_PAINT_STROKE   2   
    variable VGR_CSR_CTX_MATRIX_NUMBER         3   


    #  VGR_CSR_CTX_CLASS_COLORRAMP indexes
    variable VGR_CSR_CTX_GRADIENT_FILL     0  
    variable VGR_CSR_CTX_GRADIENT_STROKE   1   
    variable VGR_CSR_CTX_GRADIENT_NUMBER   2   
 

    # VGR_CSR_CTX_PARAM_PAINT
    variable VGR_CSR_PAINT_PARAM_TYPE       0   
    variable VGR_CSR_PAINT_PARAM_COLOR      1 
    variable VGR_CSR_PAINT_PARAM_GRADIENT_K 2 
    variable VGR_CSR_PAINT_PARAM_NUMBER     3

        # VGR_CMD_PAINT_PARAM_TYPE
        variable VGR_CSR_PAINT_DATATYPE_MSK          0x3
        variable VGR_CSR_PAINT_DATATYPE_OFST         0
        variable VGR_CSR_PAINT_SPREAD_MODE_MSK       0x30
        variable VGR_CSR_PAINT_SPREAD_MODE_OFST      4
        variable VGR_CSR_PAINT_PATTERN_QUALITY_MSK   0x300
        variable VGR_CSR_PAINT_PATTERN_QUALITY_OFST  8
        variable VGR_CSR_PAINT_EN_COLORMULTIPLY_MSK  0x1000
        variable VGR_CSR_PAINT_EN_COLORMULTIPLY_OFST 12
        variable VGR_CSR_PAINT_GRADIENT_TYPE_MSK     0x10000                                                                                                             
        variable VGR_CSR_PAINT_GRADIENT_TYPE_OFST    16  

            # /* VGR_CSR_PAINT_DATATYPE_MSK */
            variable VGR_CSR_PAINT_COLOR	  0
            variable VGR_CSR_PAINT_GRADIENT	1
            variable VGR_CSR_PAINT_PATTERN	2
 
            # /* VGR_CSR_PAINT_GRADIENT_TYPE_MSK */
            variable VGR_CSR_GRADIENT_TYPE_LINEAR	 0
            variable VGR_CSR_GRADIENT_TYPE_RADIAL	 1
            variable VGR_CSR_GRADIENT_TYPE_ANGULAR 2
                
            # /* VGR_CSR_PAINT_SPREAD_MODE_MSK */
            variable VGR_CSR_PAINT_SPREAD_MODE_PAD	    0
            variable VGR_CSR_PAINT_SPREAD_MODE_REPEAT	  1
            variable VGR_CSR_PAINT_SPREAD_MODE_REFLECT	2
            
            # /* VGR_CSR_PAINT_PATTERN_QUALITY_MSK */
            variable VGR_CSR_QUALITY_NONANTIALIASED  0     
            variable VGR_CSR_QUALITY_FASTER          1    
            variable VGR_CSR_QUALITY_BETTER          2    
            variable VGR_CSR_QUALITY_NUMBER          3
  
       
#   variable VGR_CSR_CTX_PARAM_DEFAULT                         0                                      
    variable VGR_CSR_CTX_PARAM_CLEAR_COLOR                     1                                      
#   variable VGR_CSR_CTX_PARAM_CLIP_ENABLE                     2                                      
#   variable VGR_CSR_CTX_PARAM_SET0                            2                                      
    variable VGR_CSR_CTX_PARAM_MASK_ENABLE                     3                                      
    variable VGR_CSR_CTX_PARAM_MASK                            4                                      
    variable VGR_CSR_CTX_PARAM_PAINT_FILL_BASE                 5                                      
    variable VGR_CSR_CTX_PARAM_PAINT_FILL_END                  7                                      
    variable VGR_CSR_CTX_PARAM_PAINT_STROKE_BASE               8                                      
    variable VGR_CSR_CTX_PARAM_PAINT_STROKE_END               10                                      
    variable VGR_CSR_CTX_PARAM_BLEND_MODE                     11                                      
    variable VGR_CSR_CTX_PARAM_PATH_FILLRULE                  12                                      
#   variable                                                  13                                                 
    variable VGR_CSR_CTX_PARAM_SCISSOR                        14                                                 
    variable VGR_CSR_CTX_PARAM_PATH_STROKE_STYLE              15                                                 
    variable VGR_CSR_CTX_PARAM_PATH_STROKE_MITER_LIMIT        16                                                 
    variable VGR_CSR_CTX_PARAM_PATH_STROKE_DASH_PHASE         17                                                 
    variable VGR_CSR_CTX_PARAM_SURFACE                        18                                                 
    variable VGR_CSR_CTX_PARAM_GLYPH_ORIGIN_X                 19                                                 
    variable VGR_CSR_CTX_PARAM_GLYPH_ORIGIN_Y                 20                                                 
    variable VGR_CSR_CTX_PARAM_NUMBER                         21                                      
                                                     
    # /* coefficients mapping for 3x2 and 3x3 */
    variable VGR_CSR_MATRIX_REG_SX             0 
    variable VGR_CSR_MATRIX_REG_SHX            1 
    variable VGR_CSR_MATRIX_REG_TX             2 
    variable VGR_CSR_MATRIX_REG_SHY            3 
    variable VGR_CSR_MATRIX_REG_SY             4 
    variable VGR_CSR_MATRIX_REG_TY             5 
  # variable VGR_CSR_MATRIX_REG_W0             6 
  # variable VGR_CSR_MATRIX_REG_W1             7 
  # variable VGR_CSR_MATRIX_REG_W2             8 
    variable VGR_CSR_MATRIX_REG_NUMBER         6 


 
 #  # /* VGR_CSR_CTX_PARAM_SET0 */
 #  variable VGR_CSR_MASK_PAINT_CODE_MSK    0x3 
 #  variable VGR_CSR_MASK_PAINT_CODE_OFST   0    
 #
 #      variable VGR_PAINT_CODE_DEFAULT 0                                                                                                                                  
 #      variable VGR_PAINT_CODE_RED     1                                                                                                
 #      variable VGR_PAINT_CODE_GREEN   2                                                                                                  
 #      variable VGR_PAINT_CODE_BLUE    3                                                                                                 
 #      variable VGR_PAINT_CODE_NUMBER  4                                                                                  

    
    # /* VGR_CSR_CTX_PARAM_MASK */
    variable VGR_CSR_MASK_COLOR_PLANE_MSK    0x3 
    variable VGR_CSR_MASK_COLOR_PLANE_OFST   0    
    variable VGR_CSR_MASK_COLOR_INVERT_MSK   0x4  
    variable VGR_CSR_MASK_COLOR_INVERT_OFST  2    

                                                    
    # /* VGR_CSR_CTX_PARAM_BLEND_MODE */
    variable VGR_DEF_VG_BLEND_CLEAR 	    0
    variable VGR_DEF_VG_BLEND_SRC 	      1
    variable VGR_DEF_VG_BLEND_DST 	      2
    variable VGR_DEF_VG_BLEND_SRC_OVER 	  3
    variable VGR_DEF_VG_BLEND_DST_OVER 	  4
    variable VGR_DEF_VG_BLEND_SRC_IN 	    5
    variable VGR_DEF_VG_BLEND_DST_IN 	    6
    variable VGR_DEF_VG_BLEND_SRC_OUT 	  7
    variable VGR_DEF_VG_BLEND_DST_OUT 	  8
    variable VGR_DEF_VG_BLEND_SRC_ATOP 	  9
    variable VGR_DEF_VG_BLEND_DST_ATOP   10
    variable VGR_DEF_VG_BLEND_XOR 	     11
    variable VGR_DEF_VG_BLEND_NUMBER     12 
    
    # /* VGR_CSR_CTX_PARAM_PATH_FILL_RULE */
    variable VGR_DEF_VG_FILLRULE_EVEN_ODD 	    0
    variable VGR_DEF_VG_FILLRULE_NON_ZERO 	    1


 #  #  VGR_CSR_CTX_CLASS_COLORTRANSFORM  
 #  variable VGR_CSR_COLORTRANSFORM_REG_A        0                                      
 #  variable VGR_CSR_COLORTRANSFORM_REG_R        1                                      
 #  variable VGR_CSR_COLORTRANSFORM_REG_G        2                                      
 #  variable VGR_CSR_COLORTRANSFORM_REG_B        3                                      
 #  variable VGR_CSR_COLORTRANSFORM_REG_NUMBER   4                                      
 #
 #  variable VGR_CSR_COLORTRANSFORM_MUL_MSK   0xFFFF 
 #  variable VGR_CSR_COLORTRANSFORM_MUL_OFST  0    
 #  variable VGR_CSR_COLORTRANSFORM_ADD_MSK   0xFFFF0000     
 #  variable VGR_CSR_COLORTRANSFORM_ADD_OFST  8    
 #  
 #  variable VGR_CSR_COLORTRANSFORM_MUL_FIX    7; # /* 1.0 => val=128 => mul=+100%         */
 #  variable VGR_CSR_COLORTRANSFORM_MUL_SIZE   9; # /* val[-128, +128] = mul[-100%, +100%] */
 #  variable VGR_CSR_COLORTRANSFORM_ADD_FIX    8; # /* 1.0 => val=256 => add=+256          */    
 #  variable VGR_CSR_COLORTRANSFORM_ADD_SIZE  10; # /* val[-256, +256] = add[-256, +256]   */


    # /*=========================== Operations ===================================*/
    
    #  VGR_CSR_CTX_ID_CLASS_MSK indexes
    variable VGR_CSR_OPR_CLASS_RECT     0                                                                                                          
    variable VGR_CSR_OPR_CLASS_IMAGE    1                                                                                                          
    variable VGR_CSR_OPR_CLASS_PATH     2                                                                                                          
    variable VGR_CSR_OPR_CLASS_NUMBER   3                                                                                                          

    
#   variable VGR_CSR_OPR_REG_ID            0                                                                                               
    variable VGR_CSR_OPR_REG_RECT_POSMIN   0                                                                                               
    variable VGR_CSR_OPR_REG_RECT_POSMAX   1                                                                                               
    variable VGR_CSR_OPR_REG_POSITION      2                                                                                               
    variable VGR_CSR_OPR_REG_ARG_BASE      3                                                                                               
    variable VGR_CSR_OPR_REG_NUMBER        3 
    

    variable VGR_CSR_OPR_PATH_ARG_DATA_L    0   
    variable VGR_CSR_OPR_PATH_ARG_DATA_H    1   
    variable VGR_CSR_OPR_PATH_ARG_PARAM     2   
    variable VGR_CSR_OPR_PATH_ARG_SCALE_X   3   
    variable VGR_CSR_OPR_PATH_ARG_SCALE_Y   4   
    variable VGR_CSR_OPR_PATH_ARG_BIAS_X    5   
    variable VGR_CSR_OPR_PATH_ARG_BIAS_Y    6   
    variable VGR_CSR_OPR_PATH_ARG_NUMBER    7   
                                        
    variable VGR_CSR_OPR_RECT_ARG_NUMBER    0   
    variable VGR_CSR_OPR_IMAGE_ARG_NUMBER   0   

    variable VGR_CSR_OPR_MAX_ARG_NUMBER    $VGR_CSR_OPR_PATH_ARG_NUMBER   

    #/* VGR_CSR_OPR_CLASS_RECT */
    variable VGR_CSR_OPR_RECT_CLEAR   0                                      
    variable VGR_CSR_OPR_RECT_FILL    1                                      
    variable VGR_CSR_OPR_RECT_BOUND   2                                      
    variable VGR_CSR_OPR_RECT_NUMBER  3
    
    #/*  VGR_CSR_OPR_CLASS_IMAGE */
    variable VGR_CSR_OPR_IMAGE_COMPOSE       0                                                          
    variable VGR_CSR_OPR_IMAGE_TRANSFORM     1                                                          
    variable VGR_CSR_OPR_IMAGE_COPY          2                                                          
    variable VGR_CSR_OPR_IMAGE_REMAP         3                                                          
    variable VGR_CSR_OPR_IMAGE_NUMBER        4 
    
    #/*  VGR_CSR_OPR_CLASS_PATH */
    variable VGR_CSR_OPR_PATH_DRAW       0                          
    variable VGR_CSR_OPR_PATH_BBOX_ROUGH 1                         
    variable VGR_CSR_OPR_PATH_BBOX_TIGHT 2                         
    variable VGR_CSR_OPR_PATH_NUMBER     3 
      
    #/* VGR_CSR_OPR_PATH_ARG_PARAM */
    variable VGR_CSR_OPR_PATH_NB_POINT_MSK   0xFFFF
    variable VGR_CSR_OPR_PATH_NB_POINT_OFST  0
    variable VGR_CSR_OPR_PATH2_NB_POINT_REG  $VGR_CSR_OPR_PATH_ARG_PARAM 
    variable VGR_CSR_OPR_PATH_PAINTMODE_MSK  0x30000
    variable VGR_CSR_OPR_PATH_PAINTMODE_OFST 16
    variable VGR_CSR_OPR_PATH_DO_MSK         0xF00000
    variable VGR_CSR_OPR_PATH_DO_OFST        20
    variable VGR_CSR_OPR_PATH_CHUNKED_MSK    0x1000000
    variable VGR_CSR_OPR_PATH_CHUNKED_OFST   24
    variable VGR_CSR_OPR_PATH_GLYPH_MSK      0x2000000
    variable VGR_CSR_OPR_PATH_GLYPH_OFST     25

    
    #/* VGR_CSR_OPR_REG_POSITION */
    variable VGR_CSR_OPR_POSITION_X_MSK    0xFFFF0000
    variable VGR_CSR_OPR_POSITION_X_OFST   16        
    variable VGR_CSR_OPR_POSITION_Y_MSK    0xFFFF
    variable VGR_CSR_OPR_POSITION_Y_OFST   0       


    # /*== GRADIENT =========================================================*/
    
    variable VGR_DEF_RAMP_STOP_REG_OFFSET  0; # /* stop offset [0..255]                  */
    variable VGR_DEF_RAMP_STOP_REG_COLOR   1; # /* stop color (ARGB alpha-premultiplied) */
    variable VGR_DEF_RAMP_STOP_REG_NUMBER  2
    
    variable VGR_DEF_STOP_OFFSET_MSK     0xFF
    variable VGR_DEF_STOP_OFFSET_OFST    0
    variable VGR_DEF_STOP_OFFSETINV_MSK  0xFFFF0000
    variable VGR_DEF_STOP_OFFSETINV_OFST 16    
    variable VGR_DEF_STOP_COLOR_MSK      0xFFFFFFFF
    variable VGR_DEF_STOP_COLOR_OFST     0
 

  # /*== STROKE ===========================================================*/


  # /* VGR_CSR_CTX_PARAM_PATH_STROKE_STYLE */
  variable VGR_CSR_STROKE_LINEWIDTH_MSK   0xFFFFFF 
  variable VGR_CSR_STROKE_LINEWIDTH_OFST  0    
  variable VGR_CSR_STROKE_LINEJOIN_MSK    0xF000000  
  variable VGR_CSR_STROKE_LINEJOIN_OFST   24    
  variable VGR_CSR_STROKE_CAP_MSK         0xF0000000  
  variable VGR_CSR_STROKE_CAP_OFST        28    
# variable VGR_CSR_STROKE_DASHCOUNT_MSK   0xF000000  
# variable VGR_CSR_STROKE_DASHCOUNT_OFST  24    

  # /* VGR_CSR_STROKE_LINEJOIN_MSK */
  # values comply with <dash_ctx_path_stroke_linejoin> 
  variable VGR_LINEJOIN_ROUND      0                                                  
  variable VGR_LINEJOIN_BEVEL      1                                                  
  variable VGR_LINEJOIN_MITER      2                                                  
  variable VGR_LINEJOIN_MITER_CLIP 3                                                  
  variable VGR_LINEJOIN_NUMBER     4                                                  


  # /* VGR_CSR_STROKE_CAP_MSK */
  variable VGR_CAP_BUTT   0                                                  
  variable VGR_CAP_ROUND  1                                                  
  variable VGR_CAP_SQUARE 2                                                  
  variable VGR_CAP_NUMBER 3                                                  

     
    #/*== BBOX =============================================================*/
    
    #/*-- Registers --*/
    
    variable VGR_DEF_BBOX_REG_MIN     0; # /* valid | xmin  | ymin */
    variable VGR_DEF_BBOX_REG_MAX     1; # /*         xmax  | ymax */
    variable VGR_DEF_BBOX_REG_NUMBER  2
    
    #/*-- Fields --*/
    
    variable VGR_DEF_BBOX_X_MSK      0x7FFF0000     
    variable VGR_DEF_BBOX_X_OFST     16            
                                    
    variable VGR_DEF_BBOX_Y_MSK      0xFFFF     
    variable VGR_DEF_BBOX_Y_OFST     0            
    
    variable VGR_DEF_BBOX_VALID_MSK  0x80000000     
    variable VGR_DEF_BBOX_VALID_OFST 31            


    
    #--------------------------private functions ------------------------------

    proc ATH_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_vgr::$field_name\_REG 
            set str_field_msk   ::cgx_vgr::$field_name\_MSK 
            set str_field_ofst  ::cgx_vgr::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc ATH_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_vgr::$field_name\_MSK 
        set str_field_ofst ::cgx_vgr::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

     
    #--------------------------public functions ------------------------------
 
 
    proc init { } {
        puts stdout "Fusion-VGR init:"

        if { ${::cgx_vgr::debug} == 1 } {
            set dash_path ${::cgx_vgr::dash_path} 
          # set dev_base [ dashboard_get_property $dash_path dash_dev_base text ]
        } 
        set instance_idx 0   
                
       #set ::cgx_vgr::VGR_CSR_DEV_BASE ${dev_base} 
        set ::cgx_vgr::VGR_CSR_DEV_BASE [ cgx_fusion::get_dev_base ${cgx_fusion::DEF_CLASS_GFX} $instance_idx ]

        if { ${::cgx_vgr::debug} == 1 } {
            set dash_path ${::cgx_vgr::dash_path} 
            dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_vgr::VGR_CSR_DEV_BASE} ]
        } 
        
        set dev_success [ ::cgx_vgr::get_version ];  
        
        if {${dev_success} == 1} {
          # set ::cgx_vgr::VGR_CSR_DEV_BASE ${dev_base} 
            set ::cgx_vgr::initialized 1
        } else {
            set ::cgx_vgr::initialized 0
        } 

        if { ${::cgx_vgr::debug} == 1 } {
            set dash_path ${::cgx_vgr::dash_path} 
            if {${dev_success} == 1} {
                dashboard_set_property $dash_path grp_core  visible true
            } else {
            	  puts stdout " DEVICE not detected "
                dashboard_set_property $dash_path grp_core  visible false
                dashboard_set_property $dash_path grp_csr   visible false
            } 
        } 
 
    }
       
 
    proc get_version { } {

        set csr_base8 ${::cgx_vgr::VGR_CSR_DEV_BASE} 
        
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_vgr::VGR_CSR_REG_VERSION} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set v_id    [ ATH_GET_FIELD $reg VGR_CSR_VERSION_ID ] ;                              
        set v_build [ ATH_GET_FIELD $reg VGR_CSR_VERSION_BUILD ] ;                           
        set v_minor [ ATH_GET_FIELD $reg VGR_CSR_VERSION_MINOR ] ;                           
        set v_major [ ATH_GET_FIELD $reg VGR_CSR_VERSION_MAJOR ] ;                           
        set version $v_major.$v_minor                            

        if {$v_id == ${::cgx_vgr::IPCORE_PRODUCT} } {
          puts stdout "    Version = $v_major.$v_minor, Build = $v_build"
          if { $version == ${::cgx_vgr::IPCORE_VERSION} } {
            set success 1
          } else {
            set success 0
            puts stdout " ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_vgr::IPCORE_VERSION} )"
          }
        } else {
          set success 0
          puts stdout " ERROR core id = $v_id, reg = $reg "
        }
        return $success
        
        
    }
        
 

    proc get_caps { } {
                
        set csr_base8 ${::cgx_vgr::VGR_CSR_DEV_BASE} 

        open_service master ${::boardInit::masterPath}        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_vgr::VGR_CSR_REG_CAPS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set caps_enable_debug          [ ATH_GET_FIELD $reg VGR_CSR_CAPS_ENABLE_DEBUG          ] ; 
        set caps_enable_path_stroke    [ ATH_GET_FIELD $reg VGR_CSR_CAPS_ENABLE_PATH_STROKE    ] ; 
        set caps_enable_scissoring     [ ATH_GET_FIELD $reg VGR_CSR_CAPS_ENABLE_SCISSORING     ] ; 
        set caps_enable_masking        [ ATH_GET_FIELD $reg VGR_CSR_CAPS_ENABLE_MASKING        ] ; 
        set caps_enable_paint_gradient [ ATH_GET_FIELD $reg VGR_CSR_CAPS_ENABLE_PAINT_GRADIENT ] ; 
        set caps_enable_paint_bitmap   [ ATH_GET_FIELD $reg VGR_CSR_CAPS_ENABLE_PAINT_BITMAP   ] ; 

        open_service master ${::boardInit::masterPath}        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_vgr::VGR_CSR_REG_CAPS2} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}
        set caps_max_scissor_rects   [ ATH_GET_FIELD $reg VGR_CSR_CAPS2_MAX_SCISSOR_RECTS  ] ; 
        set caps_max_gradient_stops  [ ATH_GET_FIELD $reg VGR_CSR_CAPS2_MAX_GRADIENT_STOPS ] ; 
        set caps_max_dash_patterns   [ ATH_GET_FIELD $reg VGR_CSR_CAPS2_MAX_DASH_PATTERNS  ] ; 

        puts "                                                             "
        puts " Capabilities:                                               "
        puts "     caps_enable_debug          = $caps_enable_debug         "
        puts "     caps_enable_path_stroke    = $caps_enable_path_stroke   "
        puts "     caps_enable_scissoring     = $caps_enable_scissoring    "
        puts "     caps_enable_masking        = $caps_enable_masking       "
        puts "     caps_enable_paint_gradient = $caps_enable_paint_gradient"
        puts "     caps_enable_paint_bitmap  = $caps_enable_paint_bitmap   "
        puts "     caps_max_scissor_rects     = $caps_max_scissor_rects    "
        puts "     caps_max_gradient_stops    = $caps_max_gradient_stops   "
        puts "     caps_max_dash_patterns     = $caps_max_dash_patterns    "
        puts "                                                             "                                                                                                                                                                
 
        if { ${::cgx_vgr::debug} == 1 } {
 
            set dash_path ${::cgx_vgr::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true


            if { $caps_enable_debug==0} { 
                dashboard_set_property $dash_path grp_context  visible false
                dashboard_set_property $dash_path grp_opr      visible false
            } else {    
                dashboard_set_property $dash_path grp_context  visible true
                dashboard_set_property $dash_path grp_opr      visible true
            }


        #   if { $caps_enable_path==0} { 
        #       dashboard_set_property $dash_path grp_path        visible false
        #   } else {    
        #       dashboard_set_property $dash_path grp_path        visible true
        #   }
        #
        #
        #   if { $caps_enable_path_raster==0} { 
        #       dashboard_set_property $dash_path grp_ctx_raster  visible false
        #   } else {    
        #       dashboard_set_property $dash_path grp_ctx_raster  visible true
        #   }


            if { $caps_enable_masking==0} { 
                dashboard_set_property $dash_path grp_ctx_masking  visible false
            } else {    
                dashboard_set_property $dash_path grp_ctx_masking  visible true
            }


            if { $caps_enable_paint_gradient==0} { 
                dashboard_set_property $dash_path grp_ctx_gradient  visible false
            } else {    
                dashboard_set_property $dash_path grp_ctx_gradient  visible true
            }


            if { $caps_enable_paint_bitmap==0} { 
                dashboard_set_property $dash_path grp_ctx_pattern  visible false
            } else {    
                dashboard_set_property $dash_path grp_ctx_pattern  visible true
                
            #   if { $caps_enable_paint_pattern_bilinear==0} { 
            #       dashboard_set_property $dash_path dash_ctx_paint_quality  visible false
            #   } else {    
            #       dashboard_set_property $dash_path dash_ctx_paint_quality  visible true            
            #   }
            }


        #   if { $caps_enable_interpolation_bilinear==0} { 
        #       dashboard_set_property $dash_path dash_ctx_image_transform_quality  visible false
        #   } else {    
        #       dashboard_set_property $dash_path dash_ctx_image_transform_quality  visible true
        #   }
        #
        #
        #   if { $caps_enable_color_transform==0} { 
        #       dashboard_set_property $dash_path grp_ctx_colortransform  visible false
        #   } else {    
        #       dashboard_set_property $dash_path grp_ctx_colortransform  visible true
        #   }
        #
        #
        #   if { $caps_enable_blending==0} { 
        #       dashboard_set_property $dash_path grp_ctx_blending  visible false
        #   } else {    
        #       dashboard_set_property $dash_path grp_ctx_blending  visible true
        #   }
                                  
        }
    }


    proc dump_reg32 { reg_offset32 } {

        open_service master ${::boardInit::masterPath}
        set dump [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*$reg_offset32 ] 1  ]
        puts stdout $dump
	      close_service master ${::boardInit::masterPath}

    }


    proc dump_all {  } {

        open_service master ${::boardInit::masterPath}
        set dump [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 0 ] ${::cgx_vgr::VGR_CSR_REG_NUMBER} ]
        puts "dump ${::cgx_vgr::VGR_CSR_REG_NUMBER} 32-bits regs at ${::cgx_vgr::VGR_CSR_DEV_BASE}: " 
	      puts stdout $dump
	      close_service master ${::boardInit::masterPath}

    }
      
 
    proc set_config { run } {

        if { ${::cgx_vgr::debug} == 1 } {
	          set dash_path ${::cgx_vgr::dash_path} 
	          set run 0 
            if { [ dashboard_get_property $dash_path dash_cfg_run checked ] == true } {
                set run 1
            } 
        }  

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CONTROL} ] 0x1]; 
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CONTROL_RUN $run ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CONTROL} ] $reg
	      close_service master ${::boardInit::masterPath}
    }


    proc set_opts {  } {

        set dash_path ${::cgx_vgr::dash_path} 
	      set opts 0 
        
        if { [ dashboard_get_property $dash_path dash_opt_undo_pipe checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_PIPELINED_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_all checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_ALL_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_rect checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_RECT_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_image checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_IMAGE_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_path checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_PATH_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_stroked checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_STROKED_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_filled checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_FILLED_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_blending checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_BLENDING_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_masking checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_MASKING_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_painting checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_PAINTING_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_opt_rect checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_OPT_RECT_BIT}) ]
        } 
        if { [ dashboard_get_property $dash_path dash_opt_undo_opt_gray checked ] == true } {
            set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_OPT_GRAY_BIT}) ]
        } 

      # if { [ dashboard_get_property $dash_path dash_opt_undo_opt_paint_matrix_norm checked ] == true } {
      #     set opts [ expr $opts | (1 << ${::cgx_vgr::OPT_FORCE_UNDO_PAINT_MATRIX_NORM_BIT}) ]
      # } 

        
    #   puts " write opts = $opts "    

        open_service master ${::boardInit::masterPath}
        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_DBG_CONFIG} ] 0x1]; 
        set reg [ ATH_SET_FIELD $reg VGR_CSR_DBG_OPTS $opts ]             
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_DBG_CONFIG} ] $reg
	      
	      close_service master ${::boardInit::masterPath}
    }


    proc get_opts { } {

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_DBG_CONFIG} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set opts [ ATH_GET_FIELD $reg VGR_CSR_DBG_OPTS ] ;                                                                

    #   puts " read opts = $opts "    

        if { ${::cgx_vgr::debug} == 1 } {
        	  set dash_path ${::cgx_vgr::dash_path} 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_PIPELINED_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_pipe checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_pipe checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_ALL_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_all checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_all checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_RECT_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_rect checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_rect checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_IMAGE_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_image checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_image checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_PATH_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_path checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_path checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_STROKED_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_stroked checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_stroked checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_FILLED_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_filled checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_filled checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_BLENDING_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_blending checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_blending checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_MASKING_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_masking checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_masking checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_PAINTING_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_painting checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_painting checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_OPT_RECT_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_opt_rect checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_opt_rect checked false  
            } 

            if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_OPT_GRAY_BIT}) & 0x1) ] == 1 } {
               dashboard_set_property $dash_path dash_opt_undo_opt_gray checked true  
            } else { 
               dashboard_set_property $dash_path dash_opt_undo_opt_gray checked false  
            } 

          # if { [expr (($opts >> ${::cgx_vgr::OPT_FORCE_UNDO_PAINT_MATRIX_NORM_BIT}) & 0x1) ] == 1 } {
          #    dashboard_set_property $dash_path dash_opt_undo_opt_paint_matrix_norm checked true  
          # } else { 
          #    dashboard_set_property $dash_path dash_opt_undo_opt_paint_matrix_norm checked false  
          # } 

        }

    ##  if { ${::cgx_vgr::debug} == 1 } {
    ##  	  set dash_path ${::cgx_vgr::dash_path} 
    ##      if { [expr (($opts >> OPT_FORCE_UNDO_ALL_BIT) & 0x1) ] == 1 } {
    ##         dashboard_set_property $dash_path dash_opt_undo_all checked true  
    ##      } else { 
    ##         dashboard_set_property $dash_path dash_opt_undo_all checked false  
    ##      } 
    ##  }


    }





#   proc set_config2 { path_tile_height1 } {
# 
#       if { ${::cgx_vgr::debug} == 1 } {
#           set dash_path ${::cgx_vgr::dash_path} 
#           set path_tile_height1 [ dashboard_get_property $dash_path dash_path_tile_height1 text ]      
#       }  
# 
#       open_service master ${::boardInit::masterPath}
# 
#       set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_CFG_PRIVATE} ] 0x1]; 
#       set reg [ ATH_SET_FIELD $reg VGR_CSR_PATH_RASTER_TILE_HEIGHT1 $path_tile_height1 ]
#       master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_CFG_PRIVATE} ] $reg
#       close_service master ${::boardInit::masterPath}
#   }

         
    proc get_config { } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CONTROL} ] 0x1]; 
        set cfg_run [ ATH_GET_FIELD $reg VGR_CSR_CONTROL_RUN ] ;                                                                

        set cfg_path_pool0_size64 [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_POOL0_MEM_SIZE64} ] 0x1];
        set cfg_path_pool1_size64 [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_POOL1_MEM_SIZE64} ] 0x1];

        set cfg_path_pool0_addr64 [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_POOL0_MEM_ADDR64} ] 0x1]; 
        set cfg_path_pool1_addr64 [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_POOL1_MEM_ADDR64} ] 0x1]; 


	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_vgr::debug} == 0 } {
            puts "                                                    "
            puts "  config:                                           "
            puts "      cfg_run               = $cfg_run              "          
            puts "      cfg_path_pool0_size64 = $cfg_path_pool0_size64  "          
            puts "      cfg_path_pool1_size64 = $cfg_path_pool1_size64  "          
            puts "      cfg_path_pool0_addr64 = $cfg_path_pool0_addr64  "          
            puts "      cfg_path_pool1_addr64 = $cfg_path_pool1_addr64  "          
            puts "                                                    "                                                                                                                                                                
        }
        if { ${::cgx_vgr::debug} == 1 } {
        	  set dash_path ${::cgx_vgr::dash_path} 
            if { $cfg_run == 1 } {
               dashboard_set_property $dash_path dash_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_run checked false  
            } 
            dashboard_set_property $dash_path dash_path_pool0_size   text $cfg_path_pool0_size64  
            dashboard_set_property $dash_path dash_path_pool1_size   text $cfg_path_pool1_size64  
            dashboard_set_property $dash_path dash_path_pool0_addr   text $cfg_path_pool0_addr64                    
            dashboard_set_property $dash_path dash_path_pool1_addr   text $cfg_path_pool1_addr64                    
        }
    }


#   proc get_config2 { } {
#
#       open_service master ${::boardInit::masterPath}
#
#       set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_CFG_PRIVATE} ] 0x1]; 
#       set cfg_path_tile_height1 [ ATH_GET_FIELD $reg VGR_CSR_PATH_RASTER_TILE_HEIGHT1 ]; 
#
#       close_service master ${::boardInit::masterPath}
#
#       if { ${::cgx_vgr::debug} == 0 } {
#           puts "                                                    "
#           puts "  config2:                                          "
#           puts "      cfg_path_tile_height1 = cfg_path_tile_height1 "          
#           puts "                                                    "                                                                                                                                                                
#       }
#       if { ${::cgx_vgr::debug} == 1 } {
#       	  set dash_path ${::cgx_vgr::dash_path} 
#           dashboard_set_property $dash_path dash_path_tile_height1 text $cfg_path_tile_height1                    
#       }
#   }

 
    proc get_status { } {
  
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_STATUS} ] 0x1]; 
        close_service master ${::boardInit::masterPath}
        set sts_busy            [ ATH_GET_FIELD $reg VGR_CSR_STATUS_BUSY ] ;                                                                
        set sts_irq             [ ATH_GET_FIELD $reg VGR_CSR_STATUS_IRQ  ] ;                                                                
        set cmd_busy            [ ATH_GET_FIELD $reg VGR_CSR_STATUS_CMD_BUSY ] ;                                                                
        set cmd_elab_busy       [ ATH_GET_FIELD $reg VGR_CSR_STATUS_CMD_ELAB_BUSY ] ;                                                                
        set cmd_fifo_empty      [ ATH_GET_FIELD $reg VGR_CSR_STATUS_CMD_FIFO_EMPTY ] ;                                                                
        set cmd_fifo_full       [ ATH_GET_FIELD $reg VGR_CSR_STATUS_CMD_FIFO_FULL ] ;                                                                
        set cmd_fifo_almostfull [ ATH_GET_FIELD $reg VGR_CSR_STATUS_CMD_FIFO_ALMOSTFULL ] ;                                                                
        set sts_irqfield        [ ATH_GET_FIELD $reg VGR_CSR_STATUS_IRQ_ACTIVE ] ;                                                                
        set sts_ia_diag_error   [ ATH_GET_FIELD $sts_irqfield VGR_CSR_IRQ_BIT_DIAG_ERROR  ] ;                                                                
        set sts_ia_cmd_error    [ ATH_GET_FIELD $sts_irqfield VGR_CSR_IRQ_BIT_CMD_ELAB_ERROR  ] ;                                                                
        set sts_ia_pool0_overflow [ ATH_GET_FIELD $sts_irqfield VGR_CSR_IRQ_BIT_PATH_POOL0_OVERFLOW ] ;                                                                
        set sts_ia_pool1_overflow [ ATH_GET_FIELD $sts_irqfield VGR_CSR_IRQ_BIT_PATH_POOL1_OVERFLOW ] ;                                                                


        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_STATUS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}
        set cmd_count     [ ATH_GET_FIELD $reg VGR_CSR_CMD_STS_COUNT ] ;                                                                             
        set cmd_fifo_used [ ATH_GET_FIELD $reg VGR_CSR_CMD_STS_FIFO_USED ] ;                                                                

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_STS_SIZE} ] 0x1]; 
        close_service master ${::boardInit::masterPath}
        set path_pts_max_src [ ATH_GET_FIELD $reg VGR_CSR_PATH_PTS_MAX_SRC ] ; 
        set path_pts_max_dst [ ATH_GET_FIELD $reg VGR_CSR_PATH_PTS_MAX_DST ] ; 


        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CTX_PARAM_USER} ] 0x1]; 
        close_service master ${::boardInit::masterPath}
        set ctx_param_user [ format %d $reg ]      

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::DEF_CSR_REG_CLOCK_FPS} ] 0x1]; 
        close_service master ${::boardInit::masterPath}
        set fps_count [ format %d $reg ]      

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_STS_PENDING} ] 0x1]; 
        close_service master ${::boardInit::masterPath}
        set path_pending_max_paths [ ATH_GET_FIELD $reg VGR_CSR_PATH_PENDING_MAX_PATHDATA ] ; 
        set path_pending_max_pts   [ ATH_GET_FIELD $reg VGR_CSR_PATH_PENDING_MAX_PTS ] ; 

        open_service master ${::boardInit::masterPath}
        set path_pool1_peak64 [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_POOL1_MEM_PEAK64} ] 0x1]; 
        close_service master ${::boardInit::masterPath}
       

        if { ${::cgx_vgr::debug} == 0 } {
            puts "                                                      "
            puts " Status:                                              "
            puts "     core busy              =$sts_busy                "
            puts "     core interrupt         =$sts_irq                 "
                                                                        
            puts "     cmd_busy               = $cmd_busy               " 
            puts "     cmd_elab_busy          = $cmd_elab_busy          " 
            puts "     cmd_fifo_empty         = $cmd_fifo_empty         "   
            puts "     cmd_fifo_full          = $cmd_fifo_full          "   
            puts "     cmd_fifo_almostfull    = $cmd_fifo_almostfull    " 
            puts "     cmd_fifo_used          = $cmd_fifo_used          "
            puts "     cmd_count              = $cmd_count              "
            puts "     sts_ia_cmd_error       = $sts_ia_cmd_error       "  
            puts "     sts_ia_pool0_overflow  = $sts_ia_pool0_overflow  "
            puts "     sts_ia_pool1_overflow  = $sts_ia_pool1_overflow  "
            puts "     diag_error             = $sts_ia_diag_error      "            
            puts "     path_pts_max_src       = $path_pts_max_src       ";
            puts "     path_pts_max_dst       = $path_pts_max_dst       ";
            puts "     path_pending_max_paths = $path_pending_max_paths ";
            puts "     path_pending_max_pts   = $path_pending_max_pts   ";
            puts "     path_pool1_peak64      = $path_pool1_peak64      ";          
            puts "     ctx_param_user         = $ctx_param_user         ";
#           puts "     fps                    =$sts_fps                 "
            puts "                                                      "                                                                                                                            
        }

 
       if { ${::cgx_vgr::debug} == 1 } {
       	  set dash_path ${::cgx_vgr::dash_path} 

          dashboard_set_property $dash_path dash_path_pts_src_peak      text $path_pts_max_src    
          dashboard_set_property $dash_path dash_path_pts_dst_peak      text $path_pts_max_dst    
          dashboard_set_property $dash_path dash_path_peak_pending      text $path_pending_max_paths    
          dashboard_set_property $dash_path dash_path_peak_pending_pts  text $path_pending_max_pts    
          dashboard_set_property $dash_path dash_path_peak_pool1_size64 text $path_pool1_peak64    

          dashboard_set_property $dash_path dash_ctx_param_user         text $ctx_param_user    
          dashboard_set_property $dash_path dash_fps_count              text $fps_count    



          if { $sts_busy == 1 } {
             dashboard_set_property $dash_path dash_sts_busy checked true
          } else { 
             dashboard_set_property $dash_path dash_sts_busy checked false
          }        
   
          if { $sts_irq == 1 } {
              dashboard_set_property $dash_path dash_sts_irq color "red"
          } else {
              dashboard_set_property $dash_path dash_sts_irq color "black"
          }



          if { $cmd_busy == 1 } {
             dashboard_set_property $dash_path dash_cmd_busy checked true
          } else { 
             dashboard_set_property $dash_path dash_cmd_busy checked false
          }   

          if { $cmd_elab_busy == 1 } {
             dashboard_set_property $dash_path dash_cmd_elab_busy checked true
          } else { 
             dashboard_set_property $dash_path dash_cmd_elab_busy checked false
          }   
              
          if { $cmd_fifo_full == 1 } {
             dashboard_set_property $dash_path dash_cmd_fifo_full checked true
          } else { 
             dashboard_set_property $dash_path dash_cmd_fifo_full checked false
          }   

          if { $sts_ia_diag_error == 1 } {
             dashboard_set_property $dash_path dash_sts_ia_diag_error checked true
             cgx_vgr::get_diag 1
          } else { 
             dashboard_set_property $dash_path dash_sts_ia_diag_error checked false
             cgx_vgr::get_diag 0
          }        
               
          if { $sts_ia_cmd_error == 1 } {
             dashboard_set_property $dash_path dash_sts_ia_cmd_elab_error checked true
          } else { 
             dashboard_set_property $dash_path dash_sts_ia_cmd_elab_error checked false
          }        

          if { $sts_ia_pool0_overflow == 1 } {
             dashboard_set_property $dash_path dash_sts_ia_pool0_overflow checked true
          } else { 
             dashboard_set_property $dash_path dash_sts_ia_pool0_overflow checked false
          }        

          if { $sts_ia_pool1_overflow == 1 } {
             dashboard_set_property $dash_path dash_sts_ia_pool1_overflow checked true
          } else { 
             dashboard_set_property $dash_path dash_sts_ia_pool1_overflow checked false
          }        

          dashboard_set_property $dash_path dash_cmd_fifo_used  text $cmd_fifo_used    
          dashboard_set_property $dash_path dash_cmd_count      text $cmd_count    

        }
    }
                        

    # clear all status interrupt-active bits
    proc clr_status { } {

        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_STATUS} ] 0xFFFFFFFF 
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_STATUS} ] 0xFFFFFFFF 
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_PATH_STS_SIZE} ] 0xFFFFFFFF 
	      close_service master ${::boardInit::masterPath}
    }
 

    proc set_interrupt { ie_cmd_elab_error } {

        if { ${::cgx_vgr::debug} == 1 } {
	          set dash_path ${::cgx_vgr::dash_path} 

	          set ie_diag_error 0 
            if { [ dashboard_get_property $dash_path dash_cfg_ie_diag_error checked ] == true } {
                set ie_diag_error 1
            } 
     
	          set ie_cmd_elab_error 0 
            if { [ dashboard_get_property $dash_path dash_cfg_ie_cmd_elab_error checked ] == true } {
                set ie_cmd_elab_error 1
            } 
            
	          set ie_pool0_overflow 0 
            if { [ dashboard_get_property $dash_path dash_cfg_ie_pool0_overflow checked ] == true } {
                set ie_pool0_overflow 1
            } 

	          set ie_pool1_overflow 0 
            if { [ dashboard_get_property $dash_path dash_cfg_ie_pool1_overflow checked ] == true } {
                set ie_pool1_overflow 1
            } 
                 
        }  
        set ie_bitfield 0
        set ie_bitfield [ ATH_SET_FIELD $ie_bitfield VGR_CSR_IRQ_BIT_DIAG_ERROR          $ie_diag_error ]
        set ie_bitfield [ ATH_SET_FIELD $ie_bitfield VGR_CSR_IRQ_BIT_CMD_ELAB_ERROR      $ie_cmd_elab_error ]
        set ie_bitfield [ ATH_SET_FIELD $ie_bitfield VGR_CSR_IRQ_BIT_PATH_POOL0_OVERFLOW $ie_pool0_overflow ]
        set ie_bitfield [ ATH_SET_FIELD $ie_bitfield VGR_CSR_IRQ_BIT_PATH_POOL1_OVERFLOW $ie_pool1_overflow ]

        open_service master ${::boardInit::masterPath}
        set reg 0
        set reg [ ATH_SET_FIELD $reg VGR_CSR_INTERRUPT_ENABLE $ie_bitfield ]           
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_INTERRUPT} ] $reg
        close_service master ${::boardInit::masterPath}
    }
 

    proc get_interrupt { } {

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_INTERRUPT} ] 0x1]; 
        set ie_bitfield  [ ATH_GET_FIELD $reg VGR_CSR_INTERRUPT_ENABLE ] ;                                                                
	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_vgr::debug} == 0 } {
            puts "                                                            "
            puts "  interrupt:                                                "
            puts "         ie_bitfield = $ie_bitfield "      
            puts "                                                            "                                                                                                           
        }
        if { ${::cgx_vgr::debug} == 1 } {
        	  set dash_path ${::cgx_vgr::dash_path} 

            if { [ ATH_GET_FIELD $ie_bitfield VGR_CSR_IRQ_BIT_DIAG_ERROR ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_diag_error checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_diag_error checked false
            }        
 
            if { [ ATH_GET_FIELD $ie_bitfield VGR_CSR_IRQ_BIT_CMD_ELAB_ERROR ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_cmd_elab_error checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_cmd_elab_error checked false
            }        

            if { [ ATH_GET_FIELD $ie_bitfield VGR_CSR_IRQ_BIT_PATH_POOL0_OVERFLOW ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_pool0_overflow checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_pool0_overflow checked false
            }        

            if { [ ATH_GET_FIELD $ie_bitfield VGR_CSR_IRQ_BIT_PATH_POOL1_OVERFLOW ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_pool1_overflow checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_pool1_overflow checked false
            }        

        }
    }


    proc get_param { var do class type reg_num } {

        # create a local reference for the array
        # upvar $var regs
        # set var 0

        # set ID
        set reg 0            
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO      $do ]
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS   $class ]
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE    $type ]        
        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg
        close_service master ${::boardInit::masterPath}
         
        for { set i 0 } { ${i} < ${reg_num} } { incr i } {
            
            # set word offset
            open_service master ${::boardInit::masterPath}
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i
            close_service master ${::boardInit::masterPath}

            # get word data
            open_service master ${::boardInit::masterPath}
            append var [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
	          close_service master ${::boardInit::masterPath}
        }

        puts "$var"; 

    }
 
    proc get_diag { diag_error } {

        set dash_path ${::cgx_vgr::dash_path}
        if { $diag_error != 0 } {
            set var {}
            open_service master ${::boardInit::masterPath}
            for {set i 0} { $i<8 } {incr i} {
                set reg [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_DIAG} ] 1 ];     
                # remove "0x" header and re-order characters from msb to lsb
                append var [string index $reg 8]
                append var [string index $reg 9]
                append var [string index $reg 6]
                append var [string index $reg 7]
                append var [string index $reg 4]
                append var [string index $reg 5]
                append var [string index $reg 2]
                append var [string index $reg 3]
            }
            close_service master ${::boardInit::masterPath}
            set msg [binary format H* $var] 
          # puts $msg
        } else {     
            set msg " - "
        }
        
        dashboard_set_property $dash_path dash_opr_diag text $msg      

    }


    proc get_opr {  } {

        set dash_path ${::cgx_vgr::dash_path} 

        # set ID
        set reg 0            
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO    ${::cgx_vgr::VGR_CMD_DO_OPR} ]
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS 0 ]
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE  0 ]        

        open_service master ${::boardInit::masterPath}
        
        # set header  
      # set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE $i ]        
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg

        # get header  
        set reg [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] 1 ]; 

        set opr_class    [ ATH_GET_FIELD $reg VGR_CSR_CMD_ID_CLASS ]    
        set opr_type     [ ATH_GET_FIELD $reg VGR_CSR_CMD_ID_TYPE ]    
        set opr_regs_num [ ATH_GET_FIELD $reg VGR_CSR_CMD_ID_REG_NUM ]    

       #set max_reg_num [ expr ${::cgx_vgr::VGR_CSR_OPR_REG_NUMBER} + ${::cgx_vgr::VGR_CSR_OPR_MAX_ARG_NUMBER} ]
        set max_reg_num $opr_regs_num
          
        for { set i 0 } { ${i} < $max_reg_num } { incr i } {
            
            # set word offset
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i

            # get word data
            set data(${i}) [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
        }

        close_service master ${::boardInit::masterPath}


      # puts "opr_class = $opr_class"
      # puts "opr_type  = $opr_type"


        if       { $opr_class == ${::cgx_vgr::VGR_CSR_OPR_CLASS_RECT} } { 
        	
                  if { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_RECT_CLEAR}      } { dashboard_set_property $dash_path dash_opr_id text "RECT - CLEAR"                            
            } elseif { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_RECT_FILL}       } { dashboard_set_property $dash_path dash_opr_id text "RECT - FILL"                           
            } elseif { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_RECT_BOUND}      } { dashboard_set_property $dash_path dash_opr_id text "RECT - BOUND"                            
            }   

        } elseif { $opr_class == ${::cgx_vgr::VGR_CSR_OPR_CLASS_IMAGE} } {                             

                  if { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_IMAGE_COMPOSE}   } { dashboard_set_property $dash_path dash_opr_id text "IMAGE - COMPOSE"                           
            } elseif { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_IMAGE_TRANSFORM} } { dashboard_set_property $dash_path dash_opr_id text "IMAGE - TRANSFORM"                          
            } elseif { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_IMAGE_COPY}      } { dashboard_set_property $dash_path dash_opr_id text "IMAGE - COPY"                           
            } elseif { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_IMAGE_REMAP}     } { dashboard_set_property $dash_path dash_opr_id text "IMAGE - REMAP"                           
            }   

        } elseif { $opr_class == ${::cgx_vgr::VGR_CSR_OPR_CLASS_PATH} } {                             

                  if { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_PATH_DRAW}      } { dashboard_set_property $dash_path dash_opr_id text "PATH - DRAW"                            
            } elseif { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_PATH_BBOX_ROUGH}} { dashboard_set_property $dash_path dash_opr_id text "PATH - BBOX ROUGH"                           
            } elseif { $opr_type == ${::cgx_vgr::VGR_CSR_OPR_PATH_BBOX_TIGHT}} { dashboard_set_property $dash_path dash_opr_id text "PATH - BBOX TIGHT"                           
            }   
        }   
    
    }

 

    proc ctx_get_frame {  } {

        set dash_path ${::cgx_vgr::dash_path} 
        
        # set ID
        set reg 0            
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO      ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ] 
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS   ${::cgx_vgr::VGR_CSR_CTX_CLASS_FRAME} ]
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE    [ dashboard_get_property $dash_path dash_ctx_frame selected ] ]        
        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg
        close_service master ${::boardInit::masterPath}

        for {set i 0} { $i<${::cgx_surface::DESC_REG_NUMBER} } {incr i} {
            # set word offset
            open_service master ${::boardInit::masterPath}
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i
            
            # get word data
            set desc($i) [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
	          close_service master ${::boardInit::masterPath}
        }

        set sfc_name "tmp"
        set clut_start_idx -2 
        set async_ptr -2
 
        cgx_surface::surface_get_desc desc $sfc_name clut_start_idx async_ptr   
            
        dashboard_set_property $dash_path dash_desc_addr8_l     text $::cgx_surface::surface($sfc_name,base)    
        dashboard_set_property $dash_path dash_desc_pixcolor    text $::cgx_surface::surface($sfc_name,color)   
        dashboard_set_property $dash_path dash_desc_pixdepth    text $::cgx_surface::surface($sfc_name,color_depth)   
        dashboard_set_property $dash_path dash_desc_width       text $::cgx_surface::surface($sfc_name,width)   
        dashboard_set_property $dash_path dash_desc_height      text $::cgx_surface::surface($sfc_name,height)  
        dashboard_set_property $dash_path dash_desc_hstride8    text [ format 0x%x $::cgx_surface::surface($sfc_name,stride) ]     
        dashboard_set_property $dash_path dash_desc_bufnum      text $::cgx_surface::surface($sfc_name,nb_buffer) 
        dashboard_set_property $dash_path dash_desc_bufidx      text $async_ptr
        dashboard_set_property $dash_path dash_desc_vstride8    text [ format 0x%x $::cgx_surface::surface($sfc_name,stride_buffer) ]         
      # dashboard_set_property $dash_path dash_desc_clut_idx    text $clut_start_idx         

    }



    proc ctx_get_param {  } {

        set dash_path ${::cgx_vgr::dash_path} 

        # set ID
        set reg 0            
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO      ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ] 
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS   ${::cgx_vgr::VGR_CSR_CTX_CLASS_PARAM} ]

        open_service master ${::boardInit::masterPath}
         
        for { set i 0 } { ${i} < ${::cgx_vgr::VGR_CSR_CTX_PARAM_NUMBER} } { incr i } {

            # set header  
            set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE $i ]        
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg
            
            # set word offset
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i

            # get word data
            set data(${i}) [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
        }

        close_service master ${::boardInit::masterPath}

      # if { $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_CLIP_ENABLE}) == 1 } {
      #    dashboard_set_property $dash_path dash_ctx_clip_enable checked true
      # } else { 
      #    dashboard_set_property $dash_path dash_ctx_clip_enable checked false
      # }        

        if { $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_MASK_ENABLE}) == 1 } {
           dashboard_set_property $dash_path dash_ctx_mask_enable checked true
        } else { 
           dashboard_set_property $dash_path dash_ctx_mask_enable checked false
        }        

        if { [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_MASK}) VGR_CSR_MASK_COLOR_INVERT ] == 1 } {
           dashboard_set_property $dash_path dash_ctx_mask_color_invert checked true
        } else { 
           dashboard_set_property $dash_path dash_ctx_mask_color_invert checked false
        }        

     #  if { $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_COLOR_TRANSFORM_ENABLE}) == 1 } {
     #     dashboard_set_property $dash_path dash_ctx_color_transform_enable checked true
     #  } else { 
     #     dashboard_set_property $dash_path dash_ctx_color_transform_enable checked false
     #  }        

        dashboard_set_property $dash_path dash_ctx_clear_color              text [ format 0x%x $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_CLEAR_COLOR}) ]                       
        dashboard_set_property $dash_path dash_ctx_mask_color_plane         selected [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_MASK}) VGR_CSR_MASK_COLOR_PLANE ]  
        
        set paint_base ${::cgx_vgr::VGR_CSR_CTX_PARAM_PAINT_FILL_BASE}
        
        for { set i 0 } { ${i} < ${::cgx_vgr::VGR_CSR_PAINT_PARAM_NUMBER} } { incr i } {
            set paint_data(${i}) $data([expr ${paint_base} + ${i}])
        }


    #   dashboard_set_property $dash_path dash_ctx_paint_code               selected [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_SET0})  VGR_CSR_MASK_PAINT_CODE ]    

        dashboard_set_property $dash_path dash_ctx_paint_color              text [ format 0x%x $paint_data(${::cgx_vgr::VGR_CSR_PAINT_PARAM_COLOR}) ] 
        dashboard_set_property $dash_path dash_ctx_paint_type               selected [ ATH_GET_FIELD $paint_data(${::cgx_vgr::VGR_CSR_PAINT_PARAM_TYPE}) VGR_CSR_PAINT_DATATYPE ]   
        dashboard_set_property $dash_path dash_ctx_paint_gradient_type      selected [ ATH_GET_FIELD $paint_data(${::cgx_vgr::VGR_CSR_PAINT_PARAM_TYPE}) VGR_CSR_PAINT_GRADIENT_TYPE ] 
        dashboard_set_property $dash_path dash_ctx_paint_spread_mode        selected [ ATH_GET_FIELD $paint_data(${::cgx_vgr::VGR_CSR_PAINT_PARAM_TYPE}) VGR_CSR_PAINT_SPREAD_MODE ] 
        dashboard_set_property $dash_path dash_ctx_paint_quality            selected [ ATH_GET_FIELD $paint_data(${::cgx_vgr::VGR_CSR_PAINT_PARAM_TYPE}) VGR_CSR_PAINT_PATTERN_QUALITY ]       
    #   dashboard_set_property $dash_path dash_ctx_image_transform_quality  selected $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_IMAGE_TRANSFORM_QUALITY}) 
        dashboard_set_property $dash_path dash_ctx_blend_mode               selected $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_BLEND_MODE});  
        dashboard_set_property $dash_path dash_ctx_path_fillrule            selected $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_PATH_FILLRULE});  

        dashboard_set_property $dash_path dash_ctx_glyph_origin_x           text [ format 0x%x $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_GLYPH_ORIGIN_X}) ]   
        dashboard_set_property $dash_path dash_ctx_glyph_origin_y           text [ format 0x%x $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_GLYPH_ORIGIN_Y}) ]   

        dashboard_set_property $dash_path dash_ctx_path_stroke_linewidth    text     [ format 0x%x [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_PATH_STROKE_STYLE})  VGR_CSR_STROKE_LINEWIDTH ] ]     
        dashboard_set_property $dash_path dash_ctx_path_stroke_linejoin     selected [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_PATH_STROKE_STYLE})  VGR_CSR_STROKE_LINEJOIN ] 
        dashboard_set_property $dash_path dash_ctx_path_stroke_cap          selected [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_PATH_STROKE_STYLE})  VGR_CSR_STROKE_CAP ]
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount    text     [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_PATH_STROKE})  VGR_CSR_STROKE_DASHCOUNT ] 
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashphase    text [ format 0x%x $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_PATH_STROKE_DASH_PHASE}) ] 
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern  text [ format 0x%x $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_PATH_STROKE_DASH_PATTERN_BASE}) ] 
        dashboard_set_property $dash_path dash_ctx_path_stroke_miterlimit   text [ format 0x%x $data(${::cgx_vgr::VGR_CSR_CTX_PARAM_PATH_STROKE_MITER_LIMIT}) ] 

        if { [ ATH_GET_FIELD $paint_data(${::cgx_vgr::VGR_CSR_PAINT_PARAM_TYPE}) VGR_CSR_PAINT_EN_COLORMULTIPLY ] == 1 } {
           dashboard_set_property $dash_path dash_ctx_paint_en_colormultiply checked true
        } else { 
           dashboard_set_property $dash_path dash_ctx_paint_en_colormultiply checked false
        }        

    }


    proc ctx_get_matrix {} {

        set dash_path ${::cgx_vgr::dash_path} 

        # set ID
        set reg 0            
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO      ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ] 
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS   ${::cgx_vgr::VGR_CSR_CTX_CLASS_MATRIX} ]
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE [ dashboard_get_property $dash_path dash_ctx_matrix selected ] ]        
        
        open_service master ${::boardInit::masterPath}
        # set header  
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg
         
        for { set i 0 } { ${i} < ${::cgx_vgr::VGR_CSR_MATRIX_REG_NUMBER} } { incr i } {
            
            # set word offset
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i

            # get word data
            set data(${i}) [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
        }

        close_service master ${::boardInit::masterPath}

        for { set i 0 } { ${i} < ${::cgx_vgr::VGR_CSR_MATRIX_REG_NUMBER} } { incr i } {

            dashboard_set_property $dash_path dash_ctx_mtx$i  text $data(${i})
            
        }
    }


    proc ctx_get_rect {  } {

        set dash_path ${::cgx_vgr::dash_path} 

        # set ID
        set reg 0            
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO    ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ] 
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS ${::cgx_vgr::VGR_CSR_CTX_CLASS_RECT} ]

        for { set j 0 } { ${j} < [ expr ${::cgx_vgr::VGR_CSR_CTX_RECT_NUMBER} ] } { incr j } {

            set rect_id $j

            set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE  $rect_id ]        
            
            open_service master ${::boardInit::masterPath}
            # set header  
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg
             
            for { set i 0 } { ${i} < ${::cgx_vgr::VGR_DEF_BBOX_REG_NUMBER} } { incr i } {
                
                # set word offset
                master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i
            
                # get word data
                set data(${i}) [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
            }
            
            close_service master ${::boardInit::masterPath}
            
            set rect_valid [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_DEF_BBOX_REG_MIN}) VGR_DEF_BBOX_VALID ]
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x text [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_DEF_BBOX_REG_MIN}) VGR_DEF_BBOX_X ]
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y text [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_DEF_BBOX_REG_MIN}) VGR_DEF_BBOX_Y ]
            
            if { $rect_valid == 1 } {
                dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w text [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_DEF_BBOX_REG_MAX}) VGR_DEF_BBOX_X ]
                dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h text [ ATH_GET_FIELD $data(${::cgx_vgr::VGR_DEF_BBOX_REG_MAX}) VGR_DEF_BBOX_Y ]
            } else { 
                dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w text 0
                dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h text 0
            }        
        }                   
    }


#   proc ctx_get_colortransform {} {
#
#       set dash_path ${::cgx_vgr::dash_path} 
#
#       # set ID
#       set reg 0            
#       set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO      ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ] 
#       set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS   ${::cgx_vgr::VGR_CSR_CTX_CLASS_COLORTRANSFORM} ]
#       set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE 0 ]        
#       
#       open_service master ${::boardInit::masterPath}
#       # set header  
#       master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg
#        
#       for { set i 0 } { ${i} < ${::cgx_vgr::VGR_CSR_COLORTRANSFORM_REG_NUMBER} } { incr i } {
#           
#           # set word offset
#           master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i
#           # get word data
#           set data(${i}) [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
#       }
#
#       close_service master ${::boardInit::masterPath}
#
#       for { set i 0 } { ${i} < ${::cgx_vgr::VGR_CSR_COLORTRANSFORM_REG_NUMBER} } { incr i } {
#
#           dashboard_set_property $dash_path dash_ctx_colortransform_mul$i text [ ATH_GET_FIELD $data($i) VGR_CSR_COLORTRANSFORM_MUL ] 
#           dashboard_set_property $dash_path dash_ctx_colortransform_add$i text [ ATH_GET_FIELD $data($i) VGR_CSR_COLORTRANSFORM_ADD ] 
#           
#       }
#   }




    proc ctx_get_dash { } {

        set dash_path ${::cgx_vgr::dash_path} 
        
        # set ID
        set reg 0            
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO    ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ] 
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS ${::cgx_vgr::VGR_CSR_CTX_CLASS_DASHS} ]
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE  0 ]        
        
        open_service master ${::boardInit::masterPath}
        # set header  
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg

        set reg [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] 1 ]

        set dash_num [ ATH_GET_FIELD $reg VGR_CSR_CMD_ID_REG_NUM ] ;            
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount text $dash_num
         
        for { set i 0 } { ${i} < ${::cgx_vgr::DASHBOARD_MAX_DASHPATTERNS} } { incr i } {
            
            # set word offset
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i
            # get word data
            set data(${i}) [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
        }

        close_service master ${::boardInit::masterPath}

        for { set i 0 } { ${i} < ${::cgx_vgr::DASHBOARD_MAX_DASHPATTERNS} } { incr i } {

            if { $i < $dash_num } {
                dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i text $data($i)       
            } else { 
                dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i text -1       
            }
        }
    }


    proc ctx_get_colorramp { } {

        set dash_path ${::cgx_vgr::dash_path} 
        
        # set ID
        set reg 0            
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_DO    ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ] 
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_CLASS ${::cgx_vgr::VGR_CSR_CTX_CLASS_COLORRAMP} ]
        set reg [ ATH_SET_FIELD $reg VGR_CSR_CMD_ID_TYPE  0 ]        
        
        open_service master ${::boardInit::masterPath}
        # set header  
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] $reg

        set reg [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_ID} ] 1 ]

        set reg_num [ ATH_GET_FIELD $reg VGR_CSR_CMD_ID_REG_NUM ] ;            
        set stops_num [ expr $reg_num / ${::cgx_vgr::VGR_DEF_RAMP_STOP_REG_NUMBER} ]
        dashboard_set_property $dash_path dash_ctx_paint_gradient_stops text $stops_num


        set num_reg32 [ expr ${::cgx_vgr::VGR_DEF_RAMP_STOP_REG_NUMBER} * ${::cgx_vgr::DASHBOARD_MAX_STOPS} ]
         
        for { set i 0 } { ${i} < $num_reg32 } { incr i } {
            
            # set word offset
            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_OFST} ] $i
            # get word data
            set data(${i}) [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vgr::VGR_CSR_DEV_BASE} + 4*${::cgx_vgr::VGR_CSR_REG_CMD_DBG_DATA} ] 1 ]; 
        }

        close_service master ${::boardInit::masterPath}

        for { set i 0 } { ${i} < ${::cgx_vgr::DASHBOARD_MAX_STOPS} } { incr i } {

            if { $i < $stops_num } {
                set reg_offset [ expr $i * ${::cgx_vgr::VGR_DEF_RAMP_STOP_REG_NUMBER} + ${::cgx_vgr::VGR_DEF_RAMP_STOP_REG_OFFSET} ]
                set reg_color  [ expr $i * ${::cgx_vgr::VGR_DEF_RAMP_STOP_REG_NUMBER} + ${::cgx_vgr::VGR_DEF_RAMP_STOP_REG_COLOR} ]
                dashboard_set_property $dash_path dash_ctx_colorramp_offset$i    text [ATH_GET_FIELD $data($reg_offset) VGR_DEF_STOP_OFFSET ]                 
                dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i text [ATH_GET_FIELD $data($reg_offset) VGR_DEF_STOP_OFFSETINV ]                 
                dashboard_set_property $dash_path dash_ctx_colorramp_color$i     text [ format 0x%x [ ATH_GET_FIELD $data($reg_color)  VGR_DEF_STOP_COLOR  ] ]     
            } else { 
                dashboard_set_property $dash_path dash_ctx_colorramp_offset$i    text -1 
                dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i text -1 
                dashboard_set_property $dash_path dash_ctx_colorramp_color$i     text -1    
            }
        }
    }


    proc get_context { } {
 
        for { set j 0 } { ${j} < [ expr ${::cgx_vgr::VGR_CSR_CTX_FRAME_NUMBER} ] } { incr j } {
            set name "frame#$j = "; 
            get_param $name ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ${::cgx_vgr::VGR_CSR_CTX_CLASS_FRAME} ${j} ${::cgx_vgr::VGR_CSR_CTX_CLASS_REGNUM_FRAME}            
        }

        for { set j 0 } { ${j} < [ expr ${::cgx_vgr::VGR_CSR_CTX_RECT_NUMBER} ] } { incr j } {
            set name "rect#$j = "; 
            get_param $name ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ${::cgx_vgr::VGR_CSR_CTX_CLASS_RECT} ${j} ${::cgx_vgr::VGR_CSR_CTX_CLASS_REGNUM_RECT}            
        }

        for { set j 0 } { ${j} < [ expr ${::cgx_vgr::VGR_CSR_CTX_MATRIX_NUMBER} ] } { incr j } {
            set name "matrix#$j = "; 
            get_param $name ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ${::cgx_vgr::VGR_CSR_CTX_CLASS_MATRIX} ${j} ${::cgx_vgr::VGR_CSR_CTX_CLASS_REGNUM_MATRIX}            
        }

        for { set j 0 } { ${j} < [ expr ${::cgx_vgr::VGR_CSR_CTX_PARAM_NUMBER} ] } { incr j } {
            set name "param#$j = "; 
            get_param $name ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ${::cgx_vgr::VGR_CSR_CTX_CLASS_PARAM} ${j} 1            
        }
      
        for { set j 0 } { ${j} < 1 } { incr j } {
            set name "colorramp (4 first stops) = "; 
            get_param $name ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ${::cgx_vgr::VGR_CSR_CTX_CLASS_COLORRAMP} ${j} [ expr 4 * 2]            
        }

      # for { set j 0 } { ${j} < 1 } { incr j } {
      #     set name "colortransform = "; 
      #     get_param $name ${::cgx_vgr::VGR_CMD_DO_SET_CONTEXT} ${::cgx_vgr::VGR_CSR_CTX_CLASS_COLORTRANSFORM} ${j} ${::cgx_vgr::VGR_CSR_COLORTRANSFORM_REG_NUMBER}            
      # }

        for { set j 0 } { ${j} < 1 } { incr j } {
            set name "drawing operation = "; 
            get_param $name ${::cgx_vgr::VGR_CMD_DO_OPR} 0 ${j} [ expr ${::cgx_vgr::VGR_CSR_OPR_REG_NUMBER} + ${::cgx_vgr::VGR_CSR_OPR_MAX_ARG_NUMBER} ]            
        }

    }



    proc dashBoard {} {

        if { ${::cgx_vgr::dashboardActive} == 1 } {
            return -code ok "dashboard already active"
        }

        set ::cgx_vgr::dashboardActive 1
        puts stdout "dashBoard start ......."

        #
        # Create dashboard 
        #
        variable ::cgx_vgr::dash_path [ add_service dashboard cgx_vgr "cgx_vgr" "Tools/cgx_vgr"]

        set dash_path ${::cgx_vgr::dash_path} 

        #
        # Set dashboard properties
        #
        dashboard_set_property $dash_path self developmentMode true
        dashboard_set_property $dash_path self itemsPerRow 1
        dashboard_set_property $dash_path self visible true
        
        #
        # groups
        #
        dashboard_add          $dash_path grp_top group self
        dashboard_set_property $dash_path grp_top expandableX false
        dashboard_set_property $dash_path grp_top expandableY false
        dashboard_set_property $dash_path grp_top itemsPerRow 1
        dashboard_set_property $dash_path grp_top title ""

        dashboard_add          $dash_path grp_device group grp_top
        dashboard_set_property $dash_path grp_device expandableX false
        dashboard_set_property $dash_path grp_device expandableY false
        dashboard_set_property $dash_path grp_device itemsPerRow 4
        dashboard_set_property $dash_path grp_device title "Device"

        dashboard_add          $dash_path grp_core group grp_top
        dashboard_set_property $dash_path grp_core expandableX false
        dashboard_set_property $dash_path grp_core expandableY false
        dashboard_set_property $dash_path grp_core itemsPerRow 1
        dashboard_set_property $dash_path grp_core title "Core ${::cgx_vgr::IPCORE_VERSION}"
        dashboard_set_property $dash_path grp_core visible false; # dashboard init

        dashboard_add          $dash_path grp_core_cmd group grp_core
        dashboard_set_property $dash_path grp_core_cmd expandableX false
        dashboard_set_property $dash_path grp_core_cmd expandableY false
        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_core_cmd title ""

        dashboard_add          $dash_path grp_csr group grp_core
        dashboard_set_property $dash_path grp_csr expandableX false
        dashboard_set_property $dash_path grp_csr expandableY false
        dashboard_set_property $dash_path grp_csr itemsPerRow 1
        dashboard_set_property $dash_path grp_csr title ""
        dashboard_set_property $dash_path grp_csr visible false; # dashboard init

        dashboard_add          $dash_path grp_csr_main group grp_csr
        dashboard_set_property $dash_path grp_csr_main expandableX false
        dashboard_set_property $dash_path grp_csr_main expandableY false
        dashboard_set_property $dash_path grp_csr_main itemsPerRow 6
        dashboard_set_property $dash_path grp_csr_main title ""
 
        dashboard_add          $dash_path grp_config group grp_csr_main
        dashboard_set_property $dash_path grp_config expandableX false
        dashboard_set_property $dash_path grp_config expandableY false
        dashboard_set_property $dash_path grp_config itemsPerRow 1
        dashboard_set_property $dash_path grp_config title "Config"

        dashboard_add          $dash_path grp_cfg_cmd group grp_config
        dashboard_set_property $dash_path grp_cfg_cmd expandableX false
        dashboard_set_property $dash_path grp_cfg_cmd expandableY false
        dashboard_set_property $dash_path grp_cfg_cmd itemsPerRow 2
        dashboard_set_property $dash_path grp_cfg_cmd title ""

        dashboard_add          $dash_path grp_cfg_param0 group grp_config
        dashboard_set_property $dash_path grp_cfg_param0 expandableX false
        dashboard_set_property $dash_path grp_cfg_param0 expandableY false
        dashboard_set_property $dash_path grp_cfg_param0 itemsPerRow 3
        dashboard_set_property $dash_path grp_cfg_param0 title ""

        dashboard_add          $dash_path grp_cfg_irq group grp_config
        dashboard_set_property $dash_path grp_cfg_irq expandableX false
        dashboard_set_property $dash_path grp_cfg_irq expandableY false
        dashboard_set_property $dash_path grp_cfg_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_cfg_irq title "interrupt enable"

        dashboard_add          $dash_path grp_status group grp_csr_main
        dashboard_set_property $dash_path grp_status expandableX false
        dashboard_set_property $dash_path grp_status expandableY false
        dashboard_set_property $dash_path grp_status itemsPerRow 1
        dashboard_set_property $dash_path grp_status title "Status"

        dashboard_add          $dash_path grp_sts_cmd group grp_status
        dashboard_set_property $dash_path grp_sts_cmd expandableX false
        dashboard_set_property $dash_path grp_sts_cmd expandableY false
        dashboard_set_property $dash_path grp_sts_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_cmd title ""

        dashboard_add          $dash_path grp_sts_param group grp_status
        dashboard_set_property $dash_path grp_sts_param expandableX false
        dashboard_set_property $dash_path grp_sts_param expandableY false
        dashboard_set_property $dash_path grp_sts_param itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_param title ""

        dashboard_add          $dash_path grp_sts_irq group grp_status
        dashboard_set_property $dash_path grp_sts_irq expandableX false
        dashboard_set_property $dash_path grp_sts_irq expandableY false
        dashboard_set_property $dash_path grp_sts_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_sts_irq title "interrupt active"

        dashboard_add          $dash_path grp_fct group grp_csr
        dashboard_set_property $dash_path grp_fct expandableX false
        dashboard_set_property $dash_path grp_fct expandableY false
        dashboard_set_property $dash_path grp_fct itemsPerRow 4
        dashboard_set_property $dash_path grp_fct title ""

     #  dashboard_add          $dash_path grp_fct_left group grp_fct
     #  dashboard_set_property $dash_path grp_fct_left expandableX false
     #  dashboard_set_property $dash_path grp_fct_left expandableY false
     #  dashboard_set_property $dash_path grp_fct_left itemsPerRow 1
     #  dashboard_set_property $dash_path grp_fct_left title ""

     #  dashboard_add          $dash_path grp_fct_right group grp_fct
     #  dashboard_set_property $dash_path grp_fct_right expandableX false
     #  dashboard_set_property $dash_path grp_fct_right expandableY false
     #  dashboard_set_property $dash_path grp_fct_right itemsPerRow 1
     #  dashboard_set_property $dash_path grp_fct_right title ""

        dashboard_add          $dash_path grp_cmd group grp_csr_main
        dashboard_set_property $dash_path grp_cmd expandableX false
        dashboard_set_property $dash_path grp_cmd expandableY true
        dashboard_set_property $dash_path grp_cmd itemsPerRow 1
        dashboard_set_property $dash_path grp_cmd title "Commands"

        dashboard_add          $dash_path grp_path group grp_csr_main
        dashboard_set_property $dash_path grp_path expandableX false
        dashboard_set_property $dash_path grp_path expandableY true
        dashboard_set_property $dash_path grp_path itemsPerRow 1
        dashboard_set_property $dash_path grp_path title "B�zier Path"

        dashboard_add          $dash_path grp_opr group grp_csr_main
        dashboard_set_property $dash_path grp_opr expandableX false
        dashboard_set_property $dash_path grp_opr expandableY true
        dashboard_set_property $dash_path grp_opr itemsPerRow 1
        dashboard_set_property $dash_path grp_opr title "Drawing Operation"

        dashboard_add          $dash_path grp_debug group grp_csr_main
        dashboard_set_property $dash_path grp_debug expandableX false
        dashboard_set_property $dash_path grp_debug expandableY false
        dashboard_set_property $dash_path grp_debug itemsPerRow 1
        dashboard_set_property $dash_path grp_debug title "Debug"

        dashboard_add          $dash_path grp_debug_cmd group grp_debug
        dashboard_set_property $dash_path grp_debug_cmd expandableX false
        dashboard_set_property $dash_path grp_debug_cmd expandableY false
        dashboard_set_property $dash_path grp_debug_cmd itemsPerRow 5
        dashboard_set_property $dash_path grp_debug_cmd title ""

        dashboard_add          $dash_path grp_break group grp_debug
        dashboard_set_property $dash_path grp_break expandableX false
        dashboard_set_property $dash_path grp_break expandableY false
        dashboard_set_property $dash_path grp_break itemsPerRow 1
        dashboard_set_property $dash_path grp_break title "Break"

        dashboard_add          $dash_path grp_brk_cfg group grp_break
        dashboard_set_property $dash_path grp_brk_cfg expandableX false
        dashboard_set_property $dash_path grp_brk_cfg expandableY false
        dashboard_set_property $dash_path grp_brk_cfg itemsPerRow 4
        dashboard_set_property $dash_path grp_brk_cfg title "Config"

        dashboard_add          $dash_path grp_brk_sts group grp_break
        dashboard_set_property $dash_path grp_brk_sts expandableX false
        dashboard_set_property $dash_path grp_brk_sts expandableY false
        dashboard_set_property $dash_path grp_brk_sts itemsPerRow 10
        dashboard_set_property $dash_path grp_brk_sts title "Status"

        dashboard_add          $dash_path grp_breaked group grp_break
        dashboard_set_property $dash_path grp_breaked expandableX false
        dashboard_set_property $dash_path grp_breaked expandableY false
        dashboard_set_property $dash_path grp_breaked itemsPerRow 1
        dashboard_set_property $dash_path grp_breaked title ""

        dashboard_add          $dash_path grp_context group grp_fct
        dashboard_set_property $dash_path grp_context expandableX false
        dashboard_set_property $dash_path grp_context expandableY false
        dashboard_set_property $dash_path grp_context itemsPerRow 1
        dashboard_set_property $dash_path grp_context title "Drawing Context"

        dashboard_add          $dash_path grp_ctx_opts group grp_context
        dashboard_set_property $dash_path grp_ctx_opts expandableX false
        dashboard_set_property $dash_path grp_ctx_opts expandableY false
        dashboard_set_property $dash_path grp_ctx_opts itemsPerRow 15
        dashboard_set_property $dash_path grp_ctx_opts title "Undo Options"

        dashboard_add          $dash_path grp_ctx_frame group grp_context
        dashboard_set_property $dash_path grp_ctx_frame expandableX false
        dashboard_set_property $dash_path grp_ctx_frame expandableY false
        dashboard_set_property $dash_path grp_ctx_frame itemsPerRow 15
        dashboard_set_property $dash_path grp_ctx_frame title "Frame"

    #   dashboard_add          $dash_path grp_ctx_rect group grp_context
    #   dashboard_set_property $dash_path grp_ctx_rect expandableX false
    #   dashboard_set_property $dash_path grp_ctx_rect expandableY false
    #   dashboard_set_property $dash_path grp_ctx_rect itemsPerRow 5
    #   dashboard_set_property $dash_path grp_ctx_rect title "Rect"

        dashboard_add          $dash_path grp_ctx_matrix group grp_context
        dashboard_set_property $dash_path grp_ctx_matrix expandableX false
        dashboard_set_property $dash_path grp_ctx_matrix expandableY false
        dashboard_set_property $dash_path grp_ctx_matrix itemsPerRow 10
        dashboard_set_property $dash_path grp_ctx_matrix title "Matrix"

        dashboard_add          $dash_path grp_ctx2 group grp_context
        dashboard_set_property $dash_path grp_ctx2 expandableX false
        dashboard_set_property $dash_path grp_ctx2 expandableY false
        dashboard_set_property $dash_path grp_ctx2 itemsPerRow 7
        dashboard_set_property $dash_path grp_ctx2 title ""

        dashboard_add          $dash_path grp_ctx_path group grp_context
        dashboard_set_property $dash_path grp_ctx_path expandableX false
        dashboard_set_property $dash_path grp_ctx_path expandableY false
        dashboard_set_property $dash_path grp_ctx_path itemsPerRow 1
        dashboard_set_property $dash_path grp_ctx_path title "Path"

        dashboard_add          $dash_path grp_ctx_paint group grp_context
        dashboard_set_property $dash_path grp_ctx_paint expandableX false
        dashboard_set_property $dash_path grp_ctx_paint expandableY false
        dashboard_set_property $dash_path grp_ctx_paint itemsPerRow 2
        dashboard_set_property $dash_path grp_ctx_paint title "Fill paint"

    #   dashboard_add          $dash_path grp_ctx3 group grp_context
    #   dashboard_set_property $dash_path grp_ctx3 expandableX false
    #   dashboard_set_property $dash_path grp_ctx3 expandableY false
    #   dashboard_set_property $dash_path grp_ctx3 itemsPerRow 3
    #   dashboard_set_property $dash_path grp_ctx3 title ""

        dashboard_add          $dash_path grp_ctx_clipping group grp_context
        dashboard_set_property $dash_path grp_ctx_clipping expandableX false
        dashboard_set_property $dash_path grp_ctx_clipping expandableY false
        dashboard_set_property $dash_path grp_ctx_clipping itemsPerRow 2
        dashboard_set_property $dash_path grp_ctx_clipping title "Clipping"

        dashboard_add          $dash_path grp_ctx_clipping_prm group grp_ctx_clipping
        dashboard_set_property $dash_path grp_ctx_clipping_prm expandableX false
        dashboard_set_property $dash_path grp_ctx_clipping_prm expandableY false
        dashboard_set_property $dash_path grp_ctx_clipping_prm itemsPerRow 1
        dashboard_set_property $dash_path grp_ctx_clipping_prm title ""

        dashboard_add          $dash_path grp_ctx_clipping_rect group grp_ctx_clipping
        dashboard_set_property $dash_path grp_ctx_clipping_rect expandableX false
        dashboard_set_property $dash_path grp_ctx_clipping_rect expandableY false
        dashboard_set_property $dash_path grp_ctx_clipping_rect itemsPerRow 4
        dashboard_set_property $dash_path grp_ctx_clipping_rect title "rect"

        dashboard_add          $dash_path grp_ctx_stroke group grp_ctx_path
        dashboard_set_property $dash_path grp_ctx_stroke expandableX false
        dashboard_set_property $dash_path grp_ctx_stroke expandableY false
        dashboard_set_property $dash_path grp_ctx_stroke itemsPerRow [ expr 6 + ${::cgx_vgr::DASHBOARD_MAX_DASHPATTERNS} ]
        dashboard_set_property $dash_path grp_ctx_stroke title "Stroke"

        dashboard_add          $dash_path grp_ctx_raster group grp_ctx_path
        dashboard_set_property $dash_path grp_ctx_raster expandableX false
        dashboard_set_property $dash_path grp_ctx_raster expandableY false
        dashboard_set_property $dash_path grp_ctx_raster itemsPerRow 3
        dashboard_set_property $dash_path grp_ctx_raster title "Raster"

        dashboard_add          $dash_path grp_ctx_paint_prm group grp_ctx_paint
        dashboard_set_property $dash_path grp_ctx_paint_prm expandableX false
        dashboard_set_property $dash_path grp_ctx_paint_prm expandableY false
        dashboard_set_property $dash_path grp_ctx_paint_prm itemsPerRow 1
        dashboard_set_property $dash_path grp_ctx_paint_prm title ""

        dashboard_add          $dash_path grp_ctx_gradient group grp_ctx_paint
        dashboard_set_property $dash_path grp_ctx_gradient expandableX false
        dashboard_set_property $dash_path grp_ctx_gradient expandableY false
        dashboard_set_property $dash_path grp_ctx_gradient itemsPerRow 2
        dashboard_set_property $dash_path grp_ctx_gradient title "Gradient"

        dashboard_add          $dash_path grp_ctx_pattern group grp_ctx_paint
        dashboard_set_property $dash_path grp_ctx_pattern expandableX false
        dashboard_set_property $dash_path grp_ctx_pattern expandableY false
        dashboard_set_property $dash_path grp_ctx_pattern itemsPerRow 2
        dashboard_set_property $dash_path grp_ctx_pattern title "Pattern"

        dashboard_add          $dash_path grp_ctx_gradient_param group grp_ctx_gradient
        dashboard_set_property $dash_path grp_ctx_gradient_param expandableX false
        dashboard_set_property $dash_path grp_ctx_gradient_param expandableY false
        dashboard_set_property $dash_path grp_ctx_gradient_param itemsPerRow 1
        dashboard_set_property $dash_path grp_ctx_gradient_param title ""

        dashboard_add          $dash_path grp_ctx_colorramp group grp_ctx_gradient
        dashboard_set_property $dash_path grp_ctx_colorramp expandableX false
        dashboard_set_property $dash_path grp_ctx_colorramp expandableY false
        dashboard_set_property $dash_path grp_ctx_colorramp itemsPerRow [ expr ${::cgx_vgr::VGR_DEF_RAMP_STOP_REG_NUMBER} * ${::cgx_vgr::DASHBOARD_MAX_STOPS} ]
        dashboard_set_property $dash_path grp_ctx_colorramp title ""

        dashboard_add          $dash_path grp_ctx_masking group grp_ctx2
        dashboard_set_property $dash_path grp_ctx_masking expandableX false
        dashboard_set_property $dash_path grp_ctx_masking expandableY false
        dashboard_set_property $dash_path grp_ctx_masking itemsPerRow 10
        dashboard_set_property $dash_path grp_ctx_masking title "Masking"

    #   dashboard_add          $dash_path grp_ctx_image_interpolation group grp_ctx2
    #   dashboard_set_property $dash_path grp_ctx_image_interpolation expandableX false
    #   dashboard_set_property $dash_path grp_ctx_image_interpolation expandableY false
    #   dashboard_set_property $dash_path grp_ctx_image_interpolation itemsPerRow 1
    #   dashboard_set_property $dash_path grp_ctx_image_interpolation title "Image interpolation"

        dashboard_add          $dash_path grp_ctx_blending group grp_ctx2
        dashboard_set_property $dash_path grp_ctx_blending expandableX false
        dashboard_set_property $dash_path grp_ctx_blending expandableY false
        dashboard_set_property $dash_path grp_ctx_blending itemsPerRow 1
        dashboard_set_property $dash_path grp_ctx_blending title "Blending"

    #   dashboard_add          $dash_path grp_ctx_colortransform group grp_context
    #   dashboard_set_property $dash_path grp_ctx_colortransform expandableX false
    #   dashboard_set_property $dash_path grp_ctx_colortransform expandableY false
    #   dashboard_set_property $dash_path grp_ctx_colortransform itemsPerRow 3
    #   dashboard_set_property $dash_path grp_ctx_colortransform title "Color-transform"
  # 
  #     dashboard_add          $dash_path grp_ctx_colortransform_ena group grp_ctx_colortransform
  #     dashboard_set_property $dash_path grp_ctx_colortransform_ena expandableX false
  #     dashboard_set_property $dash_path grp_ctx_colortransform_ena expandableY false
  #     dashboard_set_property $dash_path grp_ctx_colortransform_ena itemsPerRow 4
  #     dashboard_set_property $dash_path grp_ctx_colortransform_ena title ""
  #
  #     dashboard_add          $dash_path grp_ctx_colortransform_mul group grp_ctx_colortransform
  #     dashboard_set_property $dash_path grp_ctx_colortransform_mul expandableX false
  #     dashboard_set_property $dash_path grp_ctx_colortransform_mul expandableY false
  #     dashboard_set_property $dash_path grp_ctx_colortransform_mul itemsPerRow 4
  #     dashboard_set_property $dash_path grp_ctx_colortransform_mul title "MUL"
  #
  #     dashboard_add          $dash_path grp_ctx_colortransform_add group grp_ctx_colortransform
  #     dashboard_set_property $dash_path grp_ctx_colortransform_add expandableX false
  #     dashboard_set_property $dash_path grp_ctx_colortransform_add expandableY false
  #     dashboard_set_property $dash_path grp_ctx_colortransform_add itemsPerRow 4
  #     dashboard_set_property $dash_path grp_ctx_colortransform_add title "ADD"

        dashboard_add          $dash_path grp_context_cmd group grp_context
        dashboard_set_property $dash_path grp_context_cmd expandableX false
        dashboard_set_property $dash_path grp_context_cmd expandableY false
        dashboard_set_property $dash_path grp_context_cmd itemsPerRow 1
        dashboard_set_property $dash_path grp_context_cmd title ""

        #
        # widgets
        #

        dashboard_add          $dash_path dash_dev_init button grp_device 
        dashboard_set_property $dash_path dash_dev_init enabled true
        dashboard_set_property $dash_path dash_dev_init text "Init"
        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_vgr::dash_init_device }  

        dashboard_add          $dash_path dash_dev_dump button grp_device 
        dashboard_set_property $dash_path dash_dev_dump enabled true
        dashboard_set_property $dash_path dash_dev_dump text "Dump"
        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_vgr::dash_dump_device }  

        dashboard_add          $dash_path dash_dev_base text grp_device 
        dashboard_set_property $dash_path dash_dev_base label "base" 
        dashboard_set_property $dash_path dash_dev_base expandableX false
        dashboard_set_property $dash_path dash_dev_base expandableY false
        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
        dashboard_set_property $dash_path dash_dev_base editable false
        dashboard_set_property $dash_path dash_dev_base htmlCapable false
        dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_vgr::VGR_CSR_DEV_BASE} ]

        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_version enabled true
        dashboard_set_property $dash_path dash_dev_version text "Version"
        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_vgr::get_version }  

        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_caps enabled true
        dashboard_set_property $dash_path dash_dev_caps text "Caps"
        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_vgr::dash_get_caps }  
        
        dashboard_add          $dash_path dash_cfg_run checkBox grp_cfg_param0 
        dashboard_set_property $dash_path dash_cfg_run enabled true
        dashboard_set_property $dash_path dash_cfg_run text "Run"

        dashboard_add          $dash_path dash_cfg_ie_diag_error checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_diag_error text "error internal"

        dashboard_add          $dash_path dash_cfg_ie_cmd_elab_error checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_cmd_elab_error text "error command"

        dashboard_add          $dash_path dash_cfg_ie_pool0_overflow checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_pool0_overflow text "pool0 overflow"

        dashboard_add          $dash_path dash_cfg_ie_pool1_overflow checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_pool1_overflow text "pool1 overflow"

        dashboard_add          $dash_path dash_cfg_set button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_set enabled true
        dashboard_set_property $dash_path dash_cfg_set text "Set"
        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_vgr::dash_set_config }  

        dashboard_add          $dash_path dash_cfg_readback button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_readback enabled true
        dashboard_set_property $dash_path dash_cfg_readback text "Readback"
        dashboard_set_property $dash_path dash_cfg_readback onClick { ::cgx_vgr::dash_get_config }  

 
        #
        # monitor /  widgets
        #

        dashboard_add          $dash_path dash_sts_get button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_get enabled true
        dashboard_set_property $dash_path dash_sts_get text "Get"
        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_vgr::dash_get_status }  

        dashboard_add          $dash_path dash_sts_clear button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_clear text "Clear"
        dashboard_set_property $dash_path dash_sts_clear onClick { ::cgx_vgr::dash_clr_status }  

        dashboard_add          $dash_path dash_sts_run button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_run text "Run"
        dashboard_set_property $dash_path dash_sts_run enabled false
        dashboard_set_property $dash_path dash_sts_run onClick { ::cgx_vgr::dash_run_status }  
      
        dashboard_add          $dash_path dash_sts_busy checkBox grp_sts_param
        dashboard_set_property $dash_path dash_sts_busy text "busy"

        dashboard_add          $dash_path dash_sts_irq led grp_sts_param
        dashboard_set_property $dash_path dash_sts_irq text "irq"
        dashboard_set_property $dash_path dash_sts_irq color "black"

        dashboard_add          $dash_path dash_sts_ia_diag_error checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_diag_error text "error internal"

        dashboard_add          $dash_path dash_sts_ia_cmd_elab_error checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_cmd_elab_error text "error command"

        dashboard_add          $dash_path dash_sts_ia_pool0_overflow checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_pool0_overflow text "pool0 overflow"

        dashboard_add          $dash_path dash_sts_ia_pool1_overflow checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_pool1_overflow text "pool1 overflow"

                                                                                          
        dashboard_add          $dash_path dash_cmd_busy checkBox grp_cmd
        dashboard_set_property $dash_path dash_cmd_busy text "busy"
        dashboard_set_property $dash_path dash_cmd_busy enabled true        

        dashboard_add          $dash_path dash_cmd_elab_busy checkBox grp_cmd
        dashboard_set_property $dash_path dash_cmd_elab_busy text "elab. busy"
        dashboard_set_property $dash_path dash_cmd_elab_busy enabled true        

    #   dashboard_add          $dash_path dash_cmd_error checkBox grp_cmd 
    #   dashboard_set_property $dash_path dash_cmd_error enabled true
    #   dashboard_set_property $dash_path dash_cmd_error text "error"

        dashboard_add          $dash_path dash_cmd_fifo_full checkBox grp_cmd 
        dashboard_set_property $dash_path dash_cmd_fifo_full enabled true
        dashboard_set_property $dash_path dash_cmd_fifo_full text "fifo full"

        dashboard_add          $dash_path dash_cmd_fifo_used text grp_cmd
        dashboard_set_property $dash_path dash_cmd_fifo_used label "fifo used" 
        dashboard_set_property $dash_path dash_cmd_fifo_used expandableX false
        dashboard_set_property $dash_path dash_cmd_fifo_used expandableY false
        dashboard_set_property $dash_path dash_cmd_fifo_used preferredWidth 50
        dashboard_set_property $dash_path dash_cmd_fifo_used editable false
        dashboard_set_property $dash_path dash_cmd_fifo_used htmlCapable false
        dashboard_set_property $dash_path dash_cmd_fifo_used text "0"
     
        dashboard_add          $dash_path dash_cmd_count text grp_cmd
        dashboard_set_property $dash_path dash_cmd_count label "count" 
        dashboard_set_property $dash_path dash_cmd_count expandableX false
        dashboard_set_property $dash_path dash_cmd_count expandableY false
        dashboard_set_property $dash_path dash_cmd_count preferredWidth 50
        dashboard_set_property $dash_path dash_cmd_count editable false
        dashboard_set_property $dash_path dash_cmd_count htmlCapable false
        dashboard_set_property $dash_path dash_cmd_count text "0"


        dashboard_add          $dash_path dash_path_pool0_addr text grp_path
        dashboard_set_property $dash_path dash_path_pool0_addr label "pool0 base64" 
        dashboard_set_property $dash_path dash_path_pool0_addr expandableX false
        dashboard_set_property $dash_path dash_path_pool0_addr expandableY false
        dashboard_set_property $dash_path dash_path_pool0_addr preferredWidth 80
        dashboard_set_property $dash_path dash_path_pool0_addr editable false
        dashboard_set_property $dash_path dash_path_pool0_addr htmlCapable false
        dashboard_set_property $dash_path dash_path_pool0_addr text "0"

        dashboard_add          $dash_path dash_path_pool0_size text grp_path
        dashboard_set_property $dash_path dash_path_pool0_size label "pool0 size64" 
        dashboard_set_property $dash_path dash_path_pool0_size expandableX false
        dashboard_set_property $dash_path dash_path_pool0_size expandableY false
        dashboard_set_property $dash_path dash_path_pool0_size preferredWidth 80
        dashboard_set_property $dash_path dash_path_pool0_size editable false
        dashboard_set_property $dash_path dash_path_pool0_size htmlCapable false
        dashboard_set_property $dash_path dash_path_pool0_size text "0"

        dashboard_add          $dash_path dash_path_pool1_addr text grp_path
        dashboard_set_property $dash_path dash_path_pool1_addr label "pool1 base64" 
        dashboard_set_property $dash_path dash_path_pool1_addr expandableX false
        dashboard_set_property $dash_path dash_path_pool1_addr expandableY false
        dashboard_set_property $dash_path dash_path_pool1_addr preferredWidth 80
        dashboard_set_property $dash_path dash_path_pool1_addr editable false
        dashboard_set_property $dash_path dash_path_pool1_addr htmlCapable false
        dashboard_set_property $dash_path dash_path_pool1_addr text "0"

        dashboard_add          $dash_path dash_path_pool1_size text grp_path
        dashboard_set_property $dash_path dash_path_pool1_size label "pool1 size64" 
        dashboard_set_property $dash_path dash_path_pool1_size expandableX false
        dashboard_set_property $dash_path dash_path_pool1_size expandableY false
        dashboard_set_property $dash_path dash_path_pool1_size preferredWidth 80
        dashboard_set_property $dash_path dash_path_pool1_size editable false
        dashboard_set_property $dash_path dash_path_pool1_size htmlCapable false
        dashboard_set_property $dash_path dash_path_pool1_size text "0"

        dashboard_add          $dash_path dash_path_pts_src_peak text grp_path
        dashboard_set_property $dash_path dash_path_pts_src_peak label "src. path peak pts" 
        dashboard_set_property $dash_path dash_path_pts_src_peak expandableX false
        dashboard_set_property $dash_path dash_path_pts_src_peak expandableY false
        dashboard_set_property $dash_path dash_path_pts_src_peak preferredWidth 50
        dashboard_set_property $dash_path dash_path_pts_src_peak editable false
        dashboard_set_property $dash_path dash_path_pts_src_peak htmlCapable false
        dashboard_set_property $dash_path dash_path_pts_src_peak text "0"

        dashboard_add          $dash_path dash_path_pts_dst_peak text grp_path
        dashboard_set_property $dash_path dash_path_pts_dst_peak label "dst. path peak pts" 
        dashboard_set_property $dash_path dash_path_pts_dst_peak expandableX false
        dashboard_set_property $dash_path dash_path_pts_dst_peak expandableY false
        dashboard_set_property $dash_path dash_path_pts_dst_peak preferredWidth 50
        dashboard_set_property $dash_path dash_path_pts_dst_peak editable false
        dashboard_set_property $dash_path dash_path_pts_dst_peak htmlCapable false
        dashboard_set_property $dash_path dash_path_pts_dst_peak text "0"

        dashboard_add          $dash_path dash_path_peak_pending text grp_path
        dashboard_set_property $dash_path dash_path_peak_pending label "pool0 peak pending paths" 
        dashboard_set_property $dash_path dash_path_peak_pending expandableX false
        dashboard_set_property $dash_path dash_path_peak_pending expandableY false
        dashboard_set_property $dash_path dash_path_peak_pending preferredWidth 50
        dashboard_set_property $dash_path dash_path_peak_pending editable false
        dashboard_set_property $dash_path dash_path_peak_pending htmlCapable false
        dashboard_set_property $dash_path dash_path_peak_pending text "0"

        dashboard_add          $dash_path dash_path_peak_pending_pts text grp_path
        dashboard_set_property $dash_path dash_path_peak_pending_pts label "pool0 peak pending pts" 
        dashboard_set_property $dash_path dash_path_peak_pending_pts expandableX false
        dashboard_set_property $dash_path dash_path_peak_pending_pts expandableY false
        dashboard_set_property $dash_path dash_path_peak_pending_pts preferredWidth 50
        dashboard_set_property $dash_path dash_path_peak_pending_pts editable false
        dashboard_set_property $dash_path dash_path_peak_pending_pts htmlCapable false
        dashboard_set_property $dash_path dash_path_peak_pending_pts text "0"

        dashboard_add          $dash_path dash_path_peak_pool1_size64 text grp_path
        dashboard_set_property $dash_path dash_path_peak_pool1_size64 label "pool1 peak size64"
        dashboard_set_property $dash_path dash_path_peak_pool1_size64 expandableX false
        dashboard_set_property $dash_path dash_path_peak_pool1_size64 expandableY false
        dashboard_set_property $dash_path dash_path_peak_pool1_size64 preferredWidth 80
        dashboard_set_property $dash_path dash_path_peak_pool1_size64 editable false
        dashboard_set_property $dash_path dash_path_peak_pool1_size64 htmlCapable false
        dashboard_set_property $dash_path dash_path_peak_pool1_size64 text "0"

    #   dashboard_add          $dash_path dash_path_tile_height1 text grp_path
    #   dashboard_set_property $dash_path dash_path_tile_height1 label "tile height-1" 
    #   dashboard_set_property $dash_path dash_path_tile_height1 expandableX false
    #   dashboard_set_property $dash_path dash_path_tile_height1 expandableY false
    #   dashboard_set_property $dash_path dash_path_tile_height1 preferredWidth 50
    #   dashboard_set_property $dash_path dash_path_tile_height1 editable true
    #   dashboard_set_property $dash_path dash_path_tile_height1 htmlCapable false
    #   dashboard_set_property $dash_path dash_path_tile_height1 text "0"
 
        set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_SX})  "sx" 
        set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_SHX}) "shx" 
        set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_TX})  "tx" 
        set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_SHY}) "shy" 
        set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_SY})  "sy" 
        set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_TY})  "ty" 
    #   set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_W0})  "w0" 
    #   set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_W1})  "w1" 
    #   set matrix_label(${::cgx_vgr::VGR_CSR_MATRIX_REG_W2})  "w2" 
 
        dashboard_add          $dash_path dash_ctx_matrix comboBox grp_ctx_matrix 
        dashboard_set_property $dash_path dash_ctx_matrix label ""
        dashboard_set_property $dash_path dash_ctx_matrix options { "path-image" "paint-fill" "paint-stroke" }; # order compliant to VGR_CSR_CTX_MATRIX_NUMBER
        dashboard_set_property $dash_path dash_ctx_matrix expandableX false
        dashboard_set_property $dash_path dash_ctx_matrix expandableY false
        dashboard_set_property $dash_path dash_ctx_matrix preferredWidth 80
        dashboard_set_property $dash_path dash_ctx_matrix selected 0   
 
        for { set i 0 } { ${i} < ${::cgx_vgr::VGR_CSR_MATRIX_REG_NUMBER} } { incr i } {        
            dashboard_add          $dash_path dash_ctx_mtx$i text grp_ctx_matrix 
            dashboard_set_property $dash_path dash_ctx_mtx$i expandableX false
            dashboard_set_property $dash_path dash_ctx_mtx$i expandableY false
            dashboard_set_property $dash_path dash_ctx_mtx$i preferredWidth 70
            dashboard_set_property $dash_path dash_ctx_mtx$i editable false
            dashboard_set_property $dash_path dash_ctx_mtx$i htmlCapable false
            dashboard_set_property $dash_path dash_ctx_mtx$i label $matrix_label($i)
            dashboard_set_property $dash_path dash_ctx_mtx$i text "0x00000000"
            if { $i >= 6 } {
                dashboard_set_property $dash_path dash_ctx_mtx$i enabled false
            }
        }

   #    dashboard_add          $dash_path dash_ctx_color_transform_enable checkBox grp_ctx_colortransform_ena         
   #    dashboard_set_property $dash_path dash_ctx_color_transform_enable text "enable"
   #    dashboard_set_property $dash_path dash_ctx_color_transform_enable enabled true
   #
   #    set colortransform_label(${::cgx_vgr::VGR_CSR_COLORTRANSFORM_REG_A}) "a" 
   #    set colortransform_label(${::cgx_vgr::VGR_CSR_COLORTRANSFORM_REG_R}) "r" 
   #    set colortransform_label(${::cgx_vgr::VGR_CSR_COLORTRANSFORM_REG_G}) "g" 
   #    set colortransform_label(${::cgx_vgr::VGR_CSR_COLORTRANSFORM_REG_B}) "b" 
   #
   #    for { set i 0 } { ${i} < ${::cgx_vgr::VGR_CSR_COLORTRANSFORM_REG_NUMBER} } { incr i } {
   #
   #        dashboard_add          $dash_path dash_ctx_colortransform_mul$i text grp_ctx_colortransform_mul 
   #        dashboard_set_property $dash_path dash_ctx_colortransform_mul$i expandableX false
   #        dashboard_set_property $dash_path dash_ctx_colortransform_mul$i expandableY false
   #        dashboard_set_property $dash_path dash_ctx_colortransform_mul$i preferredWidth 60
   #        dashboard_set_property $dash_path dash_ctx_colortransform_mul$i editable false
   #        dashboard_set_property $dash_path dash_ctx_colortransform_mul$i htmlCapable false
   #        dashboard_set_property $dash_path dash_ctx_colortransform_mul$i label $colortransform_label($i)
   #        dashboard_set_property $dash_path dash_ctx_colortransform_mul$i text "0"
   #
   #        dashboard_add          $dash_path dash_ctx_colortransform_add$i text grp_ctx_colortransform_add 
   #        dashboard_set_property $dash_path dash_ctx_colortransform_add$i expandableX false
   #        dashboard_set_property $dash_path dash_ctx_colortransform_add$i expandableY false
   #        dashboard_set_property $dash_path dash_ctx_colortransform_add$i preferredWidth 60
   #        dashboard_set_property $dash_path dash_ctx_colortransform_add$i editable false
   #        dashboard_set_property $dash_path dash_ctx_colortransform_add$i htmlCapable false
   #        dashboard_set_property $dash_path dash_ctx_colortransform_add$i label $colortransform_label($i)
   #        dashboard_set_property $dash_path dash_ctx_colortransform_add$i text "0"
   #        
   #    }

        for { set i 0 } { ${i} < ${::cgx_vgr::DASHBOARD_MAX_STOPS} } { incr i } {

            dashboard_add          $dash_path dash_ctx_colorramp_offset$i text grp_ctx_colorramp 
            dashboard_set_property $dash_path dash_ctx_colorramp_offset$i expandableX false
            dashboard_set_property $dash_path dash_ctx_colorramp_offset$i expandableY false
            dashboard_set_property $dash_path dash_ctx_colorramp_offset$i preferredWidth 30
            dashboard_set_property $dash_path dash_ctx_colorramp_offset$i editable false
            dashboard_set_property $dash_path dash_ctx_colorramp_offset$i htmlCapable false
            dashboard_set_property $dash_path dash_ctx_colorramp_offset$i label "offset#$i"
            dashboard_set_property $dash_path dash_ctx_colorramp_offset$i text "0x0"

            dashboard_add          $dash_path dash_ctx_colorramp_offsetinv$i text grp_ctx_colorramp 
            dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i expandableX false
            dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i expandableY false
            dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i preferredWidth 30
            dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i editable false
            dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i htmlCapable false
            dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i label "dofst-inv#$i"
            dashboard_set_property $dash_path dash_ctx_colorramp_offsetinv$i text "0x0"

            dashboard_add          $dash_path dash_ctx_colorramp_color$i text grp_ctx_colorramp 
            dashboard_set_property $dash_path dash_ctx_colorramp_color$i expandableX false
            dashboard_set_property $dash_path dash_ctx_colorramp_color$i expandableY false
            dashboard_set_property $dash_path dash_ctx_colorramp_color$i preferredWidth 60
            dashboard_set_property $dash_path dash_ctx_colorramp_color$i editable false
            dashboard_set_property $dash_path dash_ctx_colorramp_color$i htmlCapable false
            dashboard_set_property $dash_path dash_ctx_colorramp_color$i label "color#$i"
            dashboard_set_property $dash_path dash_ctx_colorramp_color$i text "0x00000000"

        }


        dashboard_add          $dash_path dash_ctx_clear_color text grp_ctx2 
        dashboard_set_property $dash_path dash_ctx_clear_color label "clear color"
        dashboard_set_property $dash_path dash_ctx_clear_color expandableX false
        dashboard_set_property $dash_path dash_ctx_clear_color expandableY false
        dashboard_set_property $dash_path dash_ctx_clear_color preferredWidth 80
        dashboard_set_property $dash_path dash_ctx_clear_color editable false 
        dashboard_set_property $dash_path dash_ctx_clear_color htmlCapable false
        dashboard_set_property $dash_path dash_ctx_clear_color text "0"

        dashboard_add          $dash_path dash_ctx_param_user text grp_ctx2 
        dashboard_set_property $dash_path dash_ctx_param_user label "user"
        dashboard_set_property $dash_path dash_ctx_param_user expandableX false
        dashboard_set_property $dash_path dash_ctx_param_user expandableY false
        dashboard_set_property $dash_path dash_ctx_param_user preferredWidth 80
        dashboard_set_property $dash_path dash_ctx_param_user editable false 
        dashboard_set_property $dash_path dash_ctx_param_user htmlCapable false
        dashboard_set_property $dash_path dash_ctx_param_user text "0"

        dashboard_add          $dash_path dash_fps_count text grp_ctx2 
        dashboard_set_property $dash_path dash_fps_count label "fps ticks"
        dashboard_set_property $dash_path dash_fps_count expandableX false
        dashboard_set_property $dash_path dash_fps_count expandableY false
        dashboard_set_property $dash_path dash_fps_count preferredWidth 80
        dashboard_set_property $dash_path dash_fps_count editable false 
        dashboard_set_property $dash_path dash_fps_count htmlCapable false
        dashboard_set_property $dash_path dash_fps_count text "0"


    #   dashboard_add          $dash_path dash_ctx_clip_enable checkBox grp_ctx_clipping_prm         
    #   dashboard_set_property $dash_path dash_ctx_clip_enable text "enable"
    #   dashboard_set_property $dash_path dash_ctx_clip_enable enabled true

    #   dashboard_add          $dash_path dash_ctx_rect comboBox grp_ctx_rect 
    #   dashboard_set_property $dash_path dash_ctx_rect label "Rect"
    #   dashboard_set_property $dash_path dash_ctx_rect options { "clipping" "masking" }
    #   dashboard_set_property $dash_path dash_ctx_rect expandableX false
    #   dashboard_set_property $dash_path dash_ctx_rect expandableY false
    #   dashboard_set_property $dash_path dash_ctx_rect preferredWidth 80
    #   dashboard_set_property $dash_path dash_ctx_rect selected 0   


        for { set j 0 } { ${j} < [ expr ${::cgx_vgr::VGR_CSR_CTX_RECT_NUMBER} ] } { incr j } {

            set rect_id $j

           #set rect_id ${::cgx_vgr::VGR_CSR_CTX_RECT_SCISSOR_START}
        
            dashboard_add          $dash_path dash_ctx_rect${rect_id}_x text grp_ctx_clipping_rect 
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x label "x"
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x expandableX false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x expandableY false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x preferredWidth 50
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x editable false 
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x htmlCapable false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x text "0"
            
            dashboard_add          $dash_path dash_ctx_rect${rect_id}_y text grp_ctx_clipping_rect 
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y label "y"
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y expandableX false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y expandableY false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y preferredWidth 50
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y editable false 
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y htmlCapable false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y text "0"
            
            dashboard_add          $dash_path dash_ctx_rect${rect_id}_w text grp_ctx_clipping_rect 
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w label "width"
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w expandableX false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w expandableY false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w preferredWidth 50
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w editable false 
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w htmlCapable false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w text "0"
            
            dashboard_add          $dash_path dash_ctx_rect${rect_id}_h text grp_ctx_clipping_rect 
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h label "height"
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h expandableX false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h expandableY false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h preferredWidth 50
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h editable false 
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h htmlCapable false
            dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h text "0"
       
        }                   
              
        dashboard_add          $dash_path dash_ctx_path_fillrule comboBox grp_ctx_raster         
        dashboard_set_property $dash_path dash_ctx_path_fillrule label "fillrule"
        dashboard_set_property $dash_path dash_ctx_path_fillrule options {"EVEN_ODD" "NON ZERO"}
        dashboard_set_property $dash_path dash_ctx_path_fillrule expandableX false
        dashboard_set_property $dash_path dash_ctx_path_fillrule expandableY false
        dashboard_set_property $dash_path dash_ctx_path_fillrule preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_path_fillrule selected 0   

        dashboard_add          $dash_path dash_ctx_glyph_origin_x text grp_ctx_raster 
        dashboard_set_property $dash_path dash_ctx_glyph_origin_x label "glyph origin x"
        dashboard_set_property $dash_path dash_ctx_glyph_origin_x expandableX false
        dashboard_set_property $dash_path dash_ctx_glyph_origin_x expandableY false
        dashboard_set_property $dash_path dash_ctx_glyph_origin_x preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_glyph_origin_x editable false 
        dashboard_set_property $dash_path dash_ctx_glyph_origin_x htmlCapable false
        dashboard_set_property $dash_path dash_ctx_glyph_origin_x text "0"

        dashboard_add          $dash_path dash_ctx_glyph_origin_y text grp_ctx_raster 
        dashboard_set_property $dash_path dash_ctx_glyph_origin_y label "glyph origin y"
        dashboard_set_property $dash_path dash_ctx_glyph_origin_y expandableX false
        dashboard_set_property $dash_path dash_ctx_glyph_origin_y expandableY false
        dashboard_set_property $dash_path dash_ctx_glyph_origin_y preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_glyph_origin_y editable false 
        dashboard_set_property $dash_path dash_ctx_glyph_origin_y htmlCapable false
        dashboard_set_property $dash_path dash_ctx_glyph_origin_y text "0"

        dashboard_add          $dash_path dash_ctx_path_stroke_linewidth text grp_ctx_stroke 
        dashboard_set_property $dash_path dash_ctx_path_stroke_linewidth label "line width"
        dashboard_set_property $dash_path dash_ctx_path_stroke_linewidth expandableX false
        dashboard_set_property $dash_path dash_ctx_path_stroke_linewidth expandableY false
        dashboard_set_property $dash_path dash_ctx_path_stroke_linewidth preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_path_stroke_linewidth editable false 
        dashboard_set_property $dash_path dash_ctx_path_stroke_linewidth htmlCapable false
        dashboard_set_property $dash_path dash_ctx_path_stroke_linewidth text "0"

        dashboard_add          $dash_path dash_ctx_path_stroke_linejoin comboBox grp_ctx_stroke         
        dashboard_set_property $dash_path dash_ctx_path_stroke_linejoin label "line join"
        dashboard_set_property $dash_path dash_ctx_path_stroke_linejoin options {"ROUND" "BEVEL" "MITER" "MITER_CLIP"}; # comply with VGR_CSR_STROKE_LINEJOIN_MSK                   

        dashboard_set_property $dash_path dash_ctx_path_stroke_linejoin expandableX false
        dashboard_set_property $dash_path dash_ctx_path_stroke_linejoin expandableY false
        dashboard_set_property $dash_path dash_ctx_path_stroke_linejoin preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_path_stroke_linejoin selected 0   

        dashboard_add          $dash_path dash_ctx_path_stroke_cap comboBox grp_ctx_stroke         
        dashboard_set_property $dash_path dash_ctx_path_stroke_cap label "cap"
        dashboard_set_property $dash_path dash_ctx_path_stroke_cap options {"BUTT" "ROUND" "SQUARE"}
        dashboard_set_property $dash_path dash_ctx_path_stroke_cap expandableX false
        dashboard_set_property $dash_path dash_ctx_path_stroke_cap expandableY false
        dashboard_set_property $dash_path dash_ctx_path_stroke_cap preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_path_stroke_cap selected 0   

        dashboard_add          $dash_path dash_ctx_path_stroke_miterlimit text grp_ctx_stroke 
        dashboard_set_property $dash_path dash_ctx_path_stroke_miterlimit label "miter limit"
        dashboard_set_property $dash_path dash_ctx_path_stroke_miterlimit expandableX false
        dashboard_set_property $dash_path dash_ctx_path_stroke_miterlimit expandableY false
        dashboard_set_property $dash_path dash_ctx_path_stroke_miterlimit preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_path_stroke_miterlimit editable false 
        dashboard_set_property $dash_path dash_ctx_path_stroke_miterlimit htmlCapable false
        dashboard_set_property $dash_path dash_ctx_path_stroke_miterlimit text "0"

        dashboard_add          $dash_path dash_ctx_path_stroke_dashcount text grp_ctx_stroke 
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount label "dash count"
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount expandableX false
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount expandableY false
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount editable false 
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount htmlCapable false
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashcount text "0"

        dashboard_add          $dash_path dash_ctx_path_stroke_dashphase text grp_ctx_stroke 
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashphase label "dash phase"
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashphase expandableX false
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashphase expandableY false
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashphase preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashphase editable false 
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashphase htmlCapable false
        dashboard_set_property $dash_path dash_ctx_path_stroke_dashphase text "0"

    #   dashboard_add          $dash_path grp_ctx_stroke_dashpattern group grp_ctx_stroke
    #   dashboard_set_property $dash_path grp_ctx_stroke_dashpattern expandableX false
    #   dashboard_set_property $dash_path grp_ctx_stroke_dashpattern expandableY false
    #   dashboard_set_property $dash_path grp_ctx_stroke_dashpattern itemsPerRow ${::cgx_vgr::DASHBOARD_MAX_DASHPATTERNS}
    #   dashboard_set_property $dash_path grp_ctx_stroke_dashpattern title "dash pattern"

        for { set i 0 } { ${i} < ${::cgx_vgr::DASHBOARD_MAX_DASHPATTERNS} } { incr i } {

            dashboard_add          $dash_path dash_ctx_path_stroke_dashpattern$i text grp_ctx_stroke 
            dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i expandableX false
            dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i expandableY false
            dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i preferredWidth 70
            dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i editable false
            dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i htmlCapable false
            dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i label "D#$i"
            dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern$i text "0x0"
        }

    #   dashboard_add          $dash_path dash_ctx_path_stroke_dashpattern text grp_ctx_stroke 
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern label "dash pattern #0"
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern expandableX false
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern expandableY false
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern preferredWidth 50
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern editable false 
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern htmlCapable false
    #   dashboard_set_property $dash_path dash_ctx_path_stroke_dashpattern text "0"
 
        dashboard_add          $dash_path dash_ctx_mask_enable checkBox grp_ctx_masking         
        dashboard_set_property $dash_path dash_ctx_mask_enable text "enable"
        dashboard_set_property $dash_path dash_ctx_mask_enable enabled true
                                                
        dashboard_add          $dash_path dash_ctx_mask_color_plane comboBox grp_ctx_masking         
        dashboard_set_property $dash_path dash_ctx_mask_color_plane label "color plane"
        dashboard_set_property $dash_path dash_ctx_mask_color_plane options { "ALPHA" "RED" "GREEN" "BLUE"}
        dashboard_set_property $dash_path dash_ctx_mask_color_plane expandableX false
        dashboard_set_property $dash_path dash_ctx_mask_color_plane expandableY false
        dashboard_set_property $dash_path dash_ctx_mask_color_plane preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_mask_color_plane selected 0   
                                               
        dashboard_add          $dash_path dash_ctx_mask_color_invert checkBox grp_ctx_masking         
        dashboard_set_property $dash_path dash_ctx_mask_color_invert text "color invert"
        dashboard_set_property $dash_path dash_ctx_mask_color_invert enabled true

#       set rect_id ${::cgx_vgr::VGR_CSR_CTX_RECT_MASK}
#       
#       dashboard_add          $dash_path dash_ctx_rect${rect_id}_x text grp_ctx_masking 
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x label "x"
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x expandableX false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x expandableY false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x preferredWidth 50
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x editable false 
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x htmlCapable false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_x text "0"
#
#       dashboard_add          $dash_path dash_ctx_rect${rect_id}_y text grp_ctx_masking 
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y label "y"
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y expandableX false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y expandableY false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y preferredWidth 50
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y editable false 
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y htmlCapable false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_y text "0"
#
#       dashboard_add          $dash_path dash_ctx_rect${rect_id}_w text grp_ctx_masking 
#     # dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w label "width"
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w expandableX false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w expandableY false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w preferredWidth 50
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w editable false 
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w htmlCapable false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w text "0"
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_w visible false; # not used by VGR 
#
#       dashboard_add          $dash_path dash_ctx_rect${rect_id}_h text grp_ctx_masking 
#     # dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h label "height"
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h expandableX false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h expandableY false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h preferredWidth 50
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h editable false 
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h htmlCapable false
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h text "0"
#       dashboard_set_property $dash_path dash_ctx_rect${rect_id}_h visible false; # not used by VGR 


    #   dashboard_add          $dash_path dash_ctx_paint_code comboBox grp_ctx_paint_prm         
    #   dashboard_set_property $dash_path dash_ctx_paint_code label "code"
    #   dashboard_set_property $dash_path dash_ctx_paint_code options { "param" "RED" "GREEN" "BLUE"}
    #   dashboard_set_property $dash_path dash_ctx_paint_code expandableX false
    #   dashboard_set_property $dash_path dash_ctx_paint_code expandableY false
    #   dashboard_set_property $dash_path dash_ctx_paint_code preferredWidth 50
    #   dashboard_set_property $dash_path dash_ctx_paint_code selected 0   

        dashboard_add          $dash_path dash_ctx_paint_type comboBox grp_ctx_paint_prm         
        dashboard_set_property $dash_path dash_ctx_paint_type label "type"
        dashboard_set_property $dash_path dash_ctx_paint_type options { "color" "gradient" "pattern"}
        dashboard_set_property $dash_path dash_ctx_paint_type expandableX false
        dashboard_set_property $dash_path dash_ctx_paint_type expandableY false
        dashboard_set_property $dash_path dash_ctx_paint_type preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_paint_type selected 0   

        dashboard_add          $dash_path dash_ctx_paint_color text grp_ctx_paint_prm 
        dashboard_set_property $dash_path dash_ctx_paint_color label "color"
        dashboard_set_property $dash_path dash_ctx_paint_color expandableX false
        dashboard_set_property $dash_path dash_ctx_paint_color expandableY false
        dashboard_set_property $dash_path dash_ctx_paint_color preferredWidth 80
        dashboard_set_property $dash_path dash_ctx_paint_color editable false 
        dashboard_set_property $dash_path dash_ctx_paint_color htmlCapable false
        dashboard_set_property $dash_path dash_ctx_paint_color text "0"

        dashboard_add          $dash_path dash_ctx_paint_en_colormultiply checkBox grp_ctx_paint_prm         
        dashboard_set_property $dash_path dash_ctx_paint_en_colormultiply text "color-multiply"
        dashboard_set_property $dash_path dash_ctx_paint_en_colormultiply enabled true

        dashboard_add          $dash_path dash_ctx_paint_gradient_type comboBox grp_ctx_gradient_param         
        dashboard_set_property $dash_path dash_ctx_paint_gradient_type label "type"
        dashboard_set_property $dash_path dash_ctx_paint_gradient_type options {"linear" "radial" "angular"}
        dashboard_set_property $dash_path dash_ctx_paint_gradient_type expandableX false
        dashboard_set_property $dash_path dash_ctx_paint_gradient_type expandableY false
        dashboard_set_property $dash_path dash_ctx_paint_gradient_type preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_paint_gradient_type selected 0   

        dashboard_add          $dash_path dash_ctx_paint_spread_mode comboBox grp_ctx_gradient_param         
        dashboard_set_property $dash_path dash_ctx_paint_spread_mode label "spread mode"
        dashboard_set_property $dash_path dash_ctx_paint_spread_mode options {"pad" "repeat" "reflect"}
        dashboard_set_property $dash_path dash_ctx_paint_spread_mode expandableX false
        dashboard_set_property $dash_path dash_ctx_paint_spread_mode expandableY false
        dashboard_set_property $dash_path dash_ctx_paint_spread_mode preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_paint_spread_mode selected 0   

        dashboard_add          $dash_path dash_ctx_paint_gradient_stops text grp_ctx_gradient_param         
        dashboard_set_property $dash_path dash_ctx_paint_gradient_stops label "stops number"
        dashboard_set_property $dash_path dash_ctx_paint_gradient_stops expandableX false
        dashboard_set_property $dash_path dash_ctx_paint_gradient_stops expandableY false
        dashboard_set_property $dash_path dash_ctx_paint_gradient_stops preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_paint_gradient_stops text "0"  

        dashboard_add          $dash_path dash_ctx_paint_quality comboBox grp_ctx_pattern         
        dashboard_set_property $dash_path dash_ctx_paint_quality label "quality"
        dashboard_set_property $dash_path dash_ctx_paint_quality options {"nonantialiased" "faster" "better"}
        dashboard_set_property $dash_path dash_ctx_paint_quality expandableX false
        dashboard_set_property $dash_path dash_ctx_paint_quality expandableY false
        dashboard_set_property $dash_path dash_ctx_paint_quality preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_paint_quality selected 0   

    #   dashboard_add          $dash_path dash_ctx_image_transform_quality comboBox grp_ctx_image_interpolation         
    #   dashboard_set_property $dash_path dash_ctx_image_transform_quality label "image transform quality"
    #   dashboard_set_property $dash_path dash_ctx_image_transform_quality options {"nonantialiased" "faster" "better"}
    #   dashboard_set_property $dash_path dash_ctx_image_transform_quality expandableX false
    #   dashboard_set_property $dash_path dash_ctx_image_transform_quality expandableY false
    #   dashboard_set_property $dash_path dash_ctx_image_transform_quality preferredWidth 50
    #   dashboard_set_property $dash_path dash_ctx_image_transform_quality selected 0   

        dashboard_add          $dash_path dash_ctx_blend_mode comboBox grp_ctx_blending         
        dashboard_set_property $dash_path dash_ctx_blend_mode label "mode"
        dashboard_set_property $dash_path dash_ctx_blend_mode options {"CLEAR" "SRC" "DST" "SRC_OVER" "DST_OVER" "SRC_IN" "DST_IN" "SRC_OUT" "DST_OUT" "SRC_ATOP" "DST_ATOP" "XOR" "MULTIPLY" "SCREEN" "DARKEN" "LIGHTEN" "ADDITIVE"}
        dashboard_set_property $dash_path dash_ctx_blend_mode expandableX false
        dashboard_set_property $dash_path dash_ctx_blend_mode expandableY false
        dashboard_set_property $dash_path dash_ctx_blend_mode preferredWidth 50
        dashboard_set_property $dash_path dash_ctx_blend_mode selected 0   

        dashboard_add          $dash_path dash_ctx_dump button grp_context_cmd 
        dashboard_set_property $dash_path dash_ctx_dump enabled true
        dashboard_set_property $dash_path dash_ctx_dump text "Dump"
        dashboard_set_property $dash_path dash_ctx_dump onClick { ::cgx_vgr::get_context }  

        dashboard_add          $dash_path dash_opt_undo_pipe checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_pipe text "Pipelined"

        dashboard_add          $dash_path dash_opt_undo_all checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_all text "All"

        dashboard_add          $dash_path dash_opt_undo_rect checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_rect text "Rect"

        dashboard_add          $dash_path dash_opt_undo_image checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_image text "Image"

        dashboard_add          $dash_path dash_opt_undo_path checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_path text "Path"

        dashboard_add          $dash_path dash_opt_undo_filled checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_filled text "Filled"

        dashboard_add          $dash_path dash_opt_undo_stroked checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_stroked text "Stroked"

        dashboard_add          $dash_path dash_opt_undo_blending checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_blending text "Blending"

        dashboard_add          $dash_path dash_opt_undo_masking checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_masking text "Masking"

        dashboard_add          $dash_path dash_opt_undo_painting checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_painting text "Painting"

        dashboard_add          $dash_path dash_opt_undo_opt_rect checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_opt_rect text "Rects Optimizations"

        dashboard_add          $dash_path dash_opt_undo_opt_gray checkBox grp_ctx_opts 
        dashboard_set_property $dash_path dash_opt_undo_opt_gray text "Grays Optimizations"

      # dashboard_add          $dash_path dash_opt_undo_opt_paint_matrix_norm checkBox grp_ctx_opts 
      # dashboard_set_property $dash_path dash_opt_undo_opt_paint_matrix_norm text "Paint Matrices Normalisation"


        dashboard_add          $dash_path dash_ctx_frame comboBox grp_ctx_frame 
        dashboard_set_property $dash_path dash_ctx_frame label ""
        dashboard_set_property $dash_path dash_ctx_frame options { "drawing surface" "mask" "image" "filter" "pattern fill" "pattern stroke" }
        dashboard_set_property $dash_path dash_ctx_frame expandableX false
        dashboard_set_property $dash_path dash_ctx_frame expandableY false
        dashboard_set_property $dash_path dash_ctx_frame preferredWidth 80
        dashboard_set_property $dash_path dash_ctx_frame selected 0   

        dashboard_add          $dash_path dash_desc_width text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_width label "width"
        dashboard_set_property $dash_path dash_desc_width expandableX false
        dashboard_set_property $dash_path dash_desc_width expandableY false
        dashboard_set_property $dash_path dash_desc_width preferredWidth 50
        dashboard_set_property $dash_path dash_desc_width editable false 
        dashboard_set_property $dash_path dash_desc_width htmlCapable false
        dashboard_set_property $dash_path dash_desc_width text "0"

        dashboard_add          $dash_path dash_desc_height text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_height label "height"
        dashboard_set_property $dash_path dash_desc_height expandableX false
        dashboard_set_property $dash_path dash_desc_height expandableY false
        dashboard_set_property $dash_path dash_desc_height preferredWidth 50
        dashboard_set_property $dash_path dash_desc_height editable false 
        dashboard_set_property $dash_path dash_desc_height htmlCapable false
        dashboard_set_property $dash_path dash_desc_height text "0"

        dashboard_add          $dash_path dash_desc_bufnum text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_bufnum label "buffer num"
        dashboard_set_property $dash_path dash_desc_bufnum expandableX false
        dashboard_set_property $dash_path dash_desc_bufnum expandableY false
        dashboard_set_property $dash_path dash_desc_bufnum preferredWidth 30
        dashboard_set_property $dash_path dash_desc_bufnum editable false 
        dashboard_set_property $dash_path dash_desc_bufnum htmlCapable false
        dashboard_set_property $dash_path dash_desc_bufnum text "0"

        dashboard_add          $dash_path dash_desc_bufidx text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_bufidx label "buffer idx"
        dashboard_set_property $dash_path dash_desc_bufidx expandableX false
        dashboard_set_property $dash_path dash_desc_bufidx expandableY false
        dashboard_set_property $dash_path dash_desc_bufidx preferredWidth 30
        dashboard_set_property $dash_path dash_desc_bufidx editable false 
        dashboard_set_property $dash_path dash_desc_bufidx htmlCapable false
        dashboard_set_property $dash_path dash_desc_bufidx text "0"

        dashboard_add          $dash_path dash_desc_pixcolor text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_pixcolor label "pixel format"
        dashboard_set_property $dash_path dash_desc_pixcolor expandableX false
        dashboard_set_property $dash_path dash_desc_pixcolor expandableY false
        dashboard_set_property $dash_path dash_desc_pixcolor preferredWidth 50
        dashboard_set_property $dash_path dash_desc_pixcolor editable false 
        dashboard_set_property $dash_path dash_desc_pixcolor htmlCapable false
        dashboard_set_property $dash_path dash_desc_pixcolor text "0"

        dashboard_add          $dash_path dash_desc_pixdepth text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_pixdepth label "pixel depth"
        dashboard_set_property $dash_path dash_desc_pixdepth expandableX false
        dashboard_set_property $dash_path dash_desc_pixdepth expandableY false
        dashboard_set_property $dash_path dash_desc_pixdepth preferredWidth 30
        dashboard_set_property $dash_path dash_desc_pixdepth editable false 
        dashboard_set_property $dash_path dash_desc_pixdepth htmlCapable false
        dashboard_set_property $dash_path dash_desc_pixdepth text "0"
        
    #   dashboard_add          $dash_path dash_desc_clut_idx text grp_ctx_frame 
    #   dashboard_set_property $dash_path dash_desc_clut_idx label "clut base"
    #   dashboard_set_property $dash_path dash_desc_clut_idx expandableX false
    #   dashboard_set_property $dash_path dash_desc_clut_idx expandableY false
    #   dashboard_set_property $dash_path dash_desc_clut_idx preferredWidth 30
    #   dashboard_set_property $dash_path dash_desc_clut_idx editable false 
    #   dashboard_set_property $dash_path dash_desc_clut_idx htmlCapable false
    #   dashboard_set_property $dash_path dash_desc_clut_idx text "0"

        dashboard_add          $dash_path dash_desc_hstride8 text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_hstride8 label "stride row"
        dashboard_set_property $dash_path dash_desc_hstride8 expandableX false
        dashboard_set_property $dash_path dash_desc_hstride8 expandableY false
        dashboard_set_property $dash_path dash_desc_hstride8 preferredWidth 70
        dashboard_set_property $dash_path dash_desc_hstride8 editable false 
        dashboard_set_property $dash_path dash_desc_hstride8 htmlCapable false
        dashboard_set_property $dash_path dash_desc_hstride8 text "0x0"

        dashboard_add          $dash_path dash_desc_vstride8 text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_vstride8 label "stride buffer"
        dashboard_set_property $dash_path dash_desc_vstride8 expandableX false
        dashboard_set_property $dash_path dash_desc_vstride8 expandableY false
        dashboard_set_property $dash_path dash_desc_vstride8 preferredWidth 70
        dashboard_set_property $dash_path dash_desc_vstride8 editable false 
        dashboard_set_property $dash_path dash_desc_vstride8 htmlCapable false
        dashboard_set_property $dash_path dash_desc_vstride8 text "0x0"

    #   dashboard_add          $dash_path dash_desc_addr8_h text grp_ctx_frame 
    #   dashboard_set_property $dash_path dash_desc_addr8_h label "address high"
    #   dashboard_set_property $dash_path dash_desc_addr8_h expandableX false
    #   dashboard_set_property $dash_path dash_desc_addr8_h expandableY false
    #   dashboard_set_property $dash_path dash_desc_addr8_h preferredWidth 70
    #   dashboard_set_property $dash_path dash_desc_addr8_h editable false 
    #   dashboard_set_property $dash_path dash_desc_addr8_h htmlCapable false
    #   dashboard_set_property $dash_path dash_desc_addr8_h text "0x0"

        dashboard_add          $dash_path dash_desc_addr8_l text grp_ctx_frame 
        dashboard_set_property $dash_path dash_desc_addr8_l label "address"
        dashboard_set_property $dash_path dash_desc_addr8_l expandableX false
        dashboard_set_property $dash_path dash_desc_addr8_l expandableY false
        dashboard_set_property $dash_path dash_desc_addr8_l preferredWidth 70
        dashboard_set_property $dash_path dash_desc_addr8_l editable false 
        dashboard_set_property $dash_path dash_desc_addr8_l htmlCapable false
        dashboard_set_property $dash_path dash_desc_addr8_l text "0x0"

        dashboard_add          $dash_path dash_opr_id textField grp_opr 
    #   dashboard_add          $dash_path dash_opr_id label "latest operation"
        dashboard_set_property $dash_path dash_opr_id editable false
        dashboard_set_property $dash_path dash_opr_id enabled true
        dashboard_set_property $dash_path dash_opr_id expandableX true
        dashboard_set_property $dash_path dash_opr_id preferredWidth 150
        dashboard_set_property $dash_path dash_opr_id text "RECT - CLEAR"

        dashboard_add          $dash_path dash_opr_diag text grp_opr 
        dashboard_set_property $dash_path dash_opr_diag label "diag message"
        dashboard_set_property $dash_path dash_opr_diag expandableX false
        dashboard_set_property $dash_path dash_opr_diag expandableY false
        dashboard_set_property $dash_path dash_opr_diag preferredWidth 200
        dashboard_set_property $dash_path dash_opr_diag editable false 
        dashboard_set_property $dash_path dash_opr_diag htmlCapable false
        dashboard_set_property $dash_path dash_opr_diag text " - "

   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_BASE})              "base" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_UP})                "up" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_DOWN_FIRST})        "down first" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_DOWN_LAST})         "down last" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_PREV})              "prev" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_NXT})               "next" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_FRAME})             "dsc frame" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_MATRIX_TRANSFORM})  "dsc matrix transf" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_MATRIX_WORLD})      "dsc matrix world" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_COLOR_TRANSFORM})       "color transform" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_CLASS_DATA})            "data" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_ID})                    "id" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_BBOX_WORLD_MIN})        "bbox world min" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_BBOX_WORLD_MAX})        "bbox world max" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_POSX})                  "posx" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_POSY})                  "posy" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_CONTROL})               "ctl" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_CONTEXT})               "ctx" 
   #    set opr_label(${::cgx_asg_dsc::DSC_ATOM_REG_DSC_STROKE})            "dsc stroke" 
   #    set opr_label([ expr ${::cgx_asg_dsc::DSC_ATOM_REG_FILLPAINT_BASE} + ${::cgx_asg_dsc::DSC_PAINT2_REG_TYPE} ])       "fillpaint type" 
   #    set opr_label([ expr ${::cgx_asg_dsc::DSC_ATOM_REG_FILLPAINT_BASE} + ${::cgx_asg_dsc::DSC_PAINT2_REG_DATA} ])       "fillpaint data" 
   #    set opr_label([ expr ${::cgx_asg_dsc::DSC_ATOM_REG_FILLPAINT_BASE} + ${::cgx_asg_dsc::DSC_PAINT2_REG_DSC_MATRIX} ]) "fillpaint matrix" 
   #    set opr_label([ expr ${::cgx_asg_dsc::DSC_ATOM_REG_VARIABLE} + 0 ]) "variable #0" 
   #    set opr_label([ expr ${::cgx_asg_dsc::DSC_ATOM_REG_VARIABLE} + 1 ]) "variable #1" 
   #
   #
   #    for { set i 0 } { ${i} < ${::cgx_asg_dsc::DSC_ATOM_REG_NUMBER} } { incr i } {        
   #        dashboard_add          $dash_path dash_dbg_atom$i text grp_debug_atom_regs 
   #        dashboard_set_property $dash_path dash_dbg_atom$i expandableX false
   #        dashboard_set_property $dash_path dash_dbg_atom$i expandableY false
   #        dashboard_set_property $dash_path dash_dbg_atom$i preferredWidth 70
   #        dashboard_set_property $dash_path dash_dbg_atom$i editable false
   #      # dashboard_set_property $dash_path dash_dbg_atom$i htmlCapable false
   #      # dashboard_set_property $dash_path dash_dbg_atom$i label $opr_label($i)
   #        dashboard_set_property $dash_path dash_dbg_atom$i label ""
   #        dashboard_set_property $dash_path dash_dbg_atom$i text "0x00000000"
   #
   #        dashboard_add          $dash_path dash_dbg_atom_label$i label grp_debug_atom_regs 
   #        dashboard_set_property $dash_path dash_dbg_atom_label$i expandableX false
   #        dashboard_set_property $dash_path dash_dbg_atom_label$i expandableY false
   #        dashboard_set_property $dash_path dash_dbg_atom_label$i preferredWidth 1
   #      # dashboard_set_property $dash_path dash_dbg_atom_label$i editable false
   #      # dashboard_set_property $dash_path dash_dbg_atom_label$i htmlCapable false
   #        dashboard_set_property $dash_path dash_dbg_atom_label$i label $opr_label($i)
   #        dashboard_set_property $dash_path dash_dbg_atom_label$i text ""
   #
   #    }

   #    dashboard_add          $dash_path dash_opr_rect comboBox grp_opr 
   #    dashboard_set_property $dash_path dash_opr_rect label ""
   #    dashboard_set_property $dash_path dash_opr_rect options { "RECT - CLEAR" "RECT - FILL" "RECT - BOUND"}
   #    dashboard_set_property $dash_path dash_opr_rect expandableX false
   #    dashboard_set_property $dash_path dash_opr_rect expandableY false
   #    dashboard_set_property $dash_path dash_opr_rect preferredWidth 50
   #    dashboard_set_property $dash_path dash_opr_rect selected 0   
   #
   #    dashboard_add          $dash_path dash_opr_image comboBox grp_opr 
   #    dashboard_set_property $dash_path dash_opr_image label ""
   #    dashboard_set_property $dash_path dash_opr_image options { "IMAGE - COMPOSE" "IMAGE - TRANSFORM" "IMAGE - COPY"}
   #    dashboard_set_property $dash_path dash_opr_image expandableX false
   #    dashboard_set_property $dash_path dash_opr_image expandableY false
   #    dashboard_set_property $dash_path dash_opr_image preferredWidth 50
   #    dashboard_set_property $dash_path dash_opr_image selected 0   
   #
   #    dashboard_add          $dash_path dash_opr_path comboBox grp_opr 
   #    dashboard_set_property $dash_path dash_opr_path label ""
   #    dashboard_set_property $dash_path dash_opr_path options { "PATH - COMPOSE" "PATH - TRANSFORM" }
   #    dashboard_set_property $dash_path dash_opr_path expandableX false
   #    dashboard_set_property $dash_path dash_opr_path expandableY false
   #    dashboard_set_property $dash_path dash_opr_path preferredWidth 50
   #    dashboard_set_property $dash_path dash_opr_path selected 0   
	                                                   	      
        after idle ::cgx_vgr::dash_update

        puts stdout "dashBoard end"

        return -code ok
    }


    proc dash_init_device {} {
    	
        set ::cgx_vgr::debug 1

        cgx_vgr::init   
        cgx_vgr::dash_get_config
        cgx_vgr::dash_get_status

        set ::cgx_vgr::debug 0
    }


    proc dash_dump_device {} {

        cgx_vgr::dump_all  

    }


    proc dash_get_caps {} {
    	
        set ::cgx_vgr::debug 1

        cgx_vgr::get_caps   

        set ::cgx_vgr::debug 0
    }


    proc dash_set_config {} {

        set ::cgx_vgr::debug 1
       
        cgx_vgr::set_config -1    
    #   cgx_vgr::set_config2 -1    
        cgx_vgr::set_interrupt -1   
        cgx_vgr::set_opts
       
        set ::cgx_vgr::debug 0
        
    }


    proc dash_get_config {} {

        set ::cgx_vgr::debug 1

        cgx_vgr::get_config 
    #   cgx_vgr::get_config2   
        cgx_vgr::get_interrupt    
        cgx_vgr::get_opts

        set ::cgx_vgr::debug 0

    }
    
   
    proc dash_get_status {} {

        set ::cgx_vgr::debug 1

        cgx_vgr::get_status                  
    #   cgx_vgr::get_context
        cgx_vgr::ctx_get_param
        cgx_vgr::ctx_get_frame
        cgx_vgr::ctx_get_rect  
    #   cgx_vgr::ctx_get_colortransform
        cgx_vgr::ctx_get_colorramp
        cgx_vgr::ctx_get_dash
        cgx_vgr::ctx_get_matrix

        cgx_vgr::get_opr

        set ::cgx_vgr::debug 0

    }


    proc dash_clr_status {} {

        set ::cgx_vgr::debug 1

        cgx_vgr::clr_status          

        set ::cgx_vgr::debug 0

    }


    proc dash_run_status {} {

    # TODO

    }


    proc dash_update {} {

        if { ${::cgx_vgr::dashboardActive} > 0 } {
     
            if { ${::cgx_vgr::initialized} > 0 } {

                ::cgx_vgr::dash_get_status

              # after 300 ::cgx_vgr::dash_update

            }
        }
    }

}


 
 
  
  