
# cgx_surface_ctrl::init             { dev_base } 
# cgx_surface_ctrl::get_version      { }
# cgx_surface_ctrl::get_caps         { }
# cgx_surface_ctrl::set_surface      { active sfc_name }
# cgx_surface_ctrl::get_surface      { }
# cgx_surface_ctrl::put_surface      { sfc_name }
# cgx_surface_ctrl::set_buffer       { op ptr_nxt }
# cgx_surface_ctrl::get_buffer       { op }
# cgx_surface_ctrl::dump             { }
# cgx_surface_ctrl::dashBoard        { }  

# olds
# cgx_surface_ctrl::set_dev_base     { host_base sfctrl_idx } 
# cgx_surface_ctrl::get_status       { }
# cgx_surface_ctrl::clr_status       { }
# cgx_surface_ctrl::set_primary      { primary_idx }
# cgx_surface_ctrl::get_primary      { }
# cgx_surface_ctrl::set_sync         { lock_on lock_gene lock_mode rate_buffer rate_repeat rate_total }
# cgx_surface_ctrl::get_sync         { }


namespace eval cgx_surface_ctrl {


    variable IPCORE_PRODUCT 60; # = 0x3c                                                                                          
    variable IPCORE_VERSION ${::cgx_fusion::IPCORE_VERSION}                                                                                           
    variable IPCORE_LABEL   "SFCTRL"                                                                                         
 

    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    # debug mode
    # 0 => console 
    # 1 => dashboard 
    variable debug 0
    
 

    #-------------------------- SYS------------------------------

    variable SFCTRL_CSR_DEV_BASE  0x00000000
    variable initialized 0
  
        
    #-------------------------- HAL------------------------------
   
    variable SFCTRL_CSR_REG_VERSION         0
    variable SFCTRL_CSR_REG_CAPS0           1
    variable SFCTRL_CSR_REG_CAPS1           2
    variable SFCTRL_CSR_REG_CONTROL         3
   #variable SFCTRL_CSR_REG_STATUS          4
    variable SFCTRL_CSR_REG_SYNC_READER     5
    variable SFCTRL_CSR_REG_SYNC_WRITER     6
    variable SFCTRL_CSR_REG_DESC_BASE       8 

    # SFCTRL_CSR_REG_VERSION      
        # /* Parameters */
        variable SFCTRL_CSR_VERSION_ID_MSK     0xFF      
        variable SFCTRL_CSR_VERSION_ID_OFST    0         
        variable SFCTRL_CSR_VERSION_BUILD_MSK  0xFF00    
        variable SFCTRL_CSR_VERSION_BUILD_OFST 8         
        variable SFCTRL_CSR_VERSION_MINOR_MSK  0xFF0000   
        variable SFCTRL_CSR_VERSION_MINOR_OFST 16        
        variable SFCTRL_CSR_VERSION_MAJOR_MSK  0x0F000000   
        variable SFCTRL_CSR_VERSION_MAJOR_OFST 24        
                                                              
    # SFCTRL_CSR_REG_CAPS0
        variable SFCTRL_CSR_CAPS0_PIXCOLOR_MSK            0xFF
        variable SFCTRL_CSR_CAPS0_PIXCOLOR_OFST           0
        variable SFCTRL_CSR_CAPS0_PIXDEPTH_MSK            0xFF
        variable SFCTRL_CSR_CAPS0_PIXDEPTH_OFST           0
        variable SFCTRL_CSR_CAPS0_PIXRAW_MSK              0x100
        variable SFCTRL_CSR_CAPS0_PIXRAW_OFST             8
        variable SFCTRL_CSR_CAPS0_BUFFER_NUM_MSK          0xFF0000
        variable SFCTRL_CSR_CAPS0_BUFFER_NUM_OFST         16
        variable SFCTRL_CSR_CAPS0_SYNC_ENABLE_PARK_MSK    0x1000000
        variable SFCTRL_CSR_CAPS0_SYNC_ENABLE_PARK_OFST   24
        variable SFCTRL_CSR_CAPS0_SYNC_ENABLE_REPEAT_MSK  0x2000000
        variable SFCTRL_CSR_CAPS0_SYNC_ENABLE_REPEAT_OFST 25

    # SFCTRL_CSR_REG_CAPS1
        variable SFCTRL_CSR_CAPS1_WIDTH_MSK   0xFFFF
        variable SFCTRL_CSR_CAPS1_WIDTH_OFST  0
        variable SFCTRL_CSR_CAPS1_HEIGHT_MSK  0xFFFF0000
        variable SFCTRL_CSR_CAPS1_HEIGHT_OFST 16

    # SFCTRL_CSR_REG_CONTROL */
        variable SFCTRL_CSR_CTL_RUN_MSK   0x1; # // set 1 when surface descriptor is valid  
        variable SFCTRL_CSR_CTL_RUN_OFST  0

    # SFCTRL_CSR_REG_SYNC_READER, SFCTRL_CSR_REG_SYNC_WRITER  
        variable SFCTRL_CSR_SYNC_PTR_PARK_NXT_MSK   0x3; #    // RW, next ptr to park on (manual sync mode only), up to 3 buffers    
        variable SFCTRL_CSR_SYNC_PTR_PARK_NXT_OFST  0   
        variable SFCTRL_CSR_SYNC_PTR_CUR_MSK        0x300; # // RO, status only - current ptr index, up to 3 buffers
        variable SFCTRL_CSR_SYNC_PTR_CUR_OFST       8   
        variable SFCTRL_CSR_SYNC_PTR_VALID_MSK      0x400
        variable SFCTRL_CSR_SYNC_PTR_VALID_OFST     10   
        variable SFCTRL_CSR_SYNC_REPEAT_NUM_MSK     0xFF0000; # // number of repeated r/w buffers 
        variable SFCTRL_CSR_SYNC_REPEAT_NUM_OFST    16        

     
    #-------------------------- MACRO------------------------------

    proc CGX_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_surface_ctrl::$field_name\_REG 
            set str_field_msk   ::cgx_surface_ctrl::$field_name\_MSK 
            set str_field_ofst  ::cgx_surface_ctrl::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc CGX_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_surface_ctrl::$field_name\_MSK 
        set str_field_ofst ::cgx_surface_ctrl::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

 
    #-------------------------- PUBLIC ------------------------------
 
    proc init { dev_base } {

        if { ${::cgx_surface_ctrl::debug} == 1 } {
            set dash_path ${::cgx_surface_ctrl::dash_path} 
            set dev_base [ dashboard_get_property $dash_path dash_dev_base text ]
        } 
                        
        set ::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE ${dev_base} 
        
        set dev_success [ ::cgx_surface_ctrl::get_version ];  
        
        if {${dev_success} == 1} {
            set ::cgx_surface_ctrl::initialized 1
        } else {
            set ::cgx_surface_ctrl::initialized 0
        } 

        if { ${::cgx_surface_ctrl::debug} == 1 } {
            set dash_path ${::cgx_surface_ctrl::dash_path} 
            # CSR visibility triggered by get_caps 
            dashboard_set_property $dash_path grp_csr   visible false
            if {${dev_success} == 1} {
            	  puts " ${::cgx_surface_ctrl::IPCORE_LABEL} DEVICE init successfull "
                dashboard_set_property $dash_path grp_core  visible true
            } else {
            	  puts " ${::cgx_surface_ctrl::IPCORE_LABEL} ERROR: device init failure "
                dashboard_set_property $dash_path grp_core  visible false
            } 
        } 
    }


    proc get_version { } {
        
        set csr_base8 ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE} 
        
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_surface_ctrl::SFCTRL_CSR_REG_VERSION} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set v_id    [ CGX_GET_FIELD $reg SFCTRL_CSR_VERSION_ID ] ;                              
        set v_build [ CGX_GET_FIELD $reg SFCTRL_CSR_VERSION_BUILD ] ;                           
        set v_minor [ CGX_GET_FIELD $reg SFCTRL_CSR_VERSION_MINOR ] ;                           
        set v_major [ CGX_GET_FIELD $reg SFCTRL_CSR_VERSION_MAJOR ] ;                           
        set version $v_major.$v_minor                            

        if {$v_id == ${::cgx_surface_ctrl::IPCORE_PRODUCT} } {
          puts " ${::cgx_surface_ctrl::IPCORE_LABEL} DEVICE detection successfull, core id = [ format 0x%x $v_id ] "
          puts " ${::cgx_surface_ctrl::IPCORE_LABEL} DEVICE Version = $v_major.$v_minor, Build = $v_build"
          if { $version == ${::cgx_surface_ctrl::IPCORE_VERSION} } {
            set success 1
          } else {
            set success 0
            puts stdout " ${::cgx_surface_ctrl::IPCORE_LABEL} ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_surface_ctrl::IPCORE_VERSION} )"
            puts stdout "        please upgrade the dashboard version accordingly to the IP core "
          }
        } else {
          set success 0
          puts stdout " ${::cgx_surface_ctrl::IPCORE_LABEL} ERROR: device not detected at device base ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE} "
          puts stdout "        core id = $v_id, reg = $reg "
          puts stdout "        please, set the right device base and press init again "
        }
        return $success
    }

 
    proc get_caps { } {

        set quiet 0

        set csr_base8 ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE}  

        open_service master ${::boardInit::masterPath}
         
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_surface_ctrl::SFCTRL_CSR_REG_CAPS0} ] 0x1]; 
        set caps_ena_sync_park   [ CGX_GET_FIELD $reg SFCTRL_CSR_CAPS0_SYNC_ENABLE_PARK ] ; 
        set caps_ena_sync_repeat [ CGX_GET_FIELD $reg SFCTRL_CSR_CAPS0_SYNC_ENABLE_REPEAT ] ; 

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_surface_ctrl::SFCTRL_CSR_REG_CAPS1} ] 0x1]; 
        set caps_max_width  [ CGX_GET_FIELD $reg SFCTRL_CSR_CAPS1_WIDTH ] ;  
        set caps_max_height [ CGX_GET_FIELD $reg SFCTRL_CSR_CAPS1_HEIGHT ] ;  
  
	      close_service master ${::boardInit::masterPath}
                          
        set ::cgx_surface_ctrl::caps_ena_sync_park $caps_ena_sync_park           
        set ::cgx_surface_ctrl::caps_ena_sync_repeat $caps_ena_sync_repeat           
        set ::cgx_surface_ctrl::caps_max_width     $caps_max_width           
        set ::cgx_surface_ctrl::caps_max_height    $caps_max_height
                            
        # display values 
        if { $quiet == 0 } {
           puts " Capabilities: "
           puts "     caps_max_width       = ${::cgx_surface_ctrl::caps_max_width}      "
           puts "     caps_max_height      = ${::cgx_surface_ctrl::caps_max_height}     "
           puts "     caps_ena_sync_park   = ${::cgx_surface_ctrl::caps_ena_sync_park}  "
           puts "     caps_ena_sync_repeat = ${::cgx_surface_ctrl::caps_ena_sync_repeat}"
        }

        if { ${::cgx_surface_ctrl::debug} == 1 } {

            set dash_path ${::cgx_surface_ctrl::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true

            # auto  
            if { $caps_ena_sync_park == 0 } {
                dashboard_set_property $dash_path dash_sync_rd_ptr_nxt visible false
                dashboard_set_property $dash_path dash_sync_wr_ptr_nxt visible false
            # manual
            } else {
                dashboard_set_property $dash_path dash_sync_rd_ptr_nxt visible true
                dashboard_set_property $dash_path dash_sync_wr_ptr_nxt visible true
            }                       	
        }
    }

       
    proc set_surface { active sfc_name } { 

        if { ${::cgx_surface_ctrl::debug} == 1 } {

            set dash_path ${::cgx_surface_ctrl::dash_path}              

            set active 0 
            if { [ dashboard_get_property $dash_path dash_cfg_run checked ] == true } {
                set active 1
            }

            set base           [ dashboard_get_property $dash_path dash_desc_addr8_l  text ]
            set color          [ dashboard_get_property $dash_path dash_desc_pixcolor text ]
            set color_depth    [ dashboard_get_property $dash_path dash_desc_pixdepth text ]            
            set width          [ dashboard_get_property $dash_path dash_desc_width    text ]
            set height         [ dashboard_get_property $dash_path dash_desc_height   text ]
            set stride         [ dashboard_get_property $dash_path dash_desc_hstride8 text ]
            set nb_buffer      [ dashboard_get_property $dash_path dash_desc_bufnum   text ]
            set stride_buffer  [ dashboard_get_property $dash_path dash_desc_vstride8 text ]
        #   set critical 0
        #   if { [ dashboard_get_property $dash_path dash_desc_critical checked ] == true } {
        #       set critical 1
        #   }
             
            cgx_surface::surface_create sfc0 $base $color $width $height $nb_buffer $color_depth $stride $stride_buffer 
            set sfc_name sfc0
        }

        set csr_base8 ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE}  
        array set desc {} 
        set clut_start_idx 0; # not used
        cgx_surface::surface_set_desc desc $sfc_name $clut_start_idx 0   

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_surface_ctrl::SFCTRL_CSR_REG_CONTROL} ] 0x1]; 
        set reg [ CGX_SET_FIELD $reg SFCTRL_CSR_CTL_RUN $active ]
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * ${::cgx_surface_ctrl::SFCTRL_CSR_REG_CONTROL} ] $reg
        
        for {set i 0} { $i<${::cgx_surface::DESC_REG_NUMBER} } {incr i} {
            master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4* [ expr ${::cgx_surface_ctrl::SFCTRL_CSR_REG_DESC_BASE} +$i ] ] $desc($i)
        }

        close_service master ${::boardInit::masterPath}       
    }
 

    proc put_surface { sfc_name } {
        puts " Surface $sfc_name: "  
        puts "     base          =$::cgx_surface::surface($sfc_name,base)          "    
        puts "     color         =$::cgx_surface::surface($sfc_name,color)         "
        puts "     color_depth   =$::cgx_surface::surface($sfc_name,color_depth)   "
        puts "     width         =$::cgx_surface::surface($sfc_name,width)         "
        puts "     height        =$::cgx_surface::surface($sfc_name,height)        "
        puts "     nb_buffer     =$::cgx_surface::surface($sfc_name,nb_buffer)     "
        puts "     stride        =$::cgx_surface::surface($sfc_name,stride)        "
        puts "     stride_buffer =$::cgx_surface::surface($sfc_name,stride_buffer) "   
    #   puts "     critical      =$::cgx_surface::surface($sfc_name,critical) "   
    }

    proc get_surface { sfc_name } {

        set csr_base8 ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE}  
        
        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * ${::cgx_surface_ctrl::SFCTRL_CSR_REG_CONTROL} ] 0x1]; 
        set active [ CGX_GET_FIELD $reg SFCTRL_CSR_CTL_RUN ]     
 
        for {set i 0} { $i<${::cgx_surface::DESC_REG_NUMBER} } {incr i} {
            set desc($i) [ master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4* [ expr ${::cgx_surface_ctrl::SFCTRL_CSR_REG_DESC_BASE} +$i ] ] 0x1 ]; 
        }

        close_service master ${::boardInit::masterPath}

        set clut_start_idx -2 
        set async_ptr -2
 
        cgx_surface::surface_get_desc desc $sfc_name clut_start_idx async_ptr   

        if { ${::cgx_surface_ctrl::debug} == 0 } {
            ::cgx_surface_ctrl::put_surface $sfc_name
        }                                                                                                                                                                                                                                                                                                                                                           

        if { ${::cgx_surface_ctrl::debug} == 1 } {
            set dash_path ${::cgx_surface_ctrl::dash_path} 
            
            if { $active == 1 } {
               dashboard_set_property $dash_path dash_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_run checked false  
            }        
            
            dashboard_set_property $dash_path dash_desc_addr8_l   text $::cgx_surface::surface($sfc_name,base)    
            dashboard_set_property $dash_path dash_desc_pixcolor  text $::cgx_surface::surface($sfc_name,color)   
            dashboard_set_property $dash_path dash_desc_pixdepth  text $::cgx_surface::surface($sfc_name,color_depth)   
            dashboard_set_property $dash_path dash_desc_width     text $::cgx_surface::surface($sfc_name,width)   
            dashboard_set_property $dash_path dash_desc_height    text $::cgx_surface::surface($sfc_name,height)  
            dashboard_set_property $dash_path dash_desc_hstride8  text [ format 0x%x $::cgx_surface::surface($sfc_name,stride) ]     
            dashboard_set_property $dash_path dash_desc_bufnum    text $::cgx_surface::surface($sfc_name,nb_buffer)          
            dashboard_set_property $dash_path dash_desc_vstride8  text [ format 0x%x $::cgx_surface::surface($sfc_name,stride_buffer) ]         
            
        #   set critical2  $::cgx_surface::surface($sfc_name,critical)
        #   
        #   if { $critical2 == 1 } {
        #      dashboard_set_property $dash_path dash_desc_critical checked true  
        #   } else { 
        #      dashboard_set_property $dash_path dash_desc_critical checked false  
        #   }
        }
    }
 

    # set the next buffer to park on                                  
    # <op> = operand (0=reader / 1=writer)
    # <ptr_nxt> [0..n-1]=manual: defines the next buffer to park on 
    #           -1      =auto:   automatic computation of next buffer
    proc set_buffer { op ptr_nxt } {
    
        if { ${::cgx_surface_ctrl::debug} == 1 } {
            set dash_path ${::cgx_surface_ctrl::dash_path}              
    
            if { ${op} == 0 } { 
          	  set ptr_nxt [ dashboard_get_property $dash_path dash_sync_rd_ptr_nxt text ]         
            } else { 
          	  set ptr_nxt [ dashboard_get_property $dash_path dash_sync_wr_ptr_nxt text ]         
            }        
         	         
        }
    
        set csr_base8 ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE}  
    
        set quiet 0
    
     #  set ptr_anim 0
     #  if { $ptr_nxt < 0 } { 
     #      set ptr_anim 1
     #      set ptr_nxt  0
     #  } 
        
        set reg 0
        set reg [ CGX_SET_FIELD $reg SFCTRL_CSR_SYNC_REPEAT_NUM 0] 
        set reg [ CGX_SET_FIELD $reg SFCTRL_CSR_SYNC_PTR_PARK_NXT  $ptr_nxt  ] 
                                                               
        open_service master ${::boardInit::masterPath}
    
        if { ${op} == 0 } { 
            master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_surface_ctrl::SFCTRL_CSR_REG_SYNC_READER} ] $reg
        } else { 
            master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_surface_ctrl::SFCTRL_CSR_REG_SYNC_WRITER} ] $reg
        }
            
        close_service master ${::boardInit::masterPath}
    
    }
   
 
    # get the buffer status
    proc get_buffer { op } {
    
        set csr_base8 ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE}  

        open_service master ${::boardInit::masterPath}
        if { ${op} == 0 } { 
            set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_surface_ctrl::SFCTRL_CSR_REG_SYNC_READER} ] 0x1]; 
        } else { 
            set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_surface_ctrl::SFCTRL_CSR_REG_SYNC_WRITER} ] 0x1]; 
        }
        close_service master ${::boardInit::masterPath}

      # set ptr_anim      [ CGX_GET_FIELD $reg SFCTRL_CSR_RW_ANIM ] 
        set ptr_nxt       [ CGX_GET_FIELD $reg SFCTRL_CSR_SYNC_PTR_PARK_NXT ] 
        set ptr_cur       [ CGX_GET_FIELD $reg SFCTRL_CSR_SYNC_PTR_CUR ] 
        set ptr_cur_valid [ CGX_GET_FIELD $reg SFCTRL_CSR_SYNC_PTR_VALID ] 

    #   if { ${ptr_anim} == 1 } { 
    #     set ptr_nxt -1
    #   } 

        if { ${ptr_cur_valid} == 0} {
        	set ptr_cur -1
        } 
 
        if { ${::cgx_surface_ctrl::debug} == 0 } {
           puts "ptr_nxt        = $ptr_nxt       "
           puts "ptr_cur        = $ptr_cur       "
      #    puts "ptr_cur_valid  = $ptr_cur_valid "
        }

        if { ${::cgx_surface_ctrl::debug} == 1 } {
            set dash_path ${::cgx_surface_ctrl::dash_path} 

            if { ${op} == 0 } { 
                dashboard_set_property $dash_path dash_sync_rd_ptr_cur text $ptr_cur 
                dashboard_set_property $dash_path dash_sync_rd_ptr_nxt text $ptr_nxt  
        	  } else { 
                dashboard_set_property $dash_path dash_sync_wr_ptr_cur text $ptr_cur 
                dashboard_set_property $dash_path dash_sync_wr_ptr_nxt text $ptr_nxt  
        	  }        
        }            
    }

    proc dump { } {

        set csr_base8 ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE}  
        
        set addr $csr_base8  

        open_service master ${::boardInit::masterPath}
        set reg [ master_read_32 ${::boardInit::masterPath} ${addr} ${::cgx_surface_ctrl::SFCTRL_CSR_REG_NUMBER} ]
	      close_service master ${::boardInit::masterPath}

        puts stdout "dump surface def. at $addr:"
        puts stdout "$reg"        
    }
 
    proc dashBoard { } {

        if { ${::cgx_surface_ctrl::dashboardActive} == 1 } {
            return -code ok " ${::cgx_surface_ctrl::IPCORE_LABEL} dashboard already active"
        }

        set ::cgx_surface_ctrl::dashboardActive 1
        puts " ${::cgx_surface_ctrl::IPCORE_LABEL} dashBoard start ......."

        #
        # Create dashboard 
        #
 
        #
        # Set dashboard properties
        #
        set ::cgx_surface_ctrl::dash_path [ add_service dashboard cgx_surface_ctrl "cgx_surface_ctrl" "Tools/cgx_surface_ctrl"]
        
        set dash_path ${::cgx_surface_ctrl::dash_path}  
        
        dashboard_set_property $dash_path self developmentMode true
        dashboard_set_property $dash_path self itemsPerRow 1
        dashboard_set_property $dash_path self visible true

                
        #
        # groups
        #
            
        dashboard_add          $dash_path grp_top group self       
        dashboard_set_property $dash_path grp_top expandableX false
        dashboard_set_property $dash_path grp_top expandableY false
        dashboard_set_property $dash_path grp_top itemsPerRow 1
        dashboard_set_property $dash_path grp_top title ""
        
        dashboard_add          $dash_path grp_host group grp_top
        dashboard_set_property $dash_path grp_host expandableX false
        dashboard_set_property $dash_path grp_host expandableY false
        dashboard_set_property $dash_path grp_host itemsPerRow 4
        dashboard_set_property $dash_path grp_host title ""

        dashboard_add          $dash_path grp_device group grp_top
        dashboard_set_property $dash_path grp_device expandableX false
        dashboard_set_property $dash_path grp_device expandableY false
        dashboard_set_property $dash_path grp_device itemsPerRow 4
        dashboard_set_property $dash_path grp_device title ""

        dashboard_add          $dash_path grp_core group grp_top
        dashboard_set_property $dash_path grp_core expandableX false
        dashboard_set_property $dash_path grp_core expandableY false
        dashboard_set_property $dash_path grp_core itemsPerRow 1
        dashboard_set_property $dash_path grp_core title "Core ${::cgx_surface_ctrl::IPCORE_VERSION}"
        dashboard_set_property $dash_path grp_core visible false; # dashboard init

        dashboard_add          $dash_path grp_core_cmd group grp_core
        dashboard_set_property $dash_path grp_core_cmd expandableX false
        dashboard_set_property $dash_path grp_core_cmd expandableY false
        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_core_cmd title ""

        dashboard_add          $dash_path grp_csr group grp_core
        dashboard_set_property $dash_path grp_csr expandableX false
        dashboard_set_property $dash_path grp_csr expandableY false
        dashboard_set_property $dash_path grp_csr itemsPerRow 1
        dashboard_set_property $dash_path grp_csr title ""
        dashboard_set_property $dash_path grp_csr visible false; # dashboard init
  
        dashboard_add          $dash_path grp_csr_main group grp_csr
        dashboard_set_property $dash_path grp_csr_main expandableX false
        dashboard_set_property $dash_path grp_csr_main expandableY false
        dashboard_set_property $dash_path grp_csr_main itemsPerRow 2
        dashboard_set_property $dash_path grp_csr_main title ""
 
        dashboard_add          $dash_path grp_config group grp_csr_main
        dashboard_set_property $dash_path grp_config expandableX false
        dashboard_set_property $dash_path grp_config expandableY false
        dashboard_set_property $dash_path grp_config itemsPerRow 1
        dashboard_set_property $dash_path grp_config title "Config"

        dashboard_add          $dash_path grp_cfg_cmd group grp_config
        dashboard_set_property $dash_path grp_cfg_cmd expandableX false
        dashboard_set_property $dash_path grp_cfg_cmd expandableY false
        dashboard_set_property $dash_path grp_cfg_cmd itemsPerRow 2
        dashboard_set_property $dash_path grp_cfg_cmd title ""

        dashboard_add          $dash_path grp_status group grp_csr_main
        dashboard_set_property $dash_path grp_status expandableX false
        dashboard_set_property $dash_path grp_status expandableY false
        dashboard_set_property $dash_path grp_status itemsPerRow 1
        dashboard_set_property $dash_path grp_status title "Status"

        dashboard_add          $dash_path grp_sts_cmd group grp_status
        dashboard_set_property $dash_path grp_sts_cmd expandableX false
        dashboard_set_property $dash_path grp_sts_cmd expandableY false
        dashboard_set_property $dash_path grp_sts_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_cmd title ""

        dashboard_add          $dash_path grp_fct group grp_csr
        dashboard_set_property $dash_path grp_fct expandableX false
        dashboard_set_property $dash_path grp_fct expandableY false
        dashboard_set_property $dash_path grp_fct itemsPerRow 3
        dashboard_set_property $dash_path grp_fct title ""

        dashboard_add          $dash_path grp_primary group grp_fct
        dashboard_set_property $dash_path grp_primary expandableX false
        dashboard_set_property $dash_path grp_primary expandableY true
        dashboard_set_property $dash_path grp_primary itemsPerRow 2
        dashboard_set_property $dash_path grp_primary title "Primary"

        dashboard_add          $dash_path grp_desc group grp_primary
        dashboard_set_property $dash_path grp_desc expandableX false
        dashboard_set_property $dash_path grp_desc expandableY true
        dashboard_set_property $dash_path grp_desc itemsPerRow 1
        dashboard_set_property $dash_path grp_desc title "Description"

        dashboard_add          $dash_path grp_sync group grp_primary
        dashboard_set_property $dash_path grp_sync expandableX false
        dashboard_set_property $dash_path grp_sync expandableY true
        dashboard_set_property $dash_path grp_sync itemsPerRow 1
        dashboard_set_property $dash_path grp_sync title "Synchronization"

        dashboard_add          $dash_path grp_desc_info group grp_desc
        dashboard_set_property $dash_path grp_desc_info expandableX false
        dashboard_set_property $dash_path grp_desc_info expandableY false
        dashboard_set_property $dash_path grp_desc_info itemsPerRow 4
        dashboard_set_property $dash_path grp_desc_info title ""

        dashboard_add          $dash_path grp_desc_color group grp_desc
        dashboard_set_property $dash_path grp_desc_color expandableX false
        dashboard_set_property $dash_path grp_desc_color expandableY false
        dashboard_set_property $dash_path grp_desc_color itemsPerRow 3
        dashboard_set_property $dash_path grp_desc_color title "color"

        dashboard_add          $dash_path grp_desc_stride group grp_desc
        dashboard_set_property $dash_path grp_desc_stride expandableX false
        dashboard_set_property $dash_path grp_desc_stride expandableY false
        dashboard_set_property $dash_path grp_desc_stride itemsPerRow 2
        dashboard_set_property $dash_path grp_desc_stride title "strides"

        dashboard_add          $dash_path grp_sync_rw group grp_sync
        dashboard_set_property $dash_path grp_sync_rw expandableX false
        dashboard_set_property $dash_path grp_sync_rw expandableY false
        dashboard_set_property $dash_path grp_sync_rw itemsPerRow 2
        dashboard_set_property $dash_path grp_sync_rw title ""
          
        dashboard_add          $dash_path grp_sync_rd group grp_sync_rw
        dashboard_set_property $dash_path grp_sync_rd expandableX false
        dashboard_set_property $dash_path grp_sync_rd expandableY false
        dashboard_set_property $dash_path grp_sync_rd itemsPerRow 1
        dashboard_set_property $dash_path grp_sync_rd title "Read"
     
        dashboard_add          $dash_path grp_sync_wr group grp_sync_rw
        dashboard_set_property $dash_path grp_sync_wr expandableX false
        dashboard_set_property $dash_path grp_sync_wr expandableY false
        dashboard_set_property $dash_path grp_sync_wr itemsPerRow 1
        dashboard_set_property $dash_path grp_sync_wr title "Write"


        #
        # widgets
        #

        dashboard_add          $dash_path dash_dev_base text grp_device 
        dashboard_set_property $dash_path dash_dev_base label "Base" 
        dashboard_set_property $dash_path dash_dev_base expandableX false
        dashboard_set_property $dash_path dash_dev_base expandableY false
        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
        dashboard_set_property $dash_path dash_dev_base editable true
        dashboard_set_property $dash_path dash_dev_base htmlCapable false
        dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_surface_ctrl::SFCTRL_CSR_DEV_BASE} ] 

        dashboard_add          $dash_path dash_dev_init button grp_device 
        dashboard_set_property $dash_path dash_dev_init enabled true
        dashboard_set_property $dash_path dash_dev_init text "Init"
        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_surface_ctrl::dash_init_device }  

        dashboard_add          $dash_path dash_dev_dump button grp_device 
        dashboard_set_property $dash_path dash_dev_dump enabled true
        dashboard_set_property $dash_path dash_dev_dump text "Dump"
        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_surface_ctrl::dash_dump_device }  

        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_version enabled true
        dashboard_set_property $dash_path dash_dev_version text "Version"
        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_surface_ctrl::get_version }  

        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_caps enabled true
        dashboard_set_property $dash_path dash_dev_caps text "Caps"
        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_surface_ctrl::dash_get_caps }  

        dashboard_add          $dash_path dash_cfg_set button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_set enabled true
        dashboard_set_property $dash_path dash_cfg_set text "Set"
        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_surface_ctrl::dash_set_config  }  

        dashboard_add          $dash_path dash_cfg_readback button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_readback enabled true
        dashboard_set_property $dash_path dash_cfg_readback text "Readback"
        dashboard_set_property $dash_path dash_cfg_readback onClick { ::cgx_surface_ctrl::dash_get_config }  

        dashboard_add          $dash_path dash_cfg_run checkBox grp_cfg_cmd
        dashboard_set_property $dash_path dash_cfg_run text "Run"

        dashboard_add          $dash_path dash_sts_get button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_get enabled true
        dashboard_set_property $dash_path dash_sts_get text "Get"
        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_surface_ctrl::dash_get_status }  

        dashboard_add          $dash_path dash_sts_clear button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_clear text "Clear"
        dashboard_set_property $dash_path dash_sts_clear onClick { ::cgx_surface_ctrl::dash_clr_status }  

        dashboard_add          $dash_path dash_sts_run button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_run text "Run"
        dashboard_set_property $dash_path dash_sts_run enabled false
        dashboard_set_property $dash_path dash_sts_run onClick { ::cgx_surface_ctrl::dash_run_status }  

        dashboard_add          $dash_path dash_desc_width text grp_desc_info 
        dashboard_set_property $dash_path dash_desc_width label "width"
        dashboard_set_property $dash_path dash_desc_width expandableX false
        dashboard_set_property $dash_path dash_desc_width expandableY false
        dashboard_set_property $dash_path dash_desc_width preferredWidth 50
        dashboard_set_property $dash_path dash_desc_width editable true 
        dashboard_set_property $dash_path dash_desc_width htmlCapable false
        dashboard_set_property $dash_path dash_desc_width text "0"

        dashboard_add          $dash_path dash_desc_height text grp_desc_info 
        dashboard_set_property $dash_path dash_desc_height label "height"
        dashboard_set_property $dash_path dash_desc_height expandableX false
        dashboard_set_property $dash_path dash_desc_height expandableY false
        dashboard_set_property $dash_path dash_desc_height preferredWidth 50
        dashboard_set_property $dash_path dash_desc_height editable true 
        dashboard_set_property $dash_path dash_desc_height htmlCapable false
        dashboard_set_property $dash_path dash_desc_height text "0"

        dashboard_add          $dash_path dash_desc_bufnum text grp_desc_info 
        dashboard_set_property $dash_path dash_desc_bufnum label "buffers"
        dashboard_set_property $dash_path dash_desc_bufnum expandableX false
        dashboard_set_property $dash_path dash_desc_bufnum expandableY false
        dashboard_set_property $dash_path dash_desc_bufnum preferredWidth 30
        dashboard_set_property $dash_path dash_desc_bufnum editable true 
        dashboard_set_property $dash_path dash_desc_bufnum htmlCapable false
        dashboard_set_property $dash_path dash_desc_bufnum text "0"

    #   dashboard_add          $dash_path dash_desc_addr8_h text grp_desc_addr 
    #   dashboard_set_property $dash_path dash_desc_addr8_h label "high"
    #   dashboard_set_property $dash_path dash_desc_addr8_h expandableX false
    #   dashboard_set_property $dash_path dash_desc_addr8_h expandableY false
    #   dashboard_set_property $dash_path dash_desc_addr8_h preferredWidth 70
    #   dashboard_set_property $dash_path dash_desc_addr8_h editable true 
    #   dashboard_set_property $dash_path dash_desc_addr8_h htmlCapable false
    #   dashboard_set_property $dash_path dash_desc_addr8_h text "0x0"

        dashboard_add          $dash_path dash_desc_addr8_l text grp_desc_info 
        dashboard_set_property $dash_path dash_desc_addr8_l label "address"
        dashboard_set_property $dash_path dash_desc_addr8_l expandableX false
        dashboard_set_property $dash_path dash_desc_addr8_l expandableY false
        dashboard_set_property $dash_path dash_desc_addr8_l preferredWidth 70
        dashboard_set_property $dash_path dash_desc_addr8_l editable true 
        dashboard_set_property $dash_path dash_desc_addr8_l htmlCapable false
        dashboard_set_property $dash_path dash_desc_addr8_l text "0x0"

      # dashboard_add          $dash_path dash_desc_critical checkBox grp_desc
      # dashboard_set_property $dash_path dash_desc_critical text "critical"

        dashboard_add          $dash_path dash_desc_pixcolor text grp_desc_color 
        dashboard_set_property $dash_path dash_desc_pixcolor label "format"
        dashboard_set_property $dash_path dash_desc_pixcolor expandableX false
        dashboard_set_property $dash_path dash_desc_pixcolor expandableY false
        dashboard_set_property $dash_path dash_desc_pixcolor preferredWidth 50
        dashboard_set_property $dash_path dash_desc_pixcolor editable true 
        dashboard_set_property $dash_path dash_desc_pixcolor htmlCapable false
        dashboard_set_property $dash_path dash_desc_pixcolor text "0"

        dashboard_add          $dash_path dash_desc_pixdepth text grp_desc_color 
        dashboard_set_property $dash_path dash_desc_pixdepth label "pixel depth"
        dashboard_set_property $dash_path dash_desc_pixdepth expandableX false
        dashboard_set_property $dash_path dash_desc_pixdepth expandableY false
        dashboard_set_property $dash_path dash_desc_pixdepth preferredWidth 30
        dashboard_set_property $dash_path dash_desc_pixdepth editable true 
        dashboard_set_property $dash_path dash_desc_pixdepth htmlCapable false
        dashboard_set_property $dash_path dash_desc_pixdepth text "0"
        
        dashboard_add          $dash_path dash_desc_hstride8 text grp_desc_stride 
        dashboard_set_property $dash_path dash_desc_hstride8 label "row"
        dashboard_set_property $dash_path dash_desc_hstride8 expandableX false
        dashboard_set_property $dash_path dash_desc_hstride8 expandableY false
        dashboard_set_property $dash_path dash_desc_hstride8 preferredWidth 70
        dashboard_set_property $dash_path dash_desc_hstride8 editable true 
        dashboard_set_property $dash_path dash_desc_hstride8 htmlCapable false
        dashboard_set_property $dash_path dash_desc_hstride8 text "0x0"

        dashboard_add          $dash_path dash_desc_vstride8 text grp_desc_stride 
        dashboard_set_property $dash_path dash_desc_vstride8 label "buffer"
        dashboard_set_property $dash_path dash_desc_vstride8 expandableX false
        dashboard_set_property $dash_path dash_desc_vstride8 expandableY false
        dashboard_set_property $dash_path dash_desc_vstride8 preferredWidth 70
        dashboard_set_property $dash_path dash_desc_vstride8 editable true 
        dashboard_set_property $dash_path dash_desc_vstride8 htmlCapable false
        dashboard_set_property $dash_path dash_desc_vstride8 text "0x0"


    #   dashboard_add          $dash_path dash_sync_lock_on   checkBox grp_sync_lock
    #   dashboard_set_property $dash_path dash_sync_lock_on   text "active"
    #
    #   dashboard_add          $dash_path dash_sync_lock_gene comboBox grp_sync_lock 
    #   dashboard_set_property $dash_path dash_sync_lock_gene label "generator"
    #   dashboard_set_property $dash_path dash_sync_lock_gene options { "read" "write" }
    #   dashboard_set_property $dash_path dash_sync_lock_gene expandableX false
    #   dashboard_set_property $dash_path dash_sync_lock_gene expandableY false
    #   dashboard_set_property $dash_path dash_sync_lock_gene preferredWidth 70
    #   dashboard_set_property $dash_path dash_sync_lock_gene selected 1   
    #
    #   dashboard_add          $dash_path dash_sync_lock_mode comboBox grp_sync_lock 
    #   dashboard_set_property $dash_path dash_sync_lock_mode label "mode"
    #   dashboard_set_property $dash_path dash_sync_lock_mode options { "free" "controlled" "master" }; #  "master-delay"
    #   dashboard_set_property $dash_path dash_sync_lock_mode expandableX false
    #   dashboard_set_property $dash_path dash_sync_lock_mode expandableY false
    #   dashboard_set_property $dash_path dash_sync_lock_mode preferredWidth 70
    #   dashboard_set_property $dash_path dash_sync_lock_mode selected 1   

    #   dashboard_add          $dash_path dash_sync_lock_delay text grp_sync_lock 
    #   dashboard_set_property $dash_path dash_sync_lock_delay label "delay"
    #   dashboard_set_property $dash_path dash_sync_lock_delay expandableX false
    #   dashboard_set_property $dash_path dash_sync_lock_delay expandableY false
    #   dashboard_set_property $dash_path dash_sync_lock_delay preferredWidth 70
    #   dashboard_set_property $dash_path dash_sync_lock_delay editable true 
    #   dashboard_set_property $dash_path dash_sync_lock_delay htmlCapable false
    #   dashboard_set_property $dash_path dash_sync_lock_delay text "0"

    #   dashboard_add          $dash_path dash_sync_rate_buffer comboBox grp_sync_rate 
    #   dashboard_set_property $dash_path dash_sync_rate_buffer label "Buffer"
    #   dashboard_set_property $dash_path dash_sync_rate_buffer options { "read" "write" }
    #   dashboard_set_property $dash_path dash_sync_rate_buffer expandableX false
    #   dashboard_set_property $dash_path dash_sync_rate_buffer expandableY false
    #   dashboard_set_property $dash_path dash_sync_rate_buffer preferredWidth 70
    #   dashboard_set_property $dash_path dash_sync_rate_buffer selected 1   
    #
    #   dashboard_add          $dash_path dash_sync_rate_repeat text grp_sync_rate 
    #   dashboard_set_property $dash_path dash_sync_rate_repeat label "Repeat"
    #   dashboard_set_property $dash_path dash_sync_rate_repeat expandableX false
    #   dashboard_set_property $dash_path dash_sync_rate_repeat expandableY false
    #   dashboard_set_property $dash_path dash_sync_rate_repeat preferredWidth 70
    #   dashboard_set_property $dash_path dash_sync_rate_repeat editable true 
    #   dashboard_set_property $dash_path dash_sync_rate_repeat htmlCapable false
    #   dashboard_set_property $dash_path dash_sync_rate_repeat text "0"
    #
    #   dashboard_add          $dash_path dash_sync_rate_total text grp_sync_rate 
    #   dashboard_set_property $dash_path dash_sync_rate_total label "Total"
    #   dashboard_set_property $dash_path dash_sync_rate_total expandableX false
    #   dashboard_set_property $dash_path dash_sync_rate_total expandableY false
    #   dashboard_set_property $dash_path dash_sync_rate_total preferredWidth 70
    #   dashboard_set_property $dash_path dash_sync_rate_total editable true 
    #   dashboard_set_property $dash_path dash_sync_rate_total htmlCapable false
    #   dashboard_set_property $dash_path dash_sync_rate_total text "0"
 
        dashboard_add          $dash_path dash_sync_rd_ptr_nxt text grp_sync_rd 
        dashboard_set_property $dash_path dash_sync_rd_ptr_nxt label "ptr next"
        dashboard_set_property $dash_path dash_sync_rd_ptr_nxt expandableX false
        dashboard_set_property $dash_path dash_sync_rd_ptr_nxt expandableY false
        dashboard_set_property $dash_path dash_sync_rd_ptr_nxt preferredWidth 50
        dashboard_set_property $dash_path dash_sync_rd_ptr_nxt editable true 
        dashboard_set_property $dash_path dash_sync_rd_ptr_nxt htmlCapable false
        dashboard_set_property $dash_path dash_sync_rd_ptr_nxt text "0"

        dashboard_add          $dash_path dash_sync_rd_ptr_cur text grp_sync_rd 
        dashboard_set_property $dash_path dash_sync_rd_ptr_cur label "ptr current" 
        dashboard_set_property $dash_path dash_sync_rd_ptr_cur expandableX false
        dashboard_set_property $dash_path dash_sync_rd_ptr_cur expandableY false
        dashboard_set_property $dash_path dash_sync_rd_ptr_cur preferredWidth 50
        dashboard_set_property $dash_path dash_sync_rd_ptr_cur editable false
        dashboard_set_property $dash_path dash_sync_rd_ptr_cur htmlCapable false
        dashboard_set_property $dash_path dash_sync_rd_ptr_cur text "0"
                    
        dashboard_add          $dash_path dash_sync_wr_ptr_nxt text grp_sync_wr                  
        dashboard_set_property $dash_path dash_sync_wr_ptr_nxt label "ptr next"       
        dashboard_set_property $dash_path dash_sync_wr_ptr_nxt expandableX false              
        dashboard_set_property $dash_path dash_sync_wr_ptr_nxt expandableY false              
        dashboard_set_property $dash_path dash_sync_wr_ptr_nxt preferredWidth 50              
        dashboard_set_property $dash_path dash_sync_wr_ptr_nxt editable true                  
        dashboard_set_property $dash_path dash_sync_wr_ptr_nxt htmlCapable false              
        dashboard_set_property $dash_path dash_sync_wr_ptr_nxt text "0"                       
                
        dashboard_add          $dash_path dash_sync_wr_ptr_cur text grp_sync_wr 
        dashboard_set_property $dash_path dash_sync_wr_ptr_cur label "ptr current" 
        dashboard_set_property $dash_path dash_sync_wr_ptr_cur expandableX false
        dashboard_set_property $dash_path dash_sync_wr_ptr_cur expandableY false
        dashboard_set_property $dash_path dash_sync_wr_ptr_cur preferredWidth 50
        dashboard_set_property $dash_path dash_sync_wr_ptr_cur editable false
        dashboard_set_property $dash_path dash_sync_wr_ptr_cur htmlCapable false
        dashboard_set_property $dash_path dash_sync_wr_ptr_cur text "0"
                
      # after idle ::cgx_surface_ctrl::dash_update

        puts " ${::cgx_surface_ctrl::IPCORE_LABEL} dashBoard end "

        return -code ok
    }



    proc dash_get_device_base {} {
    	
        set ::cgx_surface_ctrl::debug 1

        cgx_surface_ctrl::set_dev_base -1 -1
 
        set ::cgx_surface_ctrl::debug 0
    }


    proc dash_init_device {} {
    	
        set ::cgx_surface_ctrl::debug 1

        cgx_surface_ctrl::init -1  
        cgx_surface_ctrl::dash_get_config
        cgx_surface_ctrl::dash_get_status

        set ::cgx_surface_ctrl::debug 0
    }


    proc dash_dump_device {} {

        cgx_surface_ctrl::dump  
 
    }


    proc dash_get_caps { } {

        set ::cgx_surface_ctrl::debug 1

        set dash_path ${::cgx_surface_ctrl::dash_path}  

        ::cgx_surface_ctrl::get_caps 

        set ::cgx_surface_ctrl::debug 0
                                                                                               
    }

 
    proc dash_set_config {} {

        set ::cgx_surface_ctrl::debug 1
       
        ::cgx_surface_ctrl::set_surface -1 -1 
        ::cgx_surface_ctrl::set_buffer 0 -1                    
        ::cgx_surface_ctrl::set_buffer 1 -1                    

        set ::cgx_surface_ctrl::debug 0
        
    }


    proc dash_get_config {} {

        set ::cgx_surface_ctrl::debug 1

        ::cgx_surface_ctrl::get_surface -1 
        ::cgx_surface_ctrl::get_buffer 0
        ::cgx_surface_ctrl::get_buffer 1

        set ::cgx_surface_ctrl::debug 0

    }
    

    proc dash_get_status {} {

        set ::cgx_surface_ctrl::debug 1

        ::cgx_surface_ctrl::get_buffer 0
        ::cgx_surface_ctrl::get_buffer 1

        set ::cgx_surface_ctrl::debug 0

    }


    proc dash_clr_status {} {

        set ::cgx_surface_ctrl::debug 1

    #   cgx_surface_ctrl::clr_status          

        set ::cgx_surface_ctrl::debug 0

    }


    proc dash_run_status {} {

##      set ::cgx_surface_ctrl::debug 1
##
##      set ::cgx_surface_ctrl::debug 0

    }
   
}


 
