 
#  cgx_vsc::init              { dev_base }
#  cgx_vsc::get_version       { }
#  cgx_vsc::get_caps          { }
#  cgx_vsc::set_config        { run rotate_msk}
#  cgx_vsc::get_config        { }
#  cgx_vsc::set_interrupt     { -1 }
#  cgx_vsc::get_interrupt     { }  
#  cgx_vsc::get_status        { }
#  cgx_vsc::clr_status        { }
#  cgx_vsc::video_get_writer   { quiet }
#  cgx_vsc::video_get_output  { }
#  cgx_vsc::video_set_output  { width height }
#  cgx_vsc::dump_reg32        { reg_offset32 }    ex: cgx_vsc::dump_reg32 ${::cgx_vsc::VSC_CSR_REG_CONTROL}; 
#  cgx_vsc::dump_all          { } 
#  cgx_vsc::dashBoard


namespace eval cgx_vsc {


    variable IPCORE_PRODUCT 62; # = 0x3e                                                                                          
    variable IPCORE_VERSION ${::cgx_fusion::IPCORE_VERSION}                                                                                          
    variable IPCORE_LABEL   "VSC"                                                                                          
 
    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    # debug mode
    # 0 => console 
    # 1 => dashboard 
    variable debug 0



    #-------------------------- SYS------------------------------

    variable VSC_CSR_DEV_BASE        0x00000000
    variable VSC_CSR_DEV_BASE_SFCTRL 0x00000000
    variable initialized 0

    # 0:  enable  info stdout   
    # 1:  disable info stdout
    variable QUIET 0

    #-------------------------- HAL------------------------------

    # /* registers definition */
    variable VSC_CSR_REG_VERSION       0
    variable VSC_CSR_REG_CAPS          1
    variable VSC_CSR_REG_INTERRUPT     2  
    variable VSC_CSR_REG_CONFIG        3  
    variable VSC_CSR_REG_STATUS        4
    variable VSC_CSR_REG_WRITER_SIZE   5
    variable VSC_CSR_REG_READER_SIZE   6
    
    variable VSC_CSR_REG_BASE_SFC     16                                  

    variable VSC_CSR_REG_NUMBER       32                                  

             
    # /* VSC_CSR_REG_VERSION */
    
        # /* Parameters */
        variable VSC_CSR_VERSION_ID_MSK     0xFF      
        variable VSC_CSR_VERSION_ID_OFST    0         
        variable VSC_CSR_VERSION_BUILD_MSK  0xFF00    
        variable VSC_CSR_VERSION_BUILD_OFST 8         
        variable VSC_CSR_VERSION_MINOR_MSK  0xFF0000   
        variable VSC_CSR_VERSION_MINOR_OFST 16        
        variable VSC_CSR_VERSION_MAJOR_MSK  0x0F000000   
        variable VSC_CSR_VERSION_MAJOR_OFST 24        
      
       
    # /* VSC_CSR_REG_CAPS */

        variable VSC_CSR_CAPS_IS_WRITER_MSK         0x1
        variable VSC_CSR_CAPS_IS_WRITER_OFST        0  
        variable VSC_CSR_CAPS_IS_READER_MSK         0x2
        variable VSC_CSR_CAPS_IS_READER_OFST        1  
        variable VSC_CSR_CAPS_ENABLE_ROTATION_MSK   0x100
        variable VSC_CSR_CAPS_ENABLE_ROTATION_OFST  8

             
    # /* VSC_CSR_REG_INTERRUPT */
        variable VSC_CSR_INTERRUPT_ENABLE_MSK  0xFF
        variable VSC_CSR_INTERRUPT_ENABLE_OFST 0


    # /* To be used for ENABLE & ACTIVE FIELDS                                
        variable VSC_CSR_IRQ_BIT_FRAME_COMPLETED_MSK  0x1                                          
        variable VSC_CSR_IRQ_BIT_FRAME_COMPLETED_OFST 0                                            
        variable VSC_CSR_IRQ_BIT_VIDEO_CHANGED_MSK    0x2 
        variable VSC_CSR_IRQ_BIT_VIDEO_CHANGED_OFST   1   

   
    # /* VSC_CSR_REG_CONFIG */
     
        # /* 0/1 = power off/on.                                               */
        # /* power-off set default value for other register parameters         */
        variable VSC_CSR_CFG_RUN_MSK      0x1
        variable VSC_CSR_CFG_RUN_OFST     0
        variable VSC_CSR_CFG_ROTATE_MSK   0x700
        variable VSC_CSR_CFG_ROTATE_OFST  8
           
            # /* VSC_CSR_CFG_ROTATE_MSK */
            variable VSC_ROTATE_MIRROR_MSK  0x1       
            variable VSC_ROTATE_MIRROR_OFST 0       
            variable VSC_ROTATE_FLIP_H_MSK  0x2             
            variable VSC_ROTATE_FLIP_H_OFST 1             
            variable VSC_ROTATE_FLIP_V_MSK  0x4             
            variable VSC_ROTATE_FLIP_V_OFST 2             


    # /* VSC_CSR_REG_STATUS */

        variable VSC_STS_BUSY_MSK            0x1
        variable VSC_STS_BUSY_OFST           0
        variable VSC_STS_IRQ_MSK             0x2
        variable VSC_STS_IRQ_OFST            1
        # /* 0/1 = interrupt active. read the register to get information      */
        # /* about active interrupts. write register to clears the interrupts. */
        variable VSC_STS_IRQ_ACTIVE_MSK      0xFF00
        variable VSC_STS_IRQ_ACTIVE_OFST     8
        variable VSC_STS_FRAME_COUNT_MSK     0xFFFF0000   
        variable VSC_STS_FRAME_COUNT_OFST    16           
 
                       
    # VSC_CSR_REG_WRITER_SIZE  
    # VSC_CSR_REG_READER_SIZE  
        variable VSC_CSR_VALX_MSK  0x0000FFFF
        variable VSC_CSR_VALX_OFST 0
        variable VSC_CSR_VALY_MSK  0xFFFF0000
        variable VSC_CSR_VALY_OFST 16



    #--------------------------private functions ------------------------------

    proc CGX_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_vsc::$field_name\_REG 
            set str_field_msk   ::cgx_vsc::$field_name\_MSK 
            set str_field_ofst  ::cgx_vsc::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc CGX_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_vsc::$field_name\_MSK 
        set str_field_ofst ::cgx_vsc::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

     
    #--------------------------public functions ------------------------------
                
    # <dev_base>  
    proc init { dev_base } {

        if { ${::cgx_vsc::debug} == 1 } {
            set dash_path ${::cgx_vsc::dash_path} 
            set dev_base [ dashboard_get_property $dash_path dash_dev_base text ]
        } 
        
        set ::cgx_vsc::VSC_CSR_DEV_BASE ${dev_base}         
        set ::cgx_vsc::VSC_CSR_DEV_BASE_SFCTRL [ expr ${dev_base} + 4*${::cgx_vsc::VSC_CSR_REG_BASE_SFC} ]    
        
        set dev_success [ ::cgx_vsc::get_version ];  
        
        if {${dev_success} == 1} {
            set ::cgx_vsc::initialized 1
        } else {
            set ::cgx_vsc::initialized 0
        } 
        
        if { ${::cgx_vsc::debug} == 1 } {
            set dash_path ${::cgx_vsc::dash_path} 
            # CSR visibility triggered by get_caps 
            dashboard_set_property $dash_path grp_csr   visible false
            if {${dev_success} == 1} {
                puts " ${::cgx_vsc::IPCORE_LABEL} init successfull "
                dashboard_set_property $dash_path grp_core  visible true
            } else {
            	  puts " ${::cgx_vsc::IPCORE_LABEL} ERROR: device init failure "
                dashboard_set_property $dash_path grp_core  visible false
            } 
        } 

    }
       


    proc get_version { } {
        
        set csr_base8 ${::cgx_vsc::VSC_CSR_DEV_BASE} 
        
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_vsc::VSC_CSR_REG_VERSION} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set v_id    [ CGX_GET_FIELD $reg VSC_CSR_VERSION_ID ] ;                              
        set v_build [ CGX_GET_FIELD $reg VSC_CSR_VERSION_BUILD ] ;                           
        set v_minor [ CGX_GET_FIELD $reg VSC_CSR_VERSION_MINOR ] ;                           
        set v_major [ CGX_GET_FIELD $reg VSC_CSR_VERSION_MAJOR ] ;                           
        set version $v_major.$v_minor                            

        if {$v_id == ${::cgx_vsc::IPCORE_PRODUCT} } {
          puts " ${::cgx_vsc::IPCORE_LABEL} detection successfull, core id = [ format 0x%x $v_id ] "
          puts " ${::cgx_vsc::IPCORE_LABEL} Version = $v_major.$v_minor, Build = $v_build"
          if { $version == ${::cgx_vsc::IPCORE_VERSION} } {
            set success 1
          } else {
            set success 0
            puts stdout " ${::cgx_vsc::IPCORE_LABEL} ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_vsc::IPCORE_VERSION} )"
            puts stdout "        please upgrade the dashboard version accordingly to the IP core "
          }
        } else {
          set success 0
          puts stdout " ${::cgx_vsc::IPCORE_LABEL} ERROR: device not detected at device base ${::cgx_vsc::VSC_CSR_DEV_BASE} "
          puts stdout "        core id = $v_id, reg = $reg "
          puts stdout "        please, set the right device base and press init again "
        }
        return $success

    }

 
    proc get_caps { } {
        
    #   cgx_vsc::csr_get_caps ${::cgx_vsc::debug}
        
        set csr_base8 ${::cgx_vsc::VSC_CSR_DEV_BASE} 

        open_service master ${::boardInit::masterPath}        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_vsc::VSC_CSR_REG_CAPS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set caps_is_reader    [ CGX_GET_FIELD $reg VSC_CSR_CAPS_IS_READER ] ; 
        set caps_is_writer    [ CGX_GET_FIELD $reg VSC_CSR_CAPS_IS_WRITER ] ; 
        set caps_ena_rotation [ CGX_GET_FIELD $reg VSC_CSR_CAPS_ENABLE_ROTATION ] ; 
 
	      puts "                                            "
        puts "  Capabilities:                             "
        puts "      caps_is_reader    = $caps_is_reader   "
        puts "      caps_is_writer    = $caps_is_writer   "
        puts "      caps_ena_rotation = $caps_ena_rotation"
        puts "                                            "                                                                                          

        if { ${::cgx_vsc::debug} == 1 } {

            set dash_path ${::cgx_vsc::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true
            
            if { $caps_is_writer==1} { 
                dashboard_set_property $dash_path grp_writer    visible true
            #   dashboard_set_property $dash_path grp_writer visible true
            } else {    
                dashboard_set_property $dash_path grp_writer    visible false
            #   dashboard_set_property $dash_path grp_writer visible false
            }

            if { $caps_is_reader==1} { 
                dashboard_set_property $dash_path grp_reader   visible true  
            #   dashboard_set_property $dash_path grp_reader visible true
            } else {                                                     
                dashboard_set_property $dash_path grp_reader   visible false 
            #   dashboard_set_property $dash_path grp_reader visible false
            }
                     
            if { $caps_ena_rotation!=0} {  
                dashboard_set_property $dash_path grp_rotate  visible true
            } else {    
                dashboard_set_property $dash_path grp_rotate  visible false
            }                        
        }
    }


    proc dump_reg32 { reg_offset32 } {

        open_service master ${::boardInit::masterPath}
        set dump [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*$reg_offset32 ] 1  ]
        puts stdout $dump
	      close_service master ${::boardInit::masterPath}

    }


    proc dump_all {  } {
        open_service master ${::boardInit::masterPath}
        set dump [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 0 ] ${::cgx_vsc::VSC_CSR_REG_NUMBER} ]
        puts "dump ${::cgx_vsc::VSC_CSR_REG_NUMBER} 32-bits regs at ${::cgx_vsc::VSC_CSR_DEV_BASE}: " 
	      puts stdout $dump
	      close_service master ${::boardInit::masterPath}
    }

  
    proc set_config { cfg_run cfg_rotate_msk } {   

        if { ${::cgx_vsc::debug} == 1 } {
            set dash_path ${::cgx_vsc::dash_path} 
            set cfg_run 0 
            if { [ dashboard_get_property $dash_path dash_cfg_run checked ] == true } {
                set cfg_run 1
            } 

            set mirror_bool [ dashboard_get_property $dash_path dash_cfg_mirror checked ]
            set flip_h_bool [ dashboard_get_property $dash_path dash_cfg_flip_h checked ]
            set flip_v_bool [ dashboard_get_property $dash_path dash_cfg_flip_v checked ]

            set cfg_rotate_msk 0 

            if { $mirror_bool == true} {   
                set cfg_rotate_msk [ CGX_SET_FIELD $cfg_rotate_msk VSC_ROTATE_MIRROR 1 ]
            } 
            if { $flip_h_bool == true} {   
                set cfg_rotate_msk [ CGX_SET_FIELD $cfg_rotate_msk VSC_ROTATE_FLIP_H 1 ]
            } 
            if { $flip_v_bool == true} {   
                set cfg_rotate_msk [ CGX_SET_FIELD $cfg_rotate_msk VSC_ROTATE_FLIP_V 1 ]
            } 
        }  
  
        open_service master ${::boardInit::masterPath}
 
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_CONFIG} ] 0x1]; 
        set reg [ CGX_SET_FIELD $reg VSC_CSR_CFG_RUN $cfg_run ]
        set reg [ CGX_SET_FIELD $reg VSC_CSR_CFG_ROTATE $cfg_rotate_msk ]

        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_CONFIG} ] $reg
 
        close_service master ${::boardInit::masterPath}
    }
    
      
    proc get_config { } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_CONFIG} ] 0x1]; 
        set cfg_run        [ CGX_GET_FIELD $reg VSC_CSR_CFG_RUN ] ;                                                                
        set cfg_rotate_msk [ CGX_GET_FIELD $reg VSC_CSR_CFG_ROTATE ] ;                                                                
        set cfg_mirror [ CGX_GET_FIELD $cfg_rotate_msk VSC_ROTATE_MIRROR ]
        set cfg_flip_h [ CGX_GET_FIELD $cfg_rotate_msk VSC_ROTATE_FLIP_H ]
        set cfg_flip_v [ CGX_GET_FIELD $cfg_rotate_msk VSC_ROTATE_FLIP_V ]

	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_vsc::debug} == 0 } {
            puts "                               "
            puts "  config:                      "
            puts "      cfg_run    = $cfg_run    "          
            puts "      cfg_mirror = $cfg_mirror "                                                                                                                                                                
            puts "      cfg_flip_h = $cfg_flip_h "                                                                                                                                                                
            puts "      cfg_flip_v = $cfg_flip_v "                                                                                                                                                                
        }
        if { ${::cgx_vsc::debug} == 1 } {
        	  set dash_path ${::cgx_vsc::dash_path} 
 
            if { $cfg_run == 1 } {
               dashboard_set_property $dash_path dash_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_run checked false  
            } 

            if { $cfg_mirror == 1 } {
               dashboard_set_property $dash_path dash_cfg_mirror checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_mirror checked false  
            } 

            if { $cfg_flip_h == 1 } {
               dashboard_set_property $dash_path dash_cfg_flip_h checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_flip_h checked false  
            } 

            if { $cfg_flip_v == 1 } {
               dashboard_set_property $dash_path dash_cfg_flip_v checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_flip_v checked false  
            } 
        }
    }


    proc set_interrupt { ie_bitfield } {

        if { ${::cgx_vsc::debug} == 1 } {
	          set dash_path ${::cgx_vsc::dash_path} 
            set ie_bitfield 0
	          if { [ dashboard_get_property $dash_path dash_cfg_ie_frame_completed checked ] == true } {
                set ie_bitfield [ CGX_SET_FIELD $ie_bitfield VSC_CSR_IRQ_BIT_FRAME_COMPLETED 1 ]
            } 

            if { [ dashboard_get_property $dash_path dash_cfg_ie_video_changed checked ] == true } {
                set ie_bitfield [ CGX_SET_FIELD $ie_bitfield VSC_CSR_IRQ_BIT_VIDEO_CHANGED 1 ]
            } 
        }   
        open_service master ${::boardInit::masterPath}
        set reg 0
        set reg [ CGX_SET_FIELD $reg VSC_CSR_INTERRUPT_ENABLE $ie_bitfield ]           
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_INTERRUPT} ] $reg
        close_service master ${::boardInit::masterPath}
    }
 

    proc get_interrupt { } {

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_INTERRUPT} ] 0x1]; 
        set ie_bitfield  [ CGX_GET_FIELD $reg VSC_CSR_INTERRUPT_ENABLE ] ;                                                                
	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_vsc::debug} == 0 } {
            puts "                                                            "
            puts "  interrupt:                                                "
            puts "         ie_bitfield = $ie_bitfield "      
            puts "                                                            "                                                                                                           
        }
        if { ${::cgx_vsc::debug} == 1 } {
        	  set dash_path ${::cgx_vsc::dash_path} 
 
            if { [ CGX_GET_FIELD $ie_bitfield VSC_CSR_IRQ_BIT_FRAME_COMPLETED ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_frame_completed checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_frame_completed checked false
            }        
            if { [ CGX_GET_FIELD $ie_bitfield VSC_CSR_IRQ_BIT_VIDEO_CHANGED ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_video_changed checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_video_changed checked false
            }        
        }
    }


    proc get_status { } {

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_STATUS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set sts_busy     [ CGX_GET_FIELD $reg VSC_STS_BUSY ] ;                                                                
        set sts_irq      [ CGX_GET_FIELD $reg VSC_STS_IRQ  ] ;                                                                
        set sts_irqfield [ CGX_GET_FIELD $reg VSC_STS_IRQ_ACTIVE ] ;                                                                
        set frame_count  [ CGX_GET_FIELD $reg VSC_STS_FRAME_COUNT ] ;                                                                

        set sts_ia_frame_completed [ CGX_GET_FIELD $sts_irqfield VSC_CSR_IRQ_BIT_FRAME_COMPLETED ] ;                                                                
        set sts_ia_video_changed   [ CGX_GET_FIELD $sts_irqfield VSC_CSR_IRQ_BIT_VIDEO_CHANGED ] ;                                                                
 
        if { ${::cgx_vsc::QUIET} == 0 } {
            puts "                                                         "
            puts "  status:                                                "
            puts "         sts_busy               = $sts_busy                 "
            puts "         sts_irq                = $sts_irq                  "
            puts "         sts_ia_frame_completed = $sts_ia_frame_completed  "  
            puts "         sts_ia_video_changed   = $sts_ia_video_changed    "
            puts "         frame_count            = $frame_count             "
            puts "                                                       "                                                                                                              
        }
        if { ${::cgx_vsc::debug} == 1 } {
        	  set dash_path ${::cgx_vsc::dash_path} 
            if { $sts_busy == 1 } {
               dashboard_set_property $dash_path dash_sts_busy checked true
            } else { 
               dashboard_set_property $dash_path dash_sts_busy checked false
            }        

            if { $sts_irq == 1 } {
                dashboard_set_property $dash_path dash_sts_irq color "red"
            } else {
                dashboard_set_property $dash_path dash_sts_irq color "black"
            }

            if { $sts_ia_frame_completed == 1 } {
               dashboard_set_property $dash_path dash_sts_ia_frame_completed checked true
            } else { 
               dashboard_set_property $dash_path dash_sts_ia_frame_completed checked false
            }        

            if { $sts_ia_video_changed == 1 } {
               dashboard_set_property $dash_path dash_sts_ia_video_changed checked true
            } else { 
               dashboard_set_property $dash_path dash_sts_ia_video_changed checked false
            }        

            dashboard_set_property $dash_path dash_frame_count text $frame_count    

        }
    }
                         

    # clear all status interrupt-active bits
    proc clr_status { } {

        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_STATUS} ] 0xFFFFFFFF 
	      close_service master ${::boardInit::masterPath}
    }
 

    proc video_get_writer { quiet } {

        open_service master ${::boardInit::masterPath}
 
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_WRITER_SIZE} ] 0x1]; 
        set writer_width  [ CGX_GET_FIELD $reg VSC_CSR_VALX ]    
        set writer_height [ CGX_GET_FIELD $reg VSC_CSR_VALY ]    

	      close_service master ${::boardInit::masterPath}
 
        if { $quiet == 0 } {
            puts "                                    "
            puts "  status:                           "
            puts "     writer_width  = $writer_width  " 
            puts "     writer_height = $writer_height " 
            puts "                                    "                                                                                                                     
        }
        if { ${::cgx_vsc::debug} == 1 } {
            set dash_path ${::cgx_vsc::dash_path}                         
            dashboard_set_property $dash_path dash_writer_width   text $writer_width   
            dashboard_set_property $dash_path dash_writer_height  text $writer_height  
        }
                
        set sts {}
        lappend sts $writer_width 
        lappend sts $writer_height         
        return $sts           
    }

    proc video_get_output { } {

        open_service master ${::boardInit::masterPath}
 
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_READER_SIZE} ] 0x1]; 
        set vout_width  [ CGX_GET_FIELD $reg VSC_CSR_VALX ]    
        set vout_height [ CGX_GET_FIELD $reg VSC_CSR_VALY ]    
 
	      close_service master ${::boardInit::masterPath}
 
        if { ${::cgx_vsc::debug} == 0 } {
            puts "                                  "
            puts "  status:                         "
            puts "      vout_width   =$vout_width   "        
            puts "      vout_height  =$vout_height  "        
            puts "                                  "                                                                                                                                                                
        }
        if { ${::cgx_vsc::debug} == 1 } {
            set dash_path ${::cgx_vsc::dash_path} 
            dashboard_set_property $dash_path dash_vout_width   text $vout_width   
            dashboard_set_property $dash_path dash_vout_height  text $vout_height  
        }
    }


    proc video_set_output { width height } {
        
        if { ${::cgx_vsc::debug} == 1 } {
            set dash_path ${::cgx_vsc::dash_path} 
            set width   [ dashboard_get_property $dash_path dash_vout_width   text ]
            set height  [ dashboard_get_property $dash_path dash_vout_height  text ]
        }
        set reg 0
        set reg [ CGX_SET_FIELD $reg VSC_CSR_VALX $width ]
        set reg [ CGX_SET_FIELD $reg VSC_CSR_VALY $height ]
        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_vsc::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_READER_SIZE} ] $reg
	      close_service master ${::boardInit::masterPath} 
    }

 
    proc dashBoard { } {

        if { ${::cgx_vsc::dashboardActive} == 1 } {
            return -code ok " ${::cgx_vsc::IPCORE_LABEL} dashboard already active"
        }

        set ::cgx_vsc::dashboardActive 1
        puts stdout " ${::cgx_vsc::IPCORE_LABEL} dashBoard start ......."

        #
        # Create dashboard 
        #
        variable ::cgx_vsc::dash_path [ add_service dashboard cgx_vsc "cgx_vsc" "Tools/cgx_vsc"]
     
        set dash_path ${::cgx_vsc::dash_path} 
     
        #
        # Set dashboard properties
        #
        dashboard_set_property $dash_path self developmentMode true
        dashboard_set_property $dash_path self itemsPerRow 1
        dashboard_set_property $dash_path self visible true
        
        #
        # groups
        #
        dashboard_add          $dash_path grp_top group self
        dashboard_set_property $dash_path grp_top expandableX false
        dashboard_set_property $dash_path grp_top expandableY false
        dashboard_set_property $dash_path grp_top itemsPerRow 1
        dashboard_set_property $dash_path grp_top title ""

        dashboard_add          $dash_path grp_device group grp_top
        dashboard_set_property $dash_path grp_device expandableX false
        dashboard_set_property $dash_path grp_device expandableY false
        dashboard_set_property $dash_path grp_device itemsPerRow 4
        dashboard_set_property $dash_path grp_device title "Device"

        dashboard_add          $dash_path grp_core group grp_top
        dashboard_set_property $dash_path grp_core expandableX false
        dashboard_set_property $dash_path grp_core expandableY false
        dashboard_set_property $dash_path grp_core itemsPerRow 1
        dashboard_set_property $dash_path grp_core title "Core ${::cgx_vsc::IPCORE_VERSION}"
        dashboard_set_property $dash_path grp_core visible false; # dashboard init

        dashboard_add          $dash_path grp_core_cmd group grp_core
        dashboard_set_property $dash_path grp_core_cmd expandableX false
        dashboard_set_property $dash_path grp_core_cmd expandableY false
        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_core_cmd title ""

        dashboard_add          $dash_path grp_csr group grp_core
        dashboard_set_property $dash_path grp_csr expandableX false
        dashboard_set_property $dash_path grp_csr expandableY false
        dashboard_set_property $dash_path grp_csr itemsPerRow 1
        dashboard_set_property $dash_path grp_csr title ""
        dashboard_set_property $dash_path grp_csr visible false; # dashboard init

        dashboard_add          $dash_path grp_csr_main group grp_csr
        dashboard_set_property $dash_path grp_csr_main expandableX false
        dashboard_set_property $dash_path grp_csr_main expandableY false
        dashboard_set_property $dash_path grp_csr_main itemsPerRow 2
        dashboard_set_property $dash_path grp_csr_main title ""
 
        dashboard_add          $dash_path grp_config group grp_csr_main
        dashboard_set_property $dash_path grp_config expandableX false
        dashboard_set_property $dash_path grp_config expandableY false
        dashboard_set_property $dash_path grp_config itemsPerRow 1
        dashboard_set_property $dash_path grp_config title "Config"

        dashboard_add          $dash_path grp_cfg_cmd group grp_config
        dashboard_set_property $dash_path grp_cfg_cmd expandableX false
        dashboard_set_property $dash_path grp_cfg_cmd expandableY false
        dashboard_set_property $dash_path grp_cfg_cmd itemsPerRow 2
        dashboard_set_property $dash_path grp_cfg_cmd title ""

        dashboard_add          $dash_path grp_cfg_param0 group grp_config
        dashboard_set_property $dash_path grp_cfg_param0 expandableX false
        dashboard_set_property $dash_path grp_cfg_param0 expandableY false
        dashboard_set_property $dash_path grp_cfg_param0 itemsPerRow 3
        dashboard_set_property $dash_path grp_cfg_param0 title ""

        dashboard_add          $dash_path grp_cfg_irq group grp_config
        dashboard_set_property $dash_path grp_cfg_irq expandableX false
        dashboard_set_property $dash_path grp_cfg_irq expandableY false
        dashboard_set_property $dash_path grp_cfg_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_cfg_irq title "interrupt enable"

        dashboard_add          $dash_path grp_status group grp_csr_main
        dashboard_set_property $dash_path grp_status expandableX false
        dashboard_set_property $dash_path grp_status expandableY false
        dashboard_set_property $dash_path grp_status itemsPerRow 1
        dashboard_set_property $dash_path grp_status title "Status"

        dashboard_add          $dash_path grp_sts_cmd group grp_status
        dashboard_set_property $dash_path grp_sts_cmd expandableX false
        dashboard_set_property $dash_path grp_sts_cmd expandableY false
        dashboard_set_property $dash_path grp_sts_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_cmd title ""

        dashboard_add          $dash_path grp_sts_param group grp_status
        dashboard_set_property $dash_path grp_sts_param expandableX false
        dashboard_set_property $dash_path grp_sts_param expandableY false
        dashboard_set_property $dash_path grp_sts_param itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_param title ""

        dashboard_add          $dash_path grp_sts_irq group grp_status
        dashboard_set_property $dash_path grp_sts_irq expandableX false
        dashboard_set_property $dash_path grp_sts_irq expandableY false
        dashboard_set_property $dash_path grp_sts_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_sts_irq title "interrupt active"

        dashboard_add          $dash_path grp_fct group grp_csr
        dashboard_set_property $dash_path grp_fct expandableX false
        dashboard_set_property $dash_path grp_fct expandableY false
        dashboard_set_property $dash_path grp_fct itemsPerRow 1
        dashboard_set_property $dash_path grp_fct title ""

        dashboard_add          $dash_path grp_rotate group grp_fct
        dashboard_set_property $dash_path grp_rotate expandableX false
        dashboard_set_property $dash_path grp_rotate expandableY false
        dashboard_set_property $dash_path grp_rotate itemsPerRow 4
        dashboard_set_property $dash_path grp_rotate title "Rotate"

        dashboard_add          $dash_path grp_writer group grp_fct
        dashboard_set_property $dash_path grp_writer expandableX false
        dashboard_set_property $dash_path grp_writer expandableY false
        dashboard_set_property $dash_path grp_writer itemsPerRow 4
        dashboard_set_property $dash_path grp_writer title "Writer"

        dashboard_add          $dash_path grp_reader group grp_fct
        dashboard_set_property $dash_path grp_reader expandableX false
        dashboard_set_property $dash_path grp_reader expandableY false
        dashboard_set_property $dash_path grp_reader itemsPerRow 1
        dashboard_set_property $dash_path grp_reader title "Reader"


        #
        # widgets
        #

        dashboard_add          $dash_path dash_dev_base text grp_device 
        dashboard_set_property $dash_path dash_dev_base label "base" 
        dashboard_set_property $dash_path dash_dev_base expandableX false
        dashboard_set_property $dash_path dash_dev_base expandableY false
        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
        dashboard_set_property $dash_path dash_dev_base editable true
        dashboard_set_property $dash_path dash_dev_base htmlCapable false
        dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_vsc::VSC_CSR_DEV_BASE} ]

        dashboard_add          $dash_path dash_sfctl_base text grp_device 
        dashboard_set_property $dash_path dash_sfctl_base label "sfctl" 
        dashboard_set_property $dash_path dash_sfctl_base expandableX false
        dashboard_set_property $dash_path dash_sfctl_base expandableY false
        dashboard_set_property $dash_path dash_sfctl_base preferredWidth 80
        dashboard_set_property $dash_path dash_sfctl_base editable false
        dashboard_set_property $dash_path dash_sfctl_base htmlCapable false
        dashboard_set_property $dash_path dash_sfctl_base text [ format 0x%x ${::cgx_vsc::VSC_CSR_DEV_BASE_SFCTRL} ]

        dashboard_add          $dash_path dash_dev_init button grp_device 
        dashboard_set_property $dash_path dash_dev_init enabled true
        dashboard_set_property $dash_path dash_dev_init text "Init"
        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_vsc::dash_init_device }  

        dashboard_add          $dash_path dash_dev_dump button grp_device 
        dashboard_set_property $dash_path dash_dev_dump enabled true
        dashboard_set_property $dash_path dash_dev_dump text "Dump"
        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_vsc::dash_dump_device }  

        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_version enabled true
        dashboard_set_property $dash_path dash_dev_version text "Version"
        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_vsc::get_version }  

        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_caps enabled true
        dashboard_set_property $dash_path dash_dev_caps text "Caps"
        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_vsc::dash_get_caps }  
        
        dashboard_add          $dash_path dash_cfg_run checkBox grp_cfg_param0 
        dashboard_set_property $dash_path dash_cfg_run enabled true
        dashboard_set_property $dash_path dash_cfg_run text "Run"

        dashboard_add          $dash_path dash_frame_count text grp_cfg_param0
        dashboard_set_property $dash_path dash_frame_count label "frame count" 
        dashboard_set_property $dash_path dash_frame_count expandableX false
        dashboard_set_property $dash_path dash_frame_count expandableY false
        dashboard_set_property $dash_path dash_frame_count preferredWidth 50
        dashboard_set_property $dash_path dash_frame_count editable false
        dashboard_set_property $dash_path dash_frame_count htmlCapable false
        dashboard_set_property $dash_path dash_frame_count text "0"

        dashboard_add          $dash_path dash_cfg_ie_frame_completed checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_frame_completed text "frame completed"

        dashboard_add          $dash_path dash_cfg_ie_video_changed checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_video_changed text "video changed"

        dashboard_add          $dash_path dash_cfg_set button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_set enabled true
        dashboard_set_property $dash_path dash_cfg_set text "Set"
        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_vsc::dash_set_config }  

        dashboard_add          $dash_path dash_cfg_readback button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_readback enabled true
        dashboard_set_property $dash_path dash_cfg_readback text "Readback"
        dashboard_set_property $dash_path dash_cfg_readback onClick { ::cgx_vsc::dash_get_config }  

 
        #
        # monitor /  widgets
        #

        dashboard_add          $dash_path dash_sts_get button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_get enabled true
        dashboard_set_property $dash_path dash_sts_get text "Get"
        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_vsc::dash_get_status }  

        dashboard_add          $dash_path dash_sts_clear button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_clear text "Clear"
        dashboard_set_property $dash_path dash_sts_clear onClick { ::cgx_vsc::dash_clr_status }  

        dashboard_add          $dash_path dash_sts_run button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_run text "Run"
        dashboard_set_property $dash_path dash_sts_run enabled false
        dashboard_set_property $dash_path dash_sts_run onClick { ::cgx_vsc::dash_run_status }  
      
        dashboard_add          $dash_path dash_sts_busy checkBox grp_sts_param
        dashboard_set_property $dash_path dash_sts_busy text "busy"

        dashboard_add          $dash_path dash_sts_irq led grp_sts_param
        dashboard_set_property $dash_path dash_sts_irq text "irq"
        dashboard_set_property $dash_path dash_sts_irq color "black"

        dashboard_add          $dash_path dash_sts_ia_frame_completed checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_frame_completed text "frame completed"

        dashboard_add          $dash_path dash_sts_ia_video_changed checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_video_changed text "video changed"

        dashboard_add          $dash_path dash_writer_width text grp_writer 
        dashboard_set_property $dash_path dash_writer_width label "width" 
        dashboard_set_property $dash_path dash_writer_width expandableX false
        dashboard_set_property $dash_path dash_writer_width expandableY false
        dashboard_set_property $dash_path dash_writer_width preferredWidth 50
        dashboard_set_property $dash_path dash_writer_width editable false
        dashboard_set_property $dash_path dash_writer_width htmlCapable false
        dashboard_set_property $dash_path dash_writer_width text "0"

        dashboard_add          $dash_path dash_writer_height text grp_writer 
        dashboard_set_property $dash_path dash_writer_height label "height" 
        dashboard_set_property $dash_path dash_writer_height expandableX false
        dashboard_set_property $dash_path dash_writer_height expandableY false
        dashboard_set_property $dash_path dash_writer_height preferredWidth 50
        dashboard_set_property $dash_path dash_writer_height editable false
        dashboard_set_property $dash_path dash_writer_height htmlCapable false
        dashboard_set_property $dash_path dash_writer_height text "0"

        dashboard_add          $dash_path dash_vout_width text grp_reader 
        dashboard_set_property $dash_path dash_vout_width label "width" 
        dashboard_set_property $dash_path dash_vout_width expandableX false
        dashboard_set_property $dash_path dash_vout_width expandableY false
        dashboard_set_property $dash_path dash_vout_width preferredWidth 50
        dashboard_set_property $dash_path dash_vout_width editable true
        dashboard_set_property $dash_path dash_vout_width htmlCapable false
        dashboard_set_property $dash_path dash_vout_width text "0"

        dashboard_add          $dash_path dash_vout_height text grp_reader 
        dashboard_set_property $dash_path dash_vout_height label "height" 
        dashboard_set_property $dash_path dash_vout_height expandableX false
        dashboard_set_property $dash_path dash_vout_height expandableY false
        dashboard_set_property $dash_path dash_vout_height preferredWidth 50
        dashboard_set_property $dash_path dash_vout_height editable true
        dashboard_set_property $dash_path dash_vout_height htmlCapable false
        dashboard_set_property $dash_path dash_vout_height text "0"
          
        dashboard_add          $dash_path dash_cfg_mirror checkBox grp_rotate         
        dashboard_set_property $dash_path dash_cfg_mirror text "Mirror"
        dashboard_set_property $dash_path dash_cfg_mirror enabled true
     
        dashboard_add          $dash_path dash_cfg_flip_h checkBox grp_rotate         
        dashboard_set_property $dash_path dash_cfg_flip_h text "Horizontal flip"
        dashboard_set_property $dash_path dash_cfg_flip_h enabled true
     
        dashboard_add          $dash_path dash_cfg_flip_v checkBox grp_rotate         
        dashboard_set_property $dash_path dash_cfg_flip_v text "Vertical flip"
        dashboard_set_property $dash_path dash_cfg_flip_v enabled true
     	      
        after idle ::cgx_vsc::dash_update

        puts stdout " ${::cgx_vsc::IPCORE_LABEL} dashBoard end"

        return -code ok
    }


    proc dash_init_device {} {
    	
        set ::cgx_vsc::debug 1

        cgx_vsc::init -1  
        cgx_vsc::dash_get_config
        cgx_vsc::dash_get_status

        set ::cgx_vsc::debug 0
    }


    proc dash_dump_device {} {

        cgx_vsc::dump_all  
      # cgx_vsc::dump_surface 

    }


    proc dash_get_caps {} {
    	
        set ::cgx_vsc::debug 1

        cgx_vsc::get_caps   

        set ::cgx_vsc::debug 0
    }


    proc dash_set_config {} {

        set ::cgx_vsc::debug 1
       
        cgx_vsc::set_config -1 -1   
        cgx_vsc::set_interrupt -1  
        cgx_vsc::video_set_output -1 -1  
       
        set ::cgx_vsc::debug 0
        
    }


    proc dash_get_config {} {

        set ::cgx_vsc::debug 1

        cgx_vsc::get_config    
        cgx_vsc::get_interrupt    
        cgx_vsc::video_get_output  

        set ::cgx_vsc::debug 0

    }
    
   
    proc dash_get_status {} {

        set ::cgx_vsc::debug 1

        cgx_vsc::get_status          
        cgx_vsc::video_get_writer 1

        set ::cgx_vsc::debug 0

    }


    proc dash_clr_status {} {

        set ::cgx_vsc::debug 1

        cgx_vsc::clr_status          

        set ::cgx_vsc::debug 0
        
    }


    proc dash_run_status {} {

    # TODO

    }

   
    proc dash_update {} {

        if { ${::cgx_vsc::dashboardActive} > 0 } {
     
            if { ${::cgx_vsc::initialized} > 0 } {

                ::cgx_vsc::dash_get_status

              # after 300 ::cgx_vsc::dash_update

            }
        }
    }
}


 