
# surface_create          { sfc_name base color width height nb_buffer user_pixel_depth user_stride user_stride_buffer }
# surface_get_color_depth { sfc_color_format }
# surface_get_desc        { sfc_desc sfc_name clut_start_idx ptr_next }
# surface_set_desc        { sfc_desc sfc_name clut_start_idx ptr_next }
#TODO
# surface_get_color_sw    { sfc_color_format_hw }   
# surface_get_color_hw    { sfc_color_format_sw }  

 
namespace eval cgx_surface {

    ############## SYS###############

    variable surface  

 
    ############## HAL###############

  variable DESC_REG_ID         0
  variable DESC_REG_ADDR8_L    1
  variable DESC_REG_ADDR8_H    2
  variable DESC_REG_VSTRIDE8   3
  variable DESC_REG_HSTRIDE8   4
  variable DESC_REG_SIZE       5
  variable DESC_REG_NUMBER     6
                                              
     
  # /* DESC_REG_ID */
    variable DESC_ID_PIXCOLOR_MSK     0xFF   
    variable DESC_ID_PIXCOLOR_OFST    0      
   #variable DESC_ID_PIXDEPTH_MSK     0xFF  
   #variable DESC_ID_PIXDEPTH_OFST    0    
    variable DESC_ID_PIXRAW_MSK       0x100 
    variable DESC_ID_PIXRAW_OFST      8 
   #variable DESC_ID_CRITICAL_MSK     0x200 
   #variable DESC_ID_CRITICAL_OFST    9 
    variable DESC_ID_PTR_COUNT_MSK    0xFF0000   # = buffer number - 1 
    variable DESC_ID_PTR_COUNT_OFST   16      
    variable DESC_ID_PTR_NEXT_MSK     0xFF000000   
    variable DESC_ID_PTR_NEXT_OFST    24           
  
   
  # /* DESC_REG_ADDR8_L */
    variable DESC_ADDR_BASE_L_MSK    0xFFFFFFFF 
    variable DESC_ADDR_BASE_L_OFST   0 
  
  
  # /* DESC_REG_ADDR8_H */
    variable DESC_ADDR_BASE_H_MSK    0xFFFFFFFF 
    variable DESC_ADDR_BASE_H_OFST   0 
  
  
  # /* DESC_REG_VSTRIDE8 */
    variable DESC_VSTRIDE_MSK    0xFFFFFFFF 
    variable DESC_VSTRIDE_OFST   0 
  
  
  # /* DESC_REG_HSTRIDE8 */
    variable DESC_HSTRIDE_MSK           0x0000FFFF  
    variable DESC_HSTRIDE_OFST          0           
  # variable DESC_CLUT_START_IDX_MSK    0xFFFF0000  
  # variable DESC_CLUT_START_IDX_OFST   16 
  
  
  # /* DESC_REG_SIZE */
    variable DESC_WIDTH_MSK    0x0000FFFF 
    variable DESC_WIDTH_OFST   0          
    variable DESC_HEIGHT_MSK   0xFFFF0000 
    variable DESC_HEIGHT_OFST  16 




    variable DEF_PIXCOLOR_XRGB_8888      [ expr int(0<<6)  +  0]
    variable DEF_PIXCOLOR_ARGB_8888      [ expr int(0<<6)  +  1]
    variable DEF_PIXCOLOR_ARGB_8888_PRE  [ expr int(0<<6)  +  2]
    variable DEF_PIXCOLOR_RGB_888        [ expr int(0<<6)  +  3]
    variable DEF_PIXCOLOR_RGB_565        [ expr int(0<<6)  +  4]
    variable DEF_PIXCOLOR_ARGB_1555      [ expr int(0<<6)  +  5]
    variable DEF_PIXCOLOR_ARGB_4444      [ expr int(0<<6)  +  6]
    variable DEF_PIXCOLOR_AL_88          [ expr int(0<<6)  +  7]
    variable DEF_PIXCOLOR_L_8            [ expr int(0<<6)  +  8]
    variable DEF_PIXCOLOR_L_4            [ expr int(0<<6)  +  9]
    variable DEF_PIXCOLOR_L_2            [ expr int(0<<6)  + 10]
    variable DEF_PIXCOLOR_L_1            [ expr int(0<<6)  + 11]
    variable DEF_PIXCOLOR_A_8            [ expr int(0<<6)  + 12]
    variable DEF_PIXCOLOR_A_4            [ expr int(0<<6)  + 13]
    variable DEF_PIXCOLOR_A_2            [ expr int(0<<6)  + 14]
    variable DEF_PIXCOLOR_A_1            [ expr int(0<<6)  + 15]                                                     
    variable DEF_PIXCOLOR_APAL_88        [ expr int(0<<6)  + 16]
    variable DEF_PIXCOLOR_PAL_8          [ expr int(0<<6)  + 17]
    variable DEF_PIXCOLOR_PAL_4          [ expr int(0<<6)  + 18]
    variable DEF_PIXCOLOR_PAL_2          [ expr int(0<<6)  + 19]
    variable DEF_PIXCOLOR_PAL_1          [ expr int(0<<6)  + 20]
                                                     
    variable DEF_PIXCOLOR_UYVY           [ expr int(0<<6)  + 32]
                                                     
    # # /* {A,X}BGR channel ordering    (base=1*64] */ 
    variable DEF_PIXCOLOR_XBGR_8888      [ expr int(1<<6)  +  0]
    variable DEF_PIXCOLOR_ABGR_8888      [ expr int(1<<6)  +  1]
    variable DEF_PIXCOLOR_ABGR_8888_PRE  [ expr int(1<<6)  +  2]
    variable DEF_PIXCOLOR_BGR_888        [ expr int(1<<6)  +  3]
    variable DEF_PIXCOLOR_BGR_565        [ expr int(1<<6)  +  4]
    variable DEF_PIXCOLOR_ABGR_1555      [ expr int(1<<6)  +  5]
    variable DEF_PIXCOLOR_ABGR_4444      [ expr int(1<<6)  +  6]
                                                     
    # # /* RGB{A,X} channel ordering    (base=2*64] */ 
    variable DEF_PIXCOLOR_RGBX_8888      [ expr int(2<<6)  +  0]
    variable DEF_PIXCOLOR_RGBA_8888      [ expr int(2<<6)  +  1]
    variable DEF_PIXCOLOR_RGBA_8888_PRE  [ expr int(2<<6)  +  2]
                                                     
    variable DEF_PIXCOLOR_RGBA_5551      [ expr int(2<<6)  +  5]
    variable DEF_PIXCOLOR_RGBA_4444      [ expr int(2<<6)  +  6]
                                                     
    # # /* BGR{A,X} channel ordering    (base=3*64] */ 
    variable DEF_PIXCOLOR_BGRX_8888      [ expr int(3<<6)  +  0]
    variable DEF_PIXCOLOR_BGRA_8888      [ expr int(3<<6)  +  1]
    variable DEF_PIXCOLOR_BGRA_8888_PRE  [ expr int(3<<6)  +  2]
                                                     
    variable DEF_PIXCOLOR_BGRA_5551      [ expr int(3<<6)  +  5]
    variable DEF_PIXCOLOR_BGRA_4444      [ expr int(3<<6)  +  6]
    

    variable DEF_PIXCOLOR_TYPE_MSK       0x3F
    variable DEF_PIXCOLOR_TYPE_OFST      0
    
    variable DEF_PIXCOLOR_ORDER_MSK      0xC0
    variable DEF_PIXCOLOR_ORDER_OFST     6
    
    # # /* ORDER field values */
    variable DEF_PIXCOLOR_ORDER_ARGB     0
    variable DEF_PIXCOLOR_ORDER_ABGR     1
    variable DEF_PIXCOLOR_ORDER_RGBA     2
    variable DEF_PIXCOLOR_ORDER_BGRA     3
    variable DEF_PIXCOLOR_ORDER_NUMBER   4



    #--------------------------private functions ------------------------------

    proc ATH_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_surface::$field_name\_REG 
            set str_field_msk   ::cgx_surface::$field_name\_MSK 
            set str_field_ofst  ::cgx_surface::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc ATH_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_surface::$field_name\_MSK 
        set str_field_ofst ::cgx_surface::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

     
    #--------------------------public functions ------------------------------


  
    proc surface_get_color_depth { sfc_color_format } { 
 
        set color_type [ expr ($sfc_color_format & $::cgx_surface::DEF_PIXCOLOR_TYPE_MSK) >> $::cgx_surface::DEF_PIXCOLOR_TYPE_OFST ]
        
      # puts "color_type = $color_type"
 
              if { $color_type == ${::cgx_surface::DEF_PIXCOLOR_XRGB_8888}     } { set color_depth 32                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_ARGB_8888}     } { set color_depth 32                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_ARGB_8888_PRE} } { set color_depth 32
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_RGB_888}       } { set color_depth 24
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_RGB_565}       } { set color_depth 16                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_ARGB_1555}     } { set color_depth 16                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_ARGB_4444}     } { set color_depth 16                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_AL_88}         } { set color_depth 16                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_L_8}           } { set color_depth  8                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_L_4}           } { set color_depth  4                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_L_2}           } { set color_depth  2                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_L_1}           } { set color_depth  1                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_A_8}           } { set color_depth  8                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_A_4}           } { set color_depth  4                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_A_2}           } { set color_depth  2                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_A_1}           } { set color_depth  1                                                                  
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_APAL_88}       } { set color_depth 16                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_PAL_8}         } { set color_depth  8                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_PAL_4}         } { set color_depth  4                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_PAL_2}         } { set color_depth  2                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_PAL_1}         } { set color_depth  1                              
        } elseif { $color_type == ${::cgx_surface::DEF_PIXCOLOR_UYVY}          } { set color_depth 32    
        } else                                                                   { set color_depth -1 }  
 
        return $color_depth
    }


    proc surface_set_desc { sfc_desc sfc_name clut_start_idx ptr_next } {

        # create a local reference for the array
        upvar $sfc_desc desc
        
        set base          $::cgx_surface::surface($sfc_name,base);                                                      
        set color         $::cgx_surface::surface($sfc_name,color);                                                     
        set color_depth   $::cgx_surface::surface($sfc_name,color_depth);                                                     
        set width         $::cgx_surface::surface($sfc_name,width);                                                     
        set height        $::cgx_surface::surface($sfc_name,height);                                                    
        set stride        $::cgx_surface::surface($sfc_name,stride);                                                    
        set nb_buffer     $::cgx_surface::surface($sfc_name,nb_buffer);                                                 
        set stride_buffer $::cgx_surface::surface($sfc_name,stride_buffer);                                             
    #   set critical      $::cgx_surface::surface($sfc_name,critical);                                             


        if {$color < 0} {
            set desc_pixraw 1
            set desc_pixcolor $color_depth
        } else {
            set desc_pixraw 0
            # /* set the hardware color_format */
            set desc_pixcolor $color
        }
 
        set reg 0            
        set reg [ ATH_SET_FIELD $reg DESC_ID_PIXCOLOR      $desc_pixcolor         ]
        set reg [ ATH_SET_FIELD $reg DESC_ID_PIXRAW        $desc_pixraw           ] 
    #   set reg [ ATH_SET_FIELD $reg DESC_ID_CRITICAL      $critical              ] 
        set reg [ ATH_SET_FIELD $reg DESC_ID_PTR_NEXT      $ptr_next              ]
        set reg [ ATH_SET_FIELD $reg DESC_ID_PTR_COUNT     [ expr $nb_buffer - 1] ]


        set desc(${::cgx_surface::DESC_REG_ID}) $reg   
        
        # /* set the image size */
        set reg 0            
        set reg [ ATH_SET_FIELD $reg DESC_WIDTH  $width  ]
        set reg [ ATH_SET_FIELD $reg DESC_HEIGHT $height ]
        set desc(${::cgx_surface::DESC_REG_SIZE}) $reg   
        
        # /* set the horizontal stride (=row stride) */
        set reg 0            
        set reg [ ATH_SET_FIELD $reg DESC_HSTRIDE        $stride         ]
    #   set reg [ ATH_SET_FIELD $reg DESC_CLUT_START_IDX $clut_start_idx ]
        set desc(${::cgx_surface::DESC_REG_HSTRIDE8}) $reg   
        
        # /* set the vertical stride (=buffer stride) */
        set reg 0            
        set reg [ ATH_SET_FIELD $reg DESC_VSTRIDE $stride_buffer ]
        set desc(${::cgx_surface::DESC_REG_VSTRIDE8}) $reg   
        
        # /* set the memory base address */
        set desc(${::cgx_surface::DESC_REG_ADDR8_L}) $base;
        set desc(${::cgx_surface::DESC_REG_ADDR8_H}) 0;
        
        return 0
  
    }


    proc surface_get_desc { sfc_desc sfc_name clut_start_idx ptr_next } {

        # create a local reference for the array
        upvar $sfc_desc       desc
        upvar $clut_start_idx var_clut_start_idx
        upvar $ptr_next       var_ptr_next
        
        set reg $desc(${::cgx_surface::DESC_REG_ID})            
        set desc_pixcolor [ ATH_GET_FIELD $reg DESC_ID_PIXCOLOR     ]
        set desc_pixraw   [ ATH_GET_FIELD $reg DESC_ID_PIXRAW       ] 
    #   set critical      [ ATH_GET_FIELD $reg DESC_ID_CRITICAL     ] 
        set var_ptr_next  [ ATH_GET_FIELD $reg DESC_ID_PTR_NEXT     ]
        set ptr_count     [ ATH_GET_FIELD $reg DESC_ID_PTR_COUNT    ] 
        set nb_buffer     [ expr $ptr_count + 1 ]

        if {$desc_pixraw == 1} {
            set color -1
            set color_depth $desc_pixcolor
        } else {
            set color $desc_pixcolor
            # not used
            set color_depth [ surface_get_color_depth $color ]
        }

    
        # /* set the image size */
        set reg $desc(${::cgx_surface::DESC_REG_SIZE})             
        set width  [ ATH_GET_FIELD $reg DESC_WIDTH  ]
        set height [ ATH_GET_FIELD $reg DESC_HEIGHT ]
      
          
        # /* set the horizontal stride (=row stride) */
        set reg $desc(${::cgx_surface::DESC_REG_HSTRIDE8})               
        set stride         [ ATH_GET_FIELD $reg DESC_HSTRIDE        ]
        set var_clut_start_idx 0; #[ ATH_GET_FIELD $reg DESC_CLUT_START_IDX ]
    
    
        # /* set the vertical stride (=buffer stride) */
        set reg $desc(${::cgx_surface::DESC_REG_VSTRIDE8})               
        set stride_buffer [ ATH_GET_FIELD $reg DESC_VSTRIDE ]
 
 
        # /* set the memory base address */
        set base $desc(${::cgx_surface::DESC_REG_ADDR8_L}) 
 
        set ::cgx_surface::surface($sfc_name,base)          $base                                                      
        set ::cgx_surface::surface($sfc_name,color)         $color                                                     
        set ::cgx_surface::surface($sfc_name,color_depth)   $color_depth                                                     
        set ::cgx_surface::surface($sfc_name,width)         $width                                                     
        set ::cgx_surface::surface($sfc_name,height)        $height                                                    
        set ::cgx_surface::surface($sfc_name,stride)        $stride                                                    
        set ::cgx_surface::surface($sfc_name,nb_buffer)     $nb_buffer                                                 
        set ::cgx_surface::surface($sfc_name,stride_buffer) $stride_buffer  
    #   set ::cgx_surface::surface($sfc_name,critical)      $critical  
                                                   
    }


  # proc surface_get_datasize { sfc_name base color width height nb_buffer stride stride_buffer } {
  #
  #     set base          $::cgx_surface::surface($sfc_name,base);                                                      
  #     set color         $::cgx_surface::surface($sfc_name,color);                                                     
  #     set width         $::cgx_surface::surface($sfc_name,width);                                                     
  #     set height        $::cgx_surface::surface($sfc_name,height);                                                    
  #     set stride        $::cgx_surface::surface($sfc_name,stride);                                                    
  #     set nb_buffer     $::cgx_surface::surface($sfc_name,nb_buffer);                                                 
  #     set stride_buffer $::cgx_surface::surface($sfc_name,stride_buffer);                                             
  #
  #     set base_buffer [ expr $base + $buffer_index * $stride_buffer ]
  #
  #     return [ expr $stride  ] 
  # }

    # <color>         -1 use raw data with <user_pixel_depth>  
    # <stride>        -1 automatically computes hstride
    # <stride_buffer> -1 automatically computes vstride
    proc surface_create { sfc_name base color width height nb_buffer user_pixel_depth user_stride user_stride_buffer } {

        set ::cgx_surface::surface($sfc_name,base)      $base                                                                                                                                                       
        set ::cgx_surface::surface($sfc_name,color)     $color                                                                                                                                                      
        set ::cgx_surface::surface($sfc_name,width)     $width                                                                                                                                                      
        set ::cgx_surface::surface($sfc_name,height)    $height                                                                                                                                                      
        set ::cgx_surface::surface($sfc_name,nb_buffer) $nb_buffer                                                                                                                                                      
    #   set ::cgx_surface::surface($sfc_name,critical)  0                                                                                                                                                      

        if {$color < 0} {
            set color_depth $user_pixel_depth 
        } else {
            set color_depth [ surface_get_color_depth $color ]
        }

        set stride_min [ expr int(ceil(($color_depth * $width) / 8.0)) ] 

        set stride $stride_min 

        if {$user_stride >= 0} {
            if {$user_stride < $stride_min} {
            	  puts "ERROR: incorrect surface stride"  
            } else {
                set stride $user_stride 
            }    
        }

        set stride_buffer_min [ expr int($stride * $height) ] 

        set stride_buffer $stride_buffer_min        

        if {$user_stride_buffer >= 0} {
            if {$user_stride_buffer < $stride_buffer_min} {
            	  puts "ERROR: incorrect surface stride buffer"  
            } else {
                set stride_buffer $user_stride_buffer 
            }    
        }

        set ::cgx_surface::surface($sfc_name,color_depth)   $color_depth                                                                                                                                                      
        set ::cgx_surface::surface($sfc_name,stride)        $stride                                                                                                                                                      
        set ::cgx_surface::surface($sfc_name,stride_buffer) $stride_buffer                                                                                                                                                       

    #   puts "                                                                          "
    #   puts " Surface $sfc_name created:                                               "
    #   puts "     base         =$::cgx_surface::surface($sfc_name,base)           "
    #   puts "     color        =$::cgx_surface::surface($sfc_name,color)          "
    #   puts "     color_depth  =$::cgx_surface::surface($sfc_name,color_depth)    "
    #   puts "     width        =$::cgx_surface::surface($sfc_name,width)          "
    #   puts "     height       =$::cgx_surface::surface($sfc_name,height)         "
    #   puts "     nb_buffer    =$::cgx_surface::surface($sfc_name,nb_buffer)      "
    #   puts "     stride       =$::cgx_surface::surface($sfc_name,stride)         "
    #   puts "     stride_buffer=$::cgx_surface::surface($sfc_name,stride_buffer)  "
    #   puts " "                                                                                                                                                                

        set clut_start_idx -1
        set ptr_next -1 

        array set desc {} 
        surface_set_desc desc $sfc_name $clut_start_idx $ptr_next
        
        for {set i 0} { $i<${::cgx_surface::DESC_REG_NUMBER} } {incr i} {
    #       puts $desc($i)
        }

        surface_get_desc desc $sfc_name clut_start_idx ptr_next

    #   puts "                                                                      " 
    #   puts " Surface $sfc_name from desc:                                         "
    #   puts " base           =$::cgx_surface::surface($sfc_name,base)         "
    #   puts " color          =$::cgx_surface::surface($sfc_name,color)        "
    #   puts " width          =$::cgx_surface::surface($sfc_name,width)        "
    #   puts " height         =$::cgx_surface::surface($sfc_name,height)       "
    #   puts " nb_buffer      =$::cgx_surface::surface($sfc_name,nb_buffer)    "
    #   puts " stride         =$::cgx_surface::surface($sfc_name,stride)       "
    #   puts " stride_buffer  =$::cgx_surface::surface($sfc_name,stride_buffer)"
    #   puts "                                                                      "
    #   puts " clut_start_idx =$clut_start_idx                                      "
    #   puts " ptr_next       =$ptr_next                                            "
 
    }
 
}

