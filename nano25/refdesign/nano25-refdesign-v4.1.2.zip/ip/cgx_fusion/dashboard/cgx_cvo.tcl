
# cgx_cvo::init          { dev_base }
# cgx_cvo::get_version   { }
# cgx_cvo::get_caps      { }
# cgx_cvo::set_config    { run }
# cgx_cvo::get_config    { }
# cgx_cvo::set_interrupt { ie_bitfield }
# cgx_cvo::get_interrupt { } 
# cgx_cvo::get_status    { }
# cgx_cvo::clr_status    { }
# cgx_cvo::set_timings   { hres vres hfpw hsw hbpw vfpw vsw vbpw hpol vpol }
# cgx_cvo::get_timings   { }
# cgx_cvo::dump          { }
# cgx_cvo::dashBoard     { }


namespace eval cgx_cvo {

    variable IPCORE_PRODUCT 66; # = 0x42 	                                                                                          
    variable IPCORE_VERSION ${::cgx_fusion::IPCORE_VERSION}                                                                                         
    variable IPCORE_LABEL "CV0"

    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    # debug mode
    # 0 => console 
    # 1 => dashboard (+console) 
    variable debug 0


    #-------------------------- SYS------------------------------

    variable CVO_CSR_DEV_BASE  0x00000000
    variable initialized 0

        
    #-------------------------- HAL------------------------------
       
    variable IMT_CVO_REG_VERSION       0
    variable IMT_CVO_REG_CAPS          1
    variable IMT_CVO_REG_INTERRUPT     2
    variable IMT_CVO_REG_CONTROL       3
    variable IMT_CVO_REG_STATUS        4
    variable IMT_CVO_REG_FRAME_COUNT   5
    variable IMT_CVO_REG_HRES          6
    variable IMT_CVO_REG_HFPW          7
    variable IMT_CVO_REG_HSW           8
    variable IMT_CVO_REG_HBPW          9
    variable IMT_CVO_REG_VRES         10
    variable IMT_CVO_REG_VFPW         11
    variable IMT_CVO_REG_VSW          12
    variable IMT_CVO_REG_VBPW         13
    variable IMT_CVO_REG_MISC         14
    variable IMT_CVO_REG_NUMBER       15


    # /* IMT_CVO_REG_VERSION fields */
    
    variable IMT_CVO_VERSION_ID_MSK     0xFF      
    variable IMT_CVO_VERSION_ID_OFST    0         
    variable IMT_CVO_VERSION_BUILD_MSK  0xFF00    
    variable IMT_CVO_VERSION_BUILD_OFST 8         
    variable IMT_CVO_VERSION_MINOR_MSK  0xFF0000   
    variable IMT_CVO_VERSION_MINOR_OFST 16        
    variable IMT_CVO_VERSION_MAJOR_MSK  0x0F000000   
    variable IMT_CVO_VERSION_MAJOR_OFST 24        

 
    # /* IMT_CVO_REG_CAPS fields */


    # /* IMT_CVO_REG_INTERRUPT fields */

        variable IMT_CVO_INTERRUPT_ENABLE_MSK  0xFF  
		    variable IMT_CVO_INTERRUPT_ENABLE_OFST 0
        
          # /* interrupt bits                                                  */
          # /* to be used for enable bits (IMT_CVO_INTERRUPT_ENABLE_MSK) and   */
          # /*                active bits (IMT_CVO_STATUS_IRQ_ACTIVE_MSK)      */  
          variable IMT_CVO_IRQ_BIT_UNDERFLOW_MSK  0x1; # /* pixel fifo underflow */                                                                                                
          variable IMT_CVO_IRQ_BIT_UNDERFLOW_OFST 0                                                      
          variable IMT_CVO_IRQ_BIT_LOCKED_MSK     0x2; # /* clocked active resolution mismatches the stream active resolution */                                                                  
          variable IMT_CVO_IRQ_BIT_LOCKED_OFST    1                                                      

   
    # /* IMT_CVO_REG_CONTROL fields */
  		
	      variable IMT_CVO_CONTROL_RUN_MSK    0x1  
		    variable IMT_CVO_CONTROL_RUN_OFST   0
    
   
    # /* IMT_CVO_REG_STATUS fields */

        variable IMT_CVO_STATUS_BUSY_MSK        0x1
        variable IMT_CVO_STATUS_BUSY_OFST       0
        variable IMT_CVO_STATUS_IRQ_MSK         0x2
        variable IMT_CVO_STATUS_IRQ_OFST        1
        variable IMT_CVO_STATUS_LOCKED_MSK      0x100; # /* 0/1 = unlocked/locked */
        variable IMT_CVO_STATUS_LOCKED_OFST     8
        variable IMT_CVO_STATUS_IRQ_ACTIVE_MSK  0xFF0000  
		    variable IMT_CVO_STATUS_IRQ_ACTIVE_OFST 16
  
  
    # /* IMT_CVO_REG_MISC fields */

        variable IMT_CVO_MISC_HPOL_MSK   0x1; # /* horizontal sync polarity. 0/1 = active low/high */
        variable IMT_CVO_MISC_HPOL_OFST  0
        variable IMT_CVO_MISC_VPOL_MSK   0x2; # /*   vertical sync polarity. 0/1 = active low/high */
        variable IMT_CVO_MISC_VPOL_OFST  1

 

    #/* IMT_CVO_REG_HRES...IMT_CVO_REG_VBPW  */
    #/* IMT_CVO_REG_FRAME_COUNT fields */
        variable IMT_CVO_VAL16_MSK  0xFFFF  
		    variable IMT_CVO_VAL16_OFST 0


       
    #--------------------------private functions ------------------------------

    proc ATH_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_cvo::$field_name\_REG 
            set str_field_msk   ::cgx_cvo::$field_name\_MSK 
            set str_field_ofst  ::cgx_cvo::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc ATH_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_cvo::$field_name\_MSK 
        set str_field_ofst ::cgx_cvo::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

     
    #--------------------------public functions ------------------------------

 
    proc init { dev_base } {

      # puts stdout "IMT CVO init:"

        if { ${::cgx_cvo::debug} == 1 } {
            set dash_path ${::cgx_cvo::dash_path} 
            set dev_base [ dashboard_get_property $dash_path dash_dev_base text ]
        } 
                        
        set ::cgx_cvo::CVO_CSR_DEV_BASE ${dev_base} 
        
        set dev_success [ ::cgx_cvo::get_version ];  
        
        if {${dev_success} == 1} {
            set ::cgx_cvo::initialized 1
        } else {
            set ::cgx_cvo::initialized 0
        } 

        if { ${::cgx_cvo::debug} == 1 } {
            set dash_path ${::cgx_cvo::dash_path} 
            dashboard_set_property $dash_path grp_csr   visible false
            if {${dev_success} == 1} {
                puts " ${::cgx_cvo::IPCORE_LABEL} init successfull "
                dashboard_set_property $dash_path grp_core  visible true
            } else {
            	  puts " ${::cgx_cvo::IPCORE_LABEL} ERROR: device init failure "
                dashboard_set_property $dash_path grp_core  visible false
            } 
        } 
    }
       


    proc get_version { } {
        
        set csr_base8 ${::cgx_cvo::CVO_CSR_DEV_BASE} 
        
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VERSION} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set v_id    [ ATH_GET_FIELD $reg IMT_CVO_VERSION_ID ] ;                              
        set v_build [ ATH_GET_FIELD $reg IMT_CVO_VERSION_BUILD ] ;                           
        set v_minor [ ATH_GET_FIELD $reg IMT_CVO_VERSION_MINOR ] ;                           
        set v_major [ ATH_GET_FIELD $reg IMT_CVO_VERSION_MAJOR ] ;                           
        set version $v_major.$v_minor                            

        if {$v_id == ${::cgx_cvo::IPCORE_PRODUCT} } {
          puts " ${::cgx_cvo::IPCORE_LABEL} detection successfull, core id = [ format 0x%x $v_id ] "
          puts " ${::cgx_cvo::IPCORE_LABEL} Version = $v_major.$v_minor, Build = $v_build"
          if { $version == ${::cgx_cvo::IPCORE_VERSION} } {
            set success 1
          } else {
            set success 0
            puts stdout " ${::cgx_cvo::IPCORE_LABEL} ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_cvo::IPCORE_VERSION} )"
            puts stdout "        please upgrade the dashboard version accordingly to the IP core "
          }
        } else {
          set success 0
          puts stdout " ${::cgx_cvo::IPCORE_LABEL} ERROR: device not detected at device base ${::cgx_cvo::CVO_CSR_DEV_BASE} "
          puts stdout "        core id = $v_id, reg = $reg "
          puts stdout "        please, set the right device base and press init again "
        }
        return $success

    }


    proc get_caps { } {
        
        set csr_base8 ${::cgx_cvo::CVO_CSR_DEV_BASE} 

        open_service master ${::boardInit::masterPath}        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_CAPS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

    #   set caps_is_reader                [ ATH_GET_FIELD $reg VSC_CSR_CAPS_IS_READER ] ; 
    #
	  #   puts "                                                                     "
    #   puts "  Capabilities:                                                      "
    #   puts "      caps_is_reader                = $caps_is_reader                "
    #   puts "                                                                     "                                                                                          

        if { ${::cgx_cvo::debug} == 1 } {

            set dash_path ${::cgx_cvo::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true
                                   
        }
    }

       
    proc set_config { run } {   

        if { ${::cgx_cvo::debug} == 1 } {
	          set dash_path ${::cgx_cvo::dash_path} 
	          set run 0 
            if { [ dashboard_get_property $dash_path dash_cfg_run checked ] == true } {
                set run 1
            } 
        }  

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_CONTROL} ] 0x1]; 
        set reg [ ATH_SET_FIELD $reg IMT_CVO_CONTROL_RUN $run ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_CONTROL} ] $reg

	      close_service master ${::boardInit::masterPath}
    }
    
      
    proc get_config { } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_CONTROL} ] 0x1]; 
        set cfg_run [ ATH_GET_FIELD $reg IMT_CVO_CONTROL_RUN ] ;                                                                

	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_cvo::debug} == 0 } {
            puts "                                 "
            puts "  config:                        "
            puts "      cfg_run = $cfg_run         "          
            puts "                                 "                                                                                                                                                                
        }
        if { ${::cgx_cvo::debug} == 1 } {
        	  set dash_path ${::cgx_cvo::dash_path} 
 
            if { $cfg_run == 1 } {
               dashboard_set_property $dash_path dash_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_run checked false  
            }        
        }
    }


    proc set_interrupt { ie_bitfield } {

        if { ${::cgx_cvo::debug} == 1 } {
	          set dash_path ${::cgx_cvo::dash_path} 
            set ie_bitfield 0
	          if { [ dashboard_get_property $dash_path dash_cfg_ie_underflow checked ] == true } {
                set ie_bitfield [ ATH_SET_FIELD $ie_bitfield IMT_CVO_IRQ_BIT_UNDERFLOW 1 ]
            } 
            if { [ dashboard_get_property $dash_path dash_cfg_ie_locked_out checked ] == true } {
                set ie_bitfield [ ATH_SET_FIELD $ie_bitfield IMT_CVO_IRQ_BIT_LOCKED 1 ]
            } 
        }   
        open_service master ${::boardInit::masterPath}
        set reg 0
        set reg [ ATH_SET_FIELD $reg IMT_CVO_INTERRUPT_ENABLE $ie_bitfield ]           
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_INTERRUPT} ] $reg
        close_service master ${::boardInit::masterPath}
    }
 

    proc get_interrupt { } {

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_INTERRUPT} ] 0x1]; 
        set ie_bitfield  [ ATH_GET_FIELD $reg IMT_CVO_INTERRUPT_ENABLE ] ;                                                                
	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_cvo::debug} == 0 } {
            puts "                                                            "
            puts "  interrupt:                                                "
            puts "         ie_bitfield = $ie_bitfield "      
            puts "                                                            "                                                                                                           
        }
        if { ${::cgx_cvo::debug} == 1 } {
        	  set dash_path ${::cgx_cvo::dash_path} 
 
            if { [ ATH_GET_FIELD $ie_bitfield IMT_CVO_IRQ_BIT_UNDERFLOW ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_underflow checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_underflow checked false
            }        
            if { [ ATH_GET_FIELD $ie_bitfield IMT_CVO_IRQ_BIT_LOCKED ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_locked_out checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_locked_out checked false
            }        
        }
    }


    # /* Sync. polarity. 0/1 = active low/high: */
    proc set_timings { hres vres hfpw hsw hbpw vfpw vsw vbpw hpol vpol } {

        if { ${::cgx_cvo::debug} == 1 } {
	          set dash_path ${::cgx_cvo::dash_path} 

            set hpol 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_hpol checked ] == true } {
                set hpol 1
            }
            set vpol 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_vpol checked ] == true } {
                set vpol 1
            }
            set hres [ dashboard_get_property $dash_path dash_cfg_vid_hres text ]
            set vres [ dashboard_get_property $dash_path dash_cfg_vid_vres text ]
            set hfpw [ dashboard_get_property $dash_path dash_cfg_vid_hfpw text ]
            set hsw  [ dashboard_get_property $dash_path dash_cfg_vid_hsw  text ]
            set hbpw [ dashboard_get_property $dash_path dash_cfg_vid_hbpw text ]
            set vfpw [ dashboard_get_property $dash_path dash_cfg_vid_vfpw text ]
            set vsw  [ dashboard_get_property $dash_path dash_cfg_vid_vsw  text ]
            set vbpw [ dashboard_get_property $dash_path dash_cfg_vid_vbpw text ]
        }  

        set cfg 0
        set cfg [ ATH_SET_FIELD $cfg IMT_CVO_MISC_HPOL $hpol ] 
        set cfg [ ATH_SET_FIELD $cfg IMT_CVO_MISC_VPOL $vpol ] 

        set csr_base8 ${::cgx_cvo::CVO_CSR_DEV_BASE}
        set reg 0
                 
        open_service master ${::boardInit::masterPath}
 
        # set H
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_HRES} ] $hres; #[ ATH_SET_FIELD $reg IMT_CVO_VAL16 $hres ]      
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_HFPW} ] $hfpw; #[ ATH_SET_FIELD $reg IMT_CVO_VAL16 $hfpw ]     
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_HSW}  ] $hsw ; #[ ATH_SET_FIELD $reg IMT_CVO_VAL16 $hsw  ] 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_HBPW} ] $hbpw; #[ ATH_SET_FIELD $reg IMT_CVO_VAL16 $hbpw ] 
        # set V                                                                                                                                                                  
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VRES} ] $vres; #[ ATH_SET_FIELD $reg IMT_CVO_VAL16 $vres ] 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VFPW} ] $vfpw; #[ ATH_SET_FIELD $reg IMT_CVO_VAL16 $vfpw ] 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VSW}  ] $vsw ; #[ ATH_SET_FIELD $reg IMT_CVO_VAL16 $vsw  ] 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VBPW} ] $vbpw; #[ ATH_SET_FIELD $reg IMT_CVO_VAL16 $vbpw ]                                                                                                                                             

        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_MISC} ] $cfg
 	      close_service master ${::boardInit::masterPath}    
 
    }
  

    proc get_timings { } {

        set csr_base8 ${::cgx_cvo::CVO_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_HRES}  ] 0x1]; 
        set hres [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VRES}  ] 0x1]; 
        set vres [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_HFPW}  ] 0x1]; 
        set hfpw [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_HSW}   ] 0x1]; 
        set hsw  [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_HBPW}  ] 0x1]; 
        set hbpw [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VFPW}  ] 0x1]; 
        set vfpw [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VSW}   ] 0x1]; 
        set vsw  [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_VBPW}  ] 0x1]; 
        set vbpw [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_cvo::IMT_CVO_REG_MISC}  ] 0x1]; 
        set hpol [ ATH_GET_FIELD $reg IMT_CVO_MISC_HPOL ] 
        set vpol [ ATH_GET_FIELD $reg IMT_CVO_MISC_VPOL ] 

	      close_service master ${::boardInit::masterPath}
                  
        if { ${::cgx_cvo::debug} == 0 } {
            puts "                   "
            puts " timings:          "
            puts "      hres = $hres "        
            puts "      vres = $vres "        
            puts "      hfpw = $hfpw "        
            puts "      hsw  = $hsw  "        
            puts "      hbpw = $hbpw "        
            puts "      vfpw = $vfpw "        
            puts "      vsw  = $vsw  "        
            puts "      vbpw = $vbpw "        
            puts "      hpol = $hpol "         
            puts "      vpol = $vpol "         
            puts "                   "                                                
        }                                                                                                                             
        if { ${::cgx_cvo::debug} == 1 } {
	          set dash_path ${::cgx_cvo::dash_path} 
            dashboard_set_property $dash_path dash_cfg_vid_hres text $hres
            dashboard_set_property $dash_path dash_cfg_vid_vres text $vres
            dashboard_set_property $dash_path dash_cfg_vid_hfpw text $hfpw
            dashboard_set_property $dash_path dash_cfg_vid_hsw  text $hsw 
            dashboard_set_property $dash_path dash_cfg_vid_hbpw text $hbpw
            dashboard_set_property $dash_path dash_cfg_vid_vfpw text $vfpw
            dashboard_set_property $dash_path dash_cfg_vid_vsw  text $vsw 
            dashboard_set_property $dash_path dash_cfg_vid_vbpw text $vbpw
            if { ${hpol} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_hpol checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_hpol checked false  
            } 
            if { ${vpol} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_vpol checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_vpol checked false  
            }            
        }
    }



    proc get_status {  } {

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_STATUS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set sts_busy       [ ATH_GET_FIELD $reg IMT_CVO_STATUS_BUSY ] ;                                                                
        set sts_irq        [ ATH_GET_FIELD $reg IMT_CVO_STATUS_IRQ  ] ;                                                                
        set sts_locked_out [ ATH_GET_FIELD $reg IMT_CVO_STATUS_LOCKED ] ;                                                                
        set sts_irqfield   [ ATH_GET_FIELD $reg IMT_CVO_STATUS_IRQ_ACTIVE ] ;                                                                

        set sts_ia_underflow  [ ATH_GET_FIELD $sts_irqfield IMT_CVO_IRQ_BIT_UNDERFLOW  ];                                                                
        set sts_ia_locked_out [ ATH_GET_FIELD $sts_irqfield IMT_CVO_IRQ_BIT_LOCKED ];                                                                

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_FRAME_COUNT} ] 0x1]; 
        set sts_frame_count  [ ATH_GET_FIELD $reg IMT_CVO_VAL16 ];  

	      close_service master ${::boardInit::masterPath}
	      
        # display values 
        if { ${::cgx_cvo::debug} == 0 } {
            puts " CVO status:                                            "
            puts "     busy              = $sts_busy                      "             
            puts "     irq               = $sts_irq                       "
            puts "     locked_out        = $sts_locked_out                "
            puts "     frame_count       = $sts_frame_count               "
            puts "                                                        "
            puts "     interrupt active:                                  "
            puts "         ia underflow  =$sts_ia_underflow               "
            puts "         ia locked_out =$sts_ia_locked_out              "
            puts "                                                        "                                                                                                                                                                
        }

        if { ${::cgx_cvo::debug} == 1 } {
        	  set dash_path ${::cgx_cvo::dash_path} 
            if { $sts_busy == 1 } {
               dashboard_set_property $dash_path dash_sts_busy checked true
            } else { 
               dashboard_set_property $dash_path dash_sts_busy checked false
            }        

            if { $sts_irq == 1 } {
                dashboard_set_property $dash_path dash_sts_irq color "red"
            } else {
                dashboard_set_property $dash_path dash_sts_irq color "black"
            }

         #  if { $sts_locked_out == 1 } {
         #      dashboard_set_property $dash_path dash_sts_locked checked true  
         #  } else {                                                            
         #      dashboard_set_property $dash_path dash_sts_locked checked false 
         #  }

            if { $sts_ia_underflow == 1 } {
               dashboard_set_property $dash_path dash_sts_ia_underflow checked true
            } else { 
               dashboard_set_property $dash_path dash_sts_ia_underflow checked false
            }        

            if { $sts_ia_locked_out == 1 } {
               dashboard_set_property $dash_path dash_sts_ia_locked_out checked true
            } else { 
               dashboard_set_property $dash_path dash_sts_ia_locked_out checked false
            }        

            if { $sts_locked_out == 1 } {
               dashboard_set_property $dash_path dash_vin_locked_out checked true
            } else { 
               dashboard_set_property $dash_path dash_vin_locked_out checked false
            }        

            dashboard_set_property $dash_path dash_frame_count  text $sts_frame_count  
        }
    }


    # clear all status interrupt-active bits
    proc clr_status { } {

        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_STATUS} ] 0xFFFFFFFF 
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 4*${::cgx_cvo::IMT_CVO_REG_FRAME_COUNT} ] 0x0 
	      close_service master ${::boardInit::masterPath}
    }


    proc dump {  } {

        open_service master ${::boardInit::masterPath}
        set dump [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_cvo::CVO_CSR_DEV_BASE} + 0 ] ${::cgx_cvo::IMT_CVO_REG_NUMBER} ]
        puts stdout $dump
	      close_service master ${::boardInit::masterPath}

    }


    proc dashBoard { } {

        if { ${::cgx_cvo::dashboardActive} == 1 } {
            return -code ok " ${::cgx_cvo::IPCORE_LABEL} dashboard already active"
        }

        set ::cgx_cvo::dashboardActive 1
        puts stdout " ${::cgx_cvo::IPCORE_LABEL} dashBoard start ......."

        #
        # Create dashboard 
        #
        variable ::cgx_cvo::dash_path [ add_service dashboard cgx_cvo "cgx_cvo" "Tools/cgx_cvo"]
     
        set dash_path ${::cgx_cvo::dash_path} 
     
        #
        # Set dashboard properties
        #
        dashboard_set_property $dash_path self developmentMode true
        dashboard_set_property $dash_path self itemsPerRow 1
        dashboard_set_property $dash_path self visible true
        
        #
        # groups
        #
        dashboard_add          $dash_path grp_top group self
        dashboard_set_property $dash_path grp_top expandableX false
        dashboard_set_property $dash_path grp_top expandableY false
        dashboard_set_property $dash_path grp_top itemsPerRow 1
        dashboard_set_property $dash_path grp_top title ""

        dashboard_add          $dash_path grp_device group grp_top
        dashboard_set_property $dash_path grp_device expandableX false
        dashboard_set_property $dash_path grp_device expandableY false
        dashboard_set_property $dash_path grp_device itemsPerRow 3
        dashboard_set_property $dash_path grp_device title "Device"

        dashboard_add          $dash_path grp_core group grp_top
        dashboard_set_property $dash_path grp_core expandableX false
        dashboard_set_property $dash_path grp_core expandableY false
        dashboard_set_property $dash_path grp_core itemsPerRow 1
        dashboard_set_property $dash_path grp_core title "Core ${::cgx_cvo::IPCORE_VERSION}"
        dashboard_set_property $dash_path grp_core visible false; # dashboard init

        dashboard_add          $dash_path grp_core_cmd group grp_core
        dashboard_set_property $dash_path grp_core_cmd expandableX false
        dashboard_set_property $dash_path grp_core_cmd expandableY false
        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_core_cmd title ""

        dashboard_add          $dash_path grp_csr group grp_core
        dashboard_set_property $dash_path grp_csr expandableX false
        dashboard_set_property $dash_path grp_csr expandableY false
        dashboard_set_property $dash_path grp_csr itemsPerRow 1
        dashboard_set_property $dash_path grp_csr title ""
        dashboard_set_property $dash_path grp_csr visible false; # dashboard init

        dashboard_add          $dash_path grp_csr_main group grp_csr
        dashboard_set_property $dash_path grp_csr_main expandableX false
        dashboard_set_property $dash_path grp_csr_main expandableY false
        dashboard_set_property $dash_path grp_csr_main itemsPerRow 3
        dashboard_set_property $dash_path grp_csr_main title ""
 
        dashboard_add          $dash_path grp_config group grp_csr_main
        dashboard_set_property $dash_path grp_config expandableX false
        dashboard_set_property $dash_path grp_config expandableY false
        dashboard_set_property $dash_path grp_config itemsPerRow 1
        dashboard_set_property $dash_path grp_config title "Config"

        dashboard_add          $dash_path grp_cfg_cmd group grp_config
        dashboard_set_property $dash_path grp_cfg_cmd expandableX false
        dashboard_set_property $dash_path grp_cfg_cmd expandableY false
        dashboard_set_property $dash_path grp_cfg_cmd itemsPerRow 2
        dashboard_set_property $dash_path grp_cfg_cmd title ""

        dashboard_add          $dash_path grp_cfg_param0 group grp_config
        dashboard_set_property $dash_path grp_cfg_param0 expandableX false
        dashboard_set_property $dash_path grp_cfg_param0 expandableY false
        dashboard_set_property $dash_path grp_cfg_param0 itemsPerRow 3
        dashboard_set_property $dash_path grp_cfg_param0 title ""

        dashboard_add          $dash_path grp_cfg_irq group grp_config
        dashboard_set_property $dash_path grp_cfg_irq expandableX false
        dashboard_set_property $dash_path grp_cfg_irq expandableY false
        dashboard_set_property $dash_path grp_cfg_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_cfg_irq title "interrupt enable"

        dashboard_add          $dash_path grp_status group grp_csr_main
        dashboard_set_property $dash_path grp_status expandableX false
        dashboard_set_property $dash_path grp_status expandableY false
        dashboard_set_property $dash_path grp_status itemsPerRow 1
        dashboard_set_property $dash_path grp_status title "Status"

        dashboard_add          $dash_path grp_sts_cmd group grp_status
        dashboard_set_property $dash_path grp_sts_cmd expandableX false
        dashboard_set_property $dash_path grp_sts_cmd expandableY false
        dashboard_set_property $dash_path grp_sts_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_cmd title ""

        dashboard_add          $dash_path grp_sts_param group grp_status
        dashboard_set_property $dash_path grp_sts_param expandableX false
        dashboard_set_property $dash_path grp_sts_param expandableY false
        dashboard_set_property $dash_path grp_sts_param itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_param title ""

        dashboard_add          $dash_path grp_sts_irq group grp_status
        dashboard_set_property $dash_path grp_sts_irq expandableX false
        dashboard_set_property $dash_path grp_sts_irq expandableY false
        dashboard_set_property $dash_path grp_sts_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_sts_irq title "interrupt active"

        dashboard_add          $dash_path grp_fct group grp_csr_main
        dashboard_set_property $dash_path grp_fct expandableX false
        dashboard_set_property $dash_path grp_fct expandableY false
        dashboard_set_property $dash_path grp_fct itemsPerRow 1
        dashboard_set_property $dash_path grp_fct title ""

        dashboard_add          $dash_path grp_vin group grp_fct
        dashboard_set_property $dash_path grp_vin expandableX false
        dashboard_set_property $dash_path grp_vin expandableY false
        dashboard_set_property $dash_path grp_vin itemsPerRow 2
        dashboard_set_property $dash_path grp_vin title "Stream-in"
 
        dashboard_add          $dash_path grp_cfg_video_timings group grp_fct
        dashboard_set_property $dash_path grp_cfg_video_timings expandableX false
        dashboard_set_property $dash_path grp_cfg_video_timings expandableY false
        dashboard_set_property $dash_path grp_cfg_video_timings itemsPerRow 1
        dashboard_set_property $dash_path grp_cfg_video_timings title "Clock-out"

        dashboard_add          $dash_path grp_cfg_video_timings_h group grp_cfg_video_timings
        dashboard_set_property $dash_path grp_cfg_video_timings_h expandableX false
        dashboard_set_property $dash_path grp_cfg_video_timings_h expandableY false
        dashboard_set_property $dash_path grp_cfg_video_timings_h itemsPerRow 5
        dashboard_set_property $dash_path grp_cfg_video_timings_h title "horizontal"

        dashboard_add          $dash_path grp_cfg_video_timings_v group grp_cfg_video_timings
        dashboard_set_property $dash_path grp_cfg_video_timings_v expandableX false
        dashboard_set_property $dash_path grp_cfg_video_timings_v expandableY false
        dashboard_set_property $dash_path grp_cfg_video_timings_v itemsPerRow 5
        dashboard_set_property $dash_path grp_cfg_video_timings_v title "vertical"



        #
        # widgets
        #

        dashboard_add          $dash_path dash_dev_base text grp_device 
        dashboard_set_property $dash_path dash_dev_base label "base" 
        dashboard_set_property $dash_path dash_dev_base expandableX false
        dashboard_set_property $dash_path dash_dev_base expandableY false
        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
        dashboard_set_property $dash_path dash_dev_base editable true
        dashboard_set_property $dash_path dash_dev_base htmlCapable false
        dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_cvo::CVO_CSR_DEV_BASE} ]

        dashboard_add          $dash_path dash_dev_init button grp_device 
        dashboard_set_property $dash_path dash_dev_init enabled true
        dashboard_set_property $dash_path dash_dev_init text "Init"
        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_cvo::dash_init_device }  

        dashboard_add          $dash_path dash_dev_dump button grp_device 
        dashboard_set_property $dash_path dash_dev_dump enabled true
        dashboard_set_property $dash_path dash_dev_dump text "Dump"
        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_cvo::dash_dump_device }  

        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_version enabled true
        dashboard_set_property $dash_path dash_dev_version text "Version"
        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_cvo::get_version }  

        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_caps enabled true
        dashboard_set_property $dash_path dash_dev_caps text "Caps"
        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_cvo::dash_get_caps }  
        
        dashboard_add          $dash_path dash_cfg_run checkBox grp_cfg_param0 
        dashboard_set_property $dash_path dash_cfg_run enabled true
        dashboard_set_property $dash_path dash_cfg_run text "Run"

        dashboard_add          $dash_path dash_cfg_ie_underflow checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_underflow text "underflow"

        dashboard_add          $dash_path dash_cfg_ie_locked_out checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_locked_out text "locked"

        dashboard_add          $dash_path dash_cfg_set button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_set enabled true
        dashboard_set_property $dash_path dash_cfg_set text "Set"
        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_cvo::dash_set_config }  

        dashboard_add          $dash_path dash_cfg_readback button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_readback enabled true
        dashboard_set_property $dash_path dash_cfg_readback text "Readback"
        dashboard_set_property $dash_path dash_cfg_readback onClick { ::cgx_cvo::dash_get_config }  

 
        #
        # monitor /  widgets
        #

        dashboard_add          $dash_path dash_sts_get button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_get enabled true
        dashboard_set_property $dash_path dash_sts_get text "Get"
        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_cvo::dash_get_status }  

        dashboard_add          $dash_path dash_sts_clear button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_clear text "Clear"
        dashboard_set_property $dash_path dash_sts_clear onClick { ::cgx_cvo::dash_clr_status }  

        dashboard_add          $dash_path dash_sts_run button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_run text "Run"
        dashboard_set_property $dash_path dash_sts_run enabled false
        dashboard_set_property $dash_path dash_sts_run onClick { ::cgx_cvo::dash_run_status }  
      
        dashboard_add          $dash_path dash_sts_busy checkBox grp_sts_param
        dashboard_set_property $dash_path dash_sts_busy text "busy"

        dashboard_add          $dash_path dash_sts_irq led grp_sts_param
        dashboard_set_property $dash_path dash_sts_irq text "irq"
        dashboard_set_property $dash_path dash_sts_irq color "black"

      # dashboard_add          $dash_path dash_sts_locked checkBox grp_sts_param
      # dashboard_set_property $dash_path dash_sts_locked text "locked"
 
        dashboard_add          $dash_path dash_sts_ia_underflow checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_underflow text "underflow"

        dashboard_add          $dash_path dash_sts_ia_locked_out checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_locked_out text "locked"

        dashboard_add          $dash_path dash_vin_locked_out checkBox grp_vin
        dashboard_set_property $dash_path dash_vin_locked_out text "locked"
        dashboard_set_property $dash_path dash_vin_locked_out visible true

        dashboard_add          $dash_path dash_frame_count text grp_vin 
        dashboard_set_property $dash_path dash_frame_count label "frame count" 
        dashboard_set_property $dash_path dash_frame_count expandableX false
        dashboard_set_property $dash_path dash_frame_count expandableY false
        dashboard_set_property $dash_path dash_frame_count preferredWidth 50
        dashboard_set_property $dash_path dash_frame_count editable false
        dashboard_set_property $dash_path dash_frame_count htmlCapable false
        dashboard_set_property $dash_path dash_frame_count text "0"

        dashboard_add          $dash_path dash_cfg_vid_hres text grp_cfg_video_timings_h 
        dashboard_set_property $dash_path dash_cfg_vid_hres label "width"
        dashboard_set_property $dash_path dash_cfg_vid_hres preferredWidth 70
        dashboard_set_property $dash_path dash_cfg_vid_hres text "0"

        dashboard_add          $dash_path dash_cfg_vid_vres text grp_cfg_video_timings_v 
        dashboard_set_property $dash_path dash_cfg_vid_vres label "height"
        dashboard_set_property $dash_path dash_cfg_vid_vres preferredWidth 70
        dashboard_set_property $dash_path dash_cfg_vid_vres text "0"

        dashboard_add          $dash_path dash_cfg_vid_hfpw text grp_cfg_video_timings_h 
        dashboard_set_property $dash_path dash_cfg_vid_hfpw label "hfpw"
        dashboard_set_property $dash_path dash_cfg_vid_hfpw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_hfpw text "0"
        dashboard_set_property $dash_path dash_cfg_vid_hfpw expandableX false
        dashboard_set_property $dash_path dash_cfg_vid_hfpw expandableY false
        dashboard_set_property $dash_path dash_cfg_vid_hfpw htmlCapable false

        dashboard_add          $dash_path dash_cfg_vid_hsw text grp_cfg_video_timings_h 
        dashboard_set_property $dash_path dash_cfg_vid_hsw label "hsw"
        dashboard_set_property $dash_path dash_cfg_vid_hsw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_hsw text "0"

        dashboard_add          $dash_path dash_cfg_vid_hbpw text grp_cfg_video_timings_h 
        dashboard_set_property $dash_path dash_cfg_vid_hbpw label "hbpw"
        dashboard_set_property $dash_path dash_cfg_vid_hbpw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_hbpw text "0"

        dashboard_add          $dash_path dash_cfg_vid_hpol checkBox grp_cfg_video_timings_h         
        dashboard_set_property $dash_path dash_cfg_vid_hpol text "polarity"

        dashboard_add          $dash_path dash_cfg_vid_vfpw text grp_cfg_video_timings_v 
        dashboard_set_property $dash_path dash_cfg_vid_vfpw label "vfpw"
        dashboard_set_property $dash_path dash_cfg_vid_vfpw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_vfpw text "0"

        dashboard_add          $dash_path dash_cfg_vid_vsw text grp_cfg_video_timings_v 
        dashboard_set_property $dash_path dash_cfg_vid_vsw label "vsw"
        dashboard_set_property $dash_path dash_cfg_vid_vsw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_vsw text "0"

        dashboard_add          $dash_path dash_cfg_vid_vbpw text grp_cfg_video_timings_v 
        dashboard_set_property $dash_path dash_cfg_vid_vbpw label "vbpw"
        dashboard_set_property $dash_path dash_cfg_vid_vbpw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_vbpw text "0"

        dashboard_add          $dash_path dash_cfg_vid_vpol checkBox grp_cfg_video_timings_v         
        dashboard_set_property $dash_path dash_cfg_vid_vpol text "polarity"

      # after idle ::cgx_cvo::dash_update

        puts stdout " ${::cgx_cvo::IPCORE_LABEL} dashBoard end"

        return -code ok
    }

	      
    proc dash_init_device {} {
    	
        set ::cgx_cvo::debug 1

        cgx_cvo::init -1  
        cgx_cvo::dash_get_config
        cgx_cvo::dash_get_status

        set ::cgx_cvo::debug 0
    }


    proc dash_dump_device {} {

        cgx_cvo::dump  

    }


    proc dash_get_caps {} {
    	
        set ::cgx_cvo::debug 1

        cgx_cvo::get_caps   

        set ::cgx_cvo::debug 0
    }


    proc dash_set_config {} {

        set ::cgx_cvo::debug 1
       
        cgx_cvo::set_config -1  
        cgx_cvo::set_interrupt -1
        cgx_cvo::set_timings  -1 -1 -1 -1 -1 -1 -1 -1 -1 -1
       
        set ::cgx_cvo::debug 0
        
    }


    proc dash_get_config {} {

        set ::cgx_cvo::debug 1

        cgx_cvo::get_config    
        cgx_cvo::get_interrupt
        cgx_cvo::get_timings    

        set ::cgx_cvo::debug 0

    }
    
   
    proc dash_get_status {} {

        set ::cgx_cvo::debug 1

        cgx_cvo::get_status          

        set ::cgx_cvo::debug 0

    }


    proc dash_clr_status {} {

        set ::cgx_cvo::debug 1

        cgx_cvo::clr_status          

        set ::cgx_cvo::debug 0
        
    }


    proc dash_run_status {} {

    # TODO

    }

   
  # proc dash_update {} {
  #
  #     if { ${::cgx_cvo::dashboardActive} > 0 } {
  #  
  #         if { ${::cgx_cvo::initialized} > 0 } {
  #
  #             ::cgx_cvo::dash_get_config
  #             ::cgx_cvo::dash_get_status
  #
  #         }
  #     }
  # }
}


 