
# cgx_video::init          { instance_idx }
# cgx_video::get_version   { }
# cgx_video::get_caps      { }
# cgx_video::dump          { }
# cgx_video::dashBoard     { }

# cgx_video::set_clocked     { run }
# cgx_video::get_clocked_cfg { }
# cgx_video::get_clocked_sts { }
# cgx_video::clr_clocked     { }

# cgx_video::set_pattern { active clkdiv width height back fore }
# cgx_video::get_pattern { quiet }        

# cgx_video::set_banding { color }    
# cgx_video::get_banding { quiet }  

# cgx_video::set_cropping { active x y w h }
# cgx_video::get_cropping { quiet }        

# cgx_video::set_scaling { active en_filter w h }
# cgx_video::get_scaling { quiet }         

# cgx_video::set_capture        { cfg_run cfg_rotate_msk } 
# cgx_video::get_capture_caps   { }
# cgx_video::get_capture_cfg    { }
# cgx_video::get_capture_sts    { }  
# cgx_video::clr_capture        { }
# cgx_video::get_capture_writer { quiet }


namespace eval cgx_video {


    variable IPCORE_PRODUCT 64; # 0x40                                                                                                 
    variable IPCORE_VERSION ${::cgx_fusion::IPCORE_VERSION}                                                                                           
    variable IPCORE_LABEL "Video-In"

    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    # debug mode
    # 0 => console 
    # 1 => dashboard (+console) 
    variable debug 0


    #-------------------------- SYS------------------------------


   #variable VID_CSR_FUSION_BASE 0x00000000
    variable VID_CSR_DEV_BASE        0x00000000
    variable VSC_CSR_DEV_BASE        0x00000000
    variable VSC_CSR_DEV_BASE_SFCTRL 0x00000000
    
    variable initialized 0

    # 0:  enable  info stdout   
    # 1:  disable info stdout
    variable QUIET 0
        
    #-------------------------- HAL------------------------------

    variable VIDEO_CSR_DEV_TOP  0                                                                                        
    variable VIDEO_CSR_DEV_CVI  1                                                                                        
    variable VIDEO_CSR_DEV_TPG  2                                                                                        
    variable VIDEO_CSR_DEV_CRP  3                                                                                        
    variable VIDEO_CSR_DEV_SCL  4                                                                                        
    variable VIDEO_CSR_DEV_BAND 5                                                                                        

    variable VIDEO_CSR_OFST_DEV 16                                                                                         

    # 32-bits regs offset
    variable VIDEO_CSR_OFST_TOP  [ expr $VIDEO_CSR_DEV_TOP  * $VIDEO_CSR_OFST_DEV ]                                                                                        
    variable VIDEO_CSR_OFST_CVI  [ expr $VIDEO_CSR_DEV_CVI  * $VIDEO_CSR_OFST_DEV ]                                                                                        
    variable VIDEO_CSR_OFST_TPG  [ expr $VIDEO_CSR_DEV_TPG  * $VIDEO_CSR_OFST_DEV ]                                                                                        
    variable VIDEO_CSR_OFST_BAND [ expr $VIDEO_CSR_DEV_BAND * $VIDEO_CSR_OFST_DEV ]                                                                                        
    variable VIDEO_CSR_OFST_CRP  [ expr $VIDEO_CSR_DEV_CRP  * $VIDEO_CSR_OFST_DEV ]                                                                                        
    variable VIDEO_CSR_OFST_SCL  [ expr $VIDEO_CSR_DEV_SCL  * $VIDEO_CSR_OFST_DEV ]                                                                                        

   
    variable VIDEO_CSR_TOP_REG_VERSION   [ expr 0 + $VIDEO_CSR_OFST_TOP ]
    variable VIDEO_CSR_TOP_REG_CAPS      [ expr 1 + $VIDEO_CSR_OFST_TOP ]
    variable VIDEO_CSR_TOP_REG_CAPS_SIZE [ expr 2 + $VIDEO_CSR_OFST_TOP ]
    variable VIDEO_CSR_TOP_REG_NUMBER    [ expr 3 + $VIDEO_CSR_OFST_TOP ]


    # /* VIDEO_CSR_TOP_REG_VERSION fields */
    
    variable VIDEO_CSR_VERSION_ID_MSK     0xFF      
    variable VIDEO_CSR_VERSION_ID_OFST    0         
    variable VIDEO_CSR_VERSION_BUILD_MSK  0xFF00    
    variable VIDEO_CSR_VERSION_BUILD_OFST 8         
    variable VIDEO_CSR_VERSION_MINOR_MSK  0xFF0000   
    variable VIDEO_CSR_VERSION_MINOR_OFST 16        
    variable VIDEO_CSR_VERSION_MAJOR_MSK  0x0F000000   
    variable VIDEO_CSR_VERSION_MAJOR_OFST 24        


    # /* VIDEO_CSR_TOP_REG_CAPS fields */

    variable VIDEO_CSR_CAPS_ENA_CFG_MSK      0x1      
    variable VIDEO_CSR_CAPS_ENA_CFG_OFST     0         
    variable VIDEO_CSR_CAPS_ENA_CLOCKED_MSK  0x2      
    variable VIDEO_CSR_CAPS_ENA_CLOCKED_OFST 1         
    variable VIDEO_CSR_CAPS_ENA_TPG_MSK      0x4      
    variable VIDEO_CSR_CAPS_ENA_TPG_OFST     2         
    variable VIDEO_CSR_CAPS_ENA_SCL_MSK      0x8      
    variable VIDEO_CSR_CAPS_ENA_SCL_OFST     3         
    variable VIDEO_CSR_CAPS_ENA_CRP_MSK      0x10      
    variable VIDEO_CSR_CAPS_ENA_CRP_OFST     4         
    variable VIDEO_CSR_CAPS_ENA_BAND_MSK     0x20
    variable VIDEO_CSR_CAPS_ENA_BAND_OFST    5


  #/* -- Fusion Video - C V I ------------------------------ */

  # variable VIDEO_CSR_CVI_REG_CAPS             [ expr 0 + $VIDEO_CSR_OFST_CVI ]
    variable VIDEO_CSR_CVI_REG_CONTROL          [ expr 1 + $VIDEO_CSR_OFST_CVI ]
    variable VIDEO_CSR_CVI_REG_STATUS           [ expr 2 + $VIDEO_CSR_OFST_CVI ]
    variable VIDEO_CSR_CVI_REG_FRAME_SIZE       [ expr 3 + $VIDEO_CSR_OFST_CVI ]
    variable VIDEO_CSR_CVI_REG_FRAME_COUNT      [ expr 4 + $VIDEO_CSR_OFST_CVI ]
    variable VIDEO_CSR_CVI_REG_PEAK_USED_PIXELS [ expr 5 + $VIDEO_CSR_OFST_CVI ]
    variable VIDEO_CSR_CVI_REG_NUMBER           [ expr 6 + $VIDEO_CSR_OFST_CVI ] 

 
        # /* interrupt bits                                                  */
        # /* to be used for enable bits (CVI_CSR_INTERRUPT_ENABLE_MSK) and   */
        # /*                active bits (CVI_CSR_STATUS_IRQ_ACTIVE_MSK)      */  
        variable CVI_CSR_IRQ_BIT_OVERFLOW_MSK          0x1; #   /* interrupt event on high state */                                                    
        variable CVI_CSR_IRQ_BIT_OVERFLOW_OFST         0                                                            
        variable CVI_CSR_IRQ_BIT_LOCKED_CHANGED_MSK    0x2; #   /* interrupt event on any state change */                                                                 
        variable CVI_CSR_IRQ_BIT_LOCKED_CHANGED_OFST   1                                 


  #/* VIDEO_CSR_CVI_REG_CONTROL fields */

	  variable CVI_CSR_CONTROL_RUN_MSK         0x1; # /* 0/1 = power off/on.*/
		variable CVI_CSR_CONTROL_RUN_OFST        0
 

  #/* VIDEO_CSR_CVI_REG_STATUS fields */

  ##variable CVI_CSR_STATUS_BUSY_MSK              0x1
  ##variable CVI_CSR_STATUS_BUSY_OFST             0
  ##variable CVI_CSR_STATUS_IRQ_MSK               0x2
  ##variable CVI_CSR_STATUS_IRQ_OFST              1
    variable CVI_CSR_STATUS_LOCKED_PIN_MSK        0x100                                                                 
    variable CVI_CSR_STATUS_LOCKED_PIN_OFST       8                                                                     
    variable CVI_CSR_STATUS_LOCKED_WIDTH_MSK      0x200                                                                                                                        
    variable CVI_CSR_STATUS_LOCKED_WIDTH_OFST     9                                                                     
    variable CVI_CSR_STATUS_LOCKED_HEIGHT_MSK     0x400                                                                 
    variable CVI_CSR_STATUS_LOCKED_HEIGHT_OFST    10                                                                    
#   variable CVI_CSR_STATUS_LOCKED_HEIGHT_F1_MSK  0x800                                                                 
#   variable CVI_CSR_STATUS_LOCKED_HEIGHT_F1_OFST 11    
    variable CVI_CSR_STATUS_INTERLACED_MSK        0x1000
    variable CVI_CSR_STATUS_INTERLACED_OFST       12    

    variable CVI_CSR_STATUS_IRQ_ACTIVE_MSK        0xFF0000  
		variable CVI_CSR_STATUS_IRQ_ACTIVE_OFST       16


  #/* VIDEO_CSR_CVI_REG_FRAME_WIDTH                  */
  #/* VIDEO_CSR_CVI_REG_FRAME_HEIGHT              */
  #/* VIDEO_CSR_CVI_REG_FRAME_HEIGHT_F1              */
  #/* VIDEO_CSR_CVI_REG_PEAK_USED_PIXELS fields */
    variable CVI_CSR_VAL16_MSK  0xFFFF  
		variable CVI_CSR_VAL16_OFST 0


  #/* -- Fusion Video - Pattern ------------------------------ */
 
    variable VIDEO_CSR_TPG_REG_CTL         [ expr 0 + $VIDEO_CSR_OFST_TPG ]
    variable VIDEO_CSR_TPG_REG_STS         [ expr 1 + $VIDEO_CSR_OFST_TPG ]
    variable VIDEO_CSR_TPG_REG_CFG_SIZE    [ expr 2 + $VIDEO_CSR_OFST_TPG ]
    variable VIDEO_CSR_TPG_REG_CFG_PATTERN [ expr 3 + $VIDEO_CSR_OFST_TPG ]
    variable VIDEO_CSR_TPG_REG_NUMBER      [ expr 4 + $VIDEO_CSR_OFST_TPG ]

    # VIDEO_CSR_TPG_REG_CTL
    variable VIDEO_CSR_TPG_CTL_ACTIVE_MSK  0x1                                                                      
    variable VIDEO_CSR_TPG_CTL_ACTIVE_OFST 0                                                                         
    variable VIDEO_CSR_TPG_CTL_CLKDIV_MSK  0xFF00 
    variable VIDEO_CSR_TPG_CTL_CLKDIV_OFST 8    

    # VIDEO_CSR_TPG_REG_STS
    variable VIDEO_CSR_TPG_STS_FRAME_BUSY_MSK   0x1       
    variable VIDEO_CSR_TPG_STS_FRAME_BUSY_OFST  0         
    variable VIDEO_CSR_TPG_STS_FRAME_COUNT_MSK  0xFFFF0000                
    variable VIDEO_CSR_TPG_STS_FRAME_COUNT_OFST 16                        
    
    # VIDEO_CSR_TPG_REG_CFG_PATTERN  
    variable VIDEO_CSR_TPG_CFG_PATTERN_BACK_MSK  0xFF                       
    variable VIDEO_CSR_TPG_CFG_PATTERN_BACK_OFST 0                          
    variable VIDEO_CSR_TPG_CFG_PATTERN_FORE_MSK  0xFF00 
    variable VIDEO_CSR_TPG_CFG_PATTERN_FORE_OFST 8    


  #/* -- Fusion Video - Banding ------------------------------ */
 
    variable VIDEO_CSR_BAND_REG_CFG_COLOR [ expr 0 + $VIDEO_CSR_OFST_BAND ]
    variable VIDEO_CSR_BAND_REG_STS_POS   [ expr 1 + $VIDEO_CSR_OFST_BAND ]
    variable VIDEO_CSR_BAND_REG_STS_SIZE  [ expr 2 + $VIDEO_CSR_OFST_BAND ]
    variable VIDEO_CSR_BAND_REG_NUMBER    [ expr 3 + $VIDEO_CSR_OFST_BAND ]


  #/* -- Fusion Video - Cropper ------------------------------ */
 
    variable VIDEO_CSR_CRP_REG_CFG      [ expr 0 + $VIDEO_CSR_OFST_CRP ]
    variable VIDEO_CSR_CRP_REG_POS      [ expr 1 + $VIDEO_CSR_OFST_CRP ]
    variable VIDEO_CSR_CRP_REG_SIZE     [ expr 2 + $VIDEO_CSR_OFST_CRP ]
    variable VIDEO_CSR_CRP_REG_NUMBER   [ expr 3 + $VIDEO_CSR_OFST_CRP ]

    # VIDEO_CSR_CRP_REG_CFG
    variable VIDEO_CSR_CRP_CFG_ACTIVE_MSK  0x1                                                                      
    variable VIDEO_CSR_CRP_CFG_ACTIVE_OFST 0                                                                         


  #/* -- Fusion Video - Scaler ------------------------------ */

    variable VIDEO_CSR_SCL_REG_CFG         [ expr 0 + $VIDEO_CSR_OFST_SCL ]
    variable VIDEO_CSR_SCL_REG_STS         [ expr 1 + $VIDEO_CSR_OFST_SCL ]
    variable VIDEO_CSR_SCL_REG_CFG_SCALEX  [ expr 2 + $VIDEO_CSR_OFST_SCL ]
    variable VIDEO_CSR_SCL_REG_CFG_SCALEY  [ expr 3 + $VIDEO_CSR_OFST_SCL ]
    variable VIDEO_CSR_SCL_REG_CFG_SIZEO   [ expr 4 + $VIDEO_CSR_OFST_SCL ]
    variable VIDEO_CSR_SCL_REG_CFG_SIZEI   [ expr 5 + $VIDEO_CSR_OFST_SCL ]
    variable VIDEO_CSR_SCL_REG_STS_SIZEI   [ expr 6 + $VIDEO_CSR_OFST_SCL ]
    variable VIDEO_CSR_SCL_REG_NUMBER      [ expr 7 + $VIDEO_CSR_OFST_SCL ]

    # VIDEO_CSR_SCL_REG_CFG
    variable VIDEO_CSR_SCL_CFG_ACTIVE_MSK     0x1                                                                     
    variable VIDEO_CSR_SCL_CFG_ACTIVE_OFST    0                                                                       
    variable VIDEO_CSR_SCL_CFG_EN_FILTER_MSK  0x2                                                                     
    variable VIDEO_CSR_SCL_CFG_EN_FILTER_OFST 1                                                                       


    # VIDEO_CSR_SCL_REG_STS
    variable VIDEO_CSR_SCL_STS_FRAME_BUSY_MSK     0x1                                                                                                  
    variable VIDEO_CSR_SCL_STS_FRAME_BUSY_OFST    0                                                                                                    
    variable VIDEO_CSR_SCL_STS_INPUT_CHANGED_MSK  0x2                                                                                                                                                                                                           
    variable VIDEO_CSR_SCL_STS_INPUT_CHANGED_OFST 1                                                                                                                                                                                                             
    variable VIDEO_CSR_SCL_STS_FRAME_COUNT_MSK    0xFFFF0000
    variable VIDEO_CSR_SCL_STS_FRAME_COUNT_OFST   16

    # VIDEO_CSR_SCL_REG_CFG_SCALEX
    # VIDEO_CSR_SCL_REG_CFG_SCALEY
    variable VIDEO_CSR_SCL_SCALE_FSIZE 16; # // fractional size  
    variable VIDEO_CSR_SCL_SCALE_ISIZE  8; # // integer size     
    variable VIDEO_CSR_SCL_SCALE_SIZE  24; # // total size     
    variable VIDEO_CSR_SCL_SCALE_MSK   0xFFFFFF
    variable VIDEO_CSR_SCL_SCALE_OFST  0
    
   #variable VIDEO_PORT_SCL_SCALE_UNITY (1<<VIDEO_PORT_SCL_SCALE_FSIZE)    

    # common
    # VIDEO_CSR_TOP_REG_CAPS_SIZE
    # VIDEO_CSR_CVI_REG_FRAME_SIZE    
    # VIDEO_CSR_TPG_REG_CFG_SIZE
    # VIDEO_CSR_CRP_REG_POS
    # VIDEO_CSR_CRP_REG_SIZE
    # VIDEO_CSR_SCL_REG_CFG_SIZEO 
    # VIDEO_CSR_SCL_REG_CFG_SIZEI
    # VIDEO_CSR_SCL_REG_STS_SIZEI 
    variable VIDEO_CSR_CFG_VALX_MSK    0xFFFF                                                                      
    variable VIDEO_CSR_CFG_VALX_OFST   0                                                                         
    variable VIDEO_CSR_CFG_VALY_MSK    0xFFFF0000                                                                      
    variable VIDEO_CSR_CFG_VALY_OFST   16


       
    #--------------------------private functions ------------------------------

    proc CGX_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_video::$field_name\_REG 
            set str_field_msk   ::cgx_video::$field_name\_MSK 
            set str_field_ofst  ::cgx_video::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc CGX_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_video::$field_name\_MSK 
        set str_field_ofst ::cgx_video::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

    proc CGX_SET_FIELD2 { reg32 field_name field_val } {
    
           #set str_field_reg32 $field_name\_REG 
            set str_field_msk   $field_name\_MSK 
            set str_field_ofst  $field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc CGX_GET_FIELD2 { reg32 field_name } {

        set str_field_msk  $field_name\_MSK 
        set str_field_ofst $field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

     
    #--------------------------public functions ------------------------------

 
    proc init { instance_idx } {

      # puts stdout "FUSION-VIDEO init:"

        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
            set instance_idx [ dashboard_get_property $dash_path dash_instance_idx text ]  
        } 
                                
        set ::cgx_video::VID_CSR_DEV_BASE [ cgx_fusion::get_dev_base ${cgx_fusion::DEF_CLASS_VIN} $instance_idx ]
        set ::cgx_video::VSC_CSR_DEV_BASE [ cgx_fusion::get_dev_base ${cgx_fusion::DEF_CLASS_VSC} $instance_idx ]
        set ::cgx_video::VSC_CSR_DEV_BASE_SFCTRL [ expr ${::cgx_video::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_BASE_SFC} ]    

        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
            dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_video::VID_CSR_DEV_BASE} ]
            dashboard_set_property $dash_path dash_sfctl_base text [ format 0x%x ${::cgx_video::VSC_CSR_DEV_BASE_SFCTRL} ]
        } 

        set dev_success [ ::cgx_video::get_version ];  
        
        if {${dev_success} == 1} {
            set ::cgx_video::initialized 1
        } else {
            set ::cgx_video::initialized 0
        } 

        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
            dashboard_set_property $dash_path grp_csr   visible false
            if {${dev_success} == 1} {
                puts " ${::cgx_video::IPCORE_LABEL} init successfull "
                dashboard_set_property $dash_path grp_core  visible true
            } else {
                puts " ${::cgx_video::IPCORE_LABEL} ERROR: device init failure "
                dashboard_set_property $dash_path grp_core  visible false
            } 
        } 
    }
       
  # proc get_dev_base { dev_idx } {
  #     set dev_base [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4 * ( $dev_idx * ${::cgx_video::VIDEO_CSR_OFST_DEV} ) ] 
  #     return $dev_base
  # }

    proc get_version { } {
        
        set csr_base8 ${::cgx_video::VID_CSR_DEV_BASE} 
        
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_video::VIDEO_CSR_TOP_REG_VERSION} ] 0x1]; 
        close_service master ${::boardInit::masterPath}

        set v_id    [ CGX_GET_FIELD $reg VIDEO_CSR_VERSION_ID ] ;                              
        set v_build [ CGX_GET_FIELD $reg VIDEO_CSR_VERSION_BUILD ] ;                           
        set v_minor [ CGX_GET_FIELD $reg VIDEO_CSR_VERSION_MINOR ] ;                           
        set v_major [ CGX_GET_FIELD $reg VIDEO_CSR_VERSION_MAJOR ] ;                           
        set version $v_major.$v_minor                            

        if {$v_id == ${::cgx_video::IPCORE_PRODUCT} } {
          puts " ${::cgx_video::IPCORE_LABEL} detection successfull, core id = [ format 0x%x $v_id ] "
          puts " ${::cgx_video::IPCORE_LABEL} Version = $v_major.$v_minor, Build = $v_build"
          if { $version == ${::cgx_video::IPCORE_VERSION} } {
            set success 1
          } else {
            set success 0
            puts stdout " ${::cgx_video::IPCORE_LABEL} ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_video::IPCORE_VERSION} )"
            puts stdout "        please upgrade the dashboard version accordingly to the IP core "
          }
        } else {
          set success 0
          puts stdout " ${::cgx_video::IPCORE_LABEL} ERROR: device not detected at device base ${::cgx_video::VID_CSR_DEV_BASE} "
          puts stdout "        core id = $v_id, reg = $reg "
          puts stdout "        please, set the right device base and press init again "
        }
        return $success

    }


    proc get_caps { } {
        
        set csr_base8 ${::cgx_video::VID_CSR_DEV_BASE} 

        open_service master ${::boardInit::masterPath}        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_video::VIDEO_CSR_TOP_REG_CAPS} ] 0x1]; 
        close_service master ${::boardInit::masterPath}

        set caps_ena_cfg  [ CGX_GET_FIELD $reg VIDEO_CSR_CAPS_ENA_CFG ] ; 
        set caps_clocked  [ CGX_GET_FIELD $reg VIDEO_CSR_CAPS_ENA_CLOCKED ] ; 
        set caps_ena_tpg  [ CGX_GET_FIELD $reg VIDEO_CSR_CAPS_ENA_TPG ] ; 
        set caps_ena_scl  [ CGX_GET_FIELD $reg VIDEO_CSR_CAPS_ENA_SCL ] ; 
        set caps_ena_crp  [ CGX_GET_FIELD $reg VIDEO_CSR_CAPS_ENA_CRP ] ; 
        set caps_ena_band [ CGX_GET_FIELD $reg VIDEO_CSR_CAPS_ENA_BAND ] ; 
              
    #   set caps_max_width  [ CGX_GET_FIELD $reg VIDEO_CSR_CAPS0_MAX_WIDTH ] ; 
    #   set caps_max_height [ CGX_GET_FIELD $reg VIDEO_CSR_CAPS0_MAX_HEIGHT ] ; 
    #
        puts "                                                  "
        puts "  Capabilities:                                   "
        puts "      enabled cfg      = $caps_ena_cfg            "
        puts "      clocked          = $caps_clocked            "
        puts "      enabled pattern  = $caps_ena_tpg            "
        puts "      enabled banding  = $caps_ena_band           "
        puts "      enabled cropping = $caps_ena_crp            "
        puts "      enabled scaling  = $caps_ena_scl            "
    #   puts "      max_width  = $caps_max_width                "
    #   puts "      max_height = $caps_max_height               "
        puts "                                                  "                                                                                          

        if { ${::cgx_video::debug} == 1 } {

            set dash_path ${::cgx_video::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true

            if { $caps_clocked==0 } {
                dashboard_set_property $dash_path grp_cvi visible false
            } else {    
                dashboard_set_property $dash_path grp_cvi visible true
            }

            if { $caps_ena_tpg==0 } {
                dashboard_set_property $dash_path grp_tpg visible false
            } else {    
                dashboard_set_property $dash_path grp_tpg visible true
            }

            if { $caps_ena_band==0 } {
                dashboard_set_property $dash_path grp_banding visible false
            } else {    
                dashboard_set_property $dash_path grp_banding visible true
            }
               
            if { $caps_ena_crp == 0 } { 
                dashboard_set_property $dash_path grp_cropping visible false
            } else {    
                dashboard_set_property $dash_path grp_cropping visible true
            }

            if { $caps_ena_scl==0 } {
                dashboard_set_property $dash_path grp_scaling visible false
            } else {    
                dashboard_set_property $dash_path grp_scaling visible true
            }

        }
    }


    proc set_pattern { active clkdiv width height back fore } {

        open_service master ${::boardInit::masterPath}

        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 

	          set active 0 
            if { [ dashboard_get_property $dash_path dash_tpg_cfg_active checked ] == true } {
                set active 1
            } 

            set clkdiv [ dashboard_get_property $dash_path dash_tpg_cfg_clkdiv text ]
	          
	          set back [ dashboard_get_property $dash_path dash_tpg_cfg_back selected ]
	          set fore [ dashboard_get_property $dash_path dash_tpg_cfg_fore selected ]

            set width  [ dashboard_get_property $dash_path dash_tpg_cfg_w text ]
            set height [ dashboard_get_property $dash_path dash_tpg_cfg_h text ]
        }

        set reg 0
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_TPG_CTL_ACTIVE $active ]
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_TPG_CTL_CLKDIV $clkdiv ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_TPG_REG_CTL} ] $reg

        set reg 0
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_TPG_CFG_PATTERN_BACK $back ]
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_TPG_CFG_PATTERN_FORE $fore ]  
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_TPG_REG_CFG_PATTERN} ] $reg

        set reg 0
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALX $width ]
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALY $height ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_TPG_REG_CFG_SIZE} ] $reg

	      close_service master ${::boardInit::masterPath}
    }


    proc get_pattern { quiet } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_TPG_REG_CTL} ] 0x1]; 
        set active [ CGX_GET_FIELD $reg VIDEO_CSR_TPG_CTL_ACTIVE ] ;                                                                
        set clkdiv [ CGX_GET_FIELD $reg VIDEO_CSR_TPG_CTL_CLKDIV ] ;                                                                

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_TPG_REG_CFG_PATTERN} ] 0x1]; 
        set back   [ CGX_GET_FIELD $reg VIDEO_CSR_TPG_CFG_PATTERN_BACK ] ;                                                                
        set fore   [ CGX_GET_FIELD $reg VIDEO_CSR_TPG_CFG_PATTERN_FORE ] ;                                                                
    
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_TPG_REG_CFG_SIZE} ] 0x1]; 
        set width  [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX ]    
        set height [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY ]    

	      close_service master ${::boardInit::masterPath}
 
        if { $quiet == 0 } {
            puts "                        "
            puts "     run     = $active  "    
            puts "     clkdiv  = $clkdiv  "    
            puts "     width   = $width   "         
            puts "     height  = $height  "         
            puts "     back    = $back    "   
            puts "     fore    = $fore    "
        }
        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 

            if { $active == 1 } {
               dashboard_set_property $dash_path dash_tpg_cfg_active checked true  
            } else { 
               dashboard_set_property $dash_path dash_tpg_cfg_active checked false  
            }   
             
            dashboard_set_property $dash_path dash_tpg_cfg_clkdiv text $clkdiv   
                  
            dashboard_set_property $dash_path dash_tpg_cfg_back selected $back
            dashboard_set_property $dash_path dash_tpg_cfg_fore selected $fore
            
            dashboard_set_property $dash_path dash_tpg_cfg_w text $width   
            dashboard_set_property $dash_path dash_tpg_cfg_h text $height  
        }

        set cfg { }
        lappend cfg $active 
        lappend cfg $width 
        lappend cfg $height
        lappend cfg $back
        lappend cfg $fore
         
        return $cfg           
    }
 

    proc set_scaling { active en_filter width height } {   

        set dash_path ${::cgx_video::dash_path} 
 
        if { ${::cgx_video::debug} == 1 } {
                 
            set active 0 
            if { [ dashboard_get_property $dash_path dash_scl_cfg_active checked ] == true } {
                set active 1
            }

            set en_filter 0 
            if { [ dashboard_get_property $dash_path dash_scl_cfg_en_filter checked ] == true } {
                set en_filter 1
            }
             
            set width [ dashboard_get_property $dash_path dash_scl_cfg_w  text ]
            set height [ dashboard_get_property $dash_path dash_scl_cfg_h  text ]                       
        }  

        open_service master ${::boardInit::masterPath}
     
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG} ] 0x1]; 
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_SCL_CFG_ACTIVE $active ]
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_SCL_CFG_EN_FILTER $en_filter ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG} ] $reg

        set reg 0; 
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALX $width ]
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALY $height ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG_SIZEO} ] $reg

        # get input size
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_STS_SIZEI} ] 0x1]; 
        set sts_wi [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX ] ;                                                                
        set sts_hi [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY ] ;                                                                
        dashboard_set_property $dash_path dash_scl_sts_w text $sts_wi 
        dashboard_set_property $dash_path dash_scl_sts_h text $sts_hi 
     
        if { $width!=0 && $height!=0} {                  
            # compute ratios
            set sx [ expr ($sts_wi * 256 * 256) / $width ]
            set sy [ expr ($sts_hi * 256 * 256) / $height ]
        } else {
            set sx 0
            set sy 0
        }
        dashboard_set_property $dash_path dash_scl_cfg_sx text $sx  
        dashboard_set_property $dash_path dash_scl_cfg_sy text $sy  
        set reg 0; 
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_SCL_SCALE $sx ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG_SCALEX} ] $reg
        set reg 0; 
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_SCL_SCALE $sy ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG_SCALEY} ] $reg


        # write back input size complying the scaling ratio
        set reg 0; 
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALX $sts_wi ]
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALY $sts_hi ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG_SIZEI} ] $reg

        close_service master ${::boardInit::masterPath}        
    }

    proc get_scaling { quiet } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG} ] 0x1]; 
        set cfg_active [ CGX_GET_FIELD $reg VIDEO_CSR_SCL_CFG_ACTIVE ] ;                                                                
        set cfg_en_filter [ CGX_GET_FIELD $reg VIDEO_CSR_SCL_CFG_EN_FILTER ] ;                                                                

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_STS_SIZEI} ] 0x1]; 
        set sts_wi [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX];                                                                
        set sts_hi [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY];                                                                

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG_SCALEX} ] 0x1]; 
        set cfg_sx [ CGX_GET_FIELD $reg VIDEO_CSR_SCL_SCALE];                                                                
        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG_SCALEY} ] 0x1]; 
        set cfg_sy [ CGX_GET_FIELD $reg VIDEO_CSR_SCL_SCALE];                                                                

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_SCL_REG_CFG_SIZEO} ] 0x1]; 
        set cfg_w [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX] ;                                                                
        set cfg_h [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY] ;                                                                

        close_service master ${::boardInit::masterPath}

        if { $quiet == 0 } {
            puts "                                 "
            puts "  config:                        "
            puts "      active    = $cfg_active    "          
            puts "      en_filter = $cfg_en_filter "          
            puts "      sts_wi    = $sts_wi        "          
            puts "      sts_hi    = $sts_hi        "          
            puts "      cfg_sx    = $cfg_sx        "          
            puts "      cfg_sy    = $cfg_sy        "          
            puts "      cfg_w     = $cfg_w         "          
            puts "      cfg_h     = $cfg_h         "          
        }
        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
 
            if { $cfg_active == 1 } {
               dashboard_set_property $dash_path dash_scl_cfg_active checked true  
            } else { 
               dashboard_set_property $dash_path dash_scl_cfg_active checked false  
            }        

            if { $cfg_en_filter == 1 } {
               dashboard_set_property $dash_path dash_scl_cfg_en_filter checked true  
            } else { 
               dashboard_set_property $dash_path dash_scl_cfg_en_filter checked false  
            }        
            
            dashboard_set_property $dash_path dash_scl_sts_w  text $sts_wi 
            dashboard_set_property $dash_path dash_scl_sts_h  text $sts_hi 
            dashboard_set_property $dash_path dash_scl_cfg_sx text $cfg_sx     
            dashboard_set_property $dash_path dash_scl_cfg_sy text $cfg_sy     
            dashboard_set_property $dash_path dash_scl_cfg_w  text $cfg_w     
            dashboard_set_property $dash_path dash_scl_cfg_h  text $cfg_h     
        }
  
        set sts { }
        lappend sts $cfg_active
        lappend sts $cfg_sx   
        lappend sts $cfg_sy   
        lappend sts $cfg_w   
        lappend sts $cfg_h   
        return $sts                   
    }


    proc set_banding { color } {   

        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
            set color [ dashboard_get_property $dash_path dash_band_cfg_color text ]
        }  

        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_BAND_REG_CFG_COLOR} ] $color
        close_service master ${::boardInit::masterPath}        
    }


    proc get_banding  { quiet } {

        open_service master ${::boardInit::masterPath}

        set cfg_color [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_BAND_REG_CFG_COLOR} ] 0x1]; 

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_BAND_REG_STS_POS} ] 0x1]; 
        set sts_x [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX ] ;                                                                
        set sts_y [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY ] ;                                                                

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_BAND_REG_STS_SIZE} ] 0x1]; 
        set sts_w [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX ] ;                                                                
        set sts_h [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY ] ;                                                                

        close_service master ${::boardInit::masterPath}

        if { $quiet == 0 } {
            puts "                  "
            puts "  status:         "
            puts "      x = $sts_x  "          
            puts "      y = $sts_y  "          
            puts "      w = $sts_w  "          
            puts "      h = $sts_h  "          
        }
        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
              
            dashboard_set_property $dash_path dash_band_cfg_color text [ format 0x%x $cfg_color ]       

            dashboard_set_property $dash_path dash_band_sts_x text $sts_x     
            dashboard_set_property $dash_path dash_band_sts_y text $sts_y     
            dashboard_set_property $dash_path dash_band_sts_w text $sts_w     
            dashboard_set_property $dash_path dash_band_sts_h text $sts_h     
        }
        
        set sts { }
        lappend sts $sts_x     
        lappend sts $sts_y     
        lappend sts $sts_w     
        lappend sts $sts_h     
        return $sts                   
    }


    proc set_cropping { active x y w h } {   

        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
                 
            set active 0 
            if { [ dashboard_get_property $dash_path dash_crp_cfg_active checked ] == true } {
                set active 1
            } 
            
            set x     [ dashboard_get_property $dash_path dash_crp_cfg_x     text ]
            set y     [ dashboard_get_property $dash_path dash_crp_cfg_y     text ]
            set w     [ dashboard_get_property $dash_path dash_crp_cfg_w     text ]
            set h     [ dashboard_get_property $dash_path dash_crp_cfg_h     text ]                       
        }  

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CRP_REG_CFG} ] 0x1]; 
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CRP_CFG_ACTIVE $active ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CRP_REG_CFG} ] $reg

        set reg 0; 
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALX $x ]
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALY $y ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CRP_REG_POS} ] $reg

        set reg 0; 
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALX $w ]
        set reg [ CGX_SET_FIELD $reg VIDEO_CSR_CFG_VALY $h ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CRP_REG_SIZE} ] $reg

        close_service master ${::boardInit::masterPath}        
    }


    proc get_cropping { quiet } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CRP_REG_CFG} ] 0x1]; 
        set cfg_active [ CGX_GET_FIELD $reg VIDEO_CSR_CRP_CFG_ACTIVE ] ;                                                                

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CRP_REG_POS} ] 0x1]; 
        set cfg_x [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX ] ;                                                                
        set cfg_y [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY ] ;                                                                

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CRP_REG_SIZE} ] 0x1]; 
        set cfg_w [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX ] ;                                                                
        set cfg_h [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY ] ;                                                                

        close_service master ${::boardInit::masterPath}

        if { $quiet == 0 } {
            puts "                           "
            puts "  config:                  "
            puts "      active = $cfg_active "          
            puts "      x      = $cfg_x      "          
            puts "      y      = $cfg_y      "          
            puts "      w      = $cfg_w      "          
            puts "      h      = $cfg_h      "          
        }
        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
 
            if { $cfg_active == 1 } {
               dashboard_set_property $dash_path dash_crp_cfg_active checked true  
            } else { 
               dashboard_set_property $dash_path dash_crp_cfg_active checked false  
            }        

            dashboard_set_property $dash_path dash_crp_cfg_x     text $cfg_x     
            dashboard_set_property $dash_path dash_crp_cfg_y     text $cfg_y     
            dashboard_set_property $dash_path dash_crp_cfg_w     text $cfg_w     
            dashboard_set_property $dash_path dash_crp_cfg_h     text $cfg_h     
        }
        
        set sts { }
        lappend sts $cfg_active
        lappend sts $cfg_x     
        lappend sts $cfg_y     
        lappend sts $cfg_w     
        lappend sts $cfg_h     
        return $sts                   
    }

    
    proc set_clocked { run } {   

        if { ${::cgx_video::debug} == 1 } {
	          set dash_path ${::cgx_video::dash_path} 
	          set run 0 
            if { [ dashboard_get_property $dash_path dash_cvi_cfg_run checked ] == true } {
                set run 1
            } 
        }  

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_CONTROL} ] 0x1]; 
        set reg [ CGX_SET_FIELD $reg CVI_CSR_CONTROL_RUN $run ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_CONTROL} ] $reg

	      close_service master ${::boardInit::masterPath}
    }
    
      
    proc get_clocked_cfg { } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_CONTROL} ] 0x1]; 
        set cfg_run [ CGX_GET_FIELD $reg CVI_CSR_CONTROL_RUN ] ;                                                                

	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_video::debug} == 0 } {
            puts "                                 "
            puts "  config:                        "
            puts "      cfg_run = $cfg_run         "          
            puts "                                 "                                                                                                                                                                
        }
        if { ${::cgx_video::debug} == 1 } {
        	  set dash_path ${::cgx_video::dash_path} 
 
            if { $cfg_run == 1 } {
               dashboard_set_property $dash_path dash_cvi_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_cvi_cfg_run checked false  
            }        
        }
    }
 

    proc get_clocked_sts {  } {

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_STATUS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

      # set sts_busy [ CGX_GET_FIELD $reg CVI_CSR_STATUS_BUSY ] ;                                                                

        set sts_interlaced    [ CGX_GET_FIELD $reg CVI_CSR_STATUS_INTERLACED ] ;  
        set sts_locked_pin    [ CGX_GET_FIELD $reg CVI_CSR_STATUS_LOCKED_PIN ] ;                                                                
        set sts_locked_width  [ CGX_GET_FIELD $reg CVI_CSR_STATUS_LOCKED_WIDTH ] ;                                                                
        set sts_locked_height [ CGX_GET_FIELD $reg CVI_CSR_STATUS_LOCKED_HEIGHT ] ;                                                                

        set sts_irqfield [ CGX_GET_FIELD $reg CVI_CSR_STATUS_IRQ_ACTIVE ] ;                                                                

        set sts_ia_overflow         [ CGX_GET_FIELD $sts_irqfield CVI_CSR_IRQ_BIT_OVERFLOW ] ;                                                                        
        set sts_ia_locked_changed   [ CGX_GET_FIELD $sts_irqfield CVI_CSR_IRQ_BIT_LOCKED_CHANGED ] ;                                                                

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_FRAME_SIZE} ] 0x1]; 
        set sts_frame_width  [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALX ] ;  
        set sts_frame_height [ CGX_GET_FIELD $reg VIDEO_CSR_CFG_VALY ] ;  

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_PEAK_USED_PIXELS} ] 0x1]; 
        set sts_used_peak  [ CGX_GET_FIELD $reg CVI_CSR_VAL16 ] ;  

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_FRAME_COUNT} ] 0x1]; 
        set sts_frame_count  [ CGX_GET_FIELD $reg CVI_CSR_VAL16 ] ;   

	      close_service master ${::boardInit::masterPath}
	      

        # display values 
        if { ${::cgx_video::QUIET} == 0 } {
            puts " CVI status:                                            "
         #  puts "     busy             = $sts_busy                       "             
            puts "     interlaced       = $sts_interlaced                 "
            puts "     locked_pin       = $sts_locked_pin                 "
            puts "     locked_width     = $sts_locked_width               "
            puts "     locked_height    = $sts_locked_height              "
            puts "     frame_width      = $sts_frame_width                "
            puts "     frame_height     = $sts_frame_height               "
            puts "     frame_count      = $sts_frame_count                "
            puts "     used_peak        = $sts_used_peak                  "
            puts "                                                        "
            puts "     interrupt active:                                  "
            puts "         ia overflow       =$sts_ia_overflow            "
            puts "         ia locked_changed =$sts_ia_locked_changed      " 
            puts "                                                        "                                                                                                                                                                
        }

        if { ${::cgx_video::debug} == 1 } {
        	  set dash_path ${::cgx_video::dash_path} 
         #  if { $sts_busy == 1 } {
         #     dashboard_set_property $dash_path dash_cvi_sts_busy checked true
         #  } else { 
         #     dashboard_set_property $dash_path dash_cvi_sts_busy checked false
         #  }        

            if { $sts_ia_overflow == 1 } {
               dashboard_set_property $dash_path dash_cvi_sts_ia_overflow checked true
            } else { 
               dashboard_set_property $dash_path dash_cvi_sts_ia_overflow checked false
            }        

            if { $sts_ia_locked_changed == 1 } {
               dashboard_set_property $dash_path dash_cvi_sts_ia_locked_changed checked true
            } else { 
               dashboard_set_property $dash_path dash_cvi_sts_ia_locked_changed checked false
            }        

            if { $sts_interlaced == 1 } {
               dashboard_set_property $dash_path dash_cvi_sts_interlaced checked true
            } else { 
               dashboard_set_property $dash_path dash_cvi_sts_interlaced checked false
            }        

            if { $sts_locked_pin == 1 } {
               dashboard_set_property $dash_path dash_cvi_sts_locked_pin checked true
            } else { 
               dashboard_set_property $dash_path dash_cvi_sts_locked_pin checked false
            }        
            if { $sts_locked_width == 1 } {
               dashboard_set_property $dash_path dash_cvi_sts_locked_width checked true
            } else { 
               dashboard_set_property $dash_path dash_cvi_sts_locked_width checked false
            }        
            if { $sts_locked_height == 1 } {
               dashboard_set_property $dash_path dash_cvi_sts_locked_height checked true
            } else { 
               dashboard_set_property $dash_path dash_cvi_sts_locked_height checked false
            }        

            dashboard_set_property $dash_path dash_cvi_frame_width     text $sts_frame_width     
            dashboard_set_property $dash_path dash_cvi_frame_height    text $sts_frame_height 
            dashboard_set_property $dash_path dash_cvi_frame_count     text $sts_frame_count 
            dashboard_set_property $dash_path dash_cvi_used_peak    text $sts_used_peak 
        }

        set sts {}
        lappend sts $sts_frame_width 
        lappend sts $sts_frame_height 
        lappend sts $sts_frame_count 
         
        return $sts           
    }


    # clear all  
    proc clr_clocked { } {

        open_service master ${::boardInit::masterPath}
        # clear interrupt-active bits
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_STATUS} ] 0xFFFFFFFF 
        # clear frame count
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_FRAME_COUNT} ] 0 
        # clear peak used pixels
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 4*${::cgx_video::VIDEO_CSR_CVI_REG_PEAK_USED_PIXELS} ] 0
	      close_service master ${::boardInit::masterPath}
    }


    proc set_capture { cfg_run cfg_rotate_msk } {   

        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path} 
            set cfg_run 0 
            if { [ dashboard_get_property $dash_path dash_vsc_cfg_run checked ] == true } {
                set cfg_run 1
            } 

            set mirror_bool [ dashboard_get_property $dash_path dash_vsc_cfg_mirror checked ]
            set flip_h_bool [ dashboard_get_property $dash_path dash_vsc_cfg_flip_h checked ]
            set flip_v_bool [ dashboard_get_property $dash_path dash_vsc_cfg_flip_v checked ]

            set cfg_rotate_msk 0 

            if { $mirror_bool == true} {   
                set cfg_rotate_msk [ CGX_SET_FIELD2 $cfg_rotate_msk ::cgx_vsc::VSC_ROTATE_MIRROR 1 ]
            } 
            if { $flip_h_bool == true} {   
                set cfg_rotate_msk [ CGX_SET_FIELD2 $cfg_rotate_msk ::cgx_vsc::VSC_ROTATE_FLIP_H 1 ]
            } 
            if { $flip_v_bool == true} {   
                set cfg_rotate_msk [ CGX_SET_FIELD2 $cfg_rotate_msk ::cgx_vsc::VSC_ROTATE_FLIP_V 1 ]
            } 
        }  
  
        open_service master ${::boardInit::masterPath}
 
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_CONFIG} ] 0x1]; 
        set reg [ CGX_SET_FIELD2 $reg ::cgx_vsc::VSC_CSR_CFG_RUN $cfg_run ]
        set reg [ CGX_SET_FIELD2 $reg ::cgx_vsc::VSC_CSR_CFG_ROTATE $cfg_rotate_msk ]

        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_CONFIG} ] $reg
 
        close_service master ${::boardInit::masterPath}
    }
    
      
    proc get_capture_cfg { } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_CONFIG} ] 0x1]; 
        set cfg_run        [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_CSR_CFG_RUN ] ;                                                                
        set cfg_rotate_msk [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_CSR_CFG_ROTATE ] ;                                                                
        set cfg_mirror     [ CGX_GET_FIELD2 $cfg_rotate_msk ::cgx_vsc::VSC_ROTATE_MIRROR ]
        set cfg_flip_h     [ CGX_GET_FIELD2 $cfg_rotate_msk ::cgx_vsc::VSC_ROTATE_FLIP_H ]
        set cfg_flip_v     [ CGX_GET_FIELD2 $cfg_rotate_msk ::cgx_vsc::VSC_ROTATE_FLIP_V ]

	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_video::debug} == 0 } {
            puts "                               "
            puts " Capture config:               "
            puts "      cfg_run    = $cfg_run    "          
            puts "      cfg_mirror = $cfg_mirror "                                                                                                                                                                
            puts "      cfg_flip_h = $cfg_flip_h "                                                                                                                                                                
            puts "      cfg_flip_v = $cfg_flip_v "                                                                                                                                                                
        }
        if { ${::cgx_video::debug} == 1 } {
        	  set dash_path ${::cgx_video::dash_path} 
 
            if { $cfg_run == 1 } {
               dashboard_set_property $dash_path dash_vsc_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_vsc_cfg_run checked false  
            } 

            if { $cfg_mirror == 1 } {
               dashboard_set_property $dash_path dash_vsc_cfg_mirror checked true  
            } else { 
               dashboard_set_property $dash_path dash_vsc_cfg_mirror checked false  
            } 

            if { $cfg_flip_h == 1 } {
               dashboard_set_property $dash_path dash_vsc_cfg_flip_h checked true  
            } else { 
               dashboard_set_property $dash_path dash_vsc_cfg_flip_h checked false  
            } 

            if { $cfg_flip_v == 1 } {
               dashboard_set_property $dash_path dash_vsc_cfg_flip_v checked true  
            } else { 
               dashboard_set_property $dash_path dash_vsc_cfg_flip_v checked false  
            } 
        }
    }


    proc get_capture_caps { } {
                
        set csr_base8 ${::cgx_video::VSC_CSR_DEV_BASE} 

        open_service master ${::boardInit::masterPath}        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_vsc::VSC_CSR_REG_CAPS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set caps_is_reader    [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_CSR_CAPS_IS_READER ] ; 
        set caps_is_writer    [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_CSR_CAPS_IS_WRITER ] ; 
        set caps_ena_rotation [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_CSR_CAPS_ENABLE_ROTATION ] ; 
 
	      puts "                                            "
        puts "  VSC Capabilities:                         "
        puts "      caps_is_reader    = $caps_is_reader   "
        puts "      caps_is_writer    = $caps_is_writer   "
        puts "      caps_ena_rotation = $caps_ena_rotation"
        puts "                                            "                                                                                          

        if { ${::cgx_video::debug} == 1 } {

            set dash_path ${::cgx_video::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true
                                 
            if { $caps_ena_rotation!=0} {  
                dashboard_set_property $dash_path grp_rotate  visible true
            } else {    
                dashboard_set_property $dash_path grp_rotate  visible false
            }                        
        }
    }


    proc get_capture_sts { } {

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_STATUS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set sts_busy     [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_STS_BUSY ] ;                                                                
        set sts_irqfield [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_STS_IRQ_ACTIVE ] ;                                                                
        set frame_count  [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_STS_FRAME_COUNT ] ;                                                                

        set sts_ia_frame_completed [ CGX_GET_FIELD2 $sts_irqfield ::cgx_vsc::VSC_CSR_IRQ_BIT_FRAME_COMPLETED ] ;                                                                
        set sts_ia_video_changed   [ CGX_GET_FIELD2 $sts_irqfield ::cgx_vsc::VSC_CSR_IRQ_BIT_VIDEO_CHANGED ] ;                                                                
 
        if { ${::cgx_vsc::QUIET} == 0 } {
            puts "                                                           "
            puts "  status:                                                  "
            puts "         sts_busy               = $sts_busy                "
            puts "         sts_ia_frame_completed = $sts_ia_frame_completed  "  
            puts "         sts_ia_video_changed   = $sts_ia_video_changed    "
            puts "         frame_count            = $frame_count             "
            puts "                                                           "                                                                                                              
        }
        if { ${::cgx_video::debug} == 1 } {
        	  set dash_path ${::cgx_video::dash_path} 
            if { $sts_busy == 1 } {
               dashboard_set_property $dash_path dash_vsc_sts_busy checked true
            } else { 
               dashboard_set_property $dash_path dash_vsc_sts_busy checked false
            }        

            if { $sts_ia_frame_completed == 1 } {
               dashboard_set_property $dash_path dash_vsc_sts_ia_frame_completed checked true
            } else { 
               dashboard_set_property $dash_path dash_vsc_sts_ia_frame_completed checked false
            }        

            if { $sts_ia_video_changed == 1 } {
               dashboard_set_property $dash_path dash_vsc_sts_ia_video_changed checked true
            } else { 
               dashboard_set_property $dash_path dash_vsc_sts_ia_video_changed checked false
            }        

            dashboard_set_property $dash_path dash_vsc_frame_count text $frame_count    

        }
    }
                         

    # clear all status interrupt-active bits
    proc clr_capture { } {

        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_STATUS} ] 0xFFFFFFFF 
	      close_service master ${::boardInit::masterPath}
    }
 

    proc get_capture_writer { quiet } {

        open_service master ${::boardInit::masterPath}
 
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VSC_CSR_DEV_BASE} + 4*${::cgx_vsc::VSC_CSR_REG_WRITER_SIZE} ] 0x1]; 
        set writer_width  [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_CSR_VALX ]    
        set writer_height [ CGX_GET_FIELD2 $reg ::cgx_vsc::VSC_CSR_VALY ]    

	      close_service master ${::boardInit::masterPath}
 
        if { $quiet == 0 } {
            puts "                                    "
            puts "  status:                           "
            puts "     writer_width  = $writer_width  " 
            puts "     writer_height = $writer_height " 
            puts "                                    "                                                                                                                     
        }
        if { ${::cgx_video::debug} == 1 } {
            set dash_path ${::cgx_video::dash_path}                         
            dashboard_set_property $dash_path dash_vsc_writer_width   text $writer_width   
            dashboard_set_property $dash_path dash_vsc_writer_height  text $writer_height  
        }
                
        set sts {}
        lappend sts $writer_width 
        lappend sts $writer_height         
        return $sts           
    }


    proc dump {  } {

        open_service master ${::boardInit::masterPath}
        set dump [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_video::VID_CSR_DEV_BASE} + 0 ] ${::cgx_video::VIDEO_CSR_TOP_REG_NUMBER} ]
        puts stdout $dump
        close_service master ${::boardInit::masterPath}

    }


    proc dashBoard { } {

        if { ${::cgx_video::dashboardActive} == 1 } {
            return -code ok " ${::cgx_video::IPCORE_LABEL} dashboard already active"
        }

        set ::cgx_video::dashboardActive 1
        puts stdout " ${::cgx_video::IPCORE_LABEL} dashBoard start ......."

        #
        # Create dashboard 
        #
        variable ::cgx_video::dash_path [ add_service dashboard cgx_video "cgx_video" "Tools/cgx_video"]
     
        set dash_path ${::cgx_video::dash_path} 
     
        #
        # Set dashboard properties
        #
        dashboard_set_property $dash_path self developmentMode true
        dashboard_set_property $dash_path self itemsPerRow 1
        dashboard_set_property $dash_path self visible true
        
        #
        # groups
        #
        dashboard_add          $dash_path grp_top group self
        dashboard_set_property $dash_path grp_top expandableX false
        dashboard_set_property $dash_path grp_top expandableY false
        dashboard_set_property $dash_path grp_top itemsPerRow 1
        dashboard_set_property $dash_path grp_top title ""

        dashboard_add          $dash_path grp_device group grp_top
        dashboard_set_property $dash_path grp_device expandableX false
        dashboard_set_property $dash_path grp_device expandableY false
        dashboard_set_property $dash_path grp_device itemsPerRow 4
        dashboard_set_property $dash_path grp_device title "Device"

        dashboard_add          $dash_path grp_core group grp_top
        dashboard_set_property $dash_path grp_core expandableX false
        dashboard_set_property $dash_path grp_core expandableY false
        dashboard_set_property $dash_path grp_core itemsPerRow 1
        dashboard_set_property $dash_path grp_core title "Core ${::cgx_video::IPCORE_VERSION}"
        dashboard_set_property $dash_path grp_core visible false; # dashboard init

        dashboard_add          $dash_path grp_core_cmd group grp_core
        dashboard_set_property $dash_path grp_core_cmd expandableX false
        dashboard_set_property $dash_path grp_core_cmd expandableY false
        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_core_cmd title ""

        dashboard_add          $dash_path grp_csr group grp_core
        dashboard_set_property $dash_path grp_csr expandableX false
        dashboard_set_property $dash_path grp_csr expandableY false
        dashboard_set_property $dash_path grp_csr itemsPerRow 1
        dashboard_set_property $dash_path grp_csr title ""
        dashboard_set_property $dash_path grp_csr visible false; # dashboard init
 
        dashboard_add          $dash_path grp_control group grp_csr
        dashboard_set_property $dash_path grp_control expandableX false
        dashboard_set_property $dash_path grp_control expandableY false
        dashboard_set_property $dash_path grp_control itemsPerRow 4
        dashboard_set_property $dash_path grp_control title "Control"

        dashboard_add          $dash_path grp_cvi group grp_csr
        dashboard_set_property $dash_path grp_cvi expandableX false
        dashboard_set_property $dash_path grp_cvi expandableY false
        dashboard_set_property $dash_path grp_cvi itemsPerRow 6
        dashboard_set_property $dash_path grp_cvi title "Clocked Input"

        dashboard_add          $dash_path grp_tpg group grp_csr
        dashboard_set_property $dash_path grp_tpg expandableX false
        dashboard_set_property $dash_path grp_tpg expandableY false
        dashboard_set_property $dash_path grp_tpg itemsPerRow 6
        dashboard_set_property $dash_path grp_tpg title "Pattern Generator"

        dashboard_add          $dash_path grp_banding group grp_csr
        dashboard_set_property $dash_path grp_banding expandableX false
        dashboard_set_property $dash_path grp_banding expandableY false
        dashboard_set_property $dash_path grp_banding itemsPerRow 5
        dashboard_set_property $dash_path grp_banding title "Banding"

        dashboard_add          $dash_path grp_cropping group grp_csr
        dashboard_set_property $dash_path grp_cropping expandableX false
        dashboard_set_property $dash_path grp_cropping expandableY false
        dashboard_set_property $dash_path grp_cropping itemsPerRow 5
        dashboard_set_property $dash_path grp_cropping title "Cropping"

        dashboard_add          $dash_path grp_scaling group grp_csr
        dashboard_set_property $dash_path grp_scaling expandableX false
        dashboard_set_property $dash_path grp_scaling expandableY false
        dashboard_set_property $dash_path grp_scaling itemsPerRow 10
        dashboard_set_property $dash_path grp_scaling title "Scaling"

        dashboard_add          $dash_path grp_capture group grp_csr
        dashboard_set_property $dash_path grp_capture expandableX false
        dashboard_set_property $dash_path grp_capture expandableY false
        dashboard_set_property $dash_path grp_capture itemsPerRow 4
        dashboard_set_property $dash_path grp_capture title "Capture"

        dashboard_add          $dash_path grp_capture1 group grp_capture
        dashboard_set_property $dash_path grp_capture1 expandableX false
        dashboard_set_property $dash_path grp_capture1 expandableY false
        dashboard_set_property $dash_path grp_capture1 itemsPerRow 1
        dashboard_set_property $dash_path grp_capture1 title "Control"

        dashboard_add          $dash_path grp_capture2 group grp_capture
        dashboard_set_property $dash_path grp_capture2 expandableX false
        dashboard_set_property $dash_path grp_capture2 expandableY false
        dashboard_set_property $dash_path grp_capture2 itemsPerRow 1
        dashboard_set_property $dash_path grp_capture2 title "Writer"

        dashboard_add          $dash_path grp_rotate group grp_capture
        dashboard_set_property $dash_path grp_rotate expandableX false
        dashboard_set_property $dash_path grp_rotate expandableY false
        dashboard_set_property $dash_path grp_rotate itemsPerRow 1
        dashboard_set_property $dash_path grp_rotate title "Capture"

        #
        # widgets
        #

        dashboard_add          $dash_path dash_instance_idx text grp_device 
        dashboard_set_property $dash_path dash_instance_idx label "Index" 
        dashboard_set_property $dash_path dash_instance_idx expandableX false
        dashboard_set_property $dash_path dash_instance_idx expandableY false
        dashboard_set_property $dash_path dash_instance_idx preferredWidth 30
        dashboard_set_property $dash_path dash_instance_idx editable true
        dashboard_set_property $dash_path dash_instance_idx htmlCapable false
        dashboard_set_property $dash_path dash_instance_idx text 0

        dashboard_add          $dash_path dash_dev_init button grp_device 
        dashboard_set_property $dash_path dash_dev_init enabled true
        dashboard_set_property $dash_path dash_dev_init text "Init"
        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_video::dash_init_device }  

        dashboard_add          $dash_path dash_dev_dump button grp_device 
        dashboard_set_property $dash_path dash_dev_dump enabled true
        dashboard_set_property $dash_path dash_dev_dump text "Dump"
        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_video::dash_dump_device }  

        dashboard_add          $dash_path dash_dev_base text grp_device 
        dashboard_set_property $dash_path dash_dev_base label "base" 
        dashboard_set_property $dash_path dash_dev_base expandableX false
        dashboard_set_property $dash_path dash_dev_base expandableY false
        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
        dashboard_set_property $dash_path dash_dev_base editable false
        dashboard_set_property $dash_path dash_dev_base htmlCapable false
        dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_video::VID_CSR_DEV_BASE} ]

        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_version enabled true
        dashboard_set_property $dash_path dash_dev_version text "Version"
        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_video::get_version }  

        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_caps enabled true
        dashboard_set_property $dash_path dash_dev_caps text "Caps"
        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_video::dash_get_caps }  
        
        dashboard_add          $dash_path dash_cfg_set button grp_control 
        dashboard_set_property $dash_path dash_cfg_set enabled true
        dashboard_set_property $dash_path dash_cfg_set text "-Set"
        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_video::dash_set_config }  

      # dashboard_add          $dash_path dash_cfg_readback button grp_control 
      # dashboard_set_property $dash_path dash_cfg_readback enabled true
      # dashboard_set_property $dash_path dash_cfg_readback text "-Readback"
      # dashboard_set_property $dash_path dash_cfg_readback onClick { ::cgx_video::dash_get_config }  

 
        #
        # monitor /  widgets
        #

        dashboard_add          $dash_path dash_sts_get button grp_control 
        dashboard_set_property $dash_path dash_sts_get enabled true
        dashboard_set_property $dash_path dash_sts_get text "Get"
        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_video::dash_get_status }  

        dashboard_add          $dash_path dash_sts_clear button grp_control 
        dashboard_set_property $dash_path dash_sts_clear text "Clear"
        dashboard_set_property $dash_path dash_sts_clear onClick { ::cgx_video::dash_clr_status }  


        dashboard_add          $dash_path dash_band_cfg_color text grp_banding 
        dashboard_set_property $dash_path dash_band_cfg_color label "-color" 
        dashboard_set_property $dash_path dash_band_cfg_color expandableX false
        dashboard_set_property $dash_path dash_band_cfg_color expandableY false
        dashboard_set_property $dash_path dash_band_cfg_color preferredWidth 80
        dashboard_set_property $dash_path dash_band_cfg_color htmlCapable false
        dashboard_set_property $dash_path dash_band_cfg_color text "0"

        dashboard_add          $dash_path dash_band_sts_x text grp_banding 
        dashboard_set_property $dash_path dash_band_sts_x label "x" 
        dashboard_set_property $dash_path dash_band_sts_x expandableX false
        dashboard_set_property $dash_path dash_band_sts_x expandableY false
        dashboard_set_property $dash_path dash_band_sts_x preferredWidth 50
        dashboard_set_property $dash_path dash_band_sts_x htmlCapable false
        dashboard_set_property $dash_path dash_band_sts_x text "0"
        dashboard_set_property $dash_path dash_band_sts_x editable false
                                                     
        dashboard_add          $dash_path dash_band_sts_y text grp_banding 
        dashboard_set_property $dash_path dash_band_sts_y label "y" 
        dashboard_set_property $dash_path dash_band_sts_y expandableX false
        dashboard_set_property $dash_path dash_band_sts_y expandableY false
        dashboard_set_property $dash_path dash_band_sts_y preferredWidth 50
        dashboard_set_property $dash_path dash_band_sts_y htmlCapable false
        dashboard_set_property $dash_path dash_band_sts_y text "0"
        dashboard_set_property $dash_path dash_band_sts_y editable false
                                                     
        dashboard_add          $dash_path dash_band_sts_w text grp_banding 
        dashboard_set_property $dash_path dash_band_sts_w label "width" 
        dashboard_set_property $dash_path dash_band_sts_w expandableX false
        dashboard_set_property $dash_path dash_band_sts_w expandableY false
        dashboard_set_property $dash_path dash_band_sts_w preferredWidth 50
        dashboard_set_property $dash_path dash_band_sts_w htmlCapable false
        dashboard_set_property $dash_path dash_band_sts_w text "0"
        dashboard_set_property $dash_path dash_band_sts_w editable false
                                                     
        dashboard_add          $dash_path dash_band_sts_h text grp_banding 
        dashboard_set_property $dash_path dash_band_sts_h label "height" 
        dashboard_set_property $dash_path dash_band_sts_h expandableX false
        dashboard_set_property $dash_path dash_band_sts_h expandableY false
        dashboard_set_property $dash_path dash_band_sts_h preferredWidth 50
        dashboard_set_property $dash_path dash_band_sts_h htmlCapable false
        dashboard_set_property $dash_path dash_band_sts_h text "0"
        dashboard_set_property $dash_path dash_band_sts_h editable false


        dashboard_add          $dash_path dash_crp_cfg_active checkBox grp_cropping
        dashboard_set_property $dash_path dash_crp_cfg_active text "-active"

        dashboard_add          $dash_path dash_crp_cfg_x text grp_cropping 
        dashboard_set_property $dash_path dash_crp_cfg_x label "-x" 
        dashboard_set_property $dash_path dash_crp_cfg_x expandableX false
        dashboard_set_property $dash_path dash_crp_cfg_x expandableY false
        dashboard_set_property $dash_path dash_crp_cfg_x preferredWidth 50
        dashboard_set_property $dash_path dash_crp_cfg_x htmlCapable false
        dashboard_set_property $dash_path dash_crp_cfg_x text "0"
     
        dashboard_add          $dash_path dash_crp_cfg_y text grp_cropping 
        dashboard_set_property $dash_path dash_crp_cfg_y label "-y" 
        dashboard_set_property $dash_path dash_crp_cfg_y expandableX false
        dashboard_set_property $dash_path dash_crp_cfg_y expandableY false
        dashboard_set_property $dash_path dash_crp_cfg_y preferredWidth 50
        dashboard_set_property $dash_path dash_crp_cfg_y htmlCapable false
        dashboard_set_property $dash_path dash_crp_cfg_y text "0"

        dashboard_add          $dash_path dash_crp_cfg_w text grp_cropping 
        dashboard_set_property $dash_path dash_crp_cfg_w label "-width" 
        dashboard_set_property $dash_path dash_crp_cfg_w expandableX false
        dashboard_set_property $dash_path dash_crp_cfg_w expandableY false
        dashboard_set_property $dash_path dash_crp_cfg_w preferredWidth 50
        dashboard_set_property $dash_path dash_crp_cfg_w htmlCapable false
        dashboard_set_property $dash_path dash_crp_cfg_w text "0"
     
        dashboard_add          $dash_path dash_crp_cfg_h text grp_cropping 
        dashboard_set_property $dash_path dash_crp_cfg_h label "-height" 
        dashboard_set_property $dash_path dash_crp_cfg_h expandableX false
        dashboard_set_property $dash_path dash_crp_cfg_h expandableY false
        dashboard_set_property $dash_path dash_crp_cfg_h preferredWidth 50
        dashboard_set_property $dash_path dash_crp_cfg_h htmlCapable false
        dashboard_set_property $dash_path dash_crp_cfg_h text "0"


        dashboard_add          $dash_path dash_scl_cfg_active checkBox grp_scaling
        dashboard_set_property $dash_path dash_scl_cfg_active text "-active"

        dashboard_add          $dash_path dash_scl_cfg_en_filter checkBox grp_scaling
        dashboard_set_property $dash_path dash_scl_cfg_en_filter text "-filtering"

        dashboard_add          $dash_path dash_scl_cfg_w text grp_scaling 
        dashboard_set_property $dash_path dash_scl_cfg_w label "-out width" 
        dashboard_set_property $dash_path dash_scl_cfg_w expandableX false
        dashboard_set_property $dash_path dash_scl_cfg_w expandableY false
        dashboard_set_property $dash_path dash_scl_cfg_w preferredWidth 50
        dashboard_set_property $dash_path dash_scl_cfg_w htmlCapable false
        dashboard_set_property $dash_path dash_scl_cfg_w text "0"
     
        dashboard_add          $dash_path dash_scl_cfg_h text grp_scaling 
        dashboard_set_property $dash_path dash_scl_cfg_h label "-out height" 
        dashboard_set_property $dash_path dash_scl_cfg_h expandableX false
        dashboard_set_property $dash_path dash_scl_cfg_h expandableY false
        dashboard_set_property $dash_path dash_scl_cfg_h preferredWidth 50
        dashboard_set_property $dash_path dash_scl_cfg_h htmlCapable false
        dashboard_set_property $dash_path dash_scl_cfg_h text "0"

        dashboard_add          $dash_path dash_scl_sts_w text grp_scaling 
        dashboard_set_property $dash_path dash_scl_sts_w label "in width" 
        dashboard_set_property $dash_path dash_scl_sts_w expandableX false
        dashboard_set_property $dash_path dash_scl_sts_w expandableY false
        dashboard_set_property $dash_path dash_scl_sts_w preferredWidth 50
        dashboard_set_property $dash_path dash_scl_sts_w htmlCapable false
        dashboard_set_property $dash_path dash_scl_sts_w editable false
        dashboard_set_property $dash_path dash_scl_sts_w text "0"
     
        dashboard_add          $dash_path dash_scl_sts_h text grp_scaling 
        dashboard_set_property $dash_path dash_scl_sts_h label "in height" 
        dashboard_set_property $dash_path dash_scl_sts_h expandableX false
        dashboard_set_property $dash_path dash_scl_sts_h expandableY false
        dashboard_set_property $dash_path dash_scl_sts_h preferredWidth 50
        dashboard_set_property $dash_path dash_scl_sts_h htmlCapable false
        dashboard_set_property $dash_path dash_scl_sts_h editable false
        dashboard_set_property $dash_path dash_scl_sts_h text "0"

        dashboard_add          $dash_path dash_scl_cfg_sx text grp_scaling 
        dashboard_set_property $dash_path dash_scl_cfg_sx label "sx" 
        dashboard_set_property $dash_path dash_scl_cfg_sx expandableX false
        dashboard_set_property $dash_path dash_scl_cfg_sx expandableY false
        dashboard_set_property $dash_path dash_scl_cfg_sx preferredWidth 50
        dashboard_set_property $dash_path dash_scl_cfg_sx htmlCapable false
        dashboard_set_property $dash_path dash_scl_cfg_sx editable false
        dashboard_set_property $dash_path dash_scl_cfg_sx text "0"
     
        dashboard_add          $dash_path dash_scl_cfg_sy text grp_scaling 
        dashboard_set_property $dash_path dash_scl_cfg_sy label "sy" 
        dashboard_set_property $dash_path dash_scl_cfg_sy expandableX false
        dashboard_set_property $dash_path dash_scl_cfg_sy expandableY false
        dashboard_set_property $dash_path dash_scl_cfg_sy preferredWidth 50
        dashboard_set_property $dash_path dash_scl_cfg_sy htmlCapable false
        dashboard_set_property $dash_path dash_scl_cfg_sy editable false
        dashboard_set_property $dash_path dash_scl_cfg_sy text "0"


        dashboard_add          $dash_path dash_tpg_cfg_active checkBox grp_tpg         
        dashboard_set_property $dash_path dash_tpg_cfg_active text "-active"

        dashboard_add          $dash_path dash_tpg_cfg_clkdiv text grp_tpg 
        dashboard_set_property $dash_path dash_tpg_cfg_clkdiv label "-clkdiv"
        dashboard_set_property $dash_path dash_tpg_cfg_clkdiv preferredWidth 30
        dashboard_set_property $dash_path dash_tpg_cfg_clkdiv text "0"

        dashboard_add          $dash_path dash_tpg_cfg_w text grp_tpg 
        dashboard_set_property $dash_path dash_tpg_cfg_w label "-width"
        dashboard_set_property $dash_path dash_tpg_cfg_w preferredWidth 50
        dashboard_set_property $dash_path dash_tpg_cfg_w text "0"

        dashboard_add          $dash_path dash_tpg_cfg_h text grp_tpg 
        dashboard_set_property $dash_path dash_tpg_cfg_h label "-height"
        dashboard_set_property $dash_path dash_tpg_cfg_h preferredWidth 50
        dashboard_set_property $dash_path dash_tpg_cfg_h text "0"

        dashboard_add          $dash_path dash_tpg_cfg_back comboBox grp_tpg 
        dashboard_set_property $dash_path dash_tpg_cfg_back label "-background"
        dashboard_set_property $dash_path dash_tpg_cfg_back options { "all" "off" "gradient H" "gradient V" "gradient" "colorbar" "checker" }
        dashboard_set_property $dash_path dash_tpg_cfg_back expandableX false
        dashboard_set_property $dash_path dash_tpg_cfg_back expandableY false
        dashboard_set_property $dash_path dash_tpg_cfg_back preferredWidth 70
        dashboard_set_property $dash_path dash_tpg_cfg_back selected 2; # gradient H   

        dashboard_add          $dash_path dash_tpg_cfg_fore comboBox grp_tpg 
        dashboard_set_property $dash_path dash_tpg_cfg_fore label "-foreground"
        dashboard_set_property $dash_path dash_tpg_cfg_fore options { "all" "off" "bounds" "scrollbar H" "scrollbar V" }
        dashboard_set_property $dash_path dash_tpg_cfg_fore expandableX false
        dashboard_set_property $dash_path dash_tpg_cfg_fore expandableY false
        dashboard_set_property $dash_path dash_tpg_cfg_fore preferredWidth 70
        dashboard_set_property $dash_path dash_tpg_cfg_fore selected 3; # scrollbar H   


      # =========== CVI ================================================  

        dashboard_add          $dash_path cvi_grp_sts group grp_cvi
        dashboard_set_property $dash_path cvi_grp_sts expandableX false
        dashboard_set_property $dash_path cvi_grp_sts expandableY true
        dashboard_set_property $dash_path cvi_grp_sts itemsPerRow 1
        dashboard_set_property $dash_path cvi_grp_sts title " "

        dashboard_add          $dash_path grp_clock group grp_cvi
        dashboard_set_property $dash_path grp_clock expandableX false
        dashboard_set_property $dash_path grp_clock expandableY true
        dashboard_set_property $dash_path grp_clock itemsPerRow 1
        dashboard_set_property $dash_path grp_clock title " "
 
        dashboard_add          $dash_path grp_stream group grp_cvi
        dashboard_set_property $dash_path grp_stream expandableX false
        dashboard_set_property $dash_path grp_stream expandableY true
        dashboard_set_property $dash_path grp_stream itemsPerRow 1
        dashboard_set_property $dash_path grp_stream title " "

        dashboard_add          $dash_path dash_cvi_cfg_run checkBox cvi_grp_sts 
        dashboard_set_property $dash_path dash_cvi_cfg_run enabled true
        dashboard_set_property $dash_path dash_cvi_cfg_run text "-Run"
       
     #  dashboard_add          $dash_path dash_cvi_sts_busy checkBox cvi_grp_sts
     #  dashboard_set_property $dash_path dash_cvi_sts_busy text "busy"
     #  dashboard_set_property $dash_path dash_cvi_sts_busy enabled false

        dashboard_add          $dash_path dash_cvi_sts_ia_overflow checkBox cvi_grp_sts
        dashboard_set_property $dash_path dash_cvi_sts_ia_overflow text "ia-overflow"

        dashboard_add          $dash_path dash_cvi_sts_ia_locked_changed checkBox cvi_grp_sts
        dashboard_set_property $dash_path dash_cvi_sts_ia_locked_changed text "ia-locked changed"

        dashboard_add          $dash_path dash_cvi_sts_locked_pin checkBox grp_clock
        dashboard_set_property $dash_path dash_cvi_sts_locked_pin text "locked input"
        dashboard_set_property $dash_path dash_cvi_sts_locked_pin visible true

        dashboard_add          $dash_path dash_cvi_sts_locked_width checkBox grp_clock
        dashboard_set_property $dash_path dash_cvi_sts_locked_width text "locked width"
 
        dashboard_add          $dash_path dash_cvi_sts_locked_height checkBox grp_clock
        dashboard_set_property $dash_path dash_cvi_sts_locked_height text "locked height"

        dashboard_add          $dash_path dash_cvi_sts_interlaced checkBox grp_clock
        dashboard_set_property $dash_path dash_cvi_sts_interlaced text "interlaced"
        dashboard_set_property $dash_path dash_cvi_sts_interlaced visible true

        dashboard_add          $dash_path dash_cvi_frame_width text grp_stream 
        dashboard_set_property $dash_path dash_cvi_frame_width label "width" 
        dashboard_set_property $dash_path dash_cvi_frame_width expandableX false
        dashboard_set_property $dash_path dash_cvi_frame_width expandableY false
        dashboard_set_property $dash_path dash_cvi_frame_width preferredWidth 50
        dashboard_set_property $dash_path dash_cvi_frame_width editable false
        dashboard_set_property $dash_path dash_cvi_frame_width htmlCapable false
        dashboard_set_property $dash_path dash_cvi_frame_width text "0"

        dashboard_add          $dash_path dash_cvi_frame_height text grp_stream 
        dashboard_set_property $dash_path dash_cvi_frame_height label "height" 
        dashboard_set_property $dash_path dash_cvi_frame_height expandableX false
        dashboard_set_property $dash_path dash_cvi_frame_height expandableY false
        dashboard_set_property $dash_path dash_cvi_frame_height preferredWidth 50
        dashboard_set_property $dash_path dash_cvi_frame_height editable false
        dashboard_set_property $dash_path dash_cvi_frame_height htmlCapable false
        dashboard_set_property $dash_path dash_cvi_frame_height text "0"

        dashboard_add          $dash_path dash_cvi_frame_count text grp_stream 
        dashboard_set_property $dash_path dash_cvi_frame_count label "frame count" 
        dashboard_set_property $dash_path dash_cvi_frame_count expandableX false
        dashboard_set_property $dash_path dash_cvi_frame_count expandableY false
        dashboard_set_property $dash_path dash_cvi_frame_count preferredWidth 50
        dashboard_set_property $dash_path dash_cvi_frame_count editable false
        dashboard_set_property $dash_path dash_cvi_frame_count htmlCapable false
        dashboard_set_property $dash_path dash_cvi_frame_count text "0"

        dashboard_add          $dash_path dash_cvi_used_peak text grp_stream 
        dashboard_set_property $dash_path dash_cvi_used_peak label "pixel buffer -  peak used" 
        dashboard_set_property $dash_path dash_cvi_used_peak expandableX false
        dashboard_set_property $dash_path dash_cvi_used_peak expandableY false
        dashboard_set_property $dash_path dash_cvi_used_peak preferredWidth 50
        dashboard_set_property $dash_path dash_cvi_used_peak editable false
        dashboard_set_property $dash_path dash_cvi_used_peak htmlCapable false
        dashboard_set_property $dash_path dash_cvi_used_peak text "0"


      # =========== VSC ================================================  

    #   dashboard_add          $dash_path dash_vsc_base text grp_capture 
    #   dashboard_set_property $dash_path dash_vsc_base label "vsc device Base" 
    #   dashboard_set_property $dash_path dash_vsc_base expandableX false
    #   dashboard_set_property $dash_path dash_vsc_base expandableY false
    #   dashboard_set_property $dash_path dash_vsc_base preferredWidth 80
    #   dashboard_set_property $dash_path dash_vsc_base editable false
    #   dashboard_set_property $dash_path dash_vsc_base htmlCapable false
    #   dashboard_set_property $dash_path dash_vsc_base text [ format 0x%x [ expr ${::cgx_video::VSC_CSR_DEV_BASE} ] ]

        dashboard_add          $dash_path dash_vsc_cfg_run checkBox grp_capture1 
        dashboard_set_property $dash_path dash_vsc_cfg_run enabled true
        dashboard_set_property $dash_path dash_vsc_cfg_run text "-Run"
      
        dashboard_add          $dash_path dash_vsc_sts_busy checkBox grp_capture1
        dashboard_set_property $dash_path dash_vsc_sts_busy text "busy"

        dashboard_add          $dash_path dash_vsc_sts_ia_frame_completed checkBox grp_capture1
        dashboard_set_property $dash_path dash_vsc_sts_ia_frame_completed text "ia-frame completed"

        dashboard_add          $dash_path dash_vsc_sts_ia_video_changed checkBox grp_capture1
        dashboard_set_property $dash_path dash_vsc_sts_ia_video_changed text "ia-video changed"

        dashboard_add          $dash_path dash_vsc_writer_width text grp_capture2 
        dashboard_set_property $dash_path dash_vsc_writer_width label "width" 
        dashboard_set_property $dash_path dash_vsc_writer_width expandableX false
        dashboard_set_property $dash_path dash_vsc_writer_width expandableY false
        dashboard_set_property $dash_path dash_vsc_writer_width preferredWidth 50
        dashboard_set_property $dash_path dash_vsc_writer_width editable false
        dashboard_set_property $dash_path dash_vsc_writer_width htmlCapable false
        dashboard_set_property $dash_path dash_vsc_writer_width text "0"

        dashboard_add          $dash_path dash_vsc_writer_height text grp_capture2 
        dashboard_set_property $dash_path dash_vsc_writer_height label "height" 
        dashboard_set_property $dash_path dash_vsc_writer_height expandableX false
        dashboard_set_property $dash_path dash_vsc_writer_height expandableY false
        dashboard_set_property $dash_path dash_vsc_writer_height preferredWidth 50
        dashboard_set_property $dash_path dash_vsc_writer_height editable false
        dashboard_set_property $dash_path dash_vsc_writer_height htmlCapable false
        dashboard_set_property $dash_path dash_vsc_writer_height text "0"

        dashboard_add          $dash_path dash_vsc_frame_count text grp_capture2
        dashboard_set_property $dash_path dash_vsc_frame_count label "frame count" 
        dashboard_set_property $dash_path dash_vsc_frame_count expandableX false
        dashboard_set_property $dash_path dash_vsc_frame_count expandableY false
        dashboard_set_property $dash_path dash_vsc_frame_count preferredWidth 50
        dashboard_set_property $dash_path dash_vsc_frame_count editable false
        dashboard_set_property $dash_path dash_vsc_frame_count htmlCapable false
        dashboard_set_property $dash_path dash_vsc_frame_count text "0"

        dashboard_add          $dash_path dash_sfctl_base text grp_capture2 
        dashboard_set_property $dash_path dash_sfctl_base label "sfctl" 
        dashboard_set_property $dash_path dash_sfctl_base expandableX false
        dashboard_set_property $dash_path dash_sfctl_base expandableY false
        dashboard_set_property $dash_path dash_sfctl_base preferredWidth 80
        dashboard_set_property $dash_path dash_sfctl_base editable false
        dashboard_set_property $dash_path dash_sfctl_base htmlCapable false
        dashboard_set_property $dash_path dash_sfctl_base text [ format 0x%x ${::cgx_video::VSC_CSR_DEV_BASE_SFCTRL} ]
          
        dashboard_add          $dash_path dash_vsc_cfg_mirror checkBox grp_rotate         
        dashboard_set_property $dash_path dash_vsc_cfg_mirror text "-Mirror"
        dashboard_set_property $dash_path dash_vsc_cfg_mirror enabled true
     
        dashboard_add          $dash_path dash_vsc_cfg_flip_h checkBox grp_rotate         
        dashboard_set_property $dash_path dash_vsc_cfg_flip_h text "-Horizontal flip"
        dashboard_set_property $dash_path dash_vsc_cfg_flip_h enabled true
     
        dashboard_add          $dash_path dash_vsc_cfg_flip_v checkBox grp_rotate         
        dashboard_set_property $dash_path dash_vsc_cfg_flip_v text "-Vertical flip"
        dashboard_set_property $dash_path dash_vsc_cfg_flip_v enabled true

       
     #  after idle ::cgx_video::dash_update

        puts stdout " ${::cgx_video::IPCORE_LABEL} dashBoard end"

        return -code ok
    }
        
    proc dash_init_device {} {
      
        set ::cgx_video::debug 1

        cgx_video::init -1  
      # cgx_video::dash_get_config
        cgx_video::dash_get_status

        set ::cgx_video::debug 0
    }


    proc dash_dump_device {} {

        cgx_video::dump  

    }


    proc dash_get_caps {} {
      
        set ::cgx_video::debug 1

        cgx_video::get_caps   
        cgx_video::get_capture_caps

        set ::cgx_video::debug 0
    }


    proc dash_set_config {} {

        set ::cgx_video::debug 1
       
        cgx_video::set_clocked -1
        cgx_video::set_pattern -1 -1 -1 -1 -1 -1  
        cgx_video::set_banding -1  
        cgx_video::set_cropping -1 -1 -1 -1 -1  
        cgx_video::set_scaling  -1 -1 -1 -1
        cgx_video::set_capture -1 -1
       
        set ::cgx_video::debug 0  
    }
    
   
    proc dash_get_status {} {

        set ::cgx_video::debug 1

        cgx_video::get_clocked_sts          
        cgx_video::get_clocked_cfg  
        cgx_video::get_pattern 1 
        cgx_video::get_banding 1 
        cgx_video::get_cropping 1 
        cgx_video::get_scaling 1
        cgx_video::get_capture_cfg    
        cgx_video::get_capture_sts   
        cgx_video::get_capture_writer 1

        set ::cgx_video::debug 0
    }


    proc dash_clr_status {} {

        set ::cgx_video::debug 1

        cgx_video::clr_clocked          
        cgx_video::clr_capture    

        set ::cgx_video::debug 0        
    }


 #  proc dash_run_status {} {
 #
 #  # TODO
 #
 #  }

   
  # proc dash_update {} {
  #
  #     if { ${::cgx_video::dashboardActive} > 0 } {
  #  
  #         if { ${::cgx_video::initialized} > 0 } {
  #
  #             ::cgx_video::dash_get_config
  #             ::cgx_video::dash_get_status
  #
  #         }
  #     }
  # }
}

    
    
