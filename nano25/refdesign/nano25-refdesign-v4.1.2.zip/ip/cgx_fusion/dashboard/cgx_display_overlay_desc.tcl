

# layer_set_geometry disabled 

# cgx_display_desc::layer_get_ptr            { id desc_base }  
# cgx_display_desc::reg_set_field            { id field_reg32 field_name field_val }  	
# cgx_display_desc::reg_get_field            { id field_reg32 field_name }  	
# cgx_display_desc::write_addr_hw            { ptr8 addr8 }  
                                             
# cgx_display_desc::init                     { desc_memory_base8 desc_memory_base8_dpy desc_memory_size8 quiet }  
# cgx_display_desc::layer_dump               { id }  
# cgx_display_desc::layer_add                { }  	
# cgx_display_desc::layer_set_surface        { id sfc_name clut_start_idx ptr_next }
# cgx_display_desc::layer_set_class          { id class }  
# cgx_display_desc::layer_set_visible        { id visible }  
# cgx_display_desc::layer_set_alpha          { id alpha }  
# cgx_display_desc::layer_set_chroma_keying  { id on_off }  
# cgx_display_desc::layer_set_colorkey       { id r g b }  
# cgx_display_desc::layer_set_colortransform { id scl_a scl_r scl_g scl_b bias_a bias_r bias_g bias_b }  
# cgx_display_desc::layer_set_geometry       { id screen_id src_x src_y src_w src_h dst_x dst_y dst_w dst_h }  
# cgx_display_desc::layer_set_mask           { id is_a_mask color_plane color_invert } 
# cgx_display_desc::layer_set_masked         { id is_masked } 
# cgx_display_desc::layer_view_bbox          { id on_off }  

# olds
# cgx_display_desc::layer_set_video          { id video_id }  	
 	 
 	  
namespace eval cgx_display_desc {


    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    variable FCT_ALL    0
    variable FCT_GEO    1
    variable FCT_CLK    2
    variable FCT_ALPHA  3
    variable FCT_CT     4


 #  variable anim_alpha 255


   #variable dash_monitor_mtx 0
 #  variable user_matrix
 #
 #  variable caps_ena_debug            0 
 #  variable caps_ena_stream           0
 #  variable caps_ena_vsync            0
 #  variable caps_ena_resizing         0
 #  variable caps_ena_filtering_h      0
 #  variable caps_ena_filtering_v      0
 #  variable caps_ena_transparency     0
 #  variable caps_ena_color_lut        0
 #  variable caps_ena_color_extended   0
 #  variable caps_ena_color_transform  0
 #  variable caps_ena_color_background 0
 #  variable caps_ena_extended_addr    0
 #  variable caps_ena_masking          0
 #
 #  variable caps_num_layer            0
 #  variable caps_num_clut             0
 #  variable caps_num_screen           0
 #  variable caps_num_stream           0
 #  variable caps_num_vsync            0
 #
 #  variable cfg_run            0
 #  variable cfg_scan_h         0
 #  variable cfg_scan_v         0
 #  variable cfg_vumeter        0

    #-------------------------- SYS------------------------------

    # RAM may be dual-port, meaning controller (JTAP master) and display controller have individual base address for slave interface.
    variable DESC_MEM_BASE8     0x0; # base address for JTAG
    variable DESC_MEM_BASE8_DPY 0x0; # base address for display

    variable DESC_MEM_SIZE8   0x0; 
    variable DESC_ADD_NEXT_ID 0x0; 
 


    #-------------------------- HAL------------------------------

    # 0:  enable  info stdout   
    # 1:  disable info stdout
    variable QUIET 0


    #-------------------------- HAL------------------------------

    variable DPY_DSC_LAYER_REG_ID                 0                                                                      
    variable DPY_DSC_LAYER_REG_SRC_POS            1                                                                      
    variable DPY_DSC_LAYER_REG_BBOX_RECT_BASE     2                                                                                        
    variable DPY_DSC_LAYER_REG_BBOX_RECT_END      3                                                                                        
    variable DPY_DSC_LAYER_REG_BBOX_CLIP_BASE     4                                                                                        
    variable DPY_DSC_LAYER_REG_BBOX_CLIP_END      5                                                                                        
    variable DPY_DSC_LAYER_REG_SCALEX             6                                                                                        
    variable DPY_DSC_LAYER_REG_SCALEY             7                                                                      
    variable DPY_DSC_LAYER_REG_COLOR_KEY          8                                                                      
    variable DPY_DSC_LAYER_REG_COLOR_TRF          9                                                                      
    variable DPY_DSC_LAYER_PTY_REG_NUMBER        10                                                                      

    variable DPY_DSC_LAYER_REG_SURFACE_BASE      10                                             
    variable DPY_DSC_LAYER_REG_NUMBER            16  


                                                                                                                                                                                     
    variable DPY_DSC_LAYER_NEXT_MSK              0xFF
    variable DPY_DSC_LAYER_NEXT_OFST             0
    variable DPY_DSC_LAYER_NEXT_REG              $DPY_DSC_LAYER_REG_ID
    
    variable DPY_DSC_LAYER_CLASS_MSK             0x100
    variable DPY_DSC_LAYER_CLASS_OFST            8
    variable DPY_DSC_LAYER_CLASS_REG             $DPY_DSC_LAYER_REG_ID
    
    variable DPY_DSC_LAYER_CLASS_SURFACE         0; # layer src data is a framebuffer defined by "fb_" prefixed parameters) */
    variable DPY_DSC_LAYER_CLASS_SOLIDCOLOR      1; # layer src data is a solidcolor defined by key-color                   */
    variable DPY_DSC_LAYER_CLASS_NUMBER          2
    
    variable DPY_DSC_LAYER_VISIBLE_MSK           0x400
    variable DPY_DSC_LAYER_VISIBLE_OFST          10   
    variable DPY_DSC_LAYER_VISIBLE_REG           $DPY_DSC_LAYER_REG_ID
  
    variable DPY_DSC_LAYER_CRITICAL_PRIMARY_MSK  0x1000
    variable DPY_DSC_LAYER_CRITICAL_PRIMARY_OFST 12
    variable DPY_DSC_LAYER_CRITICAL_PRIMARY_REG  DPY_DSC_LAYER_REG_ID
  
    variable DPY_DSC_LAYER_CRITICAL_AUX_MSK      0x2000
    variable DPY_DSC_LAYER_CRITICAL_AUX_OFST     13
    variable DPY_DSC_LAYER_CRITICAL_AUX_REG      DPY_DSC_LAYER_REG_ID
                                                
    variable DPY_DSC_LAYER_CHROMA_KEYING_MSK     0x4000 # chroma keying feature enabling: 0/1 = disabled/enabled */  
    variable DPY_DSC_LAYER_CHROMA_KEYING_OFST    14
    variable DPY_DSC_LAYER_CHROMA_KEYING_REG     $DPY_DSC_LAYER_REG_ID 
  
    variable DPY_DSC_LAYER_VIEW_BBOX_MSK         0x8000 # bbox viewing feature enabling: 0/1 = disabled/enabled 
    variable DPY_DSC_LAYER_VIEW_BBOX_OFST        15
    variable DPY_DSC_LAYER_VIEW_BBOX_REG         $DPY_DSC_LAYER_REG_ID 
                                                
    variable DPY_DSC_LAYER_EN_FILTERING_MSK      0x10000
    variable DPY_DSC_LAYER_EN_FILTERING_OFST     16
    variable DPY_DSC_LAYER_EN_FILTERING_REG      $DPY_DSC_LAYER_REG_ID
                                               
    variable DPY_DSC_LAYER_PRIMARY_TYPE_MSK      0xC00000
    variable DPY_DSC_LAYER_PRIMARY_TYPE_OFST     22
    variable DPY_DSC_LAYER_PRIMARY_TYPE_REG      $DPY_DSC_LAYER_REG_ID
  
        # DSC_LAYER_PRIMARY_TYPE_MSK
        variable DPY_DSC_PRIMARY_TYPE_BITMAP   0           
        variable DPY_DSC_PRIMARY_TYPE_VIDEO    1           
        variable DPY_DSC_PRIMARY_TYPE_GRAPHICS 2           
        variable DPY_DSC_PRIMARY_TYPE_NUMBER   3           
                                                
    variable DPY_DSC_LAYER_PRIMARY_IDX_MSK       0xF000000
    variable DPY_DSC_LAYER_PRIMARY_IDX_OFST      24
    variable DPY_DSC_LAYER_PRIMARY_IDX_REG       $DPY_DSC_LAYER_REG_ID
                                                
    variable DPY_DSC_LAYER_SCREEN_IDX_MSK        0xF0000000
    variable DPY_DSC_LAYER_SCREEN_IDX_OFST       28
    variable DPY_DSC_LAYER_SCREEN_IDX_REG        $DPY_DSC_LAYER_REG_ID
      
    variable DPY_DSC_LAYER_SCREEN_ALL_MSK        0x80000000            
    variable DPY_DSC_LAYER_SCREEN_ALL_OFST       31                    
    variable DPY_DSC_LAYER_SCREEN_ALL_REG        $DPY_DSC_LAYER_REG_ID  
   
        
    variable DPY_DSC_COLOR_KEY_B_MSK             0xFF
    variable DPY_DSC_COLOR_KEY_B_OFST            0
    variable DPY_DSC_COLOR_KEY_G_MSK             0xFF00
    variable DPY_DSC_COLOR_KEY_G_OFST            8
    variable DPY_DSC_COLOR_KEY_R_MSK             0xFF0000
    variable DPY_DSC_COLOR_KEY_R_OFST            16
    variable DPY_DSC_COLOR_KEY_REG               $DPY_DSC_LAYER_REG_COLOR_KEY
  
  
    variable DPY_DSC_COLOR_MUL_B_MSK             0xFF
    variable DPY_DSC_COLOR_MUL_B_OFST            0
    variable DPY_DSC_COLOR_MUL_G_MSK             0xFF00
    variable DPY_DSC_COLOR_MUL_G_OFST            8
    variable DPY_DSC_COLOR_MUL_R_MSK             0xFF0000
    variable DPY_DSC_COLOR_MUL_R_OFST            16
    variable DPY_DSC_COLOR_MUL_A_MSK             0xFF000000
    variable DPY_DSC_COLOR_MUL_A_OFST            24
    variable DPY_DSC_COLOR_MUL_REG               $DPY_DSC_LAYER_REG_COLOR_TRF


    # DPY_DSC_LAYER_REG_SRC_POS
    variable DPY_DSC_LAYER_SIZE16_H_MSK   0xFFFF
    variable DPY_DSC_LAYER_SIZE16_H_OFST  0                                   
    variable DPY_DSC_LAYER_SIZE16_V_MSK   0xFFFF0000
    variable DPY_DSC_LAYER_SIZE16_V_OFST  16
  
    # DPY_DSC_LAYER_REG_SCALEX                                                                                                      
    # DPY_DSC_LAYER_REG_SCALEY                                                                        
    variable DPY_DSC_LAYER_SCALE_MSK   0xFFFFFF
    variable DPY_DSC_LAYER_SCALE_OFST  0
     
  
    variable DPY_DSC_LAYER_SRC_X_MSK      $DPY_DSC_LAYER_SIZE16_H_MSK
    variable DPY_DSC_LAYER_SRC_X_OFST     $DPY_DSC_LAYER_SIZE16_H_OFST
    variable DPY_DSC_LAYER_SRC_X_REG      $DPY_DSC_LAYER_REG_SRC_POS
    
    variable DPY_DSC_LAYER_SRC_Y_MSK      $DPY_DSC_LAYER_SIZE16_V_MSK
    variable DPY_DSC_LAYER_SRC_Y_OFST     $DPY_DSC_LAYER_SIZE16_V_OFST
    variable DPY_DSC_LAYER_SRC_Y_REG      $DPY_DSC_LAYER_REG_SRC_POS

 

  
    #--------------------------private functions ------------------------------


    # byte address
    proc layer_get_ptr { id desc_base } {

        set ofst_layer     [ expr  ${id}      * 4 * ${::cgx_display_desc::DSC_LAYER_REG_NUMBER} ]
        set ofst_layer_nxt [ expr (${id} + 1) * 4 * ${::cgx_display_desc::DSC_LAYER_REG_NUMBER} ]

      # puts stdout "ofst_layer = ${ofst_layer}"
      # puts stdout "ofst_layer_nxt = ${ofst_layer_nxt}"
      
        if { ${ofst_layer_nxt} > ${::cgx_display_desc::DESC_MEM_SIZE8} } {
            puts stdout "memory overflow with id# ${id}"
            return -1     
        } else {
            return [ expr $desc_base + $ofst_layer ]
        }
    }


    proc reg_set_field { id field_reg32 field_name field_val } {

        set base_layer [layer_get_ptr ${id} ${::cgx_display_desc::DESC_MEM_BASE8} ]  
    
        if { $base_layer < 0 } {
            return -1
        } else {

    
            set str_field_reg32 ::cgx_display_desc::$field_name\_REG 
            set str_field_msk   ::cgx_display_desc::$field_name\_MSK 
            set str_field_ofst  ::cgx_display_desc::$field_name\_OFST

            if { $field_reg32 != -1 } {
                set str_field_reg32 ::cgx_display_desc::$field_reg32 
            } 
            
            set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
            
          # puts stdout "field_reg32  = $field_reg32 "
          # puts stdout "field_msk    = $field_msk "
          # puts stdout "field_ofst   = $field_ofst"
         
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
         
            open_service master ${::boardInit::masterPath}
         
            set reg32 [ master_read_32 ${::boardInit::masterPath} [ expr ${base_layer} + 4 * ${field_reg32} ] 1 ]         
         #  set reg32 0xFFFFFFFF
     
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
         
          # puts stdout "inverted_mask = $inverted_mask"
          # puts stdout "reg32         = $reg32"
          # puts stdout "reg32_masked  = $reg32_masked"
          # puts stdout "reg32_new     = $reg32_new"
     
            master_write_32 ${::boardInit::masterPath} [ expr ${base_layer} + 4 * ${field_reg32} ] $reg32_new
         
	          close_service master ${::boardInit::masterPath}
    
            if { ${::cgx_display_desc::QUIET} == 0 } {
                puts stdout "field $field_name set to $field_val"
            }
            
        }

    }



    # write address to the ptr location
    # hardware address format is:
    # 32-bits address with 64 bits range (low + high)
    proc write_addr_hw { ptr8 addr8 } {

        open_service master ${::boardInit::masterPath}
     
        # hardware address in bytes
        set hw_addr8 [ expr 1 * ${addr8} ]
 
        # write low 
        master_write_32 ${::boardInit::masterPath} [ expr ${ptr8} + 0 ] [ expr ($hw_addr8 >>  0) & 0xFFFFFFFF ]
        # write high 
        master_write_32 ${::boardInit::masterPath} [ expr ${ptr8} + 4 ] [ expr ($hw_addr8 >> 32) & 0xFFFFFFFF ]

	      close_service master ${::boardInit::masterPath}

    }


    #--------------------------public functions ------------------------------
       

    # base address, size (in bytes)
    # return descriptor list memory address  
    proc init { desc_memory_base8 desc_memory_base8_dpy desc_memory_size8 quiet } {

        set ::cgx_display_desc::QUIET $quiet
        set ::cgx_display_desc::DESC_MEM_BASE8     ${desc_memory_base8} 
        set ::cgx_display_desc::DESC_MEM_BASE8_DPY ${desc_memory_base8_dpy} 
        set ::cgx_display_desc::DESC_MEM_SIZE8     ${desc_memory_size8} 

        return [ expr ${::cgx_display_desc::DESC_MEM_BASE8_DPY} + ${::cgx_display_desc::DSC_LAYER_REG_BASE_L} ]  

      # puts stdout "desc base = ${::cgx_display_desc::DESC_MEM_BASE8}"
    }


    proc layer_dump { id } {

        # layer byte address
        set base_layer [ layer_get_ptr $id ${::cgx_display_desc::DESC_MEM_BASE8} ]  

        if { $base_layer < 0 } {
            return -1
        } else {
            open_service master ${::boardInit::masterPath}
            set dump [ master_read_32 ${::boardInit::masterPath} ${base_layer} ${::cgx_display_desc::DSC_LAYER_REG_NUMBER} ]
            puts stdout $dump
	          close_service master ${::boardInit::masterPath}
        }

    }


    proc layer_add { } {
    
        set id ${::cgx_display_desc::DESC_ADD_NEXT_ID}

        # layer byte address
        set base_layer [ layer_get_ptr $id ${::cgx_display_desc::DESC_MEM_BASE8} ]

        # puts stdout "base_layer = $base_layer "
  
        if { $base_layer < 0 } {

            return -1

        } else {

            open_service master ${::boardInit::masterPath}

            for { set i 0 } { ${i} < ${::cgx_display_desc::DSC_LAYER_REG_NUMBER} } { incr i } {
                master_write_32 ${::boardInit::masterPath} [ expr $base_layer + 4 * ${i} ] 0x0
            }

	          close_service master ${::boardInit::masterPath}

            # signature
            set dpy_base_layer [ layer_get_ptr $id ${::cgx_display_desc::DESC_MEM_BASE8_DPY} ]      

            write_addr_hw [ expr $base_layer + 4 * ${::cgx_display_desc::DSC_LAYER_REG_BASE_L}] $dpy_base_layer
            write_addr_hw [ expr $base_layer + 4 * ${::cgx_display_desc::DSC_LAYER_REG_UP_L}] 0x0
            write_addr_hw [ expr $base_layer + 4 * ${::cgx_display_desc::DSC_LAYER_REG_DOWN_L}] 0x0
            write_addr_hw [ expr $base_layer + 4 * ${::cgx_display_desc::DSC_LAYER_REG_NEXT_L}] 0x0
            
            if { ${id} != 0 } {
            
                # JTAG ptr
                set base_layer_prev     [layer_get_ptr [ expr ${id} - 1 ] ${::cgx_display_desc::DESC_MEM_BASE8} ]
                # DPY ptr
                set dpy_base_layer_prev [layer_get_ptr [ expr ${id} - 1 ] ${::cgx_display_desc::DESC_MEM_BASE8_DPY} ]
            
                write_addr_hw [ expr $base_layer_prev + 4 * ${::cgx_display_desc::DSC_LAYER_REG_NEXT_L}] $dpy_base_layer
                write_addr_hw [ expr $base_layer      + 4 * ${::cgx_display_desc::DSC_LAYER_REG_PREV_L}] $dpy_base_layer_prev
            
            } else {
                write_addr_hw [ expr $base_layer      + 4 * ${::cgx_display_desc::DSC_LAYER_REG_PREV_L}] 0x0
            }

            puts stdout "layer #$id ready"
            
            # increase layer list 
            set ::cgx_display_desc::DESC_ADD_NEXT_ID [ expr $id + 1 ] 
        }

    }

 #  proc layer_set_video { id video_id } {
 #
 #    reg_set_field $id -1 DSC_LAYER_VIDEO_ID $video_id 
 #
 #  }


   # set surface 
    proc layer_set_surface { id sfc_name clut_start_idx ptr_next } {
         
        array set desc {} 

        cgx_surface::surface_set_desc desc $sfc_name $clut_start_idx $ptr_next   

        set base_layer [layer_get_ptr ${id} ${::cgx_display_desc::DESC_MEM_BASE8} ]  

        if { $base_layer < 0 } {
            return -1
        } else {

            open_service master ${::boardInit::masterPath}     

            for {set i 0} { $i<${::cgx_surface::DESC_REG_NUMBER} } {incr i} {
                master_write_32 ${::boardInit::masterPath} [ expr $base_layer + 4* [ expr ${::cgx_display_desc::DPY_DSC_LAYER_REG_SURFACE_BASE} +$i ] ] $desc($i)
            }

	          close_service master ${::boardInit::masterPath}
        }

    #   reg_set_field $id DSC_LAYER_SURFACE_COLOR     $color 
    #   reg_set_field $id DSC_LAYER_SURFACE_HSTRIDE   $stride 
    #   # tmp
    #   reg_set_field $id DSC_LAYER_SURFACE_CLUT_START_IDX 0x0
    #
    #
    #   if { ${ptr_next} < 0 } {
    #
    #     reg_set_field $id DSC_LAYER_SURFACE_VIDEO_ENA 1
    #     reg_set_field $id DSC_LAYER_SURFACE_VSTRIDE   $stride_buffer 
    #     # apply first buffer base address
    #     set data_base $base 
    #
    #   } else {
    #
    #     reg_set_field $id DSC_LAYER_SURFACE_VIDEO_ENA 0
    #     reg_set_field $id DSC_LAYER_SURFACE_VSTRIDE 0 
    #
    #     if { $ptr_next < $nb_buffer } {
    #
    #       # compute target buffer base address
    #       set data_base [ expr $base + ($ptr_next * $stride_buffer) ]  
    #
    #     } else {
    #       set data_base $base
    #       puts "ERROR: surface buffer invalid" 
    #     }
    #
    #   }
    #    
    #   # set buffer address
    #   set base_layer [ layer_get_ptr $id ${::cgx_display_desc::DESC_MEM_BASE8} ]
    #   write_addr_hw [ expr $base_layer + 4 * ${::cgx_display_desc::DSC_LAYER_REG_ADDR_L}] $data_base

        # set SURFACE properties (class, geometry)
        layer_set_class  $id ${cgx_display_desc::DPY_DSC_LAYER_CLASS_SURFACE} 
        
        set width         $::cgx_surface::surface($sfc_name,width);   
        set height        $::cgx_surface::surface($sfc_name,height);   
    #   layer_set_geometry $id 0 0 0 $width $height 0 0 $width $height  

    }


    # DPY_DSC_LAYER_CLASS_SURFACE                                                                                           
    # DPY_DSC_LAYER_CLASS_SOLIDCOLOR                                                                                        
    proc layer_set_class { id class } {
        reg_set_field $id -1 DSC_LAYER_CLASS $class  
    }

    # DSC_LAYER_OFF            
    # DSC_LAYER_ON             
    # DSC_LAYER_ON_IF_VIDEO_ON 
    # DSC_LAYER_ON_IF_VIDEO_OFF
    proc layer_set_visible { id visible } {
        reg_set_field $id -1 DSC_LAYER_VISIBLE $visible 
    }

    proc layer_set_chroma_keying { id on_off } {
        reg_set_field $id -1 DSC_LAYER_CHROMA_KEYING $on_off 
    }

    proc layer_view_bbox { id on_off } {
        reg_set_field $id -1 DSC_LAYER_VIEW_BBOX $on_off 
    }

    proc layer_set_alpha { id alpha } {
        reg_set_field $id -1 DSC_ALPHA $alpha 
    }

    proc layer_set_colorkey { id r g b } {
        reg_set_field $id DPY_DSC_COLOR_KEY_REG DPY_DSC_COLOR_KEY_R $r 
        reg_set_field $id DPY_DSC_COLOR_KEY_REG DPY_DSC_COLOR_KEY_G $g 
        reg_set_field $id DPY_DSC_COLOR_KEY_REG DPY_DSC_COLOR_KEY_B $b 
    }


    # 
    proc layer_set_colortransform { id scl_a scl_r scl_g scl_b bias_a bias_r bias_g bias_b } {
        reg_set_field $id -1 DSC_COLOR_TRANSFORM_SCALE_A $scl_a 
        reg_set_field $id -1 DSC_COLOR_TRANSFORM_SCALE_R $scl_r 
        reg_set_field $id -1 DSC_COLOR_TRANSFORM_SCALE_G $scl_g 
        reg_set_field $id -1 DSC_COLOR_TRANSFORM_SCALE_B $scl_b 

        reg_set_field $id -1 DSC_COLOR_TRANSFORM_BIAS_A $bias_a 
        reg_set_field $id -1 DSC_COLOR_TRANSFORM_BIAS_R $bias_r 
        reg_set_field $id -1 DSC_COLOR_TRANSFORM_BIAS_G $bias_g 
        reg_set_field $id -1 DSC_COLOR_TRANSFORM_BIAS_B $bias_b 
    }


    # is_a_mask: 1 when layer produces alpha-mask
    # color_plane: color plane selection for mask layer (is_a_mask=1): 0/1/2/3 = A/R/G/B
    # color_invert: 1 to invert the selected color plane
    proc layer_set_mask { id is_a_mask color_plane color_invert } {
        reg_set_field $id -1 DSC_LAYER_IS_A_MASK         $is_a_mask 
        reg_set_field $id -1 DSC_LAYER_MASK_COLOR_PLANE  $color_plane 
        reg_set_field $id -1 DSC_LAYER_MASK_COLOR_INVERT $color_invert 
    }

    # is_masked: 1 when current alpha-mask applies to the layer
    proc layer_set_masked { id is_masked } {
        reg_set_field $id -1 DSC_LAYER_IS_MASKED $is_masked 
    }



  # proc layer_set_geometry { id screen_id src_x src_y dst_x dst_y dst_w dst_h } {
  #
  #     reg_set_field $id DSC_LAYER_SCREEN_ID $screen_id
  #
  #     reg_set_field $id DSC_LAYER_SRC_X $src_x 
  #     reg_set_field $id DSC_LAYER_SRC_Y $src_y 
  #
  #     reg_set_field $id DSC_LAYER_HW_WIDTH $dst_w 
  #     reg_set_field $id DSC_LAYER_HW_XMIN $dst_x 
  #     reg_set_field $id DSC_LAYER_HW_XMAX [ expr $dst_x + $dst_w ] 
  #     reg_set_field $id DSC_LAYER_HW_YMIN $dst_y 
  #     reg_set_field $id DSC_LAYER_HW_YMAX [ expr $dst_y + $dst_h ]
  #
  #     reg_set_field $id DSC_LAYER_GEOMETRY_INVALID 0
  #
  #     reg_set_field $id DSC_LAYER_CLIP_DX 0 
  #     reg_set_field $id DSC_LAYER_CLIP_DY 0 
  #     reg_set_field $id DSC_LAYER_SCALEX 0x100 
  #     reg_set_field $id DSC_LAYER_SCALEY 0x100 
  #
  # }

    # assumes that the destination geometry is inside the screen geometry (no screen clipping is computed)
    proc layer_set_geometry { id screen_id src_x src_y src_w src_h dst_x dst_y dst_w dst_h } {

        
        if { $dst_w < 0 } {
          set dst_w $src_w
        } 
            
        if { $dst_h < 0 } {
          set dst_h $src_h
        } 
          
        reg_set_field $id -1 DSC_LAYER_SCREEN_ID $screen_id

        reg_set_field $id -1 DSC_LAYER_SRC_X $src_x 
        reg_set_field $id -1 DSC_LAYER_SRC_Y $src_y 

        # assuming no screen/layer clipping
        reg_set_field $id -1 DSC_LAYER_CLIP_DX 0 
        reg_set_field $id -1 DSC_LAYER_CLIP_DY 0 


        reg_set_field $id DSC_LAYER_REG_RECT_H DSC_LAYER_POS  $dst_x 
        reg_set_field $id DSC_LAYER_REG_RECT_V DSC_LAYER_POS  $dst_y 
        reg_set_field $id DSC_LAYER_REG_RECT_H DSC_LAYER_SIZE $dst_w 
        reg_set_field $id DSC_LAYER_REG_RECT_V DSC_LAYER_SIZE $dst_h 

        reg_set_field $id -1 DSC_LAYER_GEOMETRY_INVALID 0

      # reg_set_field $id -1 DSC_LAYER_SCALEX 0x10000 
      # reg_set_field $id -1 DSC_LAYER_SCALEY 0x10000 
        reg_set_field $id DPY_DSC_LAYER_REG_SCALEX DSC_LAYER_SCALE [ expr $src_w * 256 * 256 / $dst_w ] 
        reg_set_field $id DPY_DSC_LAYER_REG_SCALEY DSC_LAYER_SCALE [ expr $src_h * 256 * 256 / $dst_h ] 

    }
   
        
   
    proc dashBoard {} {

        if { ${::cgx_display_desc::dashboardActive} == 1 } {
            return -code ok "dashboard already active"
        }

        set ::cgx_display_desc::dashboardActive 1
        #
        # Create dashboard 
        #
        variable ::cgx_display_desc::dash_path [ add_service dashboard cgx_display_desc "cgx_display_desc" "Tools/DISPLAY CONTROLLER"]

        #
        # Set dashboard properties
        #
        dashboard_set_property ${::cgx_display_desc::dash_path} self developmentMode true
        dashboard_set_property ${::cgx_display_desc::dash_path} self itemsPerRow 1
        dashboard_set_property ${::cgx_display_desc::dash_path} self visible true
        
        #
        # top group widget
        #
        dashboard_add          ${::cgx_display_desc::dash_path} grp_top group self
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_top expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_top expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_top itemsPerRow 3
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_top title ""

 
        dashboard_add          ${::cgx_display_desc::dash_path} grp_settings group grp_top
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_settings expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_settings expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_settings itemsPerRow 1
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_settings title "Settings"

        dashboard_add          ${::cgx_display_desc::dash_path} grp_anim group grp_top
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_anim expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_anim expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_anim itemsPerRow 1
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_anim title "Animations"


        dashboard_add          ${::cgx_display_desc::dash_path} mon_anim_param comboBox grp_anim 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_param options { "ALPHA" "KEY_R" "KEY_G" "KEY_B" "MUL_A" "MUL_R" "MUL_G" "MUL_B" "ADD_A" "ADD_R" "ADD_G" "ADD_B" "SRC_X" "SRC_Y" "SRC_W" "SRC_H" "DST_X" "DST_Y" "DST_W" "DST_H" }
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_param enabled true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_param expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_param expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_param label ""
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_param selected 0

        dashboard_add          ${::cgx_display_desc::dash_path} mon_anim_inc text grp_anim 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_inc label "increment"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_inc expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_inc expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_inc preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_inc editable true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_inc htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_inc text "8"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_anim_run checkBox grp_anim         
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_run text "Run"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_run enabled true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_anim_run onClick { ::cgx_display_desc::dash_update_anim }  

        dashboard_add          ${::cgx_display_desc::dash_path} mon_layer_id text grp_top 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_layer_id label "layer ID"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_layer_id expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_layer_id expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_layer_id preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_layer_id editable true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_layer_id htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_layer_id text "0"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_class comboBox grp_settings 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_class options { "surface" "solidcolor" "stream" }
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_class enabled true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_class expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_class expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_class label "class"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_class selected 1

        dashboard_add          ${::cgx_display_desc::dash_path} chroma_keying checkBox grp_settings         
        dashboard_set_property ${::cgx_display_desc::dash_path} chroma_keying text "chroma keying"
        dashboard_set_property ${::cgx_display_desc::dash_path} chroma_keying enabled true
 
        dashboard_add          ${::cgx_display_desc::dash_path} mon_visible comboBox grp_settings 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_visible options { "OFF" "ON" "ON_IF_VIDEO_ON" "ON_IF_VIDEO_OFF" }
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_visible enabled true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_visible expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_visible expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_visible label "visibility"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_visible selected 1

        dashboard_add          ${::cgx_display_desc::dash_path} mon_alpha text grp_settings 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_alpha label "alpha"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_alpha expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_alpha expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_alpha preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_alpha editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_alpha htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_alpha text "255"

 

        dashboard_add          ${::cgx_display_desc::dash_path} grp_masking group grp_settings
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_masking expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_masking expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_masking itemsPerRow 2
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_masking title "Masking"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_masked checkBox grp_masking         
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_masked text "masked"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_masked enabled true

        dashboard_add          ${::cgx_display_desc::dash_path} mon_mask checkBox grp_masking         
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask text "mask"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask enabled true

        dashboard_add          ${::cgx_display_desc::dash_path} mon_mask_color_plane comboBox grp_masking 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask_color_plane options { "A" "R" "G" "B" }
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask_color_plane enabled true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask_color_plane expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask_color_plane expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask_color_plane label "color plane"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask_color_plane selected 0

        dashboard_add          ${::cgx_display_desc::dash_path} mon_mask_color_invert checkBox grp_masking         
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask_color_invert text "color inversion"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mask_color_invert enabled true

 
 
        dashboard_add          ${::cgx_display_desc::dash_path} grp_colorkey group grp_settings
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_colorkey expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_colorkey expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_colorkey itemsPerRow 3
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_colorkey title "Color key"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_key_r text grp_colorkey 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_r label "R"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_r expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_r expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_r preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_r editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_r htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_r text "00"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_key_g text grp_colorkey 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_g label "G"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_g expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_g expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_g preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_g editable true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_g htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_g text "00"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_key_b text grp_colorkey 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_b label "B"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_b expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_b expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_b preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_b editable true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_b htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_b text "00"




        dashboard_add          ${::cgx_display_desc::dash_path} grp_colortransform group grp_settings
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_colortransform expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_colortransform expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_colortransform itemsPerRow 4
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_colortransform title "Color transform"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_mul_a text grp_colortransform 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_a label "MUL A"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_a expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_a expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_a preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_a editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_a htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_a text "256"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_mul_r text grp_colortransform 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_r label "MUL R"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_r expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_r expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_r preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_r editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_r htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_r text "256"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_mul_g text grp_colortransform 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_g label "MUL G"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_g expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_g expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_g preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_g editable true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_g htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_g text "256"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_mul_b text grp_colortransform 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_b label "MUL B"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_b expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_b expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_b preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_b editable true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_b htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_b text "256"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_add_a text grp_colortransform 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_a label "ADD A"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_a expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_a expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_a preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_a editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_a htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_a text "00"
                                                                    
        dashboard_add          ${::cgx_display_desc::dash_path} mon_add_r text grp_colortransform 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_r label "ADD R"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_r expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_r expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_r preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_r editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_r htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_r text "00"
                                                                   
        dashboard_add          ${::cgx_display_desc::dash_path} mon_add_g text grp_colortransform 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_g label "ADD G"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_g expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_g expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_g preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_g editable true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_g htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_g text "00"
                                                                    
        dashboard_add          ${::cgx_display_desc::dash_path} mon_add_b text grp_colortransform 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_b label "ADD B"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_b expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_b expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_b preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_b editable true
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_b htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_b text "00"


        dashboard_add          ${::cgx_display_desc::dash_path} grp_geometry group grp_settings
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_geometry expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_geometry expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_geometry itemsPerRow 4
        dashboard_set_property ${::cgx_display_desc::dash_path} grp_geometry title "Geometry"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_src_x text grp_geometry 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_x label "src X"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_x expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_x expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_x preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_x editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_x htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_x text "0"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_src_y text grp_geometry 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_y label "src Y"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_y expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_y expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_y preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_y editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_y htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_y text "0"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_src_w text grp_geometry 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_w label "src W"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_w expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_w expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_w preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_w editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_w htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_w text "100"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_src_h text grp_geometry 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_h label "src H"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_h expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_h expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_h preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_h editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_h htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_src_h text "100"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_dst_x text grp_geometry 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_x label "dst X"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_x expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_x expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_x preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_x editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_x htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_x text "0"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_dst_y text grp_geometry 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_y label "dst Y"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_y expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_y expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_y preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_y editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_y htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_y text "0"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_dst_w text grp_geometry 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_w label "dst W"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_w expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_w expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_w preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_w editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_w htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_w text "100"

        dashboard_add          ${::cgx_display_desc::dash_path} mon_dst_h text grp_geometry 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_h label "dst H"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_h expandableX false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_h expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_h preferredWidth 70
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_h editable true 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_h htmlCapable false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_dst_h text "100"

 
        dashboard_add          ${::cgx_display_desc::dash_path} mon_cfg_set button grp_settings 
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_cfg_set enabled true
      # dashboard_set_property ${::cgx_display_desc::dash_path} mon_cfg_set expandableY false
      # dashboard_set_property ${::cgx_display_desc::dash_path} mon_cfg_set expandableY false
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_cfg_set text "Set"
        dashboard_set_property ${::cgx_display_desc::dash_path} mon_cfg_set onClick { ::cgx_display_desc::dash_update_config ${::cgx_display_desc::FCT_ALL} }  

      # ::cgx_display_desc::dash_update_config
      # ::cgx_display_desc::dash_update_status
         
      # after idle ::cgx_display_desc::dash_update

        return -code ok
    }


    proc dash_update_anim {} {

        set anim_run [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_anim_run checked ]  
        
        if { $anim_run == false } {

            set cgx_display_desc::QUIET 0 

        } else {
     
            set cgx_display_desc::QUIET 1 
     
            set layer_id [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_layer_id text ]
     
         #  set anim_alpha ${::cgx_display_desc::anim_alpha} 
    
            set anim_param [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_anim_param selected ]

            set anim_val_inc [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_anim_inc text ] 

            	      set anim_val_min 0 
            	      set anim_val_max 255 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_alpha text ]

            switch $anim_param {
            	  # "ALPHA"
            	  0 { 
            	      set anim_val_min 0 
            	      set anim_val_max 255 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_alpha text ]
                }
            	  # "KEY_R"
            	  1 { 
            	      set anim_val_min 0 
            	      set anim_val_max 255 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_key_r text ]
                }
            	  # "KEY_G"
            	  2 { 
            	      set anim_val_min 0 
            	      set anim_val_max 255 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_key_g text ]
                }
            	  # "KEY_B"
            	  3 { 
            	      set anim_val_min 0 
            	      set anim_val_max 255 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_key_b text ]
                }
            	  # "MUL_A"
            	  4 { 
            	      set anim_val_min -256 
            	      set anim_val_max 256 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mul_a text ]
                }
            	  # "MUL_R"
            	  5 { 
            	      set anim_val_min -256 
            	      set anim_val_max 256 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mul_r text ]
                }
            	  # "MUL_G"
            	  6 { 
            	      set anim_val_min -256 
            	      set anim_val_max 256 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mul_g text ]
                }
            	  # "MUL_B"
            	  7 { 
            	      set anim_val_min -256 
            	      set anim_val_max 256 
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mul_b text ]
                }
            	  # "ADD_A"
            	  8 { 
            	      set anim_val_min -128 
            	      set anim_val_max 127
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_add_a text ]
                }
            	  # "ADD_R"
            	  9 { 
            	      set anim_val_min -128 
            	      set anim_val_max 127
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_add_r text ]
                }
            	  # "ADD_G"
            	  10 { 
            	      set anim_val_min -128 
            	      set anim_val_max 127
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_add_g text ]
                }
            	  # "ADD_B"
            	  11 { 
            	      set anim_val_min -128 
            	      set anim_val_max 127
            	      set anim_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_add_b text ]
                }
            }

            set anim_val [ expr $anim_val + $anim_val_inc ]
            if { $anim_val > $anim_val_max } {
            	  set anim_val $anim_val_min
            } 
            

            switch $anim_param {
            	  # "ALPHA"
            	  0 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_alpha text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_ALPHA} 
                }
            	  # "KEY_R"
            	  1 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_r text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CLK} 
                }
            	  # "KEY_G"
            	  2 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_g text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CLK} 
                }
            	  # "KEY_B"
            	  3 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_key_b text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CLK}  
                }
            	  # "MUL_A"
            	  4 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_a text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CT} 
                }
            	  # "MUL_R"
            	  5 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_r text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CT} 
                }
            	  # "MUL_G"
            	  6 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_g text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CT} 
                }
            	  # "MUL_B"
            	  7 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_mul_b text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CT} 
                }
            	  # "ADD_A"
            	  8 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_a text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CT} 
                }
            	  # "ADD_R"
            	  9 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_r text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CT} 
                }
            	  # "ADD_G"
            	  10 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_g text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CT} 
                }
            	  # "ADD_B"
            	  11 { 
            	      dashboard_set_property ${::cgx_display_desc::dash_path} mon_add_b text "$anim_val"
            	      set fct_id ${::cgx_display_desc::FCT_CT} 
                }
            }
            
            ::cgx_display_desc::dash_update_config $fct_id
                 
            after 10 ::cgx_display_desc::dash_update_anim

        }
    }


    proc dash_update_config { fct_id } {


        set layer_id [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_layer_id text ]

        #=========================================
        if { $fct_id == 0 } {  
            set cfg_on 0
            if { [ dashboard_get_property ${::cgx_display_desc::dash_path} chroma_keying checked ] == true } {
                set cfg_on 1
            }
            cgx_display_desc::layer_set_chroma_keying $layer_id $cfg_on
        }      
        #=========================================
        if { $fct_id == 0 || $fct_id == ${::cgx_display_desc::FCT_CLK} } {  
            set cfg_key_r  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_key_r text ]
            set cfg_key_g  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_key_g text ]
            set cfg_key_b  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_key_b text ]
            cgx_display_desc::layer_set_colorkey $layer_id $cfg_key_r $cfg_key_g $cfg_key_b    
        }      
        #=========================================
        if { $fct_id == 0 || $fct_id == ${::cgx_display_desc::FCT_ALPHA} } {  
            set cfg_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_alpha text ]
            cgx_display_desc::layer_set_alpha $layer_id $cfg_val 
        }      
        #=========================================
        if { $fct_id == 0 || $fct_id == ${::cgx_display_desc::FCT_CT} } {  
            set cfg_mul_a  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mul_a text ]
            set cfg_mul_r  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mul_r text ]
            set cfg_mul_g  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mul_g text ]
            set cfg_mul_b  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mul_b text ]
            set cfg_bias_a [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_add_a text ]
            set cfg_bias_r [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_add_r text ]
            set cfg_bias_g [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_add_g text ]
            set cfg_bias_b [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_add_b text ]
            cgx_display_desc::layer_set_colortransform $layer_id $cfg_mul_a $cfg_mul_r $cfg_mul_g $cfg_mul_b $cfg_bias_a $cfg_bias_r $cfg_bias_g $cfg_bias_b   
        }      
        #=========================================
        if { $fct_id == 0 } {  
            set cfg_on 0
            if { [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_masked checked ] == true } {
                set cfg_on 1
            }
            cgx_display_desc::layer_set_masked $layer_id $cfg_on;                        
        }      
        #=========================================
        if { $fct_id == 0 } {  
            set cfg_mask_on 0
            if { [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mask checked ] == true } {
                set cfg_mask_on 1
            }
            set cfg_mask_color_invert 0
            if { [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mask_color_invert checked ] == true } {
                set cfg_mask_color_invert 1
            }
            set cfg_mask_color_plane [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_mask_color_plane selected ]
            
            cgx_display_desc::layer_set_mask $layer_id $cfg_mask_on $cfg_mask_color_plane $cfg_mask_color_invert   
        }      
        #=========================================
        if { $fct_id == 0 } {  

            set cfg_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_visible selected ]
            
            switch $cfg_val {
            	  0 { 
            	      set visible ${cgx_display_desc::DSC_LAYER_OFF} 
                }
            	  1 { 
            	      set visible ${cgx_display_desc::DSC_LAYER_ON} 
                }
            	  2 { 
            	      set visible ${cgx_display_desc::DSC_LAYER_ON_IF_VIDEO_ON} 
                }
            	  3 { 
            	      set visible ${cgx_display_desc::DSC_LAYER_ON_IF_VIDEO_OFF} 
                }
            }
            
            cgx_display_desc::layer_set_visible $layer_id $visible  
        } 
        
        #=========================================
        if { $fct_id == 0 } {  

            set cfg_val [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_class selected ]
            
            switch $cfg_val {
            	  0 { 
            	      set class ${cgx_display_desc::DPY_DSC_LAYER_CLASS_SURFACE} 
                }
            	  1 { 
            	      set class ${cgx_display_desc::DPY_DSC_LAYER_CLASS_SOLIDCOLOR} 
                }
            	# 2 { 
            	#     set class ${cgx_display_desc::DSC_LAYER_CLASS_STREAM} 
              # }
            }
            
            cgx_display_desc::layer_set_class $layer_id $class  
        } 
             
        #=========================================
        if { $fct_id == 0 || $fct_id == ${::cgx_display_desc::FCT_GEO} } { 

            set screen_id 0
            
            set src_x  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_src_x text ]
            set src_y  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_src_y text ]
            set src_w  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_src_w text ]
            set src_h  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_src_h text ]
            set dst_x  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_dst_x text ]
            set dst_y  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_dst_y text ]
            set dst_w  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_dst_w text ]
            set dst_h  [ dashboard_get_property ${::cgx_display_desc::dash_path} mon_dst_h text ]
            
         #  cgx_display_desc::layer_set_geometry $layer_id $screen_id $src_x $src_y $src_w $src_h $dst_x $dst_y $dst_w $dst_h;  
        }      
        #=========================================
        imt_display::desc_start [ expr ${::cgx_display_desc::DESC_MEM_BASE8_DPY} + ${::cgx_display_desc::DSC_LAYER_REG_BASE_L} ]

        
    }
    
       
}

  