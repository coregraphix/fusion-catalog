
# cgx_mem::init           { instance_idx }
# cgx_mem::get_version    { }
# cgx_mem::get_caps       { quiet }
# cgx_mem::set_config     { run max_pending_rd max_pending_wr }
# cgx_mem::get_config     { }
# cgx_mem::set_interrupt  { ie_bitfield }
# cgx_mem::get_interrupt  { } 
# cgx_mem::get_status     { }
# cgx_mem::clr_status     { }
# cgx_mem::dbg_set_config { trig_mode trig_sig }
# cgx_mem::dbg_get_config { }
# cgx_mem::dbg_get_counts { }
# cgx_mem::dump           { }
# cgx_mem::dashBoard      { }
 

namespace eval cgx_mem {


    variable IPCORE_PRODUCT 68; # = 0x44 	                                                                                          
    variable IPCORE_VERSION ${::cgx_fusion::IPCORE_VERSION}                                                                                          
    variable IPCORE_LABEL "MEM"

    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    # debug mode
    # 0 => console 
    # 1 => dashboard (+console) 
    variable debug 0

    variable dash_run 0


    #-------------------------- SYS------------------------------

    variable MEM_CSR_DEV_BASE  0x00000000
    variable initialized 0

    # 0:  enable  info stdout   
    # 1:  disable info stdout
    variable QUIET 0
        
    #-------------------------- HAL------------------------------
      
    variable MEM_CSR_REG_VERSION          0
    variable MEM_CSR_REG_CAPS             1
    variable MEM_CSR_REG_INTERRUPT        2
    variable MEM_CSR_REG_CFG              3
    variable MEM_CSR_REG_STS              4
    variable MEM_CSR_REG_DBG_MODE         5
    variable MEM_CSR_REG_DBG_CHANNEL      6
    variable MEM_CSR_REG_DBG_CLOCK_RATE   7
    variable MEM_CSR_REG_DBG_COUNT_CLK    8
  # variable MEM_CSR_REG_DBG_COUNT_MAX    9
    variable MEM_CSR_REG_DBG_SELECT_WR   10
    variable MEM_CSR_REG_DBG_SELECT_RD   11
    variable MEM_CSR_REG_DBG_TOTAL_WR    12
    variable MEM_CSR_REG_DBG_TOTAL_RD    13
    variable MEM_CSR_REG_NUMBER          16

    # /* MEM_CSR_REG_VERSION fields */
    
    variable MEM_VERSION_ID_MSK     0xFF      
    variable MEM_VERSION_ID_OFST    0         
    variable MEM_VERSION_BUILD_MSK  0xFF00    
    variable MEM_VERSION_BUILD_OFST 8         
    variable MEM_VERSION_MINOR_MSK  0xFF0000   
    variable MEM_VERSION_MINOR_OFST 16        
    variable MEM_VERSION_MAJOR_MSK  0x0F000000   
    variable MEM_VERSION_MAJOR_OFST 24        


    # /* MEM_CSR_REG_CAPS fields */

    variable MEM_CAPS_ENABLE_DEBUG_MSK   0x1      
    variable MEM_CAPS_ENABLE_DEBUG_OFST  0         
    variable MEM_CAPS_NUM_WR_MSK         0xF0000      
    variable MEM_CAPS_NUM_WR_OFST        16         
    variable MEM_CAPS_NUM_RD_MSK         0xF00000      
    variable MEM_CAPS_NUM_RD_OFST        20         
    variable MEM_CAPS_NUM_BYTES_MSK      0xFF000000      
    variable MEM_CAPS_NUM_BYTES_OFST     24         

 
    # /* MEM_CSR_REG_INTERRUPT fields */
 
    variable MEM_INTERRUPT_ENABLE_MSK      0xFF  
 	  variable MEM_INTERRUPT_ENABLE_OFST     0
 
        # /* interrupt bits                                                  */
        # /* to be used for enable bits (MEM_INTERRUPT_ENABLE_MSK) and   */
        # /*                active bits (MEM_STS_IRQ_ACTIVE_MSK)      */  
        variable MEM_IRQ_BIT_ERROR_RD_MSK  0x1; #                                                                                          
        variable MEM_IRQ_BIT_ERROR_RD_OFST 0                                                       
        variable MEM_IRQ_BIT_ERROR_WR_MSK  0x2; #                                                                                                             
        variable MEM_IRQ_BIT_ERROR_WR_OFST 1                           

  #/* MEM_CSR_REG_CFG fields */

	  variable MEM_CFG_RUN_MSK              0x1                                     
		variable MEM_CFG_RUN_OFST             0                                       
   #variable MEM_CFG_FIRST_RD_ENA_MSK     0x10                                     
   #variable MEM_CFG_FIRST_RD_ENA_OFST    4                                       
   #variable MEM_CFG_FIRST_WR_ENA_MSK     0x20                                     
   #variable MEM_CFG_FIRST_WR_ENA_OFST    5                                       
   #variable MEM_CFG_ENA_CMD_PENDING_MSK  0x40                                    
   #variable MEM_CFG_ENA_CMD_PENDING_OFST 6                                       
   #variable MEM_CFG_MAX_CMD_PENDING_MSK  0xFF00                                     
   #variable MEM_CFG_MAX_CMD_PENDING_OFST 8                                       
   #variable MEM_CFG_FIRST_RD_IDX_MSK     0xF0000                                   
   #variable MEM_CFG_FIRST_RD_IDX_OFST    16                                      
   #variable MEM_CFG_FIRST_WR_IDX_MSK     0xF00000                                   
   #variable MEM_CFG_FIRST_WR_IDX_OFST    20                                       
	  variable MEM_CFG_MAX_PENDING_RD_MSK   0xFF0000                                     
		variable MEM_CFG_MAX_PENDING_RD_OFST  16                                       
	  variable MEM_CFG_MAX_PENDING_WR_MSK   0xFF000000                                     
		variable MEM_CFG_MAX_PENDING_WR_OFST  24                                       

 
  #/* MEM_CSR_REG_STS fields */

    variable MEM_STS_IRQ_MSK         0x2
    variable MEM_STS_IRQ_OFST        1
    variable MEM_STS_BUSY_RD_MSK     0x10
    variable MEM_STS_BUSY_RD_OFST    4
    variable MEM_STS_BUSY_WR_MSK     0x20
    variable MEM_STS_BUSY_WR_OFST    5
    variable MEM_STS_MAX_POST_MSK    0xFFC0
    variable MEM_STS_MAX_POST_OFST   6
    variable MEM_STS_IRQ_ACTIVE_MSK  0xFF0000  
  	variable MEM_STS_IRQ_ACTIVE_OFST 16


   #/* MEM_CSR_REG_DBG_MODE fields */

	  variable MEM_DBG_TRIG_MSK   0x3                                 
		variable MEM_DBG_TRIG_OFST  0                                      
	  variable MEM_DBG_EXT_MSK    0xF0                                 
		variable MEM_DBG_EXT_OFST   4                                      

     #// MEM_DBG_TRIG_MSK
      variable MEM_TRIG_NO     0 
      variable MEM_TRIG_1S     1 
      variable MEM_TRIG_EXT    2 
      variable MEM_TRIG_NUMBER 3 

	  ##variable MEM_CFG_TRIG_MSK          0x300000                                 
		##variable MEM_CFG_TRIG_OFST         20                                      
	  ##variable MEM_CFG_EXT_MSK           0xF000000                                 
		##variable MEM_CFG_EXT_OFST          24                                      


   #/* MEM_CSR_REG_DBG_CHANNEL fields */
    
	  variable MEM_DBG_INDEX_MSK  0xF                                 
	  variable MEM_DBG_INDEX_OFST 0                                      


  # !!! register value = value / 1024  
    variable MEM_VAL32_MSK  0xFFFFFFFF  
		variable MEM_VAL32_OFST 0

    # compute the Byte rate 
    proc GET_REG_COUNT { reg need_rate } {
       #set cnt [ expr [ ATH_GET_FIELD $reg MEM_VAL32 ] * 1024 ];                      
        set cnt [ ATH_GET_FIELD $reg MEM_VAL32 ];                      
        if { $need_rate == 0 } {
            return $cnt
        } else {        
            set clk_rate  [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_CLOCK_RATE} ] 0x1]; 
            set clk_cnt   [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_COUNT_CLK} ] 0x1]; 
           #puts "clk_rate = $clk_rate, clk_cnt = $clk_cnt "
            set rate 0
            if { $clk_cnt > 0 } {
              set rate [ expr ($cnt * $clk_rate) / $clk_cnt ]; 
            }
        }    
        return $rate             
    }

       
    #--------------------------private functions ------------------------------

    proc ATH_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_mem::$field_name\_REG 
            set str_field_msk   ::cgx_mem::$field_name\_MSK 
            set str_field_ofst  ::cgx_mem::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc ATH_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_mem::$field_name\_MSK 
        set str_field_ofst ::cgx_mem::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

     
    #--------------------------public functions ------------------------------

 
    proc init { instance_idx } {

      # puts stdout "FUSION-MEM init:"

        if { ${::cgx_mem::debug} == 1 } {
            set dash_path ${::cgx_mem::dash_path} 
           #set dev_base [ dashboard_get_property $dash_path dash_dev_base text ]
            set instance_idx [ dashboard_get_property $dash_path dash_instance_idx text ]  
        } 
                        
       #set ::cgx_mem::MEM_CSR_DEV_BASE ${dev_base} 
        set ::cgx_mem::MEM_CSR_DEV_BASE [ cgx_fusion::get_dev_base ${cgx_fusion::DEF_CLASS_MEM} $instance_idx ]

        if { ${::cgx_mem::debug} == 1 } {
            set dash_path ${::cgx_mem::dash_path} 
            dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_mem::MEM_CSR_DEV_BASE} ]
        } 

        set dev_success [ ::cgx_mem::get_version ];  
        
        if {${dev_success} == 1} {
            set ::cgx_mem::initialized 1
        } else {
            set ::cgx_mem::initialized 0
        } 

        if { ${::cgx_mem::debug} == 1 } {
            set dash_path ${::cgx_mem::dash_path} 
            dashboard_set_property $dash_path grp_csr   visible false
            if {${dev_success} == 1} {
                puts " ${::cgx_mem::IPCORE_LABEL} init successfull "
                dashboard_set_property $dash_path grp_core  visible true
            } else {
            	  puts " ${::cgx_mem::IPCORE_LABEL} ERROR: device init failure "
                dashboard_set_property $dash_path grp_core  visible false
            } 
        } 
    }
       


    proc get_version { } {
        
        set csr_base8 ${::cgx_mem::MEM_CSR_DEV_BASE} 
        
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_mem::MEM_CSR_REG_VERSION} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set v_id    [ ATH_GET_FIELD $reg MEM_VERSION_ID ] ;                              
        set v_build [ ATH_GET_FIELD $reg MEM_VERSION_BUILD ] ;                           
        set v_minor [ ATH_GET_FIELD $reg MEM_VERSION_MINOR ] ;                           
        set v_major [ ATH_GET_FIELD $reg MEM_VERSION_MAJOR ] ;                           
        set version $v_major.$v_minor                            

        if {$v_id == ${::cgx_mem::IPCORE_PRODUCT} } {
          puts " ${::cgx_mem::IPCORE_LABEL} detection successfull, core id = [ format 0x%x $v_id ] "
          puts " ${::cgx_mem::IPCORE_LABEL} Version = $v_major.$v_minor, Build = $v_build"
          if { $version == ${::cgx_mem::IPCORE_VERSION} } {
            set success 1
          } else {
            set success 0
            puts stdout " ${::cgx_mem::IPCORE_LABEL} ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_mem::IPCORE_VERSION} )"
            puts stdout "        please upgrade the dashboard version accordingly to the IP core "
          }
        } else {
          set success 0
          puts stdout " ${::cgx_mem::IPCORE_LABEL} ERROR: device not detected at device base ${::cgx_mem::MEM_CSR_DEV_BASE} "
          puts stdout "        core id = $v_id, reg = $reg "
          puts stdout "        please, set the right device base and press init again "
        }
        return $success

    }

    # /*  fields */

    proc get_caps { quiet } {
        
        set csr_base8 ${::cgx_mem::MEM_CSR_DEV_BASE} 

        open_service master ${::boardInit::masterPath}        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_mem::MEM_CSR_REG_CAPS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set caps_ena_debug  [ ATH_GET_FIELD $reg MEM_CAPS_ENABLE_DEBUG ] ; 
        set caps_num_wr     [ ATH_GET_FIELD $reg MEM_CAPS_NUM_WR ] ; 
        set caps_num_rd     [ ATH_GET_FIELD $reg MEM_CAPS_NUM_RD ] ; 
        set caps_num_bytes  [ ATH_GET_FIELD $reg MEM_CAPS_NUM_BYTES ] ; 
 
        if { $quiet == 0 } {
          puts "                                                  "
          puts "  Capabilities:                                   "
          puts "      ena_debug  = $caps_ena_debug                "
          puts "      num_wr     = $caps_num_wr                   "
          puts "      num_rd     = $caps_num_rd                   "
          puts "      num_bytes  = $caps_num_bytes                "
          puts "                                                  "                                                                                          
        }

        if { ${::cgx_mem::debug} == 1 } {
            set dash_path ${::cgx_mem::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true                          
        }   
        set ret {}
        lappend ret $caps_ena_debug
        lappend ret $caps_num_wr   
        lappend ret $caps_num_rd   
        lappend ret $caps_num_bytes           
        return $ret           
    }

       
    proc set_config { run max_pending_rd max_pending_wr } {   

        if { ${::cgx_mem::debug} == 1 } {
	          set dash_path ${::cgx_mem::dash_path} 
	          set run 0 
            if { [ dashboard_get_property $dash_path dash_cfg_run checked ] == true } {
                set run 1
            } 
            
          # set trig_mode     [ dashboard_get_property $dash_path dash_mem0_trig_mode    selected ]
          # set trig_sig      [ dashboard_get_property $dash_path dash_mem0_trig_sig     selected ]
            
        #   set first_rd_ena 0
        #   set first_wr_ena 0
        #   if { [ dashboard_get_property $dash_path dash_mem0_first_rd_ena checked ] == true } {
        #       set first_rd_ena 1
        #   } 
        #    if { [ dashboard_get_property $dash_path dash_mem0_first_wr_ena checked ] == true } {
        #       set first_wr_ena 1
        #   } 
        #   set first_rd_idx  [ dashboard_get_property $dash_path dash_mem0_first_rd_idx selected ]
        #   set first_wr_idx  [ dashboard_get_property $dash_path dash_mem0_first_wr_idx selected ]
        #
        #
        #   set ena_pending_cmd 0
        #   if { [ dashboard_get_property $dash_path dash_mem0_ena_pending_cmd checked ] == true } {
        #       set ena_pending_cmd 1
        #   } 
            set max_pending_rd  [ dashboard_get_property $dash_path dash_mem0_max_pending_rd text ]
            set max_pending_wr  [ dashboard_get_property $dash_path dash_mem0_max_pending_wr text ]
        }  

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_CFG} ] 0x1]; 
        set reg [ ATH_SET_FIELD $reg MEM_CFG_RUN $run ]
     #  set reg [ ATH_SET_FIELD $reg MEM_DBG_TRIG $trig_mode ]
     #  set reg [ ATH_SET_FIELD $reg MEM_DBG_EXT $trig_sig ]
        
     #  set reg [ ATH_SET_FIELD $reg MEM_CFG_ENA_CMD_PENDING $ena_pending_cmd ]
        set reg [ ATH_SET_FIELD $reg MEM_CFG_MAX_PENDING_RD $max_pending_rd ]
        set reg [ ATH_SET_FIELD $reg MEM_CFG_MAX_PENDING_WR $max_pending_wr ]
       
     #  set reg [ ATH_SET_FIELD $reg MEM_CFG_FIRST_RD_ENA $first_rd_ena ]
     #  set reg [ ATH_SET_FIELD $reg MEM_CFG_FIRST_WR_ENA $first_wr_ena ]
     #  set reg [ ATH_SET_FIELD $reg MEM_CFG_FIRST_RD_IDX $first_rd_idx ]
     #  set reg [ ATH_SET_FIELD $reg MEM_CFG_FIRST_WR_IDX $first_wr_idx ]
        
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_CFG} ] $reg

	      close_service master ${::boardInit::masterPath}
    }
    
      
    proc get_config { } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_CFG} ] 0x1]; 
        set cfg_run      [ ATH_GET_FIELD $reg MEM_CFG_RUN ] ;                                                                
      # set trig_mode    [ ATH_GET_FIELD $reg MEM_DBG_TRIG ] ;                                                                
      # set trig_sig     [ ATH_GET_FIELD $reg MEM_DBG_EXT ] ;                                                                
      # set first_rd_ena [ ATH_GET_FIELD $reg MEM_CFG_FIRST_RD_ENA ] ; 
      # set first_wr_ena [ ATH_GET_FIELD $reg MEM_CFG_FIRST_WR_ENA ] ; 
      # set first_rd_idx [ ATH_GET_FIELD $reg MEM_CFG_FIRST_RD_IDX ] ; 
      # set first_wr_idx [ ATH_GET_FIELD $reg MEM_CFG_FIRST_WR_IDX ] ; 

      # set ena_pending_cmd [ ATH_GET_FIELD $reg MEM_CFG_ENA_CMD_PENDING ] ; 
        set max_pending_rd [ ATH_GET_FIELD $reg MEM_CFG_MAX_PENDING_RD ] ; 
        set max_pending_wr [ ATH_GET_FIELD $reg MEM_CFG_MAX_PENDING_WR ] ; 
        
	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_mem::debug} == 0 } {
            puts "                                 "
            puts "  config:                        "
            puts "      run            = $cfg_run         "          
            puts "      max_pending_rd = $max_pending_rd  "          
            puts "      max_pending_wr = $max_pending_wr  "          
            puts "                                 "                                                                                                                                                                
        }
        if { ${::cgx_mem::debug} == 1 } {
        	  set dash_path ${::cgx_mem::dash_path} 
 
            if { $cfg_run == 1 } {
               dashboard_set_property $dash_path dash_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_run checked false  
            }        

        #   dashboard_set_property $dash_path dash_mem0_trig_mode selected $trig_mode 
        #   dashboard_set_property $dash_path dash_mem0_trig_sig  selected $trig_sig  

        #   if { $first_rd_ena == 1 } {
        #      dashboard_set_property $dash_path dash_mem0_first_rd_ena checked true  
        #   } else { 
        #      dashboard_set_property $dash_path dash_mem0_first_rd_ena checked false  
        #   }        
        #
        #   if { $first_wr_ena == 1 } {
        #      dashboard_set_property $dash_path dash_mem0_first_wr_ena checked true  
        #   } else { 
        #      dashboard_set_property $dash_path dash_mem0_first_wr_ena checked false  
        #   }        
        #
        #   dashboard_set_property $dash_path dash_mem0_first_rd_idx selected $first_rd_idx 
        #   dashboard_set_property $dash_path dash_mem0_first_wr_idx selected $first_wr_idx     
        #
        #   if { $ena_pending_cmd == 1 } {
        #      dashboard_set_property $dash_path dash_mem0_ena_pending_cmd checked true  
        #   } else { 
        #      dashboard_set_property $dash_path dash_mem0_ena_pending_cmd checked false  
        #   }        
                               
            dashboard_set_property $dash_path dash_mem0_max_pending_rd text $max_pending_rd 
            dashboard_set_property $dash_path dash_mem0_max_pending_wr text $max_pending_wr 
            
        }
        set ret {}
      # lappend ret $trig_mode
      # return $ret           
    }


    proc set_interrupt { ie_bitfield } {

        if { ${::cgx_mem::debug} == 1 } {
	          set dash_path ${::cgx_mem::dash_path} 
            set ie_bitfield 0
	          if { [ dashboard_get_property $dash_path dash_cfg_ie_error_rd checked ] == true } {
                set ie_bitfield [ ATH_SET_FIELD $ie_bitfield MEM_IRQ_BIT_ERROR_RD 1 ]
            } 
            if { [ dashboard_get_property $dash_path dash_cfg_ie_error_wr checked ] == true } {
                set ie_bitfield [ ATH_SET_FIELD $ie_bitfield MEM_IRQ_BIT_ERROR_WR 1 ]
            } 
        }   
        open_service master ${::boardInit::masterPath}
        set reg 0
        set reg [ ATH_SET_FIELD $reg MEM_INTERRUPT_ENABLE $ie_bitfield ]           
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_INTERRUPT} ] $reg
        close_service master ${::boardInit::masterPath}
    }
  
 
    proc get_interrupt { } {
 
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_INTERRUPT} ] 0x1]; 
        set ie_bitfield  [ ATH_GET_FIELD $reg MEM_INTERRUPT_ENABLE ] ;                                                                
 	      close_service master ${::boardInit::masterPath}
 
        if { ${::cgx_mem::debug} == 0 } {
             puts "                                                            "
             puts "  interrupt:                                                "
             puts "         ie_bitfield = $ie_bitfield "      
             puts "                                                            "                                                                                                           
        }
        if { ${::cgx_mem::debug} == 1 } {
        	  set dash_path ${::cgx_mem::dash_path} 
  
            if { [ ATH_GET_FIELD $ie_bitfield MEM_IRQ_BIT_ERROR_RD ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_error_rd checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_error_rd checked false
            }        
            if { [ ATH_GET_FIELD $ie_bitfield MEM_IRQ_BIT_ERROR_WR ] == 1 } {
               dashboard_set_property $dash_path dash_cfg_ie_error_wr checked true
            } else { 
               dashboard_set_property $dash_path dash_cfg_ie_error_wr checked false
            }        
        }
    }


    proc dbg_set_config { trig_mode trig_sig } {   

        if { ${::cgx_mem::debug} == 1 } {
	          set dash_path ${::cgx_mem::dash_path} 
            
            set trig_mode     [ dashboard_get_property $dash_path dash_mem0_trig_mode    selected ]
            set trig_sig      [ dashboard_get_property $dash_path dash_mem0_trig_sig     selected ]
        }  

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_MODE} ] 0x1]; 
        set reg [ ATH_SET_FIELD $reg MEM_DBG_TRIG $trig_mode ]
        set reg [ ATH_SET_FIELD $reg MEM_DBG_EXT $trig_sig ]                
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_MODE} ] $reg

	      close_service master ${::boardInit::masterPath}
    }
    
      
    proc dbg_get_config { } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_MODE} ] 0x1]; 
        set trig_mode    [ ATH_GET_FIELD $reg MEM_DBG_TRIG ] ;                                                                
        set trig_sig     [ ATH_GET_FIELD $reg MEM_DBG_EXT ] ;                                                                
                
	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_mem::debug} == 0 } {
            puts "                              "
            puts "  debug:                      "
            puts "      trig_mode = $trig_mode  "          
            puts "      trig_sig  = $trig_sig   "          
            puts "                              "                                                                                                                                                                
        }
        if { ${::cgx_mem::debug} == 1 } {
        	  set dash_path ${::cgx_mem::dash_path} 
            dashboard_set_property $dash_path dash_mem0_trig_mode selected $trig_mode 
            dashboard_set_property $dash_path dash_mem0_trig_sig  selected $trig_sig                
        }
        set ret {}
        lappend ret $trig_mode
        return $ret           
    }


    proc dbg_get_counts {  } {
 
#        set dash_path ${::cgx_mem::dash_path} 
#
#        set caps [cgx_mem::get_caps 1]
#      # set bytes_num [lindex $caps 3 ]
#        set num_wrs [lindex $caps 1 ]
#        set num_rds [lindex $caps 2 ]
#        set max_total 0
#
#        set cfg [cgx_mem::dbg_get_config] 
#        set trig_mode [lindex $cfg 0 ]
#        # 0=count value, 1=rate
#        set get_rate 1
#        if {${trig_mode} == 0} {
#          set get_rate 0
#        }
#
#        set dash_unit [ dashboard_get_property $dash_path dash_mem0_display_unit selected ]
#      # puts "dash_unit = $dash_unit"
#        switch $dash_unit {
#          0 {
#            set val_unit 1;
#          }                                              
#          1 {
#            set val_unit 1000;
#          }                                              
#          2 {
#            set val_unit 1000000;
#          }                                              
#        }
#        
#        open_service master ${::boardInit::masterPath}             	    
#
#        # debug rate
#      # set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_COUNT_CLK} ] 0x1]; 
#      # set rate [ GET_REG_COUNT $reg ];
#      # dashboard_set_property $dash_path dash_mem0_dbg_rate text [ expr $rate / 1000000  ]  
#        set clk_rate  [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_CLOCK_RATE} ] 0x1]; 
#        set clk_cnt   [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_COUNT_CLK} ] 0x1]; 
#     #  puts "clk_rate = $clk_rate, clk_cnt = $clk_cnt "
#        set rate 0
#        if { $clk_cnt > 0 } {
#          set rate [ expr ($clk_rate) / $clk_cnt ]; 
#        }
#        dashboard_set_property $dash_path dash_mem0_dbg_rate text [ expr $rate ]  
#
#
#    #   # MAX
#    #   set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_COUNT_MAX} ] 0x1]; 
#    #   set cnt [ GET_REG_COUNT $reg $get_rate ]; 
#    #   dashboard_set_property $dash_path dash_mem0_rd_max text [ expr $cnt / $val_unit ] 
#    #   dashboard_set_property $dash_path dash_mem0_wr_max text [ expr $cnt / $val_unit ]         
#
#
#        # read --------------------------- 
#        
#     #  # get empty 
#     #  set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_EMPTY_RD} ] 0x1]; 
#     #  set cnt [ GET_REG_COUNT $reg $get_rate ]; 
#     #  dashboard_set_property $dash_path dash_mem0_rd_empty text [ expr $cnt / $val_unit ] 
#
#        # get total 
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_TOTAL_RD} ] 0x1]; 
#        set cnt [ GET_REG_COUNT $reg $get_rate ]; 
#        dashboard_set_property $dash_path dash_mem0_rd_total text [ expr $cnt / $val_unit ] 
#
#        set cnt_total $cnt
#
#        set chans { }
#        for { set j 0 } { ${j} < $num_rds } { incr j } {   
#            set chan_id $j
#            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_CHANNEL} ] $chan_id;  
#            
#            set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_SELECT_RD} ] 0x1]; 
#          # puts "reg rds = $reg ";
#            set cnt [ GET_REG_COUNT $reg $get_rate ]; 
#            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_cnt text [ expr $cnt / $val_unit ] 
#            lappend chans $cnt
#        }
#
#        for { set j 0 } { ${j} < $num_rds } { incr j } {   
#            # no trig => inconsistent percent 
#            if {${get_rate} == 0} {
#            	  set percent -1
#            } else {
#                set chan_id $j
#                set cnt [lindex $chans ${j} ]
#                if { $cnt_total == 0 } {
#                  set percent 0
#                } else {
#                  set percent [ expr $cnt * 100 / $cnt_total ]
#                }
#            }
#            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_percent text $percent
#        }
#        
#        # write --------------------------- 
#
#     #  # get empty  
#     #  set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_EMPTY_WR} ] 0x1]; 
#     #  set cnt [ GET_REG_COUNT $reg $get_rate ]; 
#     #  dashboard_set_property $dash_path dash_mem0_wr_empty text [ expr $cnt / $val_unit ] 
#
#        # get total  
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_TOTAL_WR} ] 0x1]; 
#        set cnt [ GET_REG_COUNT $reg $get_rate ]; 
#        dashboard_set_property $dash_path dash_mem0_wr_total text [ expr $cnt / $val_unit ] 
#
#        set cnt_total $cnt
#                                
#        set chans { }
#        for { set j 0 } { ${j} < $num_wrs } { incr j } {   
#
#            set chan_id $j
#
#          # set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_CFG} ] 0x1]; 
#          # set reg [ ATH_SET_FIELD $reg MEM_DBG_INDEX $chan_id ]
#            master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_CHANNEL} ] $chan_id; # $reg  
#            
#            set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_DBG_SELECT_WR} ] 0x1]; 
#            set cnt [ GET_REG_COUNT $reg $get_rate ]; 
#            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_cnt text [ expr $cnt / $val_unit ] 
#            lappend chans $cnt
#        }
#        for { set j 0 } { ${j} < $num_wrs } { incr j } {   
#            # no trig => inconsistent percent 
#            if {${get_rate} == 0} {
#            	  set percent -1
#            } else {
#                set chan_id $j
#                set cnt [lindex $chans ${j} ]
#                if { $cnt_total == 0 } {
#                  set percent 0
#                } else {
#                  set percent [ expr $cnt * 100 / $cnt_total ]
#                }
#            }
#            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_percent text $percent
#        }
#                
#        close_service master ${::boardInit::masterPath}
 	  } 
 
 
     proc get_status {  } {
 
         open_service master ${::boardInit::masterPath}
         set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_STS} ] 0x1]; 
 	       close_service master ${::boardInit::masterPath}
 
        #set sts_busy     [ ATH_GET_FIELD $reg MEM_STS_BUSY ] ;                                                                
         set sts_irq      [ ATH_GET_FIELD $reg MEM_STS_IRQ  ] ;                                                                
         set sts_busy_rd  [ ATH_GET_FIELD $reg MEM_STS_BUSY_RD ] ;  
         set sts_busy_wr  [ ATH_GET_FIELD $reg MEM_STS_BUSY_WR ] ;   
         set sts_post_max [ ATH_GET_FIELD $reg MEM_STS_MAX_POST ] ;   
         set sts_irqfield [ ATH_GET_FIELD $reg MEM_STS_IRQ_ACTIVE ] ;                                                                
 
         set sts_ia_error_rd [ ATH_GET_FIELD $sts_irqfield MEM_IRQ_BIT_ERROR_RD ] ;                                                                
         set sts_ia_error_wr [ ATH_GET_FIELD $sts_irqfield MEM_IRQ_BIT_ERROR_WR ] ;                                                                

        # display values 
         if { ${::cgx_mem::debug} == 0 } {
             puts " MEM status:                            "
        #    puts "     busy     = $sts_busy               "             
             puts "     irq      = $sts_irq                "
             puts "     busy_rd  = $sts_busy_rd            "
             puts "     busy_wr  = $sts_busy_wr            "
             puts "     post_max = $sts_post_max           "             
             puts "                                        "
             puts "     interrupt active:                  "
             puts "         ia error_rd = $sts_ia_error_rd "
             puts "         ia error_wr = $sts_ia_error_wr "
             puts "                                        "                                                                                                                                                                
         }

         if { ${::cgx_mem::debug} == 1 } {
         	  set dash_path ${::cgx_mem::dash_path} 
         #   if { $sts_busy == 1 } {
         #      dashboard_set_property $dash_path dash_sts_busy checked true
         #   } else { 
         #      dashboard_set_property $dash_path dash_sts_busy checked false
         #   }        

             dashboard_set_property $dash_path dash_sts_posted text [ expr $sts_post_max ]  
           
             if { $sts_busy_rd == 1 } {
                dashboard_set_property $dash_path dash_sts_busy_rd checked true
             } else { 
                dashboard_set_property $dash_path dash_sts_busy_rd checked false
             }        
         
             if { $sts_busy_wr == 1 } {
                dashboard_set_property $dash_path dash_sts_busy_wr checked true
             } else { 
                dashboard_set_property $dash_path dash_sts_busy_wr checked false
             }        
         
             if { $sts_irq == 1 } {
                 dashboard_set_property $dash_path dash_sts_irq color "red"
             } else {
                 dashboard_set_property $dash_path dash_sts_irq color "black"
             }
         
             if { $sts_ia_error_rd == 1 } {
                dashboard_set_property $dash_path dash_sts_ia_error_rd checked true
             } else { 
                dashboard_set_property $dash_path dash_sts_ia_error_rd checked false
             }        
         
             if { $sts_ia_error_wr == 1 } {
                dashboard_set_property $dash_path dash_sts_ia_error_wr checked true
             } else { 
                dashboard_set_property $dash_path dash_sts_ia_error_wr checked false
             }        
         }
#        set sts {}
#        lappend sts $sts_cnt_max 
#        lappend sts $sts_cnt_nop 
#        lappend sts $sts_cnt_wrs 
#        return $sts           
    }




    # clear all  
    proc clr_status { } {

        open_service master ${::boardInit::masterPath}
        # clear interrupt-active bits
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 4*${::cgx_mem::MEM_CSR_REG_STS} ] 0xFFFFFFFF 
	      close_service master ${::boardInit::masterPath}
    }


    proc dump {  } {

        open_service master ${::boardInit::masterPath}
        set dump [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_mem::MEM_CSR_DEV_BASE} + 0 ] ${::cgx_mem::MEM_CSR_REG_NUMBER} ]
        puts stdout $dump
	      close_service master ${::boardInit::masterPath}

    }


    proc dashBoard { } {

        if { ${::cgx_mem::dashboardActive} == 1 } {
            return -code ok " ${::cgx_mem::IPCORE_LABEL} dashboard already active"
        }

        set ::cgx_mem::dashboardActive 1
        puts stdout " ${::cgx_mem::IPCORE_LABEL} dashBoard start ......."

        #
        # Create dashboard 
        #
        variable ::cgx_mem::dash_path [ add_service dashboard cgx_mem "cgx_mem" "Tools/cgx_mem"]
     
        set dash_path ${::cgx_mem::dash_path} 
     
        #
        # Set dashboard properties
        #
        dashboard_set_property $dash_path self developmentMode true
        dashboard_set_property $dash_path self itemsPerRow 1
        dashboard_set_property $dash_path self visible true
        
        #
        # groups
        #
        dashboard_add          $dash_path grp_top group self
        dashboard_set_property $dash_path grp_top expandableX false
        dashboard_set_property $dash_path grp_top expandableY false
        dashboard_set_property $dash_path grp_top itemsPerRow 1
        dashboard_set_property $dash_path grp_top title ""

        dashboard_add          $dash_path grp_device group grp_top
        dashboard_set_property $dash_path grp_device expandableX false
        dashboard_set_property $dash_path grp_device expandableY false
        dashboard_set_property $dash_path grp_device itemsPerRow 4
        dashboard_set_property $dash_path grp_device title "Device"

        dashboard_add          $dash_path grp_core group grp_top
        dashboard_set_property $dash_path grp_core expandableX false
        dashboard_set_property $dash_path grp_core expandableY false
        dashboard_set_property $dash_path grp_core itemsPerRow 1
        dashboard_set_property $dash_path grp_core title "Core ${::cgx_mem::IPCORE_VERSION}"
        dashboard_set_property $dash_path grp_core visible false; # dashboard init

        dashboard_add          $dash_path grp_core_cmd group grp_core
        dashboard_set_property $dash_path grp_core_cmd expandableX false
        dashboard_set_property $dash_path grp_core_cmd expandableY false
        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_core_cmd title ""

        dashboard_add          $dash_path grp_csr group grp_core
        dashboard_set_property $dash_path grp_csr expandableX false
        dashboard_set_property $dash_path grp_csr expandableY false
        dashboard_set_property $dash_path grp_csr itemsPerRow 1
        dashboard_set_property $dash_path grp_csr title ""
        dashboard_set_property $dash_path grp_csr visible false; # dashboard init

        dashboard_add          $dash_path grp_csr_main group grp_csr
        dashboard_set_property $dash_path grp_csr_main expandableX false
        dashboard_set_property $dash_path grp_csr_main expandableY true
        dashboard_set_property $dash_path grp_csr_main itemsPerRow 4
        dashboard_set_property $dash_path grp_csr_main title ""
 
        dashboard_add          $dash_path grp_config group grp_csr_main
        dashboard_set_property $dash_path grp_config expandableX false
        dashboard_set_property $dash_path grp_config expandableY false
        dashboard_set_property $dash_path grp_config itemsPerRow 1
        dashboard_set_property $dash_path grp_config title "Config"

        dashboard_add          $dash_path grp_cfg_cmd group grp_config
        dashboard_set_property $dash_path grp_cfg_cmd expandableX false
        dashboard_set_property $dash_path grp_cfg_cmd expandableY false
        dashboard_set_property $dash_path grp_cfg_cmd itemsPerRow 2
        dashboard_set_property $dash_path grp_cfg_cmd title ""

        dashboard_add          $dash_path grp_cfg_param0 group grp_config
        dashboard_set_property $dash_path grp_cfg_param0 expandableX false
        dashboard_set_property $dash_path grp_cfg_param0 expandableY false
        dashboard_set_property $dash_path grp_cfg_param0 itemsPerRow 3
        dashboard_set_property $dash_path grp_cfg_param0 title ""

        dashboard_add          $dash_path grp_cfg_irq group grp_config
        dashboard_set_property $dash_path grp_cfg_irq expandableX false
        dashboard_set_property $dash_path grp_cfg_irq expandableY false
        dashboard_set_property $dash_path grp_cfg_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_cfg_irq title "interrupt enable"

        dashboard_add          $dash_path grp_status group grp_csr_main
        dashboard_set_property $dash_path grp_status expandableX false
        dashboard_set_property $dash_path grp_status expandableY false
        dashboard_set_property $dash_path grp_status itemsPerRow 1
        dashboard_set_property $dash_path grp_status title "Status"

        dashboard_add          $dash_path grp_sts_cmd group grp_status
        dashboard_set_property $dash_path grp_sts_cmd expandableX false
        dashboard_set_property $dash_path grp_sts_cmd expandableY false
        dashboard_set_property $dash_path grp_sts_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_cmd title ""

        dashboard_add          $dash_path grp_sts_param group grp_status
        dashboard_set_property $dash_path grp_sts_param expandableX false
        dashboard_set_property $dash_path grp_sts_param expandableY false
        dashboard_set_property $dash_path grp_sts_param itemsPerRow 4
        dashboard_set_property $dash_path grp_sts_param title ""

        dashboard_add          $dash_path grp_sts_irq group grp_status
        dashboard_set_property $dash_path grp_sts_irq expandableX false
        dashboard_set_property $dash_path grp_sts_irq expandableY false
        dashboard_set_property $dash_path grp_sts_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_sts_irq title "interrupt active"

        dashboard_add          $dash_path grp_fct group grp_csr
        dashboard_set_property $dash_path grp_fct expandableX false
        dashboard_set_property $dash_path grp_fct expandableY true
        dashboard_set_property $dash_path grp_fct itemsPerRow 3
        dashboard_set_property $dash_path grp_fct title ""

        dashboard_add          $dash_path grp_mem0 group grp_fct
        dashboard_set_property $dash_path grp_mem0 expandableX false
        dashboard_set_property $dash_path grp_mem0 expandableY true
        dashboard_set_property $dash_path grp_mem0 itemsPerRow 4
        dashboard_set_property $dash_path grp_mem0 title "Memory#0"
 
        #
        # widgets
        #

        dashboard_add          $dash_path dash_instance_idx text grp_device 
        dashboard_set_property $dash_path dash_instance_idx label "Index" 
        dashboard_set_property $dash_path dash_instance_idx expandableX false
        dashboard_set_property $dash_path dash_instance_idx expandableY false
        dashboard_set_property $dash_path dash_instance_idx preferredWidth 30
        dashboard_set_property $dash_path dash_instance_idx editable true
        dashboard_set_property $dash_path dash_instance_idx htmlCapable false
        dashboard_set_property $dash_path dash_instance_idx text 0

        dashboard_add          $dash_path dash_dev_init button grp_device 
        dashboard_set_property $dash_path dash_dev_init enabled true
        dashboard_set_property $dash_path dash_dev_init text "Init"
        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_mem::dash_init_device }  

        dashboard_add          $dash_path dash_dev_dump button grp_device 
        dashboard_set_property $dash_path dash_dev_dump enabled true
        dashboard_set_property $dash_path dash_dev_dump text "Dump"
        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_mem::dash_dump_device }  

        dashboard_add          $dash_path dash_dev_base text grp_device 
        dashboard_set_property $dash_path dash_dev_base label "base" 
        dashboard_set_property $dash_path dash_dev_base expandableX false
        dashboard_set_property $dash_path dash_dev_base expandableY false
        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
        dashboard_set_property $dash_path dash_dev_base editable false
        dashboard_set_property $dash_path dash_dev_base htmlCapable false
        dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_mem::MEM_CSR_DEV_BASE} ]

        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_version enabled true
        dashboard_set_property $dash_path dash_dev_version text "Version"
        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_mem::get_version }  

        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_caps enabled true
        dashboard_set_property $dash_path dash_dev_caps text "Caps"
        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_mem::dash_get_caps }  
        
        dashboard_add          $dash_path dash_cfg_run checkBox grp_cfg_param0 
        dashboard_set_property $dash_path dash_cfg_run enabled false; #true
        dashboard_set_property $dash_path dash_cfg_run text "Run"

        dashboard_add          $dash_path dash_cfg_ie_error_rd checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_error_rd text "error_rd"

        dashboard_add          $dash_path dash_cfg_ie_error_wr checkBox grp_cfg_irq
        dashboard_set_property $dash_path dash_cfg_ie_error_wr text "error_wr"

        dashboard_add          $dash_path dash_cfg_set button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_set enabled true
        dashboard_set_property $dash_path dash_cfg_set text "Set"
        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_mem::dash_set_config }  

        dashboard_add          $dash_path dash_cfg_readback button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_readback enabled true
        dashboard_set_property $dash_path dash_cfg_readback text "Readback"
        dashboard_set_property $dash_path dash_cfg_readback onClick { ::cgx_mem::dash_get_config }  

 
        #
        # monitor /  widgets
        #

        dashboard_add          $dash_path dash_sts_get button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_get enabled true
        dashboard_set_property $dash_path dash_sts_get text "Get"
        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_mem::dash_get_status }  

        dashboard_add          $dash_path dash_sts_clear button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_clear text "Clear"
        dashboard_set_property $dash_path dash_sts_clear onClick { ::cgx_mem::dash_clr_status }  

        dashboard_add          $dash_path dash_sts_run button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_run text "Run"
        dashboard_set_property $dash_path dash_sts_run enabled true
        dashboard_set_property $dash_path dash_sts_run onClick { ::cgx_mem::dash_run_start }  
      
     #  dashboard_add          $dash_path dash_sts_busy checkBox grp_sts_param
     #  dashboard_set_property $dash_path dash_sts_busy text "busy"

        dashboard_add          $dash_path dash_sts_irq led grp_sts_param
        dashboard_set_property $dash_path dash_sts_irq text "irq"
        dashboard_set_property $dash_path dash_sts_irq color "black"

        dashboard_add          $dash_path dash_sts_busy_rd checkBox grp_sts_param
        dashboard_set_property $dash_path dash_sts_busy_rd text "busy rd"
      
        dashboard_add          $dash_path dash_sts_busy_wr checkBox grp_sts_param
        dashboard_set_property $dash_path dash_sts_busy_wr text "busy wr"

        dashboard_add          $dash_path dash_sts_posted text grp_sts_param 
        dashboard_set_property $dash_path dash_sts_posted label "posted" 
        dashboard_set_property $dash_path dash_sts_posted expandableX false
        dashboard_set_property $dash_path dash_sts_posted expandableY false
        dashboard_set_property $dash_path dash_sts_posted preferredWidth 30
        dashboard_set_property $dash_path dash_sts_posted editable false
        dashboard_set_property $dash_path dash_sts_posted htmlCapable false
        dashboard_set_property $dash_path dash_sts_posted text "0"


        dashboard_add          $dash_path dash_sts_ia_error_rd checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_error_rd text "error rd"

        dashboard_add          $dash_path dash_sts_ia_error_wr checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_error_wr text "error wr"

        dashboard_add          $dash_path grp_mem0_cfg group grp_mem0
        dashboard_set_property $dash_path grp_mem0_cfg expandableX false
        dashboard_set_property $dash_path grp_mem0_cfg expandableY false
        dashboard_set_property $dash_path grp_mem0_cfg itemsPerRow 1
        dashboard_set_property $dash_path grp_mem0_cfg title ""
 
        dashboard_add          $dash_path grp_mem0_rd group grp_mem0
        dashboard_set_property $dash_path grp_mem0_rd expandableX false
        dashboard_set_property $dash_path grp_mem0_rd expandableY false
        dashboard_set_property $dash_path grp_mem0_rd itemsPerRow 2
        dashboard_set_property $dash_path grp_mem0_rd title "read (unit/s)"
        dashboard_set_property $dash_path grp_mem0_rd toolTip "Layer(s) => Screen(s) => Graphics(s)"

        dashboard_add          $dash_path grp_mem0_wr group grp_mem0
        dashboard_set_property $dash_path grp_mem0_wr expandableX false
        dashboard_set_property $dash_path grp_mem0_wr expandableY false
        dashboard_set_property $dash_path grp_mem0_wr itemsPerRow 2
        dashboard_set_property $dash_path grp_mem0_wr title "write (unit/s)"
        dashboard_set_property $dash_path grp_mem0_wr toolTip "Video(s) -> Screen(s) -> Graphics(s)"

        dashboard_add          $dash_path dash_mem0_trig_mode comboBox grp_mem0_cfg 
        dashboard_set_property $dash_path dash_mem0_trig_mode label "time"
        dashboard_set_property $dash_path dash_mem0_trig_mode options {"continu" "1s" "signal"}; # same order than MEM_DBG_TRIG_MSK
        dashboard_set_property $dash_path dash_mem0_trig_mode expandableX false
        dashboard_set_property $dash_path dash_mem0_trig_mode expandableY false
        dashboard_set_property $dash_path dash_mem0_trig_mode preferredWidth 20
        dashboard_set_property $dash_path dash_mem0_trig_mode selected 0   

        dashboard_add          $dash_path dash_mem0_trig_sig comboBox grp_mem0_cfg 
        dashboard_set_property $dash_path dash_mem0_trig_sig label "signal"
        dashboard_set_property $dash_path dash_mem0_trig_sig options {"ASG-draw" "ASG-draw2" "VBlank" "no"}; # same order than ? => TODO 
        dashboard_set_property $dash_path dash_mem0_trig_sig expandableX false
        dashboard_set_property $dash_path dash_mem0_trig_sig expandableY false
        dashboard_set_property $dash_path dash_mem0_trig_sig preferredWidth 20
        dashboard_set_property $dash_path dash_mem0_trig_sig selected 0   

        dashboard_add          $dash_path dash_mem0_dbg_rate text grp_mem0_cfg 
        dashboard_set_property $dash_path dash_mem0_dbg_rate label "debug rate (s)"
        dashboard_set_property $dash_path dash_mem0_dbg_rate expandableX false
        dashboard_set_property $dash_path dash_mem0_dbg_rate expandableY false
        dashboard_set_property $dash_path dash_mem0_dbg_rate preferredWidth 100
        dashboard_set_property $dash_path dash_mem0_dbg_rate editable false 
        dashboard_set_property $dash_path dash_mem0_dbg_rate htmlCapable false
        dashboard_set_property $dash_path dash_mem0_dbg_rate text "0"

        dashboard_add          $dash_path dash_mem0_display_unit comboBox grp_mem0_cfg 
        dashboard_set_property $dash_path dash_mem0_display_unit label "unit"
        dashboard_set_property $dash_path dash_mem0_display_unit options {"Bytes" "KB" "MB"}
        dashboard_set_property $dash_path dash_mem0_display_unit expandableX false
        dashboard_set_property $dash_path dash_mem0_display_unit expandableY false
        dashboard_set_property $dash_path dash_mem0_display_unit preferredWidth 20
        dashboard_set_property $dash_path dash_mem0_display_unit selected 0   

      # dashboard_add          $dash_path dash_mem0_ena_pending_cmd checkBox grp_mem0_cfg 
      # dashboard_set_property $dash_path dash_mem0_ena_pending_cmd enabled true
      # dashboard_set_property $dash_path dash_mem0_ena_pending_cmd text "ena pending"

        dashboard_add          $dash_path dash_mem0_max_pending_rd text grp_mem0_cfg 
        dashboard_set_property $dash_path dash_mem0_max_pending_rd label "max pending rd"
        dashboard_set_property $dash_path dash_mem0_max_pending_rd expandableX false
        dashboard_set_property $dash_path dash_mem0_max_pending_rd expandableY false
        dashboard_set_property $dash_path dash_mem0_max_pending_rd preferredWidth 30
        dashboard_set_property $dash_path dash_mem0_max_pending_rd text "0" 

        dashboard_add          $dash_path dash_mem0_max_pending_wr text grp_mem0_cfg 
        dashboard_set_property $dash_path dash_mem0_max_pending_wr label "max pending wr"
        dashboard_set_property $dash_path dash_mem0_max_pending_wr expandableX false
        dashboard_set_property $dash_path dash_mem0_max_pending_wr expandableY false
        dashboard_set_property $dash_path dash_mem0_max_pending_wr preferredWidth 30
        dashboard_set_property $dash_path dash_mem0_max_pending_wr text "0" 


        set caps [cgx_mem::get_caps 1]
        set num_wrs [lindex $caps 1 ]
        set num_rds [lindex $caps 2 ]

      # dashboard_add          $dash_path dash_mem0_first_rd_ena checkBox grp_mem0_rd 
      # dashboard_set_property $dash_path dash_mem0_first_rd_ena enabled true
      # dashboard_set_property $dash_path dash_mem0_first_rd_ena text "Force priority"
      #
      # dashboard_add          $dash_path dash_mem0_first_rd_idx comboBox grp_mem0_rd 
      # dashboard_set_property $dash_path dash_mem0_first_rd_idx label "channel"
      # dashboard_set_property $dash_path dash_mem0_first_rd_idx options {"0" "1" "2" "3" "4" "5"}
      # dashboard_set_property $dash_path dash_mem0_first_rd_idx expandableX false
      # dashboard_set_property $dash_path dash_mem0_first_rd_idx expandableY false
      # dashboard_set_property $dash_path dash_mem0_first_rd_idx preferredWidth 20
      # dashboard_set_property $dash_path dash_mem0_first_rd_idx selected 0   
              
        for { set j 0 } { ${j} < $num_rds } { incr j } {   
            set chan_id $j

            dashboard_add          $dash_path dash_mem0_rd${chan_id}_cnt text grp_mem0_rd 
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_cnt label "#${chan_id}"
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_cnt expandableX false
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_cnt expandableY false
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_cnt preferredWidth 80
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_cnt editable false 
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_cnt htmlCapable false
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_cnt text "0"
            
            dashboard_add          $dash_path dash_mem0_rd${chan_id}_percent text grp_mem0_rd 
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_percent label "%"
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_percent expandableX false
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_percent expandableY false
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_percent preferredWidth 30
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_percent editable false 
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_percent htmlCapable false
            dashboard_set_property $dash_path dash_mem0_rd${chan_id}_percent text "0"                   
        }                   
    #   dashboard_add          $dash_path dash_mem0_rd_empty text grp_mem0_rd 
    #   dashboard_set_property $dash_path dash_mem0_rd_empty label "empty"
    #   dashboard_set_property $dash_path dash_mem0_rd_empty expandableX false
    #   dashboard_set_property $dash_path dash_mem0_rd_empty expandableY false
    #   dashboard_set_property $dash_path dash_mem0_rd_empty preferredWidth 80
    #   dashboard_set_property $dash_path dash_mem0_rd_empty editable false 
    #   dashboard_set_property $dash_path dash_mem0_rd_empty htmlCapable false
    #   dashboard_set_property $dash_path dash_mem0_rd_empty text "0"

        dashboard_add          $dash_path dash_mem0_rd_total text grp_mem0_rd 
        dashboard_set_property $dash_path dash_mem0_rd_total label "total"
        dashboard_set_property $dash_path dash_mem0_rd_total expandableX false
        dashboard_set_property $dash_path dash_mem0_rd_total expandableY false
        dashboard_set_property $dash_path dash_mem0_rd_total preferredWidth 80
        dashboard_set_property $dash_path dash_mem0_rd_total editable false 
        dashboard_set_property $dash_path dash_mem0_rd_total htmlCapable false
        dashboard_set_property $dash_path dash_mem0_rd_total text "0"

    #   dashboard_add          $dash_path dash_mem0_rd_max text grp_mem0_rd 
    #   dashboard_set_property $dash_path dash_mem0_rd_max label "max"
    #   dashboard_set_property $dash_path dash_mem0_rd_max expandableX false
    #   dashboard_set_property $dash_path dash_mem0_rd_max expandableY false
    #   dashboard_set_property $dash_path dash_mem0_rd_max preferredWidth 80
    #   dashboard_set_property $dash_path dash_mem0_rd_max editable false 
    #   dashboard_set_property $dash_path dash_mem0_rd_max htmlCapable false
    #   dashboard_set_property $dash_path dash_mem0_rd_max text "0"

    #   dashboard_add          $dash_path dash_mem0_first_wr_ena checkBox grp_mem0_wr 
    #   dashboard_set_property $dash_path dash_mem0_first_wr_ena enabled true
    #   dashboard_set_property $dash_path dash_mem0_first_wr_ena text "Force priority"
    #
    #   dashboard_add          $dash_path dash_mem0_first_wr_idx comboBox grp_mem0_wr 
    #   dashboard_set_property $dash_path dash_mem0_first_wr_idx label "channel"
    #   dashboard_set_property $dash_path dash_mem0_first_wr_idx options {"0" "1" "2" "3" "4" "5"}
    #   dashboard_set_property $dash_path dash_mem0_first_wr_idx expandableX false
    #   dashboard_set_property $dash_path dash_mem0_first_wr_idx expandableY false
    #   dashboard_set_property $dash_path dash_mem0_first_wr_idx preferredWidth 20
    #   dashboard_set_property $dash_path dash_mem0_first_wr_idx selected 0   


        for { set j 0 } { ${j} < $num_wrs } { incr j } {   

            set chan_id $j
        
            dashboard_add          $dash_path dash_mem0_wr${chan_id}_cnt text grp_mem0_wr 
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_cnt label "#${chan_id}"
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_cnt expandableX false
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_cnt expandableY false
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_cnt preferredWidth 80
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_cnt editable false 
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_cnt htmlCapable false
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_cnt text "0"
            
            dashboard_add          $dash_path dash_mem0_wr${chan_id}_percent text grp_mem0_wr 
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_percent label "%"
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_percent expandableX false
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_percent expandableY false
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_percent preferredWidth 30
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_percent editable false 
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_percent htmlCapable false
            dashboard_set_property $dash_path dash_mem0_wr${chan_id}_percent text "0"                   
        }                   
    #   dashboard_add          $dash_path dash_mem0_wr_empty text grp_mem0_wr 
    #   dashboard_set_property $dash_path dash_mem0_wr_empty label "empty"
    #   dashboard_set_property $dash_path dash_mem0_wr_empty expandableX false
    #   dashboard_set_property $dash_path dash_mem0_wr_empty expandableY false
    #   dashboard_set_property $dash_path dash_mem0_wr_empty preferredWidth 80
    #   dashboard_set_property $dash_path dash_mem0_wr_empty editable false 
    #   dashboard_set_property $dash_path dash_mem0_wr_empty htmlCapable false
    #   dashboard_set_property $dash_path dash_mem0_wr_empty text "0"

        dashboard_add          $dash_path dash_mem0_wr_total text grp_mem0_wr 
        dashboard_set_property $dash_path dash_mem0_wr_total label "total"
        dashboard_set_property $dash_path dash_mem0_wr_total expandableX false
        dashboard_set_property $dash_path dash_mem0_wr_total expandableY false
        dashboard_set_property $dash_path dash_mem0_wr_total preferredWidth 80
        dashboard_set_property $dash_path dash_mem0_wr_total editable false 
        dashboard_set_property $dash_path dash_mem0_wr_total htmlCapable false
        dashboard_set_property $dash_path dash_mem0_wr_total text "0"

    #   dashboard_add          $dash_path dash_mem0_wr_max text grp_mem0_wr 
    #   dashboard_set_property $dash_path dash_mem0_wr_max label "max"
    #   dashboard_set_property $dash_path dash_mem0_wr_max expandableX false
    #   dashboard_set_property $dash_path dash_mem0_wr_max expandableY false
    #   dashboard_set_property $dash_path dash_mem0_wr_max preferredWidth 80
    #   dashboard_set_property $dash_path dash_mem0_wr_max editable false 
    #   dashboard_set_property $dash_path dash_mem0_wr_max htmlCapable false
    #   dashboard_set_property $dash_path dash_mem0_wr_max text "0"
	      
        after idle ::cgx_mem::dash_update

        puts stdout " ${::cgx_mem::IPCORE_LABEL} dashBoard end"

        return -code ok
    }


	      
    proc dash_init_device {} {
    	
        set ::cgx_mem::debug 1

        cgx_mem::init -1  
        cgx_mem::dash_get_config
        cgx_mem::dash_get_status

        set ::cgx_mem::debug 0
    }


    proc dash_dump_device {} {

        cgx_mem::dump  

    }


    proc dash_get_caps {} {
    	
        set ::cgx_mem::debug 1

        cgx_mem::get_caps 0   

        set ::cgx_mem::debug 0
    }


    proc dash_set_config {} {

        set ::cgx_mem::debug 1
       
        cgx_mem::set_config     -1 -1 -1   
        cgx_mem::dbg_set_config -1 -1        
        cgx_mem::set_interrupt  -1  
       
        set ::cgx_mem::debug 0
        
    }



    proc dash_get_config {} {

        set ::cgx_mem::debug 1

        cgx_mem::get_config    
        cgx_mem::dbg_get_config    
        cgx_mem::get_interrupt    

        set ::cgx_mem::debug 0

    }
    
   
    proc dash_get_status {} {

        set ::cgx_mem::debug 1

        cgx_mem::get_status          
       #cgx_mem::dbg_get_counts          

        set ::cgx_mem::debug 0

    }


    proc dash_clr_status {} {

        set ::cgx_mem::debug 1

        cgx_mem::clr_status          

        set ::cgx_mem::debug 0
        
    }


    proc dash_run_start {} {

        if { ${::cgx_mem::dash_run} > 0 } {
            set ::cgx_mem::dash_run 0
            puts "stop"
        } else {
            set ::cgx_mem::dash_run 1
            puts "start"
        }
    }
   
    proc dash_update {} {  
      # puts "run0"
        if { ${::cgx_mem::dashboardActive} > 0 } {     
            if { ${::cgx_mem::initialized} > 0 } {
                if { ${::cgx_mem::dash_run} > 0 } {
      #             puts "run1"
                    ::cgx_mem::dash_get_config
                    ::cgx_mem::dash_get_status 
                }
                after 1000 ::cgx_mem::dash_update

            }
        }
    }

}


    