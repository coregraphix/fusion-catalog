
namespace eval cgx_tpg {

    # background layer
    variable TPG_BACK_ALL         0  
    variable TPG_BACK_OFF         1 
    variable TPG_BACK_GRADIENT_H  2 
    variable TPG_BACK_GRADIENT_V  3 
    variable TPG_BACK_GRADIENT    4 
    variable TPG_BACK_COLORBAR    5 
    variable TPG_BACK_CHECKER     6 
    variable TPG_BACK_NUMBER      7 
    
    # foreground layer
    variable TPG_FORE_ALL         0  
    variable TPG_FORE_OFF         1 
    variable TPG_FORE_BOUNDS      2 
    variable TPG_FORE_SCROLLBAR_H 3 
    variable TPG_FORE_SCROLLBAR_V 4 
    variable TPG_FORE_NUMBER      5 
   
}



# cgx_tpg::init        { dev_base }
# cgx_tpg::get_version { }
# cgx_tpg::get_caps    { }
# cgx_tpg::set_config  { on pattern_back pattern_fore }  
# cgx_tpg::get_config  { quiet }   return { cfg_run cfg_back cfg_fore } 
# cgx_tpg::get_status  { }
# cgx_tpg::clr_status  { }
# cgx_tpg::set_size    { width height }
# cgx_tpg::get_size    { quiet }    return { width height } 
# cgx_tpg::dump        { }
# cgx_tpg::dashBoard   { }



#    variable IPCORE_PRODUCT 67; # = 0x43 	                                                                                          
#    variable IPCORE_VERSION ${::cgx_fusion::IPCORE_VERSION}                                                                                           
#    variable IPCORE_LABEL "TPG"
#
#    #----------------------- dashboard---------------------------
#
#    variable dash_path ""
#    variable dashboardActive  0
#
#    # debug mode
#    # 0 => console 
#    # 1 => dashboard (+console) 
#    variable debug 0
#
#
#
#    #-------------------------- SYS------------------------------
#
#    variable TPG_CSR_DEV_BASE  0x00000000
#    variable initialized 0
#
#    
#    #-------------------------- HAL------------------------------
#    
#    variable TPG_CSR_REG_VERSION     0
#    variable TPG_CSR_REG_CAPS        1
#    variable TPG_CSR_REG_CONTROL     2
#    variable TPG_CSR_REG_STATUS      3
#    variable TPG_CSR_REG_SIZE        4
#   #variable                         5
#    variable TPG_CSR_REG_PATTERN     6
#    variable TPG_CSR_REG_COUNT       7
#    variable TPG_CSR_REG_NUMBER      8
#    
# 
#    # /* TPG_CSR_REG_VERSION */    
#        # /* Parameters */
#        variable TPG_CSR_VERSION_ID_MSK     0xFF      
#        variable TPG_CSR_VERSION_ID_OFST    0         
#        variable TPG_CSR_VERSION_BUILD_MSK  0xFF00    
#        variable TPG_CSR_VERSION_BUILD_OFST 8         
#        variable TPG_CSR_VERSION_MINOR_MSK  0xFF0000   
#        variable TPG_CSR_VERSION_MINOR_OFST 16        
#        variable TPG_CSR_VERSION_MAJOR_MSK  0x0F000000   
#        variable TPG_CSR_VERSION_MAJOR_OFST 24        
#
#    
#    # /* TPG_CSR_REG_CAPS */		
#    	  variable TPG_CSR_CAPS_ENABLE_CHANNEL_MSK    0x1                                                                                                                                                               
#    	  variable TPG_CSR_CAPS_ENABLE_CHANNEL_OFST   0                                                                                                                                                                
#    	  variable TPG_CSR_CAPS_MAX_CHANNEL_IDX_MSK   0xFF00  
#    	  variable TPG_CSR_CAPS_MAX_CHANNEL_IDX_OFST  8                    
#
#    
#    # /* TPG_CSR_REG_CONTROL */		
#    	  variable TPG_CSR_CONTROL_RUN_MSK      0x1;  # 0/1 = power off/on. power-off set default value for other register parameters
#    		variable TPG_CSR_CONTROL_RUN_OFST     0
#     
#    
#    # /* TPG_CSR_REG_STATUS */
#        # parameters
#        variable TPG_CSR_STATUS_BUSY_MSK   0x1 
#        variable TPG_CSR_STATUS_BUSY_OFST  0 
#    
#    
#    # /* TPG_CSR_REG_SIZE */
#    	  variable TPG_CSR_WIDTH_MSK    0x0000FFFF 
#    	  variable TPG_CSR_WIDTH_OFST   0 
#    	  variable TPG_CSR_HEIGHT_MSK   0xFFFF0000 
#    	  variable TPG_CSR_HEIGHT_OFST  16 
#         
#    
#    # /* TPG_CSR_REG_PATTERN */
#    	variable TPG_CSR_PATTERN_BACK_MSK   0xFF;     # background layer pattern selection
#    	variable TPG_CSR_PATTERN_BACK_OFST  0          
#    	variable TPG_CSR_PATTERN_FORE_MSK   0xFF00;   # foreground layer pattern selection
#    	variable TPG_CSR_PATTERN_FORE_OFST  8         
#    	variable TPG_CSR_CHANNEL_MSK        0xFF0000; #  
#    	variable TPG_CSR_CHANNEL_OFST       16         
#    
#    
#
#
#    # /* TPG_CSR_REG_COUNT */
#
#    variable TPG_CSR_FRAME_COUNT_MSK  0xFFFF   
#    variable TPG_CSR_FRAME_COUNT_OFST 0           
#
#    
# 
#    #--------------------------private functions ------------------------------
#
#    proc ATH_SET_FIELD { reg32 field_name field_val } {
#    
#           #set str_field_reg32 ::cgx_tpg::$field_name\_REG 
#            set str_field_msk   ::cgx_tpg::$field_name\_MSK 
#            set str_field_ofst  ::cgx_tpg::$field_name\_OFST
#            
#           #set field_reg32 [ subst $$str_field_reg32 ]
#            set field_msk   [ subst $$str_field_msk   ]
#            set field_ofst  [ subst $$str_field_ofst  ]
#                     
#            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
#              
#            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
#                  
#            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
#                 
#      # puts "reg_old=$reg32 / reg_new=$reg32_new"
#          
#        return $reg32_new             
#    }
#
#
#    proc ATH_GET_FIELD { reg32 field_name } {
#
#        set str_field_msk  ::cgx_tpg::$field_name\_MSK 
#        set str_field_ofst ::cgx_tpg::$field_name\_OFST
#        
#        set field_msk   [ subst $$str_field_msk   ]
#        set field_ofst  [ subst $$str_field_ofst  ]
#
#        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]
#
#        return $field_val             
#
#    }
#
#     
#    #--------------------------public functions ------------------------------
#
# 
#    proc init { dev_base } {
#
#      # puts stdout "FUSION-TPG init:"
#
#        if { ${::cgx_tpg::debug} == 1 } {
#            set dash_path ${::cgx_tpg::dash_path} 
#            set dev_base [ dashboard_get_property $dash_path dash_dev_base text ]
#        } 
#                        
#        set ::cgx_tpg::TPG_CSR_DEV_BASE ${dev_base} 
#        
#        set dev_success [ ::cgx_tpg::get_version ];  
#        
#        if {${dev_success} == 1} {
#            set ::cgx_tpg::initialized 1
#        } else {
#            set ::cgx_tpg::initialized 0
#        } 
#
#        if { ${::cgx_tpg::debug} == 1 } {
#            set dash_path ${::cgx_tpg::dash_path} 
#            dashboard_set_property $dash_path grp_csr   visible false
#            if {${dev_success} == 1} {
#                puts " ${::cgx_tpg::IPCORE_LABEL} init successfull "
#                dashboard_set_property $dash_path grp_core  visible true
#            } else {
#            	  puts " ${::cgx_tpg::IPCORE_LABEL} ERROR: device init failure "
#                dashboard_set_property $dash_path grp_core  visible false
#            } 
#        } 
#    }
#       
#
#
#    proc get_version { } {
#        
#        set csr_base8 ${::cgx_tpg::TPG_CSR_DEV_BASE} 
#        
#        open_service master ${::boardInit::masterPath}
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_tpg::TPG_CSR_REG_VERSION} ] 0x1]; 
#	      close_service master ${::boardInit::masterPath}
#
#        set v_id    [ ATH_GET_FIELD $reg TPG_CSR_VERSION_ID ] ;                              
#        set v_build [ ATH_GET_FIELD $reg TPG_CSR_VERSION_BUILD ] ;                           
#        set v_minor [ ATH_GET_FIELD $reg TPG_CSR_VERSION_MINOR ] ;                           
#        set v_major [ ATH_GET_FIELD $reg TPG_CSR_VERSION_MAJOR ] ;                           
#        set version $v_major.$v_minor                            
#
#        if {$v_id == ${::cgx_tpg::IPCORE_PRODUCT} } {
#          puts " ${::cgx_tpg::IPCORE_LABEL} detection successfull, core id = [ format 0x%x $v_id ] "
#          puts " ${::cgx_tpg::IPCORE_LABEL} Version = $v_major.$v_minor, Build = $v_build"
#          if { $version == ${::cgx_tpg::IPCORE_VERSION} } {
#            set success 1
#          } else {
#            set success 0
#            puts stdout " ${::cgx_tpg::IPCORE_LABEL} ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_tpg::IPCORE_VERSION} )"
#            puts stdout "        please upgrade the dashboard version accordingly to the IP core "
#          }
#        } else {
#          set success 0
#          puts stdout " ${::cgx_tpg::IPCORE_LABEL} ERROR: device not detected at device base ${::cgx_tpg::TPG_CSR_DEV_BASE} "
#          puts stdout "        core id = $v_id, reg = $reg "
#          puts stdout "        please, set the right device base and press init again "
#        }
#        return $success
#
#    }
#
#
#    proc get_caps { } {
#
#        set csr_base8 ${::cgx_tpg::TPG_CSR_DEV_BASE} 
#
#        open_service master ${::boardInit::masterPath}
#
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_tpg::TPG_CSR_REG_CAPS} ] 0x1]; 
#        set caps_ena_channel    [ ATH_GET_FIELD $reg TPG_CSR_CAPS_ENABLE_CHANNEL ] ; 
#        set caps_max_channel    [ expr [ ATH_GET_FIELD $reg TPG_CSR_CAPS_MAX_CHANNEL_IDX ] + 1]; 
# 
#	      close_service master ${::boardInit::masterPath}
#                          
#        set ::cgx_tpg::caps_ena_channel   $caps_ena_channel         
#        set ::cgx_tpg::caps_max_channel   $caps_max_channel         
#                            
#        set quiet 0
#        if { $quiet == 0 } {
#           puts " Capabilities: "
#           puts "     caps_ena_channel = ${::cgx_tpg::caps_ena_channel} "         
#           puts "     caps_max_channel = ${::cgx_tpg::caps_max_channel} " 
#        }
#
#        if { ${::cgx_tpg::debug} == 1 } {
#
#            set dash_path ${::cgx_tpg::dash_path} 
#            dashboard_set_property $dash_path grp_csr visible true
#    
#        #   if { $caps_ena_channel == 0 } {
#        #       dashboard_set_property $dash_path dash_cfg_channel visible false
#        #   } else {
#        #       dashboard_set_property $dash_path dash_cfg_channel visible true
#        #   }                    	
#        }
#
#    }
#
#
#    proc dump { } {
#
# 
#        open_service master ${::boardInit::masterPath}
#        set reg [ master_read_32  ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 0 ] ${::cgx_tpg::TPG_CSR_REG_NUMBER} ];         
#	      close_service master ${::boardInit::masterPath}
#
#        puts stdout "dump core at ${::cgx_tpg::TPG_CSR_DEV_BASE}:"
#        puts stdout "$reg"
#    }
#
#
#    proc set_size { width height } {
#
#        open_service master ${::boardInit::masterPath}
#
#        if { ${::cgx_tpg::debug} == 1 } {
#            set dash_path ${::cgx_tpg::dash_path} 
#            set width  [ dashboard_get_property $dash_path dash_width text ]
#            set height [ dashboard_get_property $dash_path dash_height text ]
#        }
#
#        set reg 0
#        set reg [ ATH_SET_FIELD $reg TPG_CSR_WIDTH $width ]
#        set reg [ ATH_SET_FIELD $reg TPG_CSR_HEIGHT $height ]
#        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_SIZE} ] $reg
#
#	      close_service master ${::boardInit::masterPath}
#    }
#
#
#    proc get_size { quiet } {
#
#        open_service master ${::boardInit::masterPath}
# 
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_SIZE} ] 0x1]; 
#        set width  [ ATH_GET_FIELD $reg TPG_CSR_WIDTH ]    
#        set height [ ATH_GET_FIELD $reg TPG_CSR_HEIGHT ]    
#
#	      close_service master ${::boardInit::masterPath}
# 
#        if { $quiet == 0 } {
#            puts "                        "
#            puts " status:                "
#            puts "        width  =$width  "         
#            puts "        height =$height "         
#        }
#        if { ${::cgx_tpg::debug} == 1 } {
#            set dash_path ${::cgx_tpg::dash_path} 
#            
#            dashboard_set_property $dash_path dash_width  text $width   
#            dashboard_set_property $dash_path dash_height text $height  
#        }
#
#        set cfg_size { }
#        lappend cfg_size $width 
#        lappend cfg_size $height 
#        return $cfg_size           
#    }
# 
#
#    proc set_config { run pattern_back pattern_fore } {   
#
#        # tmp
#        set channel 0
#        
#        if { ${::cgx_tpg::debug} == 1 } {
#	          set dash_path ${::cgx_tpg::dash_path} 
#	          set run 0 
#            if { [ dashboard_get_property $dash_path dash_cfg_run checked ] == true } {
#                set run 1
#            } 
#	          
#	          set pattern_back [ dashboard_get_property $dash_path dash_cfg_back    selected ]
#	          set pattern_fore [ dashboard_get_property $dash_path dash_cfg_fore    selected ]
#	      #   set channel      [ dashboard_get_property $dash_path dash_cfg_channel text ]
#	          
#        }  
#
#        open_service master ${::boardInit::masterPath}
#        set reg 0
#        set reg [ ATH_SET_FIELD $reg TPG_CSR_CONTROL_RUN $run ]
#        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_CONTROL} ] $reg
#
#        set reg 0
#        set reg [ ATH_SET_FIELD $reg TPG_CSR_PATTERN_BACK $pattern_back ]
#        set reg [ ATH_SET_FIELD $reg TPG_CSR_PATTERN_FORE $pattern_fore ]
#        set reg [ ATH_SET_FIELD $reg TPG_CSR_CHANNEL      $channel ]
#
#        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_PATTERN} ] $reg
#	      close_service master ${::boardInit::masterPath}
#
#    }
#
# 
#    proc get_config { quiet } {
#
#        open_service master ${::boardInit::masterPath}
#
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_CONTROL} ] 0x1]; 
#        set cfg_run   [ ATH_GET_FIELD $reg TPG_CSR_CONTROL_RUN ] ;                                                                
#
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_PATTERN} ] 0x1]; 
#        set cfg_back    [ ATH_GET_FIELD $reg TPG_CSR_PATTERN_BACK  ] ;                                                                
#        set cfg_fore    [ ATH_GET_FIELD $reg TPG_CSR_PATTERN_FORE  ] ;                                                                
#        set cfg_channel [ ATH_GET_FIELD $reg TPG_CSR_CHANNEL  ] ;                                                                
# 
#	      close_service master ${::boardInit::masterPath}
#
#        if { $quiet == 0 } {
#            puts " config:                    "  
#            puts "     run     = $cfg_run     "    
#            puts "     back    = $cfg_back    "   
#            puts "     fore    = $cfg_fore    "
#            puts "     channel = $cfg_channel "          
#            puts " "                                                                                                                                                                
#        }
#
#        if { ${::cgx_tpg::debug} == 1 } {
#        	  set dash_path ${::cgx_tpg::dash_path} 
# 
#            if { $cfg_run == 1 } {
#               dashboard_set_property $dash_path dash_cfg_run checked true  
#            } else { 
#               dashboard_set_property $dash_path dash_cfg_run checked false  
#            }        
#            dashboard_set_property $dash_path dash_cfg_back    selected $cfg_back
#            dashboard_set_property $dash_path dash_cfg_fore    selected $cfg_fore
#        #   dashboard_set_property $dash_path dash_cfg_channel text     $cfg_channel         
#        }
#        
#        
#        set cfg { }
#        lappend cfg $cfg_run 
#        lappend cfg $cfg_back 
#        lappend cfg $cfg_fore
#         
#        return $cfg           
#    }
#
#
#    proc get_status { } {
#
#        open_service master ${::boardInit::masterPath}
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_STATUS} ] 0x1]; 
#        set sts_busy       [ ATH_GET_FIELD $reg TPG_CSR_STATUS_BUSY ] ;                                                                
#
#        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_COUNT} ] 0x1]; 
#        set sts_framecount [ ATH_GET_FIELD $reg TPG_CSR_FRAME_COUNT ] ;                                                                
#
#	      close_service master ${::boardInit::masterPath}
#
# 
#        if { ${::cgx_tpg::debug} == 1 } {
#            puts "                                          "
#            puts "  status:                                 "
#            puts "         sts_busy       = $sts_busy       "    
#            puts "         sts_framecount = $sts_framecount "         
#            puts "                                          "                                                                                                                           
#        }
#        if { ${::cgx_tpg::debug} == 1 } {
#        	  set dash_path ${::cgx_tpg::dash_path} 
#            if { $sts_busy == 1 } {
#               dashboard_set_property $dash_path dash_sts_busy checked true
#            } else { 
#               dashboard_set_property $dash_path dash_sts_busy checked false
#            }        
#
#            dashboard_set_property $dash_path dash_sts_framecount text $sts_framecount
#
#        }
#    }
#                         
#
#    # clear all status interrupt-active bits
#    proc clr_status { } {
#
#        open_service master ${::boardInit::masterPath}
#        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_tpg::TPG_CSR_DEV_BASE} + 4*${::cgx_tpg::TPG_CSR_REG_STATUS} ] 0xFFFFFFFF 
#	      close_service master ${::boardInit::masterPath}
#    }
#
#
#    proc dashBoard { } {
#
#        if { ${::cgx_tpg::dashboardActive} == 1 } {
#            return -code ok " ${::cgx_tpg::IPCORE_LABEL} dashboard already active"
#        }
#        
#        set ::cgx_tpg::dashboardActive 1
#        puts " ${::cgx_tpg::IPCORE_LABEL} dashBoard start ......."
#
#        #
#        # Create dashboard 
#        #
#
#
#        #
#        # Set dashboard properties
#        #
#        variable ::cgx_tpg::dash_path [ add_service dashboard cgx_tpg "cgx_tpg" "Tools/cgx_tpg"]
#        
#        set dash_path ${::cgx_tpg::dash_path} 
#        
#        dashboard_set_property $dash_path self developmentMode true
#        dashboard_set_property $dash_path self itemsPerRow 1
#        dashboard_set_property $dash_path self visible true
#                
#        #
#        # groups
#        #
#
#        dashboard_add          $dash_path grp_top group self        
#        dashboard_set_property $dash_path grp_top expandableX false
#        dashboard_set_property $dash_path grp_top expandableY false
#        dashboard_set_property $dash_path grp_top itemsPerRow 1
#        dashboard_set_property $dash_path grp_top title ""
#
#        dashboard_add          $dash_path grp_device group grp_top
#        dashboard_set_property $dash_path grp_device expandableX false
#        dashboard_set_property $dash_path grp_device expandableY false
#        dashboard_set_property $dash_path grp_device itemsPerRow 3
#        dashboard_set_property $dash_path grp_device title "Device"
#
#        dashboard_add          $dash_path grp_core group grp_top
#        dashboard_set_property $dash_path grp_core expandableX false
#        dashboard_set_property $dash_path grp_core expandableY false
#        dashboard_set_property $dash_path grp_core itemsPerRow 1
#        dashboard_set_property $dash_path grp_core title "Core"
#        dashboard_set_property $dash_path grp_core visible false; # dashboard init
#
#        dashboard_add          $dash_path grp_core_cmd group grp_core
#        dashboard_set_property $dash_path grp_core_cmd expandableX false
#        dashboard_set_property $dash_path grp_core_cmd expandableY false
#        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 3
#        dashboard_set_property $dash_path grp_core_cmd title ""
#
#        dashboard_add          $dash_path grp_csr group grp_core
#        dashboard_set_property $dash_path grp_csr expandableX false
#        dashboard_set_property $dash_path grp_csr expandableY false
#        dashboard_set_property $dash_path grp_csr itemsPerRow 2
#        dashboard_set_property $dash_path grp_csr title ""
#        dashboard_set_property $dash_path grp_csr visible false; # dashboard init
#
#        dashboard_add          $dash_path grp_config group grp_csr
#        dashboard_set_property $dash_path grp_config expandableX false
#        dashboard_set_property $dash_path grp_config expandableY true
#        dashboard_set_property $dash_path grp_config itemsPerRow 1
#        dashboard_set_property $dash_path grp_config title "Config"
#
#        dashboard_add          $dash_path grp_cfg_cmd group grp_config
#        dashboard_set_property $dash_path grp_cfg_cmd expandableX false
#        dashboard_set_property $dash_path grp_cfg_cmd expandableY false
#        dashboard_set_property $dash_path grp_cfg_cmd itemsPerRow 2
#        dashboard_set_property $dash_path grp_cfg_cmd title ""
#
#        dashboard_add          $dash_path grp_cfg_param1 group grp_config
#        dashboard_set_property $dash_path grp_cfg_param1 expandableX false
#        dashboard_set_property $dash_path grp_cfg_param1 expandableY false
#        dashboard_set_property $dash_path grp_cfg_param1 itemsPerRow 1
#        dashboard_set_property $dash_path grp_cfg_param1 title ""
#
#        dashboard_add          $dash_path grp_cfg_param2 group grp_config
#        dashboard_set_property $dash_path grp_cfg_param2 expandableX false
#        dashboard_set_property $dash_path grp_cfg_param2 expandableY false
#        dashboard_set_property $dash_path grp_cfg_param2 itemsPerRow 2
#        dashboard_set_property $dash_path grp_cfg_param2 title ""
#
#        dashboard_add          $dash_path grp_cfg_param3 group grp_config
#        dashboard_set_property $dash_path grp_cfg_param3 expandableX false
#        dashboard_set_property $dash_path grp_cfg_param3 expandableY false
#        dashboard_set_property $dash_path grp_cfg_param3 itemsPerRow 2
#        dashboard_set_property $dash_path grp_cfg_param3 title ""
#
#    #   dashboard_add          $dash_path grp_size group grp_csr
#    #   dashboard_set_property $dash_path grp_size expandableX false
#    #   dashboard_set_property $dash_path grp_size expandableY false
#    #   dashboard_set_property $dash_path grp_size itemsPerRow 2
#    #   dashboard_set_property $dash_path grp_size title ""
# 
#        dashboard_add          $dash_path grp_status group grp_csr
#        dashboard_set_property $dash_path grp_status expandableX false
#        dashboard_set_property $dash_path grp_status expandableY true
#        dashboard_set_property $dash_path grp_status itemsPerRow 1
#        dashboard_set_property $dash_path grp_status title "Status"
#
#        dashboard_add          $dash_path grp_sts_cmd group grp_status
#        dashboard_set_property $dash_path grp_sts_cmd expandableX false
#        dashboard_set_property $dash_path grp_sts_cmd expandableY false
#        dashboard_set_property $dash_path grp_sts_cmd itemsPerRow 3
#        dashboard_set_property $dash_path grp_sts_cmd title ""
#
#        dashboard_add          $dash_path grp_sts_param group grp_status
#        dashboard_set_property $dash_path grp_sts_param expandableX false
#        dashboard_set_property $dash_path grp_sts_param expandableY false
#        dashboard_set_property $dash_path grp_sts_param itemsPerRow 3
#        dashboard_set_property $dash_path grp_sts_param title ""
#
#
#        #
#        # widgets
#        #
#
#        dashboard_add          $dash_path dash_dev_base text grp_device 
#        dashboard_set_property $dash_path dash_dev_base label "base" 
#        dashboard_set_property $dash_path dash_dev_base expandableX false
#        dashboard_set_property $dash_path dash_dev_base expandableY false
#        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
#        dashboard_set_property $dash_path dash_dev_base editable true
#        dashboard_set_property $dash_path dash_dev_base htmlCapable false
#        dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_tpg::TPG_CSR_DEV_BASE} ]
# 
#        dashboard_add          $dash_path dash_dev_init button grp_device 
#        dashboard_set_property $dash_path dash_dev_init enabled true
#        dashboard_set_property $dash_path dash_dev_init text "Init"
#        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_tpg::dash_init_device }  
#
#        dashboard_add          $dash_path dash_dev_dump button grp_device 
#        dashboard_set_property $dash_path dash_dev_dump enabled true
#        dashboard_set_property $dash_path dash_dev_dump text "Dump"
#        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_tpg::dash_dump_device }  
#
#        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
#        dashboard_set_property $dash_path dash_dev_version enabled true
#        dashboard_set_property $dash_path dash_dev_version text "Version"
#        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_tpg::get_version }  
#
#        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
#        dashboard_set_property $dash_path dash_dev_caps visible true;  
#        dashboard_set_property $dash_path dash_dev_caps text "Caps"
#        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_tpg::dash_get_caps }  
#        
#        dashboard_add          $dash_path dash_cfg_set button grp_cfg_cmd 
#        dashboard_set_property $dash_path dash_cfg_set enabled true
#        dashboard_set_property $dash_path dash_cfg_set text "Set"
#        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_tpg::dash_set_config }  
#
#        dashboard_add          $dash_path dash_cfg_get button grp_cfg_cmd 
#        dashboard_set_property $dash_path dash_cfg_get enabled true
#        dashboard_set_property $dash_path dash_cfg_get text "Readback"
#        dashboard_set_property $dash_path dash_cfg_get onClick { ::cgx_tpg::dash_get_config }  
#
#        dashboard_add          $dash_path dash_cfg_run checkBox grp_cfg_param1 
#        dashboard_set_property $dash_path dash_cfg_run enabled true
#        dashboard_set_property $dash_path dash_cfg_run text "Run"
#
#        dashboard_add          $dash_path dash_cfg_back comboBox grp_cfg_param2 
#        dashboard_set_property $dash_path dash_cfg_back label "background"
#        dashboard_set_property $dash_path dash_cfg_back options { "random" "off" "gradient H" "gradient V" "gradient" "colorbar" "checker" }
#        dashboard_set_property $dash_path dash_cfg_back expandableX false
#        dashboard_set_property $dash_path dash_cfg_back expandableY false
#        dashboard_set_property $dash_path dash_cfg_back preferredWidth 70
#        dashboard_set_property $dash_path dash_cfg_back selected 2; # gradient H   
#
#        dashboard_add          $dash_path dash_cfg_fore comboBox grp_cfg_param2 
#        dashboard_set_property $dash_path dash_cfg_fore label "foreground"
#        dashboard_set_property $dash_path dash_cfg_fore options { "random" "off" "bounds" "scrollbar H" "scrollbar V" }
#        dashboard_set_property $dash_path dash_cfg_fore expandableX false
#        dashboard_set_property $dash_path dash_cfg_fore expandableY false
#        dashboard_set_property $dash_path dash_cfg_fore preferredWidth 70
#        dashboard_set_property $dash_path dash_cfg_fore selected 3; # scrollbar H   
#
#    #   dashboard_add          $dash_path dash_cfg_channel text grp_cfg_param2 
#    #   dashboard_set_property $dash_path dash_cfg_channel label "channel" 
#    #   dashboard_set_property $dash_path dash_cfg_channel expandableX false
#    #   dashboard_set_property $dash_path dash_cfg_channel expandableY false
#    #   dashboard_set_property $dash_path dash_cfg_channel preferredWidth 50
#    #   dashboard_set_property $dash_path dash_cfg_channel editable true
#    #   dashboard_set_property $dash_path dash_cfg_channel htmlCapable false
#    #   dashboard_set_property $dash_path dash_cfg_channel text "0"
#        
# 
#        dashboard_add          $dash_path dash_width text grp_cfg_param3 
#        dashboard_set_property $dash_path dash_width label "width" 
#        dashboard_set_property $dash_path dash_width expandableX false
#        dashboard_set_property $dash_path dash_width expandableY false
#        dashboard_set_property $dash_path dash_width preferredWidth 50
#        dashboard_set_property $dash_path dash_width editable true
#        dashboard_set_property $dash_path dash_width htmlCapable false
#        dashboard_set_property $dash_path dash_width text "0"
#
#        dashboard_add          $dash_path dash_height text grp_cfg_param3 
#        dashboard_set_property $dash_path dash_height label "height" 
#        dashboard_set_property $dash_path dash_height expandableX false
#        dashboard_set_property $dash_path dash_height expandableY false
#        dashboard_set_property $dash_path dash_height preferredWidth 50
#        dashboard_set_property $dash_path dash_height editable true
#        dashboard_set_property $dash_path dash_height htmlCapable false
#        dashboard_set_property $dash_path dash_height text "0"
#
#        dashboard_add          $dash_path dash_sts_get button grp_sts_cmd 
#        dashboard_set_property $dash_path dash_sts_get enabled true
#        dashboard_set_property $dash_path dash_sts_get text "Get"
#        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_tpg::dash_get_status }  
#      
#        dashboard_add          $dash_path dash_sts_busy checkBox grp_sts_param
#        dashboard_set_property $dash_path dash_sts_busy text "busy"
#
#        dashboard_add          $dash_path dash_sts_framecount text grp_sts_param 
#        dashboard_set_property $dash_path dash_sts_framecount label "frame count" 
#        dashboard_set_property $dash_path dash_sts_framecount expandableX false
#        dashboard_set_property $dash_path dash_sts_framecount expandableY false
#        dashboard_set_property $dash_path dash_sts_framecount preferredWidth 50
#        dashboard_set_property $dash_path dash_sts_framecount editable false
#        dashboard_set_property $dash_path dash_sts_framecount htmlCapable false
#        dashboard_set_property $dash_path dash_sts_framecount text "0"
#
#        puts stdout " ${::cgx_tpg::IPCORE_LABEL} dashBoard end"
#
#        return -code ok
#    }
#
#
#    proc dash_init_device {} {
#    	
#        set ::cgx_tpg::debug 1
#
#        cgx_tpg::init -1  
#        cgx_tpg::dash_get_config
#        cgx_tpg::dash_get_status
#
#        set ::cgx_tpg::debug 0
#    }
#
#
#    proc dash_dump_device {} {
#
#        cgx_tpg::dump 
#
#    }
#
#
#    proc dash_get_caps { } {
#
#        set ::cgx_tpg::debug 1
#
#        ::cgx_tpg::get_caps 
#
#        set ::cgx_tpg::debug 0
#                                                                                               
#    }
#
#
#    proc dash_set_config {} {
#
#        set ::cgx_tpg::debug 1
#       
#        cgx_tpg::set_config -1 -1 -1  
#        cgx_tpg::set_size   -1 -1   
#       
#        set ::cgx_tpg::debug 0
#        
#    }
#
#
#    proc dash_get_config {} {
#
#        set ::cgx_tpg::debug 1
#
#        cgx_tpg::get_config 1   
#        cgx_tpg::get_size 1   
#
#        set ::cgx_tpg::debug 0
#
#    }
#
#
#    proc dash_get_status {} {
#
#        set ::cgx_tpg::debug 1
#       
#        cgx_tpg::get_status  
#        
#        set ::cgx_tpg::debug 0
#        
#    }
#
 

    