
# 180718: added "TPG"

# cgx_display::init              { instance_idx }           
# cgx_display::get_version       { } 
# cgx_display::get_caps          { }
# cgx_display::set_config        { run vumeter bkg_r bkg_g bkg_b }
# cgx_display::get_config        { }
# cgx_display::get_interrupt     { }
# cgx_display::get_status        { }
# cgx_display::clr_status        { }
# cgx_display::video_set_config  { flip_h flip_v ena_screenbuffer rotate tpg_on tpg_back tpg_fore }
# cgx_display::video_get_config  { }
# cgx_display::video_set_timings { hres vres hfpw hsw hbpw vfpw vsw vbpw hpol vpol }  
# cgx_display::video_get_timings { }  
# cgx_display::dump_layer        { layer_idx }
# cgx_display::dump_core         { }
# cgx_display::dump_video        { }
# cgx_display::dump_surface_ctrl { idx }
# cgx_display::dashBoard         { }
# cgx_display::set_core_reg      { reg32 reg_val }  

# source ../common/imagem/cgx_display_overlay_desc.tcl
# source ../common/imagem/dashboard_cgx_display_overlay/cgx_display_overlay_desc.tcl

# old
# cgx_display::set_interrupt     { ie_bitfield }

		
namespace eval cgx_display {


    variable IPCORE_PRODUCT 61; # = 0x3d                                                                                          
    variable IPCORE_VERSION ${::cgx_fusion::IPCORE_VERSION}                                                                                          
    variable IPCORE_LABEL   DPYCTRL                                                                                          



    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    # debug mode
    # 0 => console 
    # 1 => dashboard 
    variable debug 0
 
    variable caps_ena_debug              0
    variable caps_ena_color_background   0           
    variable caps_ena_extended_addr      0
    variable caps_ena_bandwidth_view     0
    variable caps_ena_resizing           0
    variable caps_ena_filtering_h        0
    variable caps_ena_filtering_v        0
  # variable caps_ena_chroma_keying      0
  # variable caps_ena_transparency       0
  # variable caps_ena_masking            0
    variable caps_ena_color_transform    0
    variable caps_ena_layers             0
                                         
    variable caps_num_layer              0
    variable caps_num_screen             0

    variable caps_video_ena_runtime      0
    variable caps_video_ena_clocked      0
    variable caps_video_ena_screenbuffer 0
    variable caps_video_ena_screenrotate 0
    variable caps_video_ena_flip_h       0
    variable caps_video_ena_flip_v       0


    #-------------------------- SYS------------------------------

    variable DPY_CSR_DEV_BASE 0
    variable DPY_CSR_DEV_BASE_SFCTRL 0x00000000
    variable initialized 0

 
    #-------------------------- HAL------------------------------
    
    # 32-bits regs offset
    variable DPY_CSR_OFST_CORE   0                                                                                         
    variable DPY_CSR_OFST_VIDEO  32                                                                                         
    variable DPY_CSR_OFST_SFCTRL 64                                                                                         
      
      
    #  /*
    #   
    #    C O R E   section
    #   
    #  */
#  variable DPY_CSR_CORE_REG_SURFACE              1; # reserved                                                                                */                                                                   
    
    # /* registers */
    variable DPY_CSR_CORE_REG_VERSION              0; # core version                                                                            */                                                                              
    variable DPY_CSR_CORE_REG_CAPS0                1; # core capabilities                                                                       */
    variable DPY_CSR_CORE_REG_CAPS1                2; # core capabilities                                                                       */
   #variable DPY_CSR_CORE_REG_INTERRUPT            3; # core interrupts                                                                         */
    variable DPY_CSR_CORE_REG_CONTROL              4; # core control                                                                            */
    variable DPY_CSR_CORE_REG_STATUS               5; # core status (includes interrupt-active)                                                 */
#   variable DPY_CSR_CORE_REG_DIAG                 7; # core diagnostic information                                                             */
 
    variable DPY_CSR_CORE_REG_SCREEN_IDX           8;                                                                           
    variable DPY_CSR_CORE_REG_SCREEN_POSITION      9;                                                           
    variable DPY_CSR_CORE_REG_SCREEN_SIZE         10;                                                           
    variable DPY_CSR_CORE_REG_FRAME_RUN_SIZE      11; # actual layer composition frame size                                                     */
    variable DPY_CSR_CORE_REG_FRAME_COUNT         12; # frame processing counters                                                               */
    variable DPY_CSR_CORE_REG_FRAME_BKG_COLOR     13; # solid background color                                                                  */
    variable DPY_CSR_CORE_REG_CLOCK_RATE          14; # clock rate of the clock ticks                                                           */ 
    variable DPY_CSR_CORE_REG_CLOCK_COUNT         15; # frame generation counters (in number of clock ticks).                                   */
    variable DPY_CSR_CORE_REG_LAYER_REG_IDX       16; # layer register indexes                                                                  */ 
    variable DPY_CSR_CORE_REG_LAYER_REG_VAL       17; # layer register value                                                                    */

    variable DPY_CSR_CORE_REG_LIST_CONFIG         18;                    
    variable DPY_CSR_CORE_REG_LIST_STATUS         19;                    
    variable DPY_CSR_CORE_REG_CRITICAL_CTL        20; 
    variable DPY_CSR_CORE_REG_CRITICAL_RSP0       21; 
    variable DPY_CSR_CORE_REG_CRITICAL_RSP1       22;                                                                    
    variable DPY_CSR_CORE_REG_GRAPHICS_CTL        24;
    variable DPY_CSR_CORE_REG_GRAPHICS_STS        25;                                                         
    variable DPY_CSR_CORE_REG_NUMBER              26;  
  




    variable DPY_CSR_CORE_REG_NUMBER              18;
    variable DPY_CSR_CORE_REG_NUMBER_BITSIZE       5  
    
    
      # /* DPY_CSR_CORE_REG_VERSION bitfields */ 
      variable DPY_CSR_VERSION_ID_MSK      0xFF       
      variable DPY_CSR_VERSION_ID_OFST     0          
      variable DPY_CSR_VERSION_BUILD_MSK   0xFF00      
      variable DPY_CSR_VERSION_BUILD_OFST  8          
      variable DPY_CSR_VERSION_MINOR_MSK   0xFF0000      
      variable DPY_CSR_VERSION_MINOR_OFST  16         
      variable DPY_CSR_VERSION_MAJOR_MSK   0x0F000000      
      variable DPY_CSR_VERSION_MAJOR_OFST  24         


      # /* DPY_CSR_CORE_REG_CAPS0 bitfields */ 
      # /* parameters */
      variable DPY_CSR_CAPS0_NB_LAYER_MSK     0x1FF    
      variable DPY_CSR_CAPS0_NB_LAYER_OFST    0       
      variable DPY_CSR_CAPS0_NB_SCREEN_MSK    0xF000  
      variable DPY_CSR_CAPS0_NB_SCREEN_OFST   12      

      #/* DPY_CSR_CORE_REG_CAPS1 bitfields */ 
      #/* features */
      variable DPY_CSR_CAPS1_ENABLE_DEBUG_MSK                  0x1
      variable DPY_CSR_CAPS1_ENABLE_DEBUG_OFST                 0
      variable DPY_CSR_CAPS1_ENABLE_LAYERS_MSK                 0x2
      variable DPY_CSR_CAPS1_ENABLE_LAYERS_OFST                1   

      
      variable DPY_CSR_CAPS1_ENABLE_LAYER_RESIZING_MSK         0x10000
      variable DPY_CSR_CAPS1_ENABLE_LAYER_RESIZING_OFST        16
      variable DPY_CSR_CAPS1_ENABLE_LAYER_FILTERING_H_MSK      0x20000
      variable DPY_CSR_CAPS1_ENABLE_LAYER_FILTERING_H_OFST     17
      variable DPY_CSR_CAPS1_ENABLE_LAYER_FILTERING_V_MSK      0x40000
      variable DPY_CSR_CAPS1_ENABLE_LAYER_FILTERING_V_OFST     18
      variable DPY_CSR_CAPS1_ENABLE_LAYER_COLOR_TRANSFORM_MSK  0x80000  
      variable DPY_CSR_CAPS1_ENABLE_LAYER_COLOR_TRANSFORM_OFST 19       
      variable DPY_CSR_CAPS1_ENABLE_LAYER_CRITICAL_MSK         0x100000 
      variable DPY_CSR_CAPS1_ENABLE_LAYER_CRITICAL_OFST        20       
      variable DPY_CSR_CAPS1_ENABLE_BANDWIDTH_VIEW_MSK         0x200000 
      variable DPY_CSR_CAPS1_ENABLE_BANDWIDTH_VIEW_OFST        21       
      variable DPY_CSR_CAPS1_ENABLE_BKG_COLOR_RUNTIME_MSK      0x400000 
      variable DPY_CSR_CAPS1_ENABLE_BKG_COLOR_RUNTIME_OFST     22       

#     variable DPY_CSR_CAPS1_ENABLE_LAYER_CHROMA_KEYING_MSK    0x80000
#     variable DPY_CSR_CAPS1_ENABLE_LAYER_CHROMA_KEYING_OFST   19
#     variable DPY_CSR_CAPS1_ENABLE_LAYER_TRANSPARENCY_MSK     0x100000
#     variable DPY_CSR_CAPS1_ENABLE_LAYER_TRANSPARENCY_OFST    20
#     variable DPY_CSR_CAPS1_ENABLE_LAYER_MASKING_MSK          0x200000
#     variable DPY_CSR_CAPS1_ENABLE_LAYER_MASKING_OFST         21



    # # /* DPY_CSR_CORE_REG_INTERRUPT bitfields */
    # # /* Interrupts-enable */
    # variable DPY_CSR_INTERRUPT_ENABLE_MSK            0xFF
    # variable DPY_CSR_INTERRUPT_ENABLE_OFST           0

          # /* bitfields for:                                       */
          # /*   - Interrupt enable (DPY_CSR_INTERRUPT_ENABLE_MSK)  */
          # /*   - Interrupt active (DPY_CSR_STATUS_IRQ_ACTIVE_MSK) */
          # /* Frame processing completion */
          variable DPY_CSR_IRQ_BIT_FRAME_COMPLETED_MSK  0x1
          variable DPY_CSR_IRQ_BIT_FRAME_COMPLETED_OFST 0
          # /* Video underflow (relevant with clocked interface) */
          variable DPY_CSR_IRQ_BIT_VIDEO_UNDERFLOW_MSK  0x2
          variable DPY_CSR_IRQ_BIT_VIDEO_UNDERFLOW_OFST 1
          # /* Layer-list swapped */
          variable DPY_CSR_IRQ_BIT_SWAP_COMPLETED_MSK   0x4
          variable DPY_CSR_IRQ_BIT_SWAP_COMPLETED_OFST  2

       
      # /* DPY_CSR_CORE_REG_CONTROL bitfields */
      # /* 0(default)/1 = frame processing Off/On */
      variable DPY_CSR_CONTROL_RUN_MSK        0x1
      variable DPY_CSR_CONTROL_RUN_OFST       0
      # /* 0/1 = vu meter off (default)/on */
      variable DPY_CSR_CONTROL_VUMETER_MSK    0x10
      variable DPY_CSR_CONTROL_VUMETER_OFST   4

      
      # /* DPY_CSR_CORE_REG_STATUS bitfields */ 
      variable DPY_CSR_STATUS_BUSY_MSK        0x1
      variable DPY_CSR_STATUS_BUSY_OFST       0
      variable DPY_CSR_STATUS_IRQ_MSK         0x2
      variable DPY_CSR_STATUS_IRQ_OFST        1
      variable DPY_CSR_STATUS_LAYER_NUM_MSK   0x1FF0 
      variable DPY_CSR_STATUS_LAYER_NUM_OFST  4        
      # /* 0/1 = interrupt active. read the register to get information about  */
      # /* active interrupts. write register to clears the interrupts:         */
      variable DPY_CSR_STATUS_IRQ_ACTIVE_MSK  0xFF0000
      variable DPY_CSR_STATUS_IRQ_ACTIVE_OFST 16

                
      # /* DPY_CSR_CORE_REG_FRAME_COUNT bitfields */
      # /* Frame processing count. increments synchronously to frame           */
      # /* processing completion (DPY_CSR_IRQ_BIT_FRAME_COMPLETED_MSK)         */
      variable DPY_CSR_FRAME_COUNT_MSK   0xFFFF0000
      variable DPY_CSR_FRAME_COUNT_OFST  16

      
      # /* DPY_CSR_CORE_REG_FRAME_BKG_COLOR bitfields */
      variable DPY_CSR_BKG_COLOR_B_MSK   0xFF
      variable DPY_CSR_BKG_COLOR_B_OFST  0
      variable DPY_CSR_BKG_COLOR_G_MSK   0xFF00
      variable DPY_CSR_BKG_COLOR_G_OFST  8
      variable DPY_CSR_BKG_COLOR_R_MSK   0xFF0000
      variable DPY_CSR_BKG_COLOR_R_OFST  16
          

      # DPY_CSR_CORE_REG_FRAME_RUN_SIZE  bitfields  
      # DPY_CSR_CORE_REG_SCREEN_POSITION                                                            
      # DPY_CSR_CORE_REG_SCREEN_SIZE                                                                
      variable DPY_CSR_SIZE16_H_MSK  0xFFFF                                                                                                                 
      variable DPY_CSR_SIZE16_H_OFST 0                                                                                                                    
      variable DPY_CSR_SIZE16_V_MSK  0xFFFF0000                                                                                                               
      variable DPY_CSR_SIZE16_V_OFST 16                                                                                                                    


      # /* DPY_CSR_CORE_REG_LAYER_REG_IDX bitfields */
      variable DPY_CSR_CORE_LAYER_IDX_NUM_MSK   0xFFFF                
      variable DPY_CSR_CORE_LAYER_IDX_NUM_OFST  0                   
      variable DPY_CSR_CORE_LAYER_IDX_REG_MSK   0xFFFF0000                
      variable DPY_CSR_CORE_LAYER_IDX_REG_OFST  16                   


#    /* DPY_CSR_CORE_REG_GRAPHICS_CTL bitfields */
#    #define DPY_CSR_CORE_GFX_CTL_PTR_NEXT_IDX_MSK      (0x3) // 2bits: range=[0..3]   
#    #define DPY_CSR_CORE_GFX_CTL_PTR_NEXT_IDX_OFST     (0)      
#    #define DPY_CSR_CORE_GFX_CTL_PTR_NEXT_DIRTY_MSK    (0x4)    
#    #define DPY_CSR_CORE_GFX_CTL_PTR_NEXT_DIRTY_OFST   (2)      
#
#    
#    /* DPY_CSR_CORE_REG_GRAPHICS_STS bitfields */
#    #define DPY_CSR_CORE_GFX_STS_SWAP_PENDING_MSK      (0x1)
#    #define DPY_CSR_CORE_GFX_STS_SWAP_PENDING_OFST     (0)
#  
#    #define DPY_CSR_CORE_GFX_STS_PTR_NEXT_IDX_MSK      (0x300);  # 2bits: range=[0..3]   
#    #define DPY_CSR_CORE_GFX_STS_PTR_NEXT_IDX_OFST     (8)      
#    #define DPY_CSR_CORE_GFX_STS_PTR_NEXT_DIRTY_MSK    (0x400)    
#    #define DPY_CSR_CORE_GFX_STS_PTR_NEXT_DIRTY_OFST   (10)      
#    #define DPY_CSR_CORE_GFX_STS_PTR_CURR_IDX_MSK      (0x3000); # 2bits: range=[0..3]
#    #define DPY_CSR_CORE_GFX_STS_PTR_CURR_IDX_OFST     (12)
#    #define DPY_CSR_CORE_GFX_STS_PTR_CURR_DIRTY_MSK    (0x4000)  
#    #define DPY_CSR_CORE_GFX_STS_PTR_CURR_DIRTY_OFST   (14)



 
    # /*
    #
    # V I D E O    section
    #
    # */
    
    variable DPY_CSR_VIDEO_REG_CAPS                0
    variable DPY_CSR_VIDEO_REG_CONTROL             1
    # /* Max supported width  (static configuration */
    
    # /* Max supported width/height (static configuration)  
    variable DPY_CSR_VIDEO_REG_FRAME_MAX_SIZE      3
    # /* actual width  */                             
    variable DPY_CSR_VIDEO_REG_FRAME_WIDTH         4
    # /* actual height */                               
    variable DPY_CSR_VIDEO_REG_FRAME_HEIGHT        5
    # /* Read-Only when runtime control is Off */       
    variable DPY_CSR_VIDEO_REG_CLOCKED_HFPW        6
    # /* Read-Only when runtime control is Off */       
    variable DPY_CSR_VIDEO_REG_CLOCKED_HSW         7
    # /* Read-Only when runtime control is Off */       
    variable DPY_CSR_VIDEO_REG_CLOCKED_HBPW        8
    # /* Read-Only when runtime control is Off */       
    variable DPY_CSR_VIDEO_REG_CLOCKED_VFPW        9
    # /* Read-Only when runtime control is Off */       
    variable DPY_CSR_VIDEO_REG_CLOCKED_VSW        10
    # /* Read-Only when runtime control is Off */       
    variable DPY_CSR_VIDEO_REG_CLOCKED_VBPW       11
    # /* Read-Only when runtime control is Off */       
    variable DPY_CSR_VIDEO_REG_CLOCKED_CONFIG     12
    # /* screenbuffer memory base address in bytes */
    variable DPY_CSR_VIDEO_REG_SCREEN_MEM_ADDR8_L 13   
    variable DPY_CSR_VIDEO_REG_SCREEN_MEM_ADDR8_H 14   
    # /* screenbuffer memory size required in bytes */
    variable DPY_CSR_VIDEO_REG_SCREEN_MEM_SIZE8   15   
    variable DPY_CSR_VIDEO_REG_NUMBER             16
    
      variable DPY_CSR_VIDEO_CLOCKED_VAL_MSK      0xFFFF
      variable DPY_CSR_VIDEO_CLOCKED_VAL_OFST     0  
     
    
      # /* DPY_CSR_VIDEO_REG_CAPS bitfields */                                                                    


      # /* 0/1: static/runtime parameters */                                 
      variable DPY_CSR_VIDEO_CAPS_ENABLE_RUNTIME_MSK        0x1
      variable DPY_CSR_VIDEO_CAPS_ENABLE_RUNTIME_OFST       0  
      # /* 0/1: streamed/clocked */                                        
      variable DPY_CSR_VIDEO_CAPS_ENABLE_CLOCKED_MSK        0x2
      variable DPY_CSR_VIDEO_CAPS_ENABLE_CLOCKED_OFST       1  
      # /* 0/1: line buffer only / screen buffer support */
      variable DPY_CSR_VIDEO_CAPS_ENABLE_SCREENBUFFER_MSK   0x4
      variable DPY_CSR_VIDEO_CAPS_ENABLE_SCREENBUFFER_OFST  2  
      # /* screen rotation feature. relevant when screen buffer is enabled */
      variable DPY_CSR_VIDEO_CAPS_ENABLE_SCREEROTATE_MSK    0x8   
      variable DPY_CSR_VIDEO_CAPS_ENABLE_SCREEROTATE_OFST   3     
      # /* horizontal flip */                                                 
      variable DPY_CSR_VIDEO_CAPS_ENABLE_FLIP_H_MSK         0x10  
      variable DPY_CSR_VIDEO_CAPS_ENABLE_FLIP_H_OFST        4     
      # /* vertical flip */                                              
      variable DPY_CSR_VIDEO_CAPS_ENABLE_FLIP_V_MSK         0x20 
      variable DPY_CSR_VIDEO_CAPS_ENABLE_FLIP_V_OFST        5 
      # /* test pattern generator */                                              
      variable DPY_CSR_VIDEO_CAPS_ENABLE_TPG_MSK            0x40 
      variable DPY_CSR_VIDEO_CAPS_ENABLE_TPG_OFST           6 



      # /* DPY_CSR_VIDEO_REG_CONTROL bitfields */
      # /* Horizontal scanline direction. 0/1= Left-Right / Right-Left */
      variable DPY_CSR_VIDEO_CTL_FLIP_H_MSK                     0x1
      variable DPY_CSR_VIDEO_CTL_FLIP_H_OFST                    0
      # /* Vertical scanline direction. 0/1 = Up-Down / Down-Up */
      variable DPY_CSR_VIDEO_CTL_FLIP_V_MSK                     0x2
      variable DPY_CSR_VIDEO_CTL_FLIP_V_OFST                    1
      # /* 0/1: line buffer (default) / frame buffer */    
      variable DPY_CSR_VIDEO_CTL_ENABLE_SCREENBUFFER_MSK        0x4                                                                                                                       
      variable DPY_CSR_VIDEO_CTL_ENABLE_SCREENBUFFER_OFST       2                                                                                                                            
      # /* 90� rotation. Requires screen-buffer operating mode */    
      variable DPY_CSR_VIDEO_CTL_SCREENBUFFER_ROTATE_MSK        0x8                                                                              
      variable DPY_CSR_VIDEO_CTL_SCREENBUFFER_ROTATE_OFST       3                                                                                   
      variable DPY_CSR_VIDEO_CTL_TPG_ACTIVE_MSK                 0x10                                                                              
      variable DPY_CSR_VIDEO_CTL_TPG_ACTIVE_OFST                4                                                                                   
      variable DPY_CSR_VIDEO_CTL_SCREENBUFFER_FRAME_REPEAT_MSK  0xFF00                                                                             
      variable DPY_CSR_VIDEO_CTL_SCREENBUFFER_FRAME_REPEAT_OFST 8                                                                                  
      variable DPY_CSR_VIDEO_CTL_TPG_BACK_MSK                   0xF0000                                                                             
      variable DPY_CSR_VIDEO_CTL_TPG_BACK_OFST                  16                                                                                  
      variable DPY_CSR_VIDEO_CTL_TPG_FORE_MSK                   0xF00000                                                                             
      variable DPY_CSR_VIDEO_CTL_TPG_FORE_OFST                  20                                                                                  
      
      # /* DPY_CSR_VIDEO_REG_CLOCKED_CONFIG bitfields */
      # /* Horizontal sync. polarity. 0/1 = active low/high: */
      variable DPY_CSR_VIDEO_CONFIG_HPOL_MSK   0x1
      variable DPY_CSR_VIDEO_CONFIG_HPOL_OFST  0  
      # /* Vertical sync. polarity.   0/1 = active low/high: */
      variable DPY_CSR_VIDEO_CONFIG_VPOL_MSK   0x2
      variable DPY_CSR_VIDEO_CONFIG_VPOL_OFST  1
    

    #-------------------------- MACRO------------------------------

    proc ATH_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_display::$field_name\_REG 
            set str_field_msk   ::cgx_display::$field_name\_MSK 
            set str_field_ofst  ::cgx_display::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc ATH_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_display::$field_name\_MSK 
        set str_field_ofst ::cgx_display::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }



 	
    #-------------------------- PUBLIC ------------------------------

    # <dev_base>  
    proc init { instance_idx } {

        if { ${::cgx_display::debug} == 1 } {
            set dash_path ${::cgx_display::dash_path} 
            set instance_idx [ dashboard_get_property $dash_path dash_instance_idx text ]  

           #set dev_base [ dashboard_get_property $dash_path dash_dev_base text ]
        }

      # set ::cgx_display::DPY_CSR_DEV_BASE ${dev_base} 
        set ::cgx_display::DPY_CSR_DEV_BASE [ cgx_fusion::get_dev_base ${cgx_fusion::DEF_CLASS_DPY} $instance_idx ]
        set ::cgx_display::DPY_CSR_DEV_BASE_SFCTRL [ expr ${::cgx_display::DPY_CSR_DEV_BASE} + 4*${::cgx_display::DPY_CSR_OFST_SFCTRL} ]    

        if { ${::cgx_display::debug} == 1 } {
            set dash_path ${::cgx_display::dash_path} 
            dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_display::DPY_CSR_DEV_BASE} ]
        } 
        
        set dev_success [ ::cgx_display::get_version ];  
            
        if {${dev_success} == 1} {
            set ::cgx_display::initialized 1
        } else {
            set ::cgx_display::initialized 0
        } 

        if { ${::cgx_display::debug} == 1 } {
            set dash_path ${::cgx_display::dash_path} 
            # CSR visibility triggered by get_caps 
            dashboard_set_property $dash_path grp_csr   visible false
            if {${dev_success} == 1} {
                puts " ${::cgx_display::IPCORE_LABEL} init successfull "
                dashboard_set_property $dash_path grp_core  visible true
            } else {
            	  puts " ${::cgx_display::IPCORE_LABEL} ERROR: device init failure "
                dashboard_set_property $dash_path grp_core  visible false
            } 
        } 
    }

 	   
    proc get_version { } {
        
        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_VERSION}] ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set v_id    [ ATH_GET_FIELD $reg DPY_CSR_VERSION_ID ] ;                              
        set v_build [ ATH_GET_FIELD $reg DPY_CSR_VERSION_BUILD ] ;                           
        set v_minor [ ATH_GET_FIELD $reg DPY_CSR_VERSION_MINOR ] ;                           
        set v_major [ ATH_GET_FIELD $reg DPY_CSR_VERSION_MAJOR ] ;                           
        set version $v_major.$v_minor                            

        if {$v_id == ${::cgx_display::IPCORE_PRODUCT} } {
          puts " ${::cgx_display::IPCORE_LABEL} detection successfull, core id = [ format 0x%x $v_id ] "
          puts " ${::cgx_display::IPCORE_LABEL} Version = $v_major.$v_minor, Build = $v_build"
          if { $version == ${::cgx_display::IPCORE_VERSION} } {
            set success 1
          } else {
            set success 0
            puts stdout " ${::cgx_display::IPCORE_LABEL} ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_display::IPCORE_VERSION} )"
            puts stdout "        please upgrade the dashboard version accordingly to the IP core "
          }
        } else {
          set success 0
          puts stdout " ${::cgx_display::IPCORE_LABEL} ERROR: device not detected at device base ${::cgx_display::DPY_CSR_DEV_BASE} "
          puts stdout "        core id = $v_id, reg = $reg "
          puts stdout "        please, set the right device base and press init again "
        }
        return $success

    }
  
 
    proc get_caps { } {

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_CAPS0}] ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set caps_num_layer  [ ATH_GET_FIELD $reg DPY_CSR_CAPS0_NB_LAYER  ]; 
      # set caps_num_clut   [ ATH_GET_FIELD $reg DPY_CSR_CAPS0_NB_CLUT   ]; 
        set caps_num_screen [ ATH_GET_FIELD $reg DPY_CSR_CAPS0_NB_SCREEN ]; 
      
 
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_CAPS1}] ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set caps_ena_debug            [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_DEBUG                ]; 
        set caps_ena_color_background [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_BKG_COLOR_RUNTIME    ]; 
        set caps_ena_bandwidth_view   [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_BANDWIDTH_VIEW       ]; 
        set caps_ena_resizing         [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_LAYER_RESIZING       ]; 
        set caps_ena_filtering_h      [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_LAYER_FILTERING_H    ]; 
        set caps_ena_filtering_v      [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_LAYER_FILTERING_V    ]; 
      # set caps_ena_chroma_keying    [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_LAYER_CHROMA_KEYING  ]; 
      # set caps_ena_transparency     [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_LAYER_TRANSPARENCY   ]; 
      # set caps_ena_masking          [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_LAYER_MASKING        ]; 
        set caps_ena_color_transform  [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_LAYER_COLOR_TRANSFORM]; 
        set caps_ena_layers           [ ATH_GET_FIELD $reg DPY_CSR_CAPS1_ENABLE_LAYERS               ]; 

        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CAPS}] ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set caps_video_ena_runtime      [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CAPS_ENABLE_RUNTIME      ]; 
        set caps_video_ena_clocked      [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CAPS_ENABLE_CLOCKED      ]; 
        set caps_video_ena_screenbuffer [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CAPS_ENABLE_SCREENBUFFER ]; 
        set caps_video_ena_screenrotate [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CAPS_ENABLE_SCREEROTATE  ]; 
        set caps_video_ena_flip_h       [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CAPS_ENABLE_FLIP_H       ]; 
        set caps_video_ena_flip_v       [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CAPS_ENABLE_FLIP_V       ]; 
        set caps_video_ena_tpg          [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CAPS_ENABLE_TPG          ]; 

        set ::cgx_display::caps_ena_debug              $caps_ena_debug             
        set ::cgx_display::caps_ena_color_background   $caps_ena_color_background  
        set ::cgx_display::caps_ena_bandwidth_view     $caps_ena_bandwidth_view    
        set ::cgx_display::caps_ena_resizing           $caps_ena_resizing          
        set ::cgx_display::caps_ena_filtering_h        $caps_ena_filtering_h       
        set ::cgx_display::caps_ena_filtering_v        $caps_ena_filtering_v       
      # set ::cgx_display::caps_ena_chroma_keying      $caps_ena_chroma_keying     
      # set ::cgx_display::caps_ena_transparency       $caps_ena_transparency      
      # set ::cgx_display::caps_ena_masking            $caps_ena_masking           
        set ::cgx_display::caps_ena_color_transform    $caps_ena_color_transform 
        set ::cgx_display::caps_ena_layers             $caps_ena_layers         
        set ::cgx_display::caps_num_layer              $caps_num_layer             
        set ::cgx_display::caps_num_screen             $caps_num_screen            
        set ::cgx_display::caps_video_ena_runtime      $caps_video_ena_runtime     
        set ::cgx_display::caps_video_ena_clocked      $caps_video_ena_clocked     
        set ::cgx_display::caps_video_ena_screenbuffer $caps_video_ena_screenbuffer
        set ::cgx_display::caps_video_ena_screenrotate $caps_video_ena_screenrotate
        set ::cgx_display::caps_video_ena_flip_h       $caps_video_ena_flip_h      
        set ::cgx_display::caps_video_ena_flip_v       $caps_video_ena_flip_v      
        set ::cgx_display::caps_video_ena_tpg          $caps_video_ena_tpg      
          
        puts "                                                                  "
        puts "  Capabilities:                                                   "
        puts "      core:                                                       "
        puts "      caps_ena_debug              = $caps_ena_debug               "
        puts "      caps_ena_color_background   = $caps_ena_color_background    "       
        puts "      caps_ena_bandwidth_view     = $caps_ena_bandwidth_view      "
        puts "      caps_ena_resizing           = $caps_ena_resizing            "
        puts "      caps_ena_filtering_h        = $caps_ena_filtering_h         "
        puts "      caps_ena_filtering_v        = $caps_ena_filtering_v         "
      # puts "      caps_ena_chroma_keying      = $caps_ena_chroma_keying       "
      # puts "      caps_ena_transparency       = $caps_ena_transparency        "
      # puts "      caps_ena_masking            = $caps_ena_masking             "
        puts "      caps_ena_color_transform    = $caps_ena_color_transform     "
        puts "      caps_ena_layers             = $caps_ena_layers              "
        puts "      caps_num_layer              = $caps_num_layer               "
        puts "      caps_num_screen             = $caps_num_screen              "
        puts "                                                                  "
        puts "      video:                                                      "
        puts "      caps_video_ena_runtime      = $caps_video_ena_runtime       "
        puts "      caps_video_ena_clocked      = $caps_video_ena_clocked       "
        puts "      caps_video_ena_screenbuffer = $caps_video_ena_screenbuffer  "
        puts "      caps_video_ena_screenrotate = $caps_video_ena_screenrotate  "
        puts "      caps_video_ena_flip_h       = $caps_video_ena_flip_h        "
        puts "      caps_video_ena_flip_v       = $caps_video_ena_flip_v        "
        puts "      caps_video_ena_tpg          = $caps_video_ena_tpg           "
        puts "                                                                  "
                                                                                                                                                        
        if { ${::cgx_display::debug} == 1 } {

            set dash_path ${::cgx_display::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true

            if { $caps_ena_layers==0 } {
                dashboard_set_property $dash_path grp_fct_composition visible false
            } else {    
                dashboard_set_property $dash_path grp_fct_composition visible true
            }

            if { $caps_video_ena_tpg==0 } {
                dashboard_set_property $dash_path grp_cfg_video_tpg visible false
            } else {    
                dashboard_set_property $dash_path grp_cfg_video_tpg visible true
            }

            if { $caps_ena_bandwidth_view==0} { 
                dashboard_set_property $dash_path dash_cfg_vumeter visible false
            } else {    
                dashboard_set_property $dash_path dash_cfg_vumeter visible true
            }
           
            if { $caps_ena_color_background==0} { 
                dashboard_set_property $dash_path dash_cfg_bkg_r editable false
                dashboard_set_property $dash_path dash_cfg_bkg_g editable false
                dashboard_set_property $dash_path dash_cfg_bkg_b editable false
            } else {    
                dashboard_set_property $dash_path dash_cfg_bkg_r editable true
                dashboard_set_property $dash_path dash_cfg_bkg_g editable true
                dashboard_set_property $dash_path dash_cfg_bkg_b editable true
            }

            if { $caps_video_ena_clocked==0} { 
                dashboard_set_property $dash_path grp_cfg_video_timings visible false
            } else {    
                dashboard_set_property $dash_path grp_cfg_video_timings visible true
            }
            
            if { $caps_video_ena_screenbuffer==0} { 
                dashboard_set_property $dash_path grp_cfg_video_sb    visible false
                dashboard_set_property $dash_path dash_cfg_vid_sb_rotate visible false         
            } else {    
                dashboard_set_property $dash_path grp_cfg_video_sb    visible true
                dashboard_set_property $dash_path dash_cfg_vid_sb_rotate visible true                     
            }
            if { $caps_video_ena_flip_h==0} { 
                dashboard_set_property $dash_path dash_cfg_vid_flip_h visible false         
            } else {    
                dashboard_set_property $dash_path dash_cfg_vid_flip_h visible true                     
            }
            if { $caps_video_ena_flip_v==0} { 
                dashboard_set_property $dash_path dash_cfg_vid_flip_v visible false         
            } else {    
                dashboard_set_property $dash_path dash_cfg_vid_flip_v visible true                     
            }

            # dashboard_set_property $dash_path  dash_cfg_vid_dump              enabled false                             
                
            if { $caps_video_ena_runtime==0} { 
                dashboard_set_property $dash_path  dash_cfg_vid_sb_ena  enabled  false        
                dashboard_set_property $dash_path  dash_cfg_vid_sb_rotate            enabled  false                             
                dashboard_set_property $dash_path  dash_cfg_vid_flip_h            enabled  false                             
                dashboard_set_property $dash_path  dash_cfg_vid_flip_v            enabled  false 
                dashboard_set_property $dash_path  dash_cfg_vid_hres              editable false                             
                dashboard_set_property $dash_path  dash_cfg_vid_vres              editable false                             
                dashboard_set_property $dash_path  dash_cfg_vid_hfpw              editable false                             
                dashboard_set_property $dash_path  dash_cfg_vid_hsw               editable false                             
                dashboard_set_property $dash_path  dash_cfg_vid_hbpw              editable false                             
                dashboard_set_property $dash_path  dash_cfg_vid_hpol              enabled  false                              
                dashboard_set_property $dash_path  dash_cfg_vid_vfpw              editable false                             
                dashboard_set_property $dash_path  dash_cfg_vid_vsw               editable false                             
                dashboard_set_property $dash_path  dash_cfg_vid_vbpw              editable false                             
                dashboard_set_property $dash_path  dash_cfg_vid_vpol              enabled  false                             
            } else {    
                dashboard_set_property $dash_path  dash_cfg_vid_sb_ena  enabled  true       
                dashboard_set_property $dash_path  dash_cfg_vid_sb_rotate            enabled  true                            
                dashboard_set_property $dash_path  dash_cfg_vid_flip_h            enabled  true                            
                dashboard_set_property $dash_path  dash_cfg_vid_flip_v            enabled  true
                dashboard_set_property $dash_path  dash_cfg_vid_hres              editable true                            
                dashboard_set_property $dash_path  dash_cfg_vid_vres              editable true                            
                dashboard_set_property $dash_path  dash_cfg_vid_hfpw              editable true                            
                dashboard_set_property $dash_path  dash_cfg_vid_hsw               editable true                            
                dashboard_set_property $dash_path  dash_cfg_vid_hbpw              editable true                            
                dashboard_set_property $dash_path  dash_cfg_vid_hpol              enabled  true                             
                dashboard_set_property $dash_path  dash_cfg_vid_vfpw              editable true                            
                dashboard_set_property $dash_path  dash_cfg_vid_vsw               editable true                            
                dashboard_set_property $dash_path  dash_cfg_vid_vbpw              editable true                            
                dashboard_set_property $dash_path  dash_cfg_vid_vpol              enabled  true                            
            }            
        }
    }


 #  proc set_interrupt { ie_bitfield } {
 #
 #      set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
 #
 #      if { ${::cgx_display::debug} == 1 } {
	#          set dash_path ${::cgx_display::dash_path} 
 #          set ie_bitfield 0
 #          if { [ dashboard_get_property $dash_path dash_cfg_ie_frame_completed checked ] == true } {
 #              set ie_bitfield [ ATH_SET_FIELD $ie_bitfield DPY_CSR_IRQ_BIT_FRAME_COMPLETED  1 ]
 #          }             
 #          if { [ dashboard_get_property $dash_path dash_cfg_ie_video_underflow checked ] == true } {
 #              set ie_bitfield [ ATH_SET_FIELD $ie_bitfield DPY_CSR_IRQ_BIT_VIDEO_UNDERFLOW  1 ]
 #          } 
 #      }  
 #      open_service master ${::boardInit::masterPath}
 #      set reg 0
 #      set reg [ ATH_SET_FIELD $reg DPY_CSR_INTERRUPT_ENABLE $ie_bitfield ]           
 #      master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_INTERRUPT}] ]  $reg
 #      close_service master ${::boardInit::masterPath}
 #  }


 #  proc get_interrupt { } {
 #
 #      set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
 #      open_service master ${::boardInit::masterPath}
 #      set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_INTERRUPT}] ] 0x1]; 
 #      set ie_bitfield [ ATH_GET_FIELD $reg DPY_CSR_INTERRUPT_ENABLE ]   
 #      close_service master ${::boardInit::masterPath}
 #
 #      if { ${::cgx_display::debug} == 0 } {
 #          puts "                                                            "
 #          puts "  interrupt:                                                "
 #          puts "         ie_bitfield = $ie_bitfield "      
 #          puts "                                                            "                                                                                                           
 #      }
 #      if { ${::cgx_display::debug} == 1 } {
 #          set dash_path ${::cgx_display::dash_path} 
 #          
 #          if { [ ATH_GET_FIELD $ie_bitfield DPY_CSR_IRQ_BIT_FRAME_COMPLETED ] == 1 } {
 #             dashboard_set_property $dash_path dash_cfg_ie_frame_completed checked true  
 #          } else { 
 #             dashboard_set_property $dash_path dash_cfg_ie_frame_completed checked false  
 #          }            
 #          if { [ ATH_GET_FIELD $ie_bitfield DPY_CSR_IRQ_BIT_VIDEO_UNDERFLOW ] == 1 } {
 #             dashboard_set_property $dash_path dash_cfg_ie_video_underflow checked true  
 #          } else { 
 #             dashboard_set_property $dash_path dash_cfg_ie_video_underflow checked false  
 #          }
 #       }
 #  }


    proc set_config { run vumeter bkg_r bkg_g bkg_b } {

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 

        if { ${::cgx_display::debug} == 1 } {
	          set dash_path ${::cgx_display::dash_path} 

	          set run 0 
            if { [ dashboard_get_property $dash_path dash_cfg_run checked ] == true } {
                set run 1
            } 
	          set vumeter 0 
            if { [ dashboard_get_property $dash_path dash_cfg_vumeter checked ] == true } {
                set vumeter 1
            } 

            set bkg_r [ dashboard_get_property $dash_path dash_cfg_bkg_r text ]
            set bkg_g [ dashboard_get_property $dash_path dash_cfg_bkg_g text ]
            set bkg_b [ dashboard_get_property $dash_path dash_cfg_bkg_b text ]

        }  

        set reg 0
        set reg [ ATH_SET_FIELD $reg DPY_CSR_CONTROL_RUN     $run ]
        set reg [ ATH_SET_FIELD $reg DPY_CSR_CONTROL_VUMETER $vumeter ]
           
        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_CONTROL}] ]  $reg
        close_service master ${::boardInit::masterPath}

        set reg 0
        set reg [ ATH_SET_FIELD $reg DPY_CSR_BKG_COLOR_R $bkg_r ]
        set reg [ ATH_SET_FIELD $reg DPY_CSR_BKG_COLOR_G $bkg_g ]
        set reg [ ATH_SET_FIELD $reg DPY_CSR_BKG_COLOR_B $bkg_b ]

        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_FRAME_BKG_COLOR}] ]  $reg 
	      close_service master ${::boardInit::masterPath}

    }
 
 
    proc get_config { } {

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}
        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_CONTROL}] ] 0x1]; 
        set cfg_run     [ ATH_GET_FIELD $reg DPY_CSR_CONTROL_RUN ]   
        set cfg_vumeter [ ATH_GET_FIELD $reg DPY_CSR_CONTROL_VUMETER ]   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_FRAME_BKG_COLOR}] ] 0x1]; 

        set cfg_bkg_r  [ ATH_GET_FIELD $reg DPY_CSR_BKG_COLOR_R ] 
        set cfg_bkg_g  [ ATH_GET_FIELD $reg DPY_CSR_BKG_COLOR_G ] 
        set cfg_bkg_b  [ ATH_GET_FIELD $reg DPY_CSR_BKG_COLOR_B ] 
 
	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_display::debug} == 1 } {
            set dash_path ${::cgx_display::dash_path} 
            
            if { ${cfg_run} == 1 } {
               dashboard_set_property $dash_path dash_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_run checked false  
            }
            
            if { ${cfg_vumeter} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vumeter checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vumeter checked false  
            }
            
            dashboard_set_property $dash_path dash_cfg_bkg_r  text $cfg_bkg_r
            dashboard_set_property $dash_path dash_cfg_bkg_g  text $cfg_bkg_g
            dashboard_set_property $dash_path dash_cfg_bkg_b  text $cfg_bkg_b
        }

    }

 

    proc get_status { } {
    	
        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}
        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_STATUS}] ] 0x1]; 
        set sts_busy       [ ATH_GET_FIELD $reg DPY_CSR_STATUS_BUSY ] ;  
        set sts_layer_num  [ ATH_GET_FIELD $reg DPY_CSR_STATUS_LAYER_NUM ] ;  
        set sts_ia_active  [ ATH_GET_FIELD $reg DPY_CSR_STATUS_IRQ_ACTIVE ] ;  
        set sts_irq        [ ATH_GET_FIELD $reg DPY_CSR_STATUS_IRQ ] ;  

        set sts_ia_frame_completed [ ATH_GET_FIELD $sts_ia_active DPY_CSR_IRQ_BIT_FRAME_COMPLETED ] ; 
        set sts_ia_video_underflow [ ATH_GET_FIELD $sts_ia_active DPY_CSR_IRQ_BIT_VIDEO_UNDERFLOW ] ; 
        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_FRAME_COUNT}] ] 0x1]; 
        set sts_frame_count [ ATH_GET_FIELD $reg DPY_CSR_FRAME_COUNT ] ;

        set sts_clock_rate      [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_CLOCK_RATE}] ] 0x1]; 
        set sts_draw_clockcount [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_CLOCK_COUNT}] ] 0x1]; 

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_FRAME_RUN_SIZE}] ] 0x1]; 
        set sts_frame_width  [ ATH_GET_FIELD $reg DPY_CSR_SIZE16_H ] ;                                                                                                             
        set sts_frame_height [ ATH_GET_FIELD $reg DPY_CSR_SIZE16_V ] ;                                                                                                             

	      close_service master ${::boardInit::masterPath}

        if { $sts_draw_clockcount == 0 } {
            set sts_fps -1
        } else {
            set sts_fps [ expr $sts_clock_rate / $sts_draw_clockcount ]
        }

        if { ${::cgx_display::debug} == 0 } {
            puts "                                              "
            puts " Status:                                      "
            puts "     core busy       =$sts_busy               "
            puts "     core interrupt  =$sts_irq                "
            puts "     frame completed =$sts_ia_frame_completed " 
            puts "     video underflow =$sts_ia_video_underflow "
            puts "     layer number    =$sts_layer_num          "
            puts "     frame width     =$sts_frame_width        "
            puts "     frame height    =$sts_frame_height       "
            puts "     frame count     =$sts_frame_count        "
            puts "     fps             =$sts_fps                "
            puts "                                              "                                                                                                                            
        }
        if { ${::cgx_display::debug} == 1 } {
	          set dash_path ${::cgx_display::dash_path} 

            if { ${sts_busy} } {
                dashboard_set_property $dash_path dash_sts_busy checked true 
            } else {                                                         
                dashboard_set_property $dash_path dash_sts_busy checked false
            } 
            
        #   if { ${sts_irq} == 1 } {
        #       dashboard_set_property $dash_path dash_sts_irq color "red"
        #   } else {
        #       dashboard_set_property $dash_path dash_sts_irq color "black"
        #   }

            if { ${sts_ia_frame_completed} } {
                dashboard_set_property $dash_path dash_sts_ia_frame_completed checked true     
            } else {                                                                  
                dashboard_set_property $dash_path dash_sts_ia_frame_completed checked false    
            }

            if { ${sts_ia_video_underflow} } {
                dashboard_set_property $dash_path dash_sts_ia_video_underflow checked true     
            } else {                                                                                     
                dashboard_set_property $dash_path dash_sts_ia_video_underflow checked false    
            }

            dashboard_set_property $dash_path dash_sts_frame_width  text ${sts_frame_width}    
            dashboard_set_property $dash_path dash_sts_frame_height text ${sts_frame_height} 
            dashboard_set_property $dash_path dash_sts_frame_count  text ${sts_frame_count} 
            dashboard_set_property $dash_path dash_layer_num        text ${sts_layer_num}    
        #   dashboard_set_property $dash_path dash_sts_desc_count   text ${sts_desc_count}    
            dashboard_set_property $dash_path dash_sts_fps          text ${sts_fps}    
        }
    }


    # clear all the status bits
    proc clr_status { } {
        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}

        # clear all irq-active bits
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_STATUS}] ] 0xFFFFFFFF
        # clear counters 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_FRAME_COUNT}] ] 0x0

        close_service master ${::boardInit::masterPath}

    }


    # /* Sync. polarity. 0/1 = active low/high: */
    proc video_set_timings { hres vres hfpw hsw hbpw vfpw vsw vbpw hpol vpol } {
 
        if { ${::cgx_display::debug} == 1 } {
	          set dash_path ${::cgx_display::dash_path} 

            set hpol 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_hpol checked ] == true } {
                set hpol 1
            }
            set vpol 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_vpol checked ] == true } {
                set vpol 1
            }
            set hres [ dashboard_get_property $dash_path dash_cfg_vid_hres text ]
            set vres [ dashboard_get_property $dash_path dash_cfg_vid_vres text ]
            set hfpw [ dashboard_get_property $dash_path dash_cfg_vid_hfpw text ]
            set hsw  [ dashboard_get_property $dash_path dash_cfg_vid_hsw  text ]
            set hbpw [ dashboard_get_property $dash_path dash_cfg_vid_hbpw text ]
            set vfpw [ dashboard_get_property $dash_path dash_cfg_vid_vfpw text ]
            set vsw  [ dashboard_get_property $dash_path dash_cfg_vid_vsw  text ]
            set vbpw [ dashboard_get_property $dash_path dash_cfg_vid_vbpw text ]
        }  

        set cfg 0
        set cfg [ ATH_SET_FIELD $cfg DPY_CSR_VIDEO_CONFIG_HPOL $hpol ] 
        set cfg [ ATH_SET_FIELD $cfg DPY_CSR_VIDEO_CONFIG_VPOL $vpol ] 

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}
 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_FRAME_WIDTH}    ] ]  $hres       
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_FRAME_HEIGHT}   ] ]  $vres      
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_HFPW}   ] ]  $hfpw
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_HSW}    ] ]  $hsw 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_HBPW}   ] ]  $hbpw
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_VFPW}   ] ]  $vfpw
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_VSW}    ] ]  $vsw 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_VBPW}   ] ]  $vbpw                                                                                                                                              
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_CONFIG} ] ]  $cfg
  
 	      close_service master ${::boardInit::masterPath}

    }

    proc video_get_timings { } {

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_FRAME_WIDTH}   ] ] 0x1]; 
        set hres [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CLOCKED_VAL ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_FRAME_HEIGHT}  ] ] 0x1]; 
        set vres [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CLOCKED_VAL ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_HFPW}  ] ] 0x1]; 
        set hfpw [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CLOCKED_VAL ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_HSW}   ] ] 0x1]; 
        set hsw  [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CLOCKED_VAL ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_HBPW}  ] ] 0x1]; 
        set hbpw [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CLOCKED_VAL ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_VFPW}  ] ] 0x1]; 
        set vfpw [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CLOCKED_VAL ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_VSW}   ] ] 0x1]; 
        set vsw  [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CLOCKED_VAL ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_VBPW}  ] ] 0x1]; 
        set vbpw [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CLOCKED_VAL ]                                   

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CLOCKED_CONFIG}] ] 0x1]; 
        set hpol [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CONFIG_HPOL ] 
        set vpol [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CONFIG_VPOL ] 

	      close_service master ${::boardInit::masterPath}
                  
        if { ${::cgx_display::debug} == 0 } {
            puts "                   "
            puts "  Video timings:   "
            puts "      hres = $hres "        
            puts "      vres = $vres "        
            puts "      hfpw = $hfpw "        
            puts "      hsw  = $hsw  "        
            puts "      hbpw = $hbpw "        
            puts "      vfpw = $vfpw "        
            puts "      vsw  = $vsw  "        
            puts "      vbpw = $vbpw "        
            puts "      hpol = $hpol "         
            puts "      vpol = $vpol "         
            puts "                   "                                                
        }                                                                                                                             
        if { ${::cgx_display::debug} == 1 } {
	          set dash_path ${::cgx_display::dash_path} 
            dashboard_set_property $dash_path dash_cfg_vid_hres text $hres
            dashboard_set_property $dash_path dash_cfg_vid_vres text $vres
            dashboard_set_property $dash_path dash_cfg_vid_hfpw text $hfpw
            dashboard_set_property $dash_path dash_cfg_vid_hsw  text $hsw 
            dashboard_set_property $dash_path dash_cfg_vid_hbpw text $hbpw
            dashboard_set_property $dash_path dash_cfg_vid_vfpw text $vfpw
            dashboard_set_property $dash_path dash_cfg_vid_vsw  text $vsw 
            dashboard_set_property $dash_path dash_cfg_vid_vbpw text $vbpw
            if { ${hpol} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_hpol checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_hpol checked false  
            } 
            if { ${vpol} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_vpol checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_vpol checked false  
            }            
        }
    }

    # frame_repeat mem_addr8 
    proc video_set_config { flip_h flip_v ena_screenbuffer rotate tpg_on tpg_back tpg_fore } {

        if { ${::cgx_display::debug} == 1 } {
	          set dash_path ${::cgx_display::dash_path} 

            set ena_screenbuffer 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_sb_ena checked ] == true } {
                set ena_screenbuffer 1
            }
            set flip_h 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_flip_h checked ] == true } {
                set flip_h 1
            }
            set flip_v 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_flip_v checked ] == true } {
                set flip_v 1
            }
            set rotate 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_sb_rotate checked ] == true } {
                set rotate 1
            }
            set tpg_on 0
            if { [ dashboard_get_property $dash_path dash_cfg_vid_tpg_on checked ] == true } {
                set tpg_on 1
            }
            set tpg_back [ dashboard_get_property $dash_path dash_cfg_vid_tpg_back selected ]
            set tpg_fore [ dashboard_get_property $dash_path dash_cfg_vid_tpg_fore selected ]
        }  

        set reg 0
        set reg [ ATH_SET_FIELD $reg DPY_CSR_VIDEO_CTL_FLIP_H              $flip_h           ] 
        set reg [ ATH_SET_FIELD $reg DPY_CSR_VIDEO_CTL_FLIP_V              $flip_v           ] 
        set reg [ ATH_SET_FIELD $reg DPY_CSR_VIDEO_CTL_ENABLE_SCREENBUFFER $ena_screenbuffer ] 
        set reg [ ATH_SET_FIELD $reg DPY_CSR_VIDEO_CTL_SCREENBUFFER_ROTATE $rotate           ] 
        set reg [ ATH_SET_FIELD $reg DPY_CSR_VIDEO_CTL_TPG_ACTIVE          $tpg_on           ] 
        set reg [ ATH_SET_FIELD $reg DPY_CSR_VIDEO_CTL_TPG_BACK            $tpg_back         ] 
        set reg [ ATH_SET_FIELD $reg DPY_CSR_VIDEO_CTL_TPG_FORE            $tpg_fore         ] 
              
        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath} 
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CONTROL} ] ]  $reg       
 	      close_service master ${::boardInit::masterPath}
    }


    proc video_get_config { } {

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_CONTROL}] ] 0x1]; 

        set cfg_vid_flip_h           [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CTL_FLIP_H                    ] 
        set cfg_vid_flip_v           [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CTL_FLIP_V                    ] 
        set cfg_vid_rotate           [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CTL_SCREENBUFFER_ROTATE       ] 
        set cfg_vid_ena_screenbuffer [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CTL_ENABLE_SCREENBUFFER       ] 
        set cfg_vid_frame_repeat     [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CTL_SCREENBUFFER_FRAME_REPEAT ] 
        set cfg_vid_tpg_on           [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CTL_TPG_ACTIVE ] 
        set cfg_vid_tpg_back         [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CTL_TPG_BACK   ] 
        set cfg_vid_tpg_fore         [ ATH_GET_FIELD $reg DPY_CSR_VIDEO_CTL_TPG_FORE   ] 

        set cfg_vid_mem_addr8 [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_SCREEN_MEM_ADDR8_L}] ] 0x1]; 
        set cfg_vid_mem_size8 [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + ${::cgx_display::DPY_CSR_VIDEO_REG_SCREEN_MEM_SIZE8}] ] 0x1]; 

	      close_service master ${::boardInit::masterPath}
                   
        if { ${::cgx_display::debug} == 0 } {
            puts "                                                  "
            puts "  Video Config:                                   "
            puts "      flip_h           =$cfg_vid_flip_h           "
            puts "      flip_v           =$cfg_vid_flip_v           "
            puts "      rotate           =$cfg_vid_rotate           "
            puts "      ena_screenbuffer =$cfg_vid_ena_screenbuffer "
            puts "      tpg_on           =$cfg_vid_tpg_on           "
            puts "      tpg_back         =$cfg_vid_tpg_back         "
            puts "      tpg_fore         =$cfg_vid_tpg_fore         "
            puts "                                                  "                                                                                                                                                                
        }
        if { ${::cgx_display::debug} == 1 } {
	          set dash_path ${::cgx_display::dash_path} 

            if { ${cfg_vid_flip_h} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_flip_h checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_flip_h checked false  
            }
            
            if { ${cfg_vid_flip_v} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_flip_v checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_flip_v checked false  
            }
            
            if { ${cfg_vid_rotate} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_sb_rotate checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_sb_rotate checked false  
            }
            
            if { ${cfg_vid_ena_screenbuffer} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_sb_ena checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_sb_ena checked false  
            }            

            if { ${cfg_vid_tpg_on} == 1 } {
               dashboard_set_property $dash_path dash_cfg_vid_tpg_on checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_vid_tpg_on checked false  
            }

            dashboard_set_property $dash_path dash_cfg_vid_tpg_back selected ${cfg_vid_tpg_back}
            dashboard_set_property $dash_path dash_cfg_vid_tpg_fore selected ${cfg_vid_tpg_fore}

        }
    }
 

    proc set_core_reg { reg32 reg_val} {
   
        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}
   
        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + $reg32 ] ]  $reg_val
   
        close_service master ${::boardInit::masterPath}
   
    }


    proc reg_get_field { id field_reg32 field_name } {
          
        set str_field_reg32 ::cgx_display_desc::$field_name\_REG 
        set str_field_msk   ::cgx_display_desc::$field_name\_MSK 
        set str_field_ofst  ::cgx_display_desc::$field_name\_OFST

        if { $field_reg32 != -1 } {
            set str_field_reg32 ::cgx_display_desc::$field_reg32 
        } 
        
        set field_reg32 [ subst $$str_field_reg32 ]
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]
        
      # set field_reg32_hw [ expr $field_reg32 - ${::cgx_display_desc::DSC_LAYER_REG_START} ]
        set field_reg32_hw $field_reg32
        
        set reg [ expr   \
           [ expr $id             << ${::cgx_display::DPY_CSR_CORE_LAYER_IDX_NUM_OFST} & ${::cgx_display::DPY_CSR_CORE_LAYER_IDX_NUM_MSK} ] | \
           [ expr $field_reg32_hw << ${::cgx_display::DPY_CSR_CORE_LAYER_IDX_REG_OFST} & ${::cgx_display::DPY_CSR_CORE_LAYER_IDX_REG_MSK} ] ]

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}

        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_LAYER_REG_IDX} ] ] $reg
        set reg [ master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_LAYER_REG_VAL} ] ] 0x1];         

        close_service master ${::boardInit::masterPath}

        set field_val [ expr [ expr ${reg} & $field_msk ] >> $field_ofst ]
                     
       #if { ${::cgx_display::debug} == 0 } {
        puts stdout "field $field_name = $field_val"
       #}
     
        return $field_val
             
    }
  
    proc layer_get_reg { id desc_reg32_idx } {
  
        set reg32_idx $desc_reg32_idx; #[ expr $desc_reg32_idx - ${::cgx_display_desc::DSC_LAYER_REG_START} ]
        
        set reg [ expr   \
           [ expr $id        << ${::cgx_display::DPY_CSR_CORE_LAYER_IDX_NUM_OFST} & ${::cgx_display::DPY_CSR_CORE_LAYER_IDX_NUM_MSK} ] | \
           [ expr $reg32_idx << ${::cgx_display::DPY_CSR_CORE_LAYER_IDX_REG_OFST} & ${::cgx_display::DPY_CSR_CORE_LAYER_IDX_REG_MSK} ] ]

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        open_service master ${::boardInit::masterPath}

        master_write_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_LAYER_REG_IDX} ] ] $reg
        set reg [ master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + ${::cgx_display::DPY_CSR_CORE_REG_LAYER_REG_VAL} ] ] 0x1];         

        close_service master ${::boardInit::masterPath}

        return $reg

    }


    proc dump_layer { layer_idx } {
 
        set id $layer_idx

        puts stdout " "
        puts stdout "layer#$id dump start: "
        puts stdout " "
 
        reg_get_field $id -1                    DPY_DSC_LAYER_VISIBLE            
       #reg_get_field $id -1                    DPY_DSC_LAYER_BOTTOM_UP           
        reg_get_field $id DPY_DSC_COLOR_KEY_REG DPY_DSC_COLOR_KEY_R    
        reg_get_field $id DPY_DSC_COLOR_KEY_REG DPY_DSC_COLOR_KEY_G    
        reg_get_field $id DPY_DSC_COLOR_KEY_REG DPY_DSC_COLOR_KEY_B    

      # if { ${::cgx_display::caps_ena_transparency} == 1} {
      #     reg_get_field $id -1 DSC_ALPHA  
      # }

        reg_get_field $id -1 DPY_DSC_LAYER_PRIMARY_TYPE
        reg_get_field $id -1 DPY_DSC_LAYER_PRIMARY_IDX
        reg_get_field $id -1 DPY_DSC_LAYER_NEXT            

        set class [ reg_get_field $id -1 DPY_DSC_LAYER_CLASS ]             
        if { $class == ${::cgx_display_desc::DPY_DSC_LAYER_CLASS_SURFACE} } {
            
            for {set i 0} { $i<${::cgx_surface::DESC_REG_NUMBER} } {incr i} {
            
                set desc($i) [ layer_get_reg $id [ expr ${::cgx_display_desc::DPY_DSC_LAYER_REG_SURFACE_BASE} +$i ] ]
            
            }
            
            set clut_start_idx -2 
            set ptr_next -2
            set sfc_name sfc0
            
            cgx_surface::surface_get_desc desc $sfc_name clut_start_idx ptr_next    
            
            ::cgx_surface_ctrl::put_surface $sfc_name
        }
 
    #   if { ${::cgx_display::caps_ena_chroma_keying} == 1} {
    #       reg_get_field $id -1 DPY_DSC_LAYER_CHROMA_KEYING  
    #   }
    #
    #   if { ${::cgx_display::caps_ena_filtering_v} == 1} {
    #       reg_get_field $id -1 DPY_DSC_LAYER_EN_FILTERING  
    #   }

    #   if { ${::cgx_display::caps_ena_color_transform} == 1} {
    #       reg_get_field $id -1 DSC_COLOR_TRANSFORM_SCALE_A                  
    #       reg_get_field $id -1 DSC_COLOR_TRANSFORM_SCALE_R                  
    #       reg_get_field $id -1 DSC_COLOR_TRANSFORM_SCALE_G                  
    #       reg_get_field $id -1 DSC_COLOR_TRANSFORM_SCALE_B                  
    #       reg_get_field $id -1 DSC_COLOR_TRANSFORM_BIAS_A                   
    #       reg_get_field $id -1 DSC_COLOR_TRANSFORM_BIAS_R                   
    #       reg_get_field $id -1 DSC_COLOR_TRANSFORM_BIAS_G                   
    #       reg_get_field $id -1 DSC_COLOR_TRANSFORM_BIAS_B                   
    #   }

     #  if { ${::cgx_display::caps_ena_masking} == 1} { 
     #      reg_get_field $id DSC_LAYER_MASK_REG DSC_LAYER_IS_A_MASK                          
     #      reg_get_field $id DSC_LAYER_MASK_REG DSC_LAYER_MASK_COLOR_PLANE                   
     #      reg_get_field $id DSC_LAYER_MASK_REG DSC_LAYER_MASK_COLOR_INVERT                  
     #      reg_get_field $id DSC_LAYER_MASK_REG DSC_LAYER_IS_MASKED            
     #  }
 
    #  # set invalid [ reg_get_field $id -1 DSC_LAYER_GEOMETRY_INVALID ]  
    #  # if { $invalid == 0} { 
    #    reg_get_field $id -1 DSC_LAYER_SCREEN_ID            
    #    reg_get_field $id -1 DSC_LAYER_SRC_X        
    #    reg_get_field $id -1 DSC_LAYER_SRC_Y        
    #  # reg_get_field $id -1 DSC_LAYER_CLIP_DX           
    #  # reg_get_field $id -1 DSC_LAYER_CLIP_DY           
    #    reg_get_field $id -1 DSC_LAYER_SCALEX                                 
    #    reg_get_field $id -1 DSC_LAYER_SCALEY                                 
    #  # reg_get_field $id DSC_LAYER_REG_RECT_H DSC_LAYER_POS           
    #  # reg_get_field $id DSC_LAYER_REG_RECT_V DSC_LAYER_POS                              
    #  # reg_get_field $id DSC_LAYER_REG_RECT_H DSC_LAYER_SIZE                              
    #  # reg_get_field $id DSC_LAYER_REG_RECT_V DSC_LAYER_SIZE                              
    #  # }

    }
 

    proc dump_core { } {

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        set addr [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_CORE} + 0x0] ] 

        open_service master ${::boardInit::masterPath}
        set reg [ master_read_32 ${::boardInit::masterPath} ${addr} ${::cgx_display::DPY_CSR_CORE_REG_NUMBER} ]
	      close_service master ${::boardInit::masterPath}

        puts stdout "dump core at $addr:"
        puts stdout "$reg"
    }

    proc dump_video { } {

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        set addr [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_VIDEO} + 0x0] ]

        open_service master ${::boardInit::masterPath}
        set reg [ master_read_32 ${::boardInit::masterPath} ${addr} ${::cgx_display::DPY_CSR_VIDEO_REG_NUMBER} ] 
	      close_service master ${::boardInit::masterPath}

        puts stdout "dump video at $addr:"
        puts stdout "$reg"

    }

    proc dump_surface_ctrl { idx } {

        set csr_base8 ${::cgx_display::DPY_CSR_DEV_BASE} 
        set addr [ expr $csr_base8 + 4 * [ expr ${::cgx_display::DPY_CSR_OFST_SFCTRL} + $idx * ${::cgx_surface_ctrl::DPY_CSR_HOST_SFC_SIZE} ] ]

        open_service master ${::boardInit::masterPath}
        set reg [ master_read_32 ${::boardInit::masterPath} ${addr} ${::cgx_surface_ctrl::DPY_CSR_HOST_SFC_SIZE} ] 
	      close_service master ${::boardInit::masterPath}

        puts stdout "dump sfctrl at $addr:"
        puts stdout "$reg"

    }


    proc dashBoard { } {

        if { ${::cgx_display::dashboardActive} == 1 } {
            return -code ok " ${::cgx_display::IPCORE_LABEL} dashboard already active"
        }

        set ::cgx_display::dashboardActive 1
        puts stdout " ${::cgx_display::IPCORE_LABEL} dashBoard start ......."


        #
        # Create dashboard 
        #
        variable ::cgx_display::dash_path [ add_service dashboard cgx_display "cgx_display" "Tools/DISPLAY CONTROLLER"]
 
        set dash_path ${::cgx_display::dash_path} 
 
        #
        # Set dashboard properties
        #
        dashboard_set_property $dash_path self developmentMode true
        dashboard_set_property $dash_path self itemsPerRow 1
        dashboard_set_property $dash_path self visible true
        
        #
        # groups
        #
        dashboard_add          $dash_path grp_top group self
        dashboard_set_property $dash_path grp_top expandableX false
        dashboard_set_property $dash_path grp_top expandableY false
        dashboard_set_property $dash_path grp_top itemsPerRow 1
        dashboard_set_property $dash_path grp_top title ""
 
        dashboard_add          $dash_path grp_device group grp_top
        dashboard_set_property $dash_path grp_device expandableX false
        dashboard_set_property $dash_path grp_device expandableY false
        dashboard_set_property $dash_path grp_device itemsPerRow 4
        dashboard_set_property $dash_path grp_device title "Device"

        dashboard_add          $dash_path grp_core group grp_top
        dashboard_set_property $dash_path grp_core expandableX false
        dashboard_set_property $dash_path grp_core expandableY false
        dashboard_set_property $dash_path grp_core itemsPerRow 1
        dashboard_set_property $dash_path grp_core title "Core ${::cgx_display::IPCORE_VERSION}"
        dashboard_set_property $dash_path grp_core visible false; # dashboard init

        dashboard_add          $dash_path grp_core_cmd group grp_core
        dashboard_set_property $dash_path grp_core_cmd expandableX false
        dashboard_set_property $dash_path grp_core_cmd expandableY false
        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 2
        dashboard_set_property $dash_path grp_core_cmd title ""

        dashboard_add          $dash_path grp_csr group grp_core
        dashboard_set_property $dash_path grp_csr expandableX false
        dashboard_set_property $dash_path grp_csr expandableY false
        dashboard_set_property $dash_path grp_csr itemsPerRow 1
        dashboard_set_property $dash_path grp_csr title ""
        dashboard_set_property $dash_path grp_csr visible false; # dashboard init

        dashboard_add          $dash_path grp_cmd group grp_csr 
        dashboard_set_property $dash_path grp_cmd expandableX false
        dashboard_set_property $dash_path grp_cmd expandableY false
        dashboard_set_property $dash_path grp_cmd itemsPerRow 5
        dashboard_set_property $dash_path grp_cmd title "Control"

        dashboard_add          $dash_path grp_fct group grp_csr
        dashboard_set_property $dash_path grp_fct expandableX false
        dashboard_set_property $dash_path grp_fct expandableY false
        dashboard_set_property $dash_path grp_fct itemsPerRow 4
        dashboard_set_property $dash_path grp_fct title ""

      # dashboard_add          $dash_path grp_csr_main group grp_csr
      # dashboard_set_property $dash_path grp_csr_main expandableX false
      # dashboard_set_property $dash_path grp_csr_main expandableY false
      # dashboard_set_property $dash_path grp_csr_main itemsPerRow 2
      # dashboard_set_property $dash_path grp_csr_main title ""

      # dashboard_add          $dash_path grp_config group grp_csr_main
      # dashboard_set_property $dash_path grp_config expandableX false
      # dashboard_set_property $dash_path grp_config expandableY true
      # dashboard_set_property $dash_path grp_config itemsPerRow 1
      # dashboard_set_property $dash_path grp_config title "Config"

      # dashboard_add          $dash_path grp_status group grp_csr_main
      # dashboard_set_property $dash_path grp_status expandableX false
      # dashboard_set_property $dash_path grp_status expandableY true
      # dashboard_set_property $dash_path grp_status itemsPerRow 1
      # dashboard_set_property $dash_path grp_status title "Status"



      # dashboard_add          $dash_path grp_cfg_cmd group grp_config
      # dashboard_set_property $dash_path grp_cfg_cmd expandableX false
      # dashboard_set_property $dash_path grp_cfg_cmd expandableY false
      # dashboard_set_property $dash_path grp_cfg_cmd itemsPerRow 2
      # dashboard_set_property $dash_path grp_cfg_cmd title ""

        dashboard_add          $dash_path grp_fct_com group grp_fct
        dashboard_set_property $dash_path grp_fct_com expandableX false
        dashboard_set_property $dash_path grp_fct_com expandableY false
        dashboard_set_property $dash_path grp_fct_com itemsPerRow 1
        dashboard_set_property $dash_path grp_fct_com title ""


    #   dashboard_add          $dash_path grp_sts_param group grp_status
    #   dashboard_set_property $dash_path grp_sts_param expandableX false
    #   dashboard_set_property $dash_path grp_sts_param expandableY false
    #   dashboard_set_property $dash_path grp_sts_param itemsPerRow 3
    #   dashboard_set_property $dash_path grp_sts_param title ""
    #
    #   dashboard_add          $dash_path grp_sts_irq group grp_status
    #   dashboard_set_property $dash_path grp_sts_irq expandableX false
    #   dashboard_set_property $dash_path grp_sts_irq expandableY false
    #   dashboard_set_property $dash_path grp_sts_irq itemsPerRow 1
    #   dashboard_set_property $dash_path grp_sts_irq title "interrupt active"

      # dashboard_add          $dash_path grp_cfg_irq group grp_config
      # dashboard_set_property $dash_path grp_cfg_irq expandableX false
      # dashboard_set_property $dash_path grp_cfg_irq expandableY false
      # dashboard_set_property $dash_path grp_cfg_irq itemsPerRow 1
      # dashboard_set_property $dash_path grp_cfg_irq title "interrupt enable"

        dashboard_add          $dash_path grp_fct_composition group grp_fct
        dashboard_set_property $dash_path grp_fct_composition expandableX false
        dashboard_set_property $dash_path grp_fct_composition expandableY true
        dashboard_set_property $dash_path grp_fct_composition itemsPerRow 1
        dashboard_set_property $dash_path grp_fct_composition title "Composition"

        dashboard_add          $dash_path grp_fct_video_out group grp_fct
        dashboard_set_property $dash_path grp_fct_video_out expandableX false
        dashboard_set_property $dash_path grp_fct_video_out expandableY true
        dashboard_set_property $dash_path grp_fct_video_out itemsPerRow 1
        dashboard_set_property $dash_path grp_fct_video_out title "Video-out"

        dashboard_add          $dash_path grp_compo_frame group grp_fct_composition
        dashboard_set_property $dash_path grp_compo_frame expandableX false
        dashboard_set_property $dash_path grp_compo_frame expandableY false
        dashboard_set_property $dash_path grp_compo_frame itemsPerRow 4
        dashboard_set_property $dash_path grp_compo_frame title "frame info"

        dashboard_add          $dash_path grp_compo_layer group grp_fct_composition
        dashboard_set_property $dash_path grp_compo_layer expandableX false
        dashboard_set_property $dash_path grp_compo_layer expandableY false
        dashboard_set_property $dash_path grp_compo_layer itemsPerRow 3
        dashboard_set_property $dash_path grp_compo_layer title "layers info"

        dashboard_add          $dash_path grp_compo_bkg group grp_fct_composition
        dashboard_set_property $dash_path grp_compo_bkg expandableX false
        dashboard_set_property $dash_path grp_compo_bkg expandableY false
        dashboard_set_property $dash_path grp_compo_bkg itemsPerRow 4
        dashboard_set_property $dash_path grp_compo_bkg title "background"

        dashboard_add          $dash_path grp_cfg_video_size group grp_fct_video_out
        dashboard_set_property $dash_path grp_cfg_video_size expandableX false
        dashboard_set_property $dash_path grp_cfg_video_size expandableY false
        dashboard_set_property $dash_path grp_cfg_video_size itemsPerRow 4
        dashboard_set_property $dash_path grp_cfg_video_size title ""

        dashboard_add          $dash_path grp_cfg_video_timings group grp_fct_video_out
        dashboard_set_property $dash_path grp_cfg_video_timings expandableX false
        dashboard_set_property $dash_path grp_cfg_video_timings expandableY false
        dashboard_set_property $dash_path grp_cfg_video_timings itemsPerRow 1
        dashboard_set_property $dash_path grp_cfg_video_timings title "timings"

        dashboard_add          $dash_path grp_cfg_video_timings_h group grp_cfg_video_timings
        dashboard_set_property $dash_path grp_cfg_video_timings_h expandableX false
        dashboard_set_property $dash_path grp_cfg_video_timings_h expandableY false
        dashboard_set_property $dash_path grp_cfg_video_timings_h itemsPerRow 4
        dashboard_set_property $dash_path grp_cfg_video_timings_h title "horizontal"

        dashboard_add          $dash_path grp_cfg_video_timings_v group grp_cfg_video_timings
        dashboard_set_property $dash_path grp_cfg_video_timings_v expandableX false
        dashboard_set_property $dash_path grp_cfg_video_timings_v expandableY false
        dashboard_set_property $dash_path grp_cfg_video_timings_v itemsPerRow 4
        dashboard_set_property $dash_path grp_cfg_video_timings_v title "vertical"

        dashboard_add          $dash_path grp_cfg_video_sb group grp_fct_video_out
        dashboard_set_property $dash_path grp_cfg_video_sb expandableX false
        dashboard_set_property $dash_path grp_cfg_video_sb expandableY false
        dashboard_set_property $dash_path grp_cfg_video_sb itemsPerRow 3
        dashboard_set_property $dash_path grp_cfg_video_sb title "screen-buffer"

        dashboard_add          $dash_path grp_cfg_video_tpg group grp_fct_video_out
        dashboard_set_property $dash_path grp_cfg_video_tpg expandableX false
        dashboard_set_property $dash_path grp_cfg_video_tpg expandableY false
        dashboard_set_property $dash_path grp_cfg_video_tpg itemsPerRow 3
        dashboard_set_property $dash_path grp_cfg_video_tpg title "test pattern"



        #
        # widgets
        #

        dashboard_add          $dash_path dash_instance_idx text grp_device 
        dashboard_set_property $dash_path dash_instance_idx label "Index" 
        dashboard_set_property $dash_path dash_instance_idx expandableX false
        dashboard_set_property $dash_path dash_instance_idx expandableY false
        dashboard_set_property $dash_path dash_instance_idx preferredWidth 30
        dashboard_set_property $dash_path dash_instance_idx editable true
        dashboard_set_property $dash_path dash_instance_idx htmlCapable false
        dashboard_set_property $dash_path dash_instance_idx text 0

        dashboard_add          $dash_path dash_dev_init button grp_device 
        dashboard_set_property $dash_path dash_dev_init enabled true
        dashboard_set_property $dash_path dash_dev_init text "Init"
        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_display::dash_init_device } 

        dashboard_add          $dash_path dash_dev_dump button grp_device 
        dashboard_set_property $dash_path dash_dev_dump enabled true
        dashboard_set_property $dash_path dash_dev_dump text "Dump"
        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_display::dash_dump_device }  

        dashboard_add          $dash_path dash_dev_base text grp_device 
        dashboard_set_property $dash_path dash_dev_base label "base" 
        dashboard_set_property $dash_path dash_dev_base expandableX false
        dashboard_set_property $dash_path dash_dev_base expandableY false
        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
        dashboard_set_property $dash_path dash_dev_base editable false
        dashboard_set_property $dash_path dash_dev_base htmlCapable false
        dashboard_set_property $dash_path dash_dev_base text [ format 0x%x ${::cgx_display::DPY_CSR_DEV_BASE} ] 

        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_version enabled true
        dashboard_set_property $dash_path dash_dev_version text "Version"
        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_display::get_version }  

        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_caps enabled true
        dashboard_set_property $dash_path dash_dev_caps text "Caps"
        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_display::dash_get_caps }  
          
        dashboard_add          $dash_path dash_cfg_bkg_r text grp_compo_bkg 
        dashboard_set_property $dash_path dash_cfg_bkg_r label "R"
        dashboard_set_property $dash_path dash_cfg_bkg_r expandableX false
        dashboard_set_property $dash_path dash_cfg_bkg_r expandableY false
        dashboard_set_property $dash_path dash_cfg_bkg_r preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_bkg_r editable true 
        dashboard_set_property $dash_path dash_cfg_bkg_r htmlCapable false
        dashboard_set_property $dash_path dash_cfg_bkg_r text "255"

        dashboard_add          $dash_path dash_cfg_bkg_g text grp_compo_bkg 
        dashboard_set_property $dash_path dash_cfg_bkg_g label "G"
        dashboard_set_property $dash_path dash_cfg_bkg_g expandableX false
        dashboard_set_property $dash_path dash_cfg_bkg_g expandableY false
        dashboard_set_property $dash_path dash_cfg_bkg_g preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_bkg_g editable true
        dashboard_set_property $dash_path dash_cfg_bkg_g htmlCapable false
        dashboard_set_property $dash_path dash_cfg_bkg_g text "0"

        dashboard_add          $dash_path dash_cfg_bkg_b text grp_compo_bkg 
        dashboard_set_property $dash_path dash_cfg_bkg_b label "B"
        dashboard_set_property $dash_path dash_cfg_bkg_b expandableX false
        dashboard_set_property $dash_path dash_cfg_bkg_b expandableY false
        dashboard_set_property $dash_path dash_cfg_bkg_b preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_bkg_b editable true
        dashboard_set_property $dash_path dash_cfg_bkg_b htmlCapable false
        dashboard_set_property $dash_path dash_cfg_bkg_b text "0"

        dashboard_add          $dash_path dash_cfg_vumeter checkBox grp_compo_bkg         
        dashboard_set_property $dash_path dash_cfg_vumeter text "bandwidth viewer"
        dashboard_set_property $dash_path dash_cfg_vumeter enabled true

        dashboard_add          $dash_path dash_sb_sfctl_base text grp_cfg_video_sb 
        dashboard_set_property $dash_path dash_sb_sfctl_base label "sfctl" 
        dashboard_set_property $dash_path dash_sb_sfctl_base expandableX false
        dashboard_set_property $dash_path dash_sb_sfctl_base expandableY false
        dashboard_set_property $dash_path dash_sb_sfctl_base preferredWidth 80
        dashboard_set_property $dash_path dash_sb_sfctl_base editable false
        dashboard_set_property $dash_path dash_sb_sfctl_base htmlCapable false
        dashboard_set_property $dash_path dash_sb_sfctl_base text [ format 0x%x ${::cgx_display::DPY_CSR_DEV_BASE_SFCTRL} ]
         
        dashboard_add          $dash_path dash_cfg_vid_sb_ena checkBox grp_cfg_video_sb         
        dashboard_set_property $dash_path dash_cfg_vid_sb_ena text "active"
        dashboard_set_property $dash_path dash_cfg_vid_sb_ena enabled true
        
        dashboard_add          $dash_path dash_cfg_vid_sb_rotate checkBox grp_cfg_video_sb         
        dashboard_set_property $dash_path dash_cfg_vid_sb_rotate text "rotation"
        dashboard_set_property $dash_path dash_cfg_vid_sb_rotate enabled true

        dashboard_add          $dash_path dash_cfg_vid_tpg_on checkBox grp_cfg_video_tpg         
        dashboard_set_property $dash_path dash_cfg_vid_tpg_on text "active"

        dashboard_add          $dash_path dash_cfg_vid_tpg_back comboBox grp_cfg_video_tpg 
        dashboard_set_property $dash_path dash_cfg_vid_tpg_back label "background"
        dashboard_set_property $dash_path dash_cfg_vid_tpg_back options { "random" "off" "gradient H" "gradient V" "gradient" "colorbar" "checker" }
        dashboard_set_property $dash_path dash_cfg_vid_tpg_back expandableX false
        dashboard_set_property $dash_path dash_cfg_vid_tpg_back expandableY false
        dashboard_set_property $dash_path dash_cfg_vid_tpg_back preferredWidth 70
        dashboard_set_property $dash_path dash_cfg_vid_tpg_back selected 2; # gradient H   

        dashboard_add          $dash_path dash_cfg_vid_tpg_fore comboBox grp_cfg_video_tpg 
        dashboard_set_property $dash_path dash_cfg_vid_tpg_fore label "foreground"
        dashboard_set_property $dash_path dash_cfg_vid_tpg_fore options { "random" "off" "bounds" "scrollbar H" "scrollbar V" }
        dashboard_set_property $dash_path dash_cfg_vid_tpg_fore expandableX false
        dashboard_set_property $dash_path dash_cfg_vid_tpg_fore expandableY false
        dashboard_set_property $dash_path dash_cfg_vid_tpg_fore preferredWidth 70
        dashboard_set_property $dash_path dash_cfg_vid_tpg_fore selected 3; # scrollbar H   

        dashboard_add          $dash_path dash_cfg_vid_hres text grp_cfg_video_size 
        dashboard_set_property $dash_path dash_cfg_vid_hres label "width"
        dashboard_set_property $dash_path dash_cfg_vid_hres preferredWidth 70
        dashboard_set_property $dash_path dash_cfg_vid_hres text "0"

        dashboard_add          $dash_path dash_cfg_vid_vres text grp_cfg_video_size 
        dashboard_set_property $dash_path dash_cfg_vid_vres label "height"
        dashboard_set_property $dash_path dash_cfg_vid_vres preferredWidth 70
        dashboard_set_property $dash_path dash_cfg_vid_vres text "0"

        dashboard_add          $dash_path dash_cfg_vid_flip_h checkBox grp_cfg_video_size         
        dashboard_set_property $dash_path dash_cfg_vid_flip_h text "flip H"

        dashboard_add          $dash_path dash_cfg_vid_flip_v checkBox grp_cfg_video_size         
        dashboard_set_property $dash_path dash_cfg_vid_flip_v text "flip V"
        
        dashboard_add          $dash_path dash_cfg_vid_hfpw text grp_cfg_video_timings_h 
        dashboard_set_property $dash_path dash_cfg_vid_hfpw label "hfpw"
        dashboard_set_property $dash_path dash_cfg_vid_hfpw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_hfpw text "0"
        dashboard_set_property $dash_path dash_cfg_vid_hfpw expandableX false
        dashboard_set_property $dash_path dash_cfg_vid_hfpw expandableY false
        dashboard_set_property $dash_path dash_cfg_vid_hfpw htmlCapable false

        dashboard_add          $dash_path dash_cfg_vid_hsw text grp_cfg_video_timings_h 
        dashboard_set_property $dash_path dash_cfg_vid_hsw label "hsw"
        dashboard_set_property $dash_path dash_cfg_vid_hsw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_hsw text "0"

        dashboard_add          $dash_path dash_cfg_vid_hbpw text grp_cfg_video_timings_h 
        dashboard_set_property $dash_path dash_cfg_vid_hbpw label "hbpw"
        dashboard_set_property $dash_path dash_cfg_vid_hbpw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_hbpw text "0"

        dashboard_add          $dash_path dash_cfg_vid_hpol checkBox grp_cfg_video_timings_h         
        dashboard_set_property $dash_path dash_cfg_vid_hpol text "polarity"

        dashboard_add          $dash_path dash_cfg_vid_vfpw text grp_cfg_video_timings_v 
        dashboard_set_property $dash_path dash_cfg_vid_vfpw label "vfpw"
        dashboard_set_property $dash_path dash_cfg_vid_vfpw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_vfpw text "0"

        dashboard_add          $dash_path dash_cfg_vid_vsw text grp_cfg_video_timings_v 
        dashboard_set_property $dash_path dash_cfg_vid_vsw label "vsw"
        dashboard_set_property $dash_path dash_cfg_vid_vsw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_vsw text "0"

        dashboard_add          $dash_path dash_cfg_vid_vbpw text grp_cfg_video_timings_v 
        dashboard_set_property $dash_path dash_cfg_vid_vbpw label "vbpw"
        dashboard_set_property $dash_path dash_cfg_vid_vbpw preferredWidth 40
        dashboard_set_property $dash_path dash_cfg_vid_vbpw text "0"

        dashboard_add          $dash_path dash_cfg_vid_vpol checkBox grp_cfg_video_timings_v         
        dashboard_set_property $dash_path dash_cfg_vid_vpol text "polarity"
       
    #   dashboard_add          $dash_path dash_cfg_ie_frame_completed checkBox grp_cfg_irq
    #   dashboard_set_property $dash_path dash_cfg_ie_frame_completed text "frame completed"
    #
    #   dashboard_add          $dash_path dash_cfg_ie_video_underflow checkBox grp_cfg_irq
    #   dashboard_set_property $dash_path dash_cfg_ie_video_underflow text "video underflow"

        dashboard_add          $dash_path dash_cfg_set button grp_cmd 
        dashboard_set_property $dash_path dash_cfg_set enabled true
        dashboard_set_property $dash_path dash_cfg_set text "Set"
        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_display::dash_set_config }  

        dashboard_add          $dash_path dash_sts_get button grp_cmd 
        dashboard_set_property $dash_path dash_sts_get text "Get"
        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_display::dash_get_status }  

        dashboard_add          $dash_path dash_sts_clear button grp_cmd 
        dashboard_set_property $dash_path dash_sts_clear text "Clear"
        dashboard_set_property $dash_path dash_sts_clear onClick { ::cgx_display::clr_status }  

    #   dashboard_add          $dash_path dash_cfg_readback button grp_cmd 
    #   dashboard_set_property $dash_path dash_cfg_readback enabled true
    #   dashboard_set_property $dash_path dash_cfg_readback text "Readback"
    #   dashboard_set_property $dash_path dash_cfg_readback onClick { ::cgx_display::dash_get_config }  

        dashboard_add          $dash_path dash_sts_run button grp_cmd 
        dashboard_set_property $dash_path dash_sts_run text "Run"
        dashboard_set_property $dash_path dash_sts_run onClick { ::cgx_display::dash_run }  
        dashboard_set_property $dash_path dash_sts_run enabled false

        dashboard_add          $dash_path dash_cfg_run checkBox grp_fct_com 
        dashboard_set_property $dash_path dash_cfg_run enabled true
      # dashboard_set_property $dash_path dash_cfg_run expandableY false
      # dashboard_set_property $dash_path dash_cfg_run expandableY false
        dashboard_set_property $dash_path dash_cfg_run text "Run"

        dashboard_add          $dash_path dash_sts_busy checkBox grp_fct_com
        dashboard_set_property $dash_path dash_sts_busy text "busy"

    #   dashboard_add          $dash_path dash_sts_irq led grp_sts_param
    #   dashboard_set_property $dash_path dash_sts_irq text "irq"
    #   dashboard_set_property $dash_path dash_sts_irq color "black"

        dashboard_add          $dash_path dash_sts_ia_frame_completed checkBox grp_fct_com
        dashboard_set_property $dash_path dash_sts_ia_frame_completed text "frame completed"

        dashboard_add          $dash_path dash_sts_ia_video_underflow checkBox grp_fct_com
        dashboard_set_property $dash_path dash_sts_ia_video_underflow text "video underflow"


        dashboard_add          $dash_path dash_sts_frame_width text grp_compo_frame 
        dashboard_set_property $dash_path dash_sts_frame_width label "width" 
        dashboard_set_property $dash_path dash_sts_frame_width preferredWidth 50
        dashboard_set_property $dash_path dash_sts_frame_width editable false
        dashboard_set_property $dash_path dash_sts_frame_width text "0"

        dashboard_add          $dash_path dash_sts_frame_height text grp_compo_frame 
        dashboard_set_property $dash_path dash_sts_frame_height label "height" 
        dashboard_set_property $dash_path dash_sts_frame_height preferredWidth 50
        dashboard_set_property $dash_path dash_sts_frame_height editable false
        dashboard_set_property $dash_path dash_sts_frame_height text "0"

        dashboard_add          $dash_path dash_sts_frame_count text grp_compo_frame 
        dashboard_set_property $dash_path dash_sts_frame_count label "count" 
        dashboard_set_property $dash_path dash_sts_frame_count preferredWidth 50
        dashboard_set_property $dash_path dash_sts_frame_count editable false
        dashboard_set_property $dash_path dash_sts_frame_count text "0"
        
        dashboard_add          $dash_path dash_sts_fps text grp_compo_frame 
        dashboard_set_property $dash_path dash_sts_fps label "FPS"
        dashboard_set_property $dash_path dash_sts_fps expandableX false
        dashboard_set_property $dash_path dash_sts_fps expandableY false
        dashboard_set_property $dash_path dash_sts_fps preferredWidth 30
        dashboard_set_property $dash_path dash_sts_fps editable false
        dashboard_set_property $dash_path dash_sts_fps htmlCapable false
        dashboard_set_property $dash_path dash_sts_fps text "-1"
        
        dashboard_add          $dash_path dash_layer_num text grp_compo_layer 
        dashboard_set_property $dash_path dash_layer_num label "active number" 
        dashboard_set_property $dash_path dash_layer_num preferredWidth 50
        dashboard_set_property $dash_path dash_layer_num editable false
        dashboard_set_property $dash_path dash_layer_num htmlCapable false
        dashboard_set_property $dash_path dash_layer_num text "0"
        
        dashboard_add          $dash_path dash_layer_idx text grp_compo_layer 
        dashboard_set_property $dash_path dash_layer_idx label "index" 
        dashboard_set_property $dash_path dash_layer_idx expandableX false
        dashboard_set_property $dash_path dash_layer_idx expandableY false
        dashboard_set_property $dash_path dash_layer_idx preferredWidth 50
        dashboard_set_property $dash_path dash_layer_idx editable true
        dashboard_set_property $dash_path dash_layer_idx htmlCapable false
        dashboard_set_property $dash_path dash_layer_idx text "0"

        dashboard_add          $dash_path dash_layer_dump button grp_compo_layer 
        dashboard_set_property $dash_path dash_layer_dump enabled true
      # dashboard_set_property $dash_path dash_layer_dump expandableY false
      # dashboard_set_property $dash_path dash_layer_dump expandableY false
        dashboard_set_property $dash_path dash_layer_dump text "Dump"
        dashboard_set_property $dash_path dash_layer_dump onClick { ::cgx_display::dump_layer [ dashboard_get_property ${::cgx_display::dash_path} dash_layer_idx text ] }  
                  
      # after idle ::cgx_display::dash_update

        puts stdout " ${::cgx_display::IPCORE_LABEL} dashBoard end"

        return -code ok
    }



    proc dash_init_device {} {
    	
        set ::cgx_display::debug 1

        cgx_display::init -1  
      # cgx_display::dash_get_config
        cgx_display::dash_get_status

        set ::cgx_display::debug 0
    }


    proc dash_dump_device {} {

        cgx_display::dump_core 
        cgx_display::dump_video 

    }


    proc dash_get_caps {} {
    	
        set ::cgx_display::debug 1

        cgx_display::get_caps   

        set ::cgx_display::debug 0
    }


#   proc dash_get_config {} {
#
#       set ::cgx_display::debug 1
#
#       cgx_display::get_config 
#     # cgx_display::get_interrupt
#       cgx_display::video_get_config 
#       cgx_display::video_get_timings 
#
#       set ::cgx_display::debug 0
#
#   }

  
    proc dash_set_config {} {

        set ::cgx_display::debug 1

        cgx_display::set_config -1 -1 -1 -1 -1  
      # cgx_display::set_interrupt -1  
        cgx_display::video_set_config -1 -1 -1 -1 -1 -1 -1   
        cgx_display::video_set_timings -1 -1 -1 -1 -1 -1 -1 -1 -1 -1    

        set ::cgx_display::debug 0           
    }


    proc dash_get_status {} {

        set ::cgx_display::debug 1

        cgx_display::get_config 
        cgx_display::video_get_config 
        cgx_display::video_get_timings 
        
        cgx_display::get_status  

        set ::cgx_display::debug 0
    }

   
  # proc dash_update {} {
  #
  #     if { ${::cgx_display::dashboardActive} > 0 } {
  #  
  #         if { ${::cgx_display::initialized} > 0 } {
  #
  #             ::cgx_display::dash_get_config
  #             ::cgx_display::dash_get_status
  #              
  #           # after 1000 ::cgx_display::dash_update
  #
  #         }
  #     }
  # }

}



