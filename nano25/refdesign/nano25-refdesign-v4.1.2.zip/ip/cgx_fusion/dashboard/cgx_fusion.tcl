# revisions
# 2.18: added software reset (cf: CSR_CONTROL_RESET_MSK)

# cgx_fusion::init 0x0;       { dev_base }
# cgx_fusion::get_version     { } 
# cgx_fusion::get_caps        { }
# cgx_fusion::set_config      { run reset }
# cgx_fusion::get_config      { }
# cgx_fusion::get_status      { }
# cgx_fusion::clr_status      { }
# cgx_fusion::get_dev_base    { dev_class dev_instance }
# cgx_fusion::get_diag        { diag_error }

		
namespace eval cgx_fusion {

    variable IPCORE_PRODUCT 72; # = 0x48                                                                                          
    variable IPCORE_VERSION 4.1                                                                                          

    #----------------------- dashboard---------------------------

    variable dash_path ""
    variable dashboardActive  0

    # debug mode
    # 0 => console 
    # 1 => dashboard 
    variable debug 0

     
    #-------------------------- SYS------------------------------

    variable CSR_DEV_BASE  0x00000000
    variable initialized 0

 
    #-------------------------- HAL------------------------------

    # /* Functions class: any update requires to update 'dash_dev_class' accordingly */
    variable DEF_CLASS_TOP    0
    variable DEF_CLASS_DPY    1
    variable DEF_CLASS_VSC    2
    variable DEF_CLASS_GFX    3
    variable DEF_CLASS_VIN    4
    variable DEF_CLASS_MEM    5
    variable DEF_CLASS_NUMBER 6


    variable CSR_ADDR_MMAP_MSK    0x7F;   #0-6                                                           
    variable CSR_ADDR_MMAP_OFST   0;                                                              
    variable CSR_ADDR_INDEX_MSK   0x380;  #7-9                                                           
    variable CSR_ADDR_INDEX_OFST  7;                                                                  
    variable CSR_ADDR_CLASS_MSK   0x1c00; #10-12                                                                                                           
    variable CSR_ADDR_CLASS_OFST  10;                                                                                                             
    variable CSR_ADDR_SIZE        13;                                                                                                              
           
       
    # /* Registers */
    variable CSR_REG_VERSION   0; # /* version                                  */
   #variable CSR_REG_SURFACE   1; # /* version                                  */
    variable CSR_REG_CAPS      2; # /* configuration capabilities               */
    variable CSR_REG_INTERRUPT 3; # /* control (includes interrupt-enable bits) */
    variable CSR_REG_CONTROL   4; # /* control (includes interrupt-enable bits) */
    variable CSR_REG_STATUS    5; # /* status (includes interrupt-trigger bits) */
    variable CSR_REG_DIAG      6
    variable CSR_REG_NUMBER    7
    
    
    # /* Read_Only registers: */
    
    variable CSR_VERSION_ID_MSK           0xFF 
    variable CSR_VERSION_ID_OFST          0
    variable CSR_VERSION_BUILD_MSK        0xFF00
    variable CSR_VERSION_BUILD_OFST       8
    variable CSR_VERSION_MINOR_MSK        0xFF0000
    variable CSR_VERSION_MINOR_OFST       16
    variable CSR_VERSION_MAJOR_MSK        0x0F000000
    variable CSR_VERSION_MAJOR_OFST       24
    # parameters                                               
    variable CSR_CAPS_NUM_DPY_MSK         0xF    ;   # /* Display controller  number  */
    variable CSR_CAPS_NUM_DPY_OFST        0      ;
    variable CSR_CAPS_NUM_VID_MSK         0xF0   ;   # /* Video frame grabber number  */
    variable CSR_CAPS_NUM_VID_OFST        4      ;
    variable CSR_CAPS_NUM_GFX_MSK         0xF00  ;   # /* Graphics renderer   number  */
    variable CSR_CAPS_NUM_GFX_OFST        8      ;
    # features 
    variable CSR_CAPS_ENA_DPY_MSK         0x1000000 ;  #  1 = support for Display controller       
    variable CSR_CAPS_ENA_DPY_OFST        24        ;  #                                           
    variable CSR_CAPS_ENA_VID_MSK         0x2000000 ;  #  1 = support for Video controller                   
    variable CSR_CAPS_ENA_VID_OFST        25        ;  #                                           
    variable CSR_CAPS_ENA_GFX_MSK         0x4000000 ;  #  1 = support for Graphics renderer        
    variable CSR_CAPS_ENA_GFX_OFST        26        ;  # 
  # variable CSR_CAPS_ENA_ASG_MSK         0x8000000 ;  #  1 = support for Atomic Scene Graph       
  # variable CSR_CAPS_ENA_ASG_OFST        27        ;  # 


    #/* CSR_REG_INTERRUPT */   
    #/* Interrupts-enable mask to disable(default)/enable interrupts. */
    variable CSR_INTERRUPT_ENABLE_MSK  0xFF
    variable CSR_INTERRUPT_ENABLE_OFST 0
    
    #/* CONTROL & STATUS Interrupts bitfields (CSR_CONTROL_IRQ_ENABLE_MSK, CSR_STATUS_IRQ_ACTIVE_MSK)  */
        variable CSR_IRQ_BIT_DIAG_MSK          0x1;  #/*  diagnostic (reserved usage) */                              
        variable CSR_IRQ_BIT_DIAG_OFST         0                                 
        variable CSR_IRQ_BIT_DEVICE_MSK        0x2;                               
        variable CSR_IRQ_BIT_DEVICE_OFST       1                                 
        variable CSR_IRQ_BIT_MEM32_ERROR_MSK   0x4;                                
        variable CSR_IRQ_BIT_MEM32_ERROR_OFST  2                                 
        variable CSR_IRQ_BIT_MEMS_ERROR_MSK    0x8;                                
        variable CSR_IRQ_BIT_MEMS_ERROR_OFST   3                                 

      
    #/* CSR_REG_CONTROL bitfields */ 
    variable CSR_CONTROL_RUN_MSK       0x1; #   # 0(default)/1  
    variable CSR_CONTROL_RUN_OFST      0
    variable CSR_CONTROL_RESET_MSK     0x2; #    
    variable CSR_CONTROL_RESET_OFST    1
 
           
    #/* CSR_REG_STATUS bitfields */ 
    variable CSR_STATUS_BUSY_MSK                  0x1         
    variable CSR_STATUS_BUSY_OFST                 0                                                          
    variable CSR_STATUS_IRQ_MSK                   0x2         
    variable CSR_STATUS_IRQ_OFST                  1                                                                                                            
    variable CSR_STATUS_IRQ_DEV_CLASS_MSK         0xF0;  # irq device class                                                    
    variable CSR_STATUS_IRQ_DEV_CLASS_OFST        4                                                           
    variable CSR_STATUS_IRQ_DEV_INDEX_MSK         0xF00; # irq device index                                                   
    variable CSR_STATUS_IRQ_DEV_INDEX_OFST        8                                                          

    variable CSR_STATUS_IRQ_ACTIVE_MSK            0xFF0000 # /* 0/1 = interrupt active. read the register to get information about active interrupts. write register to clears the interrupts */        
    variable CSR_STATUS_IRQ_ACTIVE_OFST           16                                                          

                                                                                                      
  # # /* Read-Write registers: */                     
  # variable CSR_CONTROL_INDEX_CLASS_MSK         0xFF
  # variable CSR_CONTROL_INDEX_CLASS_OFST        0
  # variable CSR_CONTROL_INDEX_INSTANCE_MSK      0xFF00
  # variable CSR_CONTROL_INDEX_INSTANCE_OFST     8
  
 
 #  # /* Memory-map status */
 #  variable CSR_MMAP_STATUS_CUSTOM_MSK          0x1  
 #  variable CSR_MMAP_STATUS_CUSTOM_OFST         0
 #  
 #  
 #  
 #  # /* Memory base address for the Writer                    */ 
 #  # /* (writer target depends on context class and instance) */
 #  variable CSR_MMAP_ADDRESS_WR_MSK             0xFFFFFFFF
 #  variable CSR_MMAP_ADDRESS_WR_OFST            0
 #  
 #  
 #  # /* Memory base address for the Reader associated to the context writer */
 #  variable CSR_MMAP_ADDRESS_RD_MSK             0xFFFFFFFF
 #  variable CSR_MMAP_ADDRESS_RD_OFST            0

    variable FUSION_MEM_CSR_DEV_64  0
    variable FUSION_MEM_CSR_DEV_0   1
    variable FUSION_MEM_CSR_DEV_NUM 2

    
    #--------------------------private functions ------------------------------

    proc ATH_SET_FIELD { reg32 field_name field_val } {
    
           #set str_field_reg32 ::cgx_fusion::$field_name\_REG 
            set str_field_msk   ::cgx_fusion::$field_name\_MSK 
            set str_field_ofst  ::cgx_fusion::$field_name\_OFST
            
           #set field_reg32 [ subst $$str_field_reg32 ]
            set field_msk   [ subst $$str_field_msk   ]
            set field_ofst  [ subst $$str_field_ofst  ]
                     
            set inverted_mask [ expr ( 0xFFFFFFFF ^ ${field_msk} ) & 0xFFFFFFFF ]
              
            set reg32_masked [ expr ($reg32 & $inverted_mask) ]
                  
            set reg32_new [ expr $reg32_masked | [ expr ( ${field_val} << $field_ofst ) & $field_msk ] ]                   
                 
      # puts "reg_old=$reg32 / reg_new=$reg32_new"
          
        return $reg32_new             
    }


    proc ATH_GET_FIELD { reg32 field_name } {

        set str_field_msk  ::cgx_fusion::$field_name\_MSK 
        set str_field_ofst ::cgx_fusion::$field_name\_OFST
        
        set field_msk   [ subst $$str_field_msk   ]
        set field_ofst  [ subst $$str_field_ofst  ]

        set field_val [ expr [ expr ${reg32} & $field_msk ] >> $field_ofst ]

        return $field_val             

    }

     
    #--------------------------public functions ------------------------------
    
 
    proc init { dev_base } {
        puts stdout "FUSION init:"

        if { ${::cgx_fusion::debug} == 1 } {
            set dash_path ${::cgx_fusion::dash_path} 
            set dev_base [ dashboard_get_property $dash_path dash_dev_base text ]
        } 
        
                
        set ::cgx_fusion::CSR_DEV_BASE ${dev_base} 
        
        set dev_success [ ::cgx_fusion::get_version ];  
        
        if {${dev_success} == 1} {
            set ::cgx_fusion::CSR_DEV_BASE ${dev_base} 
            set ::cgx_fusion::initialized 1
        } else {
            set ::cgx_fusion::initialized 0
        } 

        if { ${::cgx_fusion::debug} == 1 } {
            set dash_path ${::cgx_fusion::dash_path} 
            if {${dev_success} == 1} {
                dashboard_set_property $dash_path grp_core  visible true
            } else {
            	  puts stdout " DEVICE not detected "
                dashboard_set_property $dash_path grp_core  visible false
                dashboard_set_property $dash_path grp_csr   visible false
            } 
        } 
 
    }
       
 
    proc get_version { } {

        set csr_base8 ${::cgx_fusion::CSR_DEV_BASE} 
        
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_fusion::CSR_REG_VERSION} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set v_id    [ ATH_GET_FIELD $reg CSR_VERSION_ID ] ;                              
        set v_build [ ATH_GET_FIELD $reg CSR_VERSION_BUILD ] ;                           
        set v_minor [ ATH_GET_FIELD $reg CSR_VERSION_MINOR ] ;                           
        set v_major [ ATH_GET_FIELD $reg CSR_VERSION_MAJOR ] ;                           
        set version $v_major.$v_minor                            

        if {$v_id == ${::cgx_fusion::IPCORE_PRODUCT} } {
          puts stdout "    Version = $v_major.$v_minor, Build = $v_build"
          if { $version == ${::cgx_fusion::IPCORE_VERSION} } {
            set success 1
          } else {
            set success 0
            puts stdout " ERROR: versions mismatch ( IPcore=$version / dashboard=${::cgx_fusion::IPCORE_VERSION} )"
          }
        } else {
          set success 0
          puts stdout " ERROR core id = $v_id, reg = $reg "
        }
        return $success
        
        
    }
        

    proc get_caps { } {
                
        set csr_base8 ${::cgx_fusion::CSR_DEV_BASE} 

        open_service master ${::boardInit::masterPath}        
        set reg [master_read_32 ${::boardInit::masterPath} [ expr $csr_base8 + 4*${::cgx_fusion::CSR_REG_CAPS} ] 0x1]; 
	      close_service master ${::boardInit::masterPath}

        set caps_ena_dpy  [ ATH_GET_FIELD $reg CSR_CAPS_ENA_DPY ] ; 
        set caps_ena_vid  [ ATH_GET_FIELD $reg CSR_CAPS_ENA_VID ] ; 
        set caps_ena_gfx  [ ATH_GET_FIELD $reg CSR_CAPS_ENA_GFX ] ; 
        set caps_num_dpy  [ ATH_GET_FIELD $reg CSR_CAPS_NUM_DPY ] ; 
        set caps_num_vid  [ ATH_GET_FIELD $reg CSR_CAPS_NUM_VID ] ; 
        set caps_num_gfx  [ ATH_GET_FIELD $reg CSR_CAPS_NUM_GFX ] ; 
        
       puts "
    Capabilities: 
    main features:    
        caps_ena_dpy = $caps_ena_dpy                    
        caps_ena_vid = $caps_ena_vid                     
        caps_ena_gfx = $caps_ena_gfx            
        caps_num_dpy = $caps_num_dpy          
        caps_num_vid = $caps_num_vid           
        caps_num_gfx = $caps_num_gfx           
                "                                                                                                                                                                
 
        if { ${::cgx_fusion::debug} == 1 } {
 
            set dash_path ${::cgx_fusion::dash_path} 
            dashboard_set_property $dash_path grp_csr visible true
        }
    }
       

    proc get_diag { diag_error } {

        set dash_path ${::cgx_fusion::dash_path}
        if { $diag_error != 0 } {
            set var {}
            open_service master ${::boardInit::masterPath}
            for {set i 0} { $i<8 } {incr i} {
                set reg [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_DIAG} ] 1 ];     
                # remove "0x" header and re-order characters from msb to lsb
                append var [string index $reg 8]
                append var [string index $reg 9]
                append var [string index $reg 6]
                append var [string index $reg 7]
                append var [string index $reg 4]
                append var [string index $reg 5]
                append var [string index $reg 2]
                append var [string index $reg 3]
            }
            close_service master ${::boardInit::masterPath}
            set msg [binary format H* $var] 
          # puts $msg
        } else {     
            set msg " - "
        }
        
        dashboard_set_property $dash_path dash_diag_msg text $msg      

    }


    proc get_dev_base { dev_class dev_instance } {

        if { ${::cgx_fusion::debug} == 1 } {
           set dash_path ${::cgx_fusion::dash_path} 
           set dev_class [ dashboard_get_property $dash_path dash_dev_class selected ]          
           set dev_instance [ dashboard_get_property $dash_path dash_dev_instance selected ]                       
        }
        
        set dev_offset32 [ expr (($dev_class << ${::cgx_fusion::CSR_ADDR_CLASS_OFST}) + ($dev_instance << ${::cgx_fusion::CSR_ADDR_INDEX_OFST})) ]
        puts "dev_offset32 = $dev_offset32"
        set dev_csr_base [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4 * $dev_offset32 ]
 
        if { ${::cgx_fusion::debug} == 1 } {
           dashboard_set_property $dash_path dash_csr_base text [ format 0x%x ${dev_csr_base} ]; # "$dev_csr_base"
        }

        return $dev_csr_base
    }


    proc set_config { run reset } {

        if { ${::cgx_fusion::debug} == 1 } {
	          set dash_path ${::cgx_fusion::dash_path} 
	          set run   0 
	          set reset 0 
            if { [ dashboard_get_property $dash_path dash_cfg_run checked ] == true } {
                set run 1
            } 
            if { [ dashboard_get_property $dash_path dash_cfg_reset checked ] == true } {
                set reset 1
            } 
        }  

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_CONTROL} ] 0x1]; 
        set reg [ ATH_SET_FIELD $reg CSR_CONTROL_RUN $run ]
        set reg [ ATH_SET_FIELD $reg CSR_CONTROL_RESET $reset ]
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_CONTROL} ] $reg

	      close_service master ${::boardInit::masterPath}
    }

         
    proc get_config { } {

        open_service master ${::boardInit::masterPath}

        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_CONTROL} ] 0x1]; 
        set cfg_run   [ ATH_GET_FIELD $reg CSR_CONTROL_RUN ] ;                                                                
        set cfg_reset [ ATH_GET_FIELD $reg CSR_CONTROL_RESET ];                                                                

#       set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_PATH_CFG_POOL} ] 0x1]; 
#       set cfg_path_pool_size [ ATH_GET_FIELD $reg CSR_PATH_PTS_NUM_POOL ]; 
#       set cfg_path_pool_addr [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_PATH_POOL_MEM_ADDR_L} ] 0x1]; 

	      close_service master ${::boardInit::masterPath}

        if { ${::cgx_fusion::debug} == 0 } {
            puts "                             "
            puts "  config:                    "
            puts "      cfg_run   = $cfg_run   "          
            puts "      cfg_reset = $cfg_reset "          
            puts "                             "                                                                                                                                                                
        }
        if { ${::cgx_fusion::debug} == 1 } {
        	  set dash_path ${::cgx_fusion::dash_path} 
            if { $cfg_run == 1 } {
               dashboard_set_property $dash_path dash_cfg_run checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_run checked false  
            } 

            if { $cfg_reset == 1 } {
               dashboard_set_property $dash_path dash_cfg_reset checked true  
            } else { 
               dashboard_set_property $dash_path dash_cfg_reset checked false  
            } 

#           dashboard_set_property $dash_path dash_path_pool_size text $cfg_path_pool_size  
#           dashboard_set_property $dash_path dash_path_pool_addr text $cfg_path_pool_addr                    
        }
    }


    proc get_status { } {
    
        open_service master ${::boardInit::masterPath}
        set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_STATUS} ] 0x1]; 
        close_service master ${::boardInit::masterPath}
        set sts_busy            [ ATH_GET_FIELD $reg CSR_STATUS_BUSY ] ;                                                                
        set sts_irq             [ ATH_GET_FIELD $reg CSR_STATUS_IRQ  ] ;                                                                
        set sts_irq_dev_class   [ ATH_GET_FIELD $reg CSR_STATUS_IRQ_DEV_CLASS ] ;                                                                
        set sts_irq_dev_index   [ ATH_GET_FIELD $reg CSR_STATUS_IRQ_DEV_INDEX ] ;                                                                
    #   set cmd_fifo_empty      [ ATH_GET_FIELD $reg CSR_STATUS_CMD_FIFO_EMPTY ] ;                                                                
    #   set cmd_fifo_full       [ ATH_GET_FIELD $reg CSR_STATUS_CMD_FIFO_FULL ] ;                                                                
    #   set cmd_fifo_almostfull [ ATH_GET_FIELD $reg CSR_STATUS_CMD_FIFO_ALMOSTFULL ] ;                                                                
        set sts_irqfield        [ ATH_GET_FIELD $reg CSR_STATUS_IRQ_ACTIVE ] ;                                                                
        set sts_ia_diag_error   [ ATH_GET_FIELD $sts_irqfield CSR_IRQ_BIT_DIAG  ] ;                                                                
        set sts_ia_device_error [ ATH_GET_FIELD $sts_irqfield CSR_IRQ_BIT_DEVICE  ] ;                                                                
        set sts_ia_mem32_error  [ ATH_GET_FIELD $sts_irqfield CSR_IRQ_BIT_MEM32_ERROR  ] ;                                                                
        set sts_ia_mems_error   [ ATH_GET_FIELD $sts_irqfield CSR_IRQ_BIT_MEMS_ERROR  ] ;                                                                


    #   open_service master ${::boardInit::masterPath}
    #   set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_CMD_STATUS} ] 0x1]; 
	  #   close_service master ${::boardInit::masterPath}
    #   set cmd_count     [ ATH_GET_FIELD $reg CSR_CMD_STS_COUNT ] ;                                                                             
    #   set cmd_fifo_used [ ATH_GET_FIELD $reg CSR_CMD_STS_FIFO_USED ] ;                                                                
    #
    #   open_service master ${::boardInit::masterPath}
    #   set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_PATH_STS_SIZE} ] 0x1]; 
    #   close_service master ${::boardInit::masterPath}
    #   set path_pts_num_peak [ ATH_GET_FIELD $reg CSR_PATH_PTS_NUM_PEAK ] ; 
    #   set path_pts_num_dest [ ATH_GET_FIELD $reg CSR_PATH_PTS_NUM_DEST ] ; 

        if { ${::cgx_fusion::debug} == 0 } {
            puts "                                                "
            puts " Status:                                        "
            puts "     core busy           =$sts_busy             "
            puts "     core interrupt      =$sts_irq              "

            puts "     sts_irq_dev_class   = $sts_irq_dev_class   " 
            puts "     sts_irq_dev_index   = $sts_irq_dev_index   " 
#           puts "     cmd_fifo_empty      = $cmd_fifo_empty      "   
#           puts "     cmd_fifo_full       = $cmd_fifo_full       "   
#           puts "     cmd_fifo_almostfull = $cmd_fifo_almostfull " 
#           puts "     cmd_fifo_used       = $cmd_fifo_used       "
#           puts "     cmd_count           = $cmd_count           "
#
            puts "     ia error memory-32  = $sts_ia_mem32_error  "
            puts "     ia error memory-sfc = $sts_ia_mems_error   "
            puts "     ia error device     = $sts_ia_device_error "
            puts "     ia error diag       = $sts_ia_diag_error   "
#
#           puts "     fps                 =$sts_fps              "
            puts "                                                "                                                                                                                            
        }

 
       if { ${::cgx_fusion::debug} == 1 } {
       	  set dash_path ${::cgx_fusion::dash_path} 

#         dashboard_set_property $dash_path dash_path_pts_num_peak text $path_pts_num_peak    
#         dashboard_set_property $dash_path dash_path_pts_num_dest text $path_pts_num_dest    

          if { $sts_busy == 1 } {
             dashboard_set_property $dash_path dash_sts_busy checked true
          } else { 
             dashboard_set_property $dash_path dash_sts_busy checked false
          }        
   
          if { $sts_irq == 1 } {
              dashboard_set_property $dash_path dash_sts_irq color "red"
          } else {
              dashboard_set_property $dash_path dash_sts_irq color "black"
          }

          if { $sts_ia_mem32_error == 1 } {
             dashboard_set_property $dash_path dash_sts_ia_mem32_error checked true
          } else { 
             dashboard_set_property $dash_path dash_sts_ia_mem32_error checked false
          }        

          if { $sts_ia_mems_error == 1 } {
             dashboard_set_property $dash_path dash_sts_ia_mems_error checked true
          } else { 
             dashboard_set_property $dash_path dash_sts_ia_mems_error checked false
          }        
               
          if { $sts_ia_device_error == 1 } {
             dashboard_set_property $dash_path dash_sts_ia_device_error checked true
          } else { 
             dashboard_set_property $dash_path dash_sts_ia_device_error checked false
          }        

          if { $sts_ia_diag_error == 1 } {
             dashboard_set_property $dash_path dash_sts_ia_diag_error checked true
             cgx_fusion::get_diag 1
          } else { 
             dashboard_set_property $dash_path dash_sts_ia_diag_error checked false
             cgx_fusion::get_diag 0
          }        

          dashboard_set_property $dash_path dash_irq_dev_class text $sts_irq_dev_class   
          dashboard_set_property $dash_path dash_irq_dev_index text $sts_irq_dev_index    

        }
    }



                        

    # clear all status interrupt-active bits
    proc clr_status { } {
    	
        open_service master ${::boardInit::masterPath}
        master_write_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4*${::cgx_fusion::CSR_REG_STATUS} ] 0xFFFFFFFF 
	      close_service master ${::boardInit::masterPath}
    }


 #  proc get_context { } {
 #
 #
 #      open_service master ${::boardInit::masterPath}
 #      
 #      set reg [master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4 * [ expr ${::cgx_fusion::DEF_CTRL_OFST_CORE} + ${::cgx_fusion::CSR_REG_CONTROL}] ] 0x1]; 
 #
	#      close_service master ${::boardInit::masterPath}
 #
 #      set dev_class    [ expr [ expr ${reg} & ${::cgx_fusion::CSR_CONTROL_INDEX_CLASS_MSK}    ] >> ${::cgx_fusion::CSR_CONTROL_INDEX_CLASS_OFST} ]
 #      set dev_id       [ expr [ expr ${reg} & ${::cgx_fusion::CSR_CONTROL_INDEX_INSTANCE_MSK} ] >> ${::cgx_fusion::CSR_CONTROL_INDEX_INSTANCE_OFST} ]
 #
 #      puts stdout "   context device: class/id = $dev_class/$dev_id "
 #  }


  # proc set_context { dev_class dev_id } {
  #
  #     open_service master ${::boardInit::masterPath}
  #
  #     set reg [ expr   \
  #        [ expr $dev_class << ${::cgx_fusion::CSR_CONTROL_INDEX_CLASS_OFST}    & ${::cgx_fusion::CSR_CONTROL_INDEX_CLASS_MSK}    ] | \
  #        [ expr $dev_id    << ${::cgx_fusion::CSR_CONTROL_INDEX_INSTANCE_OFST} & ${::cgx_fusion::CSR_CONTROL_INDEX_INSTANCE_MSK} ] ]                   
  #
  #     puts stdout "mobj control reg = $reg"
  #
  #     set addr [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4 * [ expr ${::cgx_fusion::DEF_CTRL_OFST_CORE} + ${::cgx_fusion::CSR_REG_CONTROL}] ]
  #   # puts stdout "set mobj control: $reg @ $addr"
  #   # set addr [ expr ${::cgx_fusion::CSR_DEV_BASE} + 4 * [ expr [ expr ${::cgx_fusion::DEF_CTRL_FIELD_CORE} << ${::cgx_fusion::CSR_CTRL_FIELD_OFST} ] + ${::cgx_fusion::CSR_REG_CONTROL}] ]
  #   # puts stdout "set mobj control: $reg @ $addr"
  #     master_write_32 ${::boardInit::masterPath} $addr $reg
  #
	#     close_service master ${::boardInit::masterPath}
  #
  # }




    proc dump_all { } {

        open_service master ${::boardInit::masterPath}

        set reg [ master_read_32 ${::boardInit::masterPath} [ expr ${::cgx_fusion::CSR_DEV_BASE} ] [ expr 1 << ${::cgx_fusion::CSR_ADDR_SIZE} ] ] 
        puts stdout "$reg"

	      close_service master ${::boardInit::masterPath}

    }



    proc dashBoard {} {

        if { ${::cgx_fusion::dashboardActive} == 1 } {
            return -code ok "dashboard already active"
        }

        set ::cgx_fusion::dashboardActive 1
        puts stdout "dashBoard start ......."

        #
        # Create dashboard 
        #
        variable ::cgx_fusion::dash_path [ add_service dashboard cgx_fusion "cgx_fusion" "Tools/cgx_fusion"]

        set dash_path ${::cgx_fusion::dash_path} 

        #
        # Set dashboard properties
        #
        dashboard_set_property $dash_path self developmentMode true
        dashboard_set_property $dash_path self itemsPerRow 1
        dashboard_set_property $dash_path self visible true
        
        #
        # groups
        #
        dashboard_add          $dash_path grp_top group self
        dashboard_set_property $dash_path grp_top expandableX false
        dashboard_set_property $dash_path grp_top expandableY false
        dashboard_set_property $dash_path grp_top itemsPerRow 1
        dashboard_set_property $dash_path grp_top title ""

        dashboard_add          $dash_path grp_device group grp_top
        dashboard_set_property $dash_path grp_device expandableX false
        dashboard_set_property $dash_path grp_device expandableY false
        dashboard_set_property $dash_path grp_device itemsPerRow 3
        dashboard_set_property $dash_path grp_device title "Device"

        dashboard_add          $dash_path grp_core group grp_top
        dashboard_set_property $dash_path grp_core expandableX false
        dashboard_set_property $dash_path grp_core expandableY false
        dashboard_set_property $dash_path grp_core itemsPerRow 1
        dashboard_set_property $dash_path grp_core title "Core ${::cgx_fusion::IPCORE_VERSION}"
        dashboard_set_property $dash_path grp_core visible false; # dashboard init

        dashboard_add          $dash_path grp_core_cmd group grp_core
        dashboard_set_property $dash_path grp_core_cmd expandableX false
        dashboard_set_property $dash_path grp_core_cmd expandableY false
        dashboard_set_property $dash_path grp_core_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_core_cmd title ""

        dashboard_add          $dash_path grp_csr group grp_core
        dashboard_set_property $dash_path grp_csr expandableX false
        dashboard_set_property $dash_path grp_csr expandableY false
        dashboard_set_property $dash_path grp_csr itemsPerRow 1
        dashboard_set_property $dash_path grp_csr title ""
        dashboard_set_property $dash_path grp_csr visible false; # dashboard init

        dashboard_add          $dash_path grp_csr_main group grp_csr
        dashboard_set_property $dash_path grp_csr_main expandableX false
        dashboard_set_property $dash_path grp_csr_main expandableY false
        dashboard_set_property $dash_path grp_csr_main itemsPerRow 2
        dashboard_set_property $dash_path grp_csr_main title ""
 
        dashboard_add          $dash_path grp_config group grp_csr_main
        dashboard_set_property $dash_path grp_config expandableX false
        dashboard_set_property $dash_path grp_config expandableY false
        dashboard_set_property $dash_path grp_config itemsPerRow 1
        dashboard_set_property $dash_path grp_config title "Config"

        dashboard_add          $dash_path grp_cfg_cmd group grp_config
        dashboard_set_property $dash_path grp_cfg_cmd expandableX false
        dashboard_set_property $dash_path grp_cfg_cmd expandableY false
        dashboard_set_property $dash_path grp_cfg_cmd itemsPerRow 2
        dashboard_set_property $dash_path grp_cfg_cmd title ""

        dashboard_add          $dash_path grp_cfg_param0 group grp_config
        dashboard_set_property $dash_path grp_cfg_param0 expandableX false
        dashboard_set_property $dash_path grp_cfg_param0 expandableY false
        dashboard_set_property $dash_path grp_cfg_param0 itemsPerRow 3
        dashboard_set_property $dash_path grp_cfg_param0 title ""

        dashboard_add          $dash_path grp_cfg_irq group grp_config
        dashboard_set_property $dash_path grp_cfg_irq expandableX false
        dashboard_set_property $dash_path grp_cfg_irq expandableY false
        dashboard_set_property $dash_path grp_cfg_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_cfg_irq title "interrupt enable"

        dashboard_add          $dash_path grp_status group grp_csr_main
        dashboard_set_property $dash_path grp_status expandableX false
        dashboard_set_property $dash_path grp_status expandableY false
        dashboard_set_property $dash_path grp_status itemsPerRow 1
        dashboard_set_property $dash_path grp_status title "Status"
 
        dashboard_add          $dash_path grp_sts_cmd group grp_status
        dashboard_set_property $dash_path grp_sts_cmd expandableX false
        dashboard_set_property $dash_path grp_sts_cmd expandableY false
        dashboard_set_property $dash_path grp_sts_cmd itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_cmd title ""
     
        dashboard_add          $dash_path grp_sts_param group grp_status
        dashboard_set_property $dash_path grp_sts_param expandableX false
        dashboard_set_property $dash_path grp_sts_param expandableY false
        dashboard_set_property $dash_path grp_sts_param itemsPerRow 3
        dashboard_set_property $dash_path grp_sts_param title ""
     
        dashboard_add          $dash_path grp_sts_irq group grp_status
        dashboard_set_property $dash_path grp_sts_irq expandableX false
        dashboard_set_property $dash_path grp_sts_irq expandableY false
        dashboard_set_property $dash_path grp_sts_irq itemsPerRow 1
        dashboard_set_property $dash_path grp_sts_irq title "interrupt active"

        dashboard_add          $dash_path grp_fct group grp_csr
        dashboard_set_property $dash_path grp_fct expandableX false
        dashboard_set_property $dash_path grp_fct expandableY false
        dashboard_set_property $dash_path grp_fct itemsPerRow 4
        dashboard_set_property $dash_path grp_fct title ""


        dashboard_add          $dash_path grp_dev group grp_fct
        dashboard_set_property $dash_path grp_dev expandableX false
        dashboard_set_property $dash_path grp_dev expandableY false
        dashboard_set_property $dash_path grp_dev itemsPerRow 5
        dashboard_set_property $dash_path grp_dev title "Component"

    #   dashboard_add          $dash_path grp_context group grp_fct
    #   dashboard_set_property $dash_path grp_context expandableX false
    #   dashboard_set_property $dash_path grp_context expandableY false
    #   dashboard_set_property $dash_path grp_context itemsPerRow 1
    #   dashboard_set_property $dash_path grp_context title "Context"


        #
        # widgets
        #

        dashboard_add          $dash_path dash_dev_base text grp_device 
        dashboard_set_property $dash_path dash_dev_base label "base" 
        dashboard_set_property $dash_path dash_dev_base expandableX false
        dashboard_set_property $dash_path dash_dev_base expandableY false
        dashboard_set_property $dash_path dash_dev_base preferredWidth 80
        dashboard_set_property $dash_path dash_dev_base editable true
        dashboard_set_property $dash_path dash_dev_base htmlCapable false
        dashboard_set_property $dash_path dash_dev_base text ${::cgx_fusion::CSR_DEV_BASE}

        dashboard_add          $dash_path dash_dev_init button grp_device 
        dashboard_set_property $dash_path dash_dev_init enabled true
        dashboard_set_property $dash_path dash_dev_init text "Init"
        dashboard_set_property $dash_path dash_dev_init onClick { ::cgx_fusion::dash_init_device }  

        dashboard_add          $dash_path dash_dev_dump button grp_device 
        dashboard_set_property $dash_path dash_dev_dump enabled true
        dashboard_set_property $dash_path dash_dev_dump text "Dump"
        dashboard_set_property $dash_path dash_dev_dump onClick { ::cgx_fusion::dash_dump_device }  

        dashboard_add          $dash_path dash_dev_version button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_version enabled true
        dashboard_set_property $dash_path dash_dev_version text "Version"
        dashboard_set_property $dash_path dash_dev_version onClick { ::cgx_fusion::get_version }  

        dashboard_add          $dash_path dash_dev_caps button grp_core_cmd 
        dashboard_set_property $dash_path dash_dev_caps enabled true
        dashboard_set_property $dash_path dash_dev_caps text "Caps"
        dashboard_set_property $dash_path dash_dev_caps onClick { ::cgx_fusion::dash_get_caps }  
        
        dashboard_add          $dash_path dash_cfg_run checkBox grp_cfg_param0 
        dashboard_set_property $dash_path dash_cfg_run enabled true
        dashboard_set_property $dash_path dash_cfg_run text "Run"

        dashboard_add          $dash_path dash_cfg_reset checkBox grp_cfg_param0 
        dashboard_set_property $dash_path dash_cfg_reset enabled true
        dashboard_set_property $dash_path dash_cfg_reset text "Reset"
     
        dashboard_add          $dash_path dash_cfg_set button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_set enabled true
        dashboard_set_property $dash_path dash_cfg_set text "Set"
        dashboard_set_property $dash_path dash_cfg_set onClick { ::cgx_fusion::dash_set_config }  
     
        dashboard_add          $dash_path dash_cfg_readback button grp_cfg_cmd 
        dashboard_set_property $dash_path dash_cfg_readback enabled true
        dashboard_set_property $dash_path dash_cfg_readback text "Readback"
        dashboard_set_property $dash_path dash_cfg_readback onClick { ::cgx_fusion::dash_get_config }  

 
        #
        # monitor /  widgets
        #

        dashboard_add          $dash_path dash_sts_get button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_get enabled true
        dashboard_set_property $dash_path dash_sts_get text "Get"
        dashboard_set_property $dash_path dash_sts_get onClick { ::cgx_fusion::dash_get_status }  

        dashboard_add          $dash_path dash_sts_clear button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_clear text "Clear"
        dashboard_set_property $dash_path dash_sts_clear onClick { ::cgx_fusion::dash_clr_status }  

        dashboard_add          $dash_path dash_sts_run button grp_sts_cmd 
        dashboard_set_property $dash_path dash_sts_run text "Run"
        dashboard_set_property $dash_path dash_sts_run enabled false
        dashboard_set_property $dash_path dash_sts_run onClick { ::cgx_fusion::dash_run_status }  
      
        dashboard_add          $dash_path dash_sts_busy checkBox grp_sts_param
        dashboard_set_property $dash_path dash_sts_busy text "busy"

        dashboard_add          $dash_path dash_sts_irq led grp_sts_param
        dashboard_set_property $dash_path dash_sts_irq text "irq"
        dashboard_set_property $dash_path dash_sts_irq color "black"

        dashboard_add          $dash_path dash_sts_ia_mem32_error checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_mem32_error text "32-bits memory"

        dashboard_add          $dash_path dash_sts_ia_mems_error checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_mems_error text "sfc memory phy"

        dashboard_add          $dash_path dash_sts_ia_device_error checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_device_error text "devices"

        dashboard_add          $dash_path dash_sts_ia_diag_error checkBox grp_sts_irq
        dashboard_set_property $dash_path dash_sts_ia_diag_error text "diag"

        dashboard_add          $dash_path dash_irq_dev_class text grp_sts_irq
        dashboard_set_property $dash_path dash_irq_dev_class label "irq device class" 
        dashboard_set_property $dash_path dash_irq_dev_class expandableX false
        dashboard_set_property $dash_path dash_irq_dev_class expandableY false
        dashboard_set_property $dash_path dash_irq_dev_class preferredWidth 50
        dashboard_set_property $dash_path dash_irq_dev_class editable false
        dashboard_set_property $dash_path dash_irq_dev_class htmlCapable false
        dashboard_set_property $dash_path dash_irq_dev_class text "0"
     
        dashboard_add          $dash_path dash_irq_dev_index text grp_sts_irq
        dashboard_set_property $dash_path dash_irq_dev_index label "irq device index" 
        dashboard_set_property $dash_path dash_irq_dev_index expandableX false
        dashboard_set_property $dash_path dash_irq_dev_index expandableY false
        dashboard_set_property $dash_path dash_irq_dev_index preferredWidth 50
        dashboard_set_property $dash_path dash_irq_dev_index editable false
        dashboard_set_property $dash_path dash_irq_dev_index htmlCapable false
        dashboard_set_property $dash_path dash_irq_dev_index text "0"

        dashboard_add          $dash_path dash_diag_msg text grp_status 
        dashboard_set_property $dash_path dash_diag_msg label "diag message"
        dashboard_set_property $dash_path dash_diag_msg expandableX false
        dashboard_set_property $dash_path dash_diag_msg expandableY false
        dashboard_set_property $dash_path dash_diag_msg preferredWidth 200
        dashboard_set_property $dash_path dash_diag_msg editable false 
        dashboard_set_property $dash_path dash_diag_msg htmlCapable false
        dashboard_set_property $dash_path dash_diag_msg text " - "

        dashboard_add          $dash_path dash_dev_class comboBox grp_dev 
        dashboard_set_property $dash_path dash_dev_class options { "TOP" "DPY" "VSC" "GFX" "VIN" "MEM" }
        dashboard_set_property $dash_path dash_dev_class enabled true
        dashboard_set_property $dash_path dash_dev_class expandableY false
        dashboard_set_property $dash_path dash_dev_class expandableY false
        dashboard_set_property $dash_path dash_dev_class label "class"
        dashboard_set_property $dash_path dash_dev_class selected 0

        dashboard_add          $dash_path dash_dev_instance comboBox grp_dev 
        dashboard_set_property $dash_path dash_dev_instance options { "#0" "#1" "#2" "#3"}
        dashboard_set_property $dash_path dash_dev_instance enabled true
        dashboard_set_property $dash_path dash_dev_instance expandableY false
        dashboard_set_property $dash_path dash_dev_instance expandableY false
        dashboard_set_property $dash_path dash_dev_instance label "instance"
        dashboard_set_property $dash_path dash_dev_instance selected 0

        dashboard_add          $dash_path dash_csr_base text grp_dev
        dashboard_set_property $dash_path dash_csr_base label "CSR base" 
        dashboard_set_property $dash_path dash_csr_base expandableX false
        dashboard_set_property $dash_path dash_csr_base expandableY false
        dashboard_set_property $dash_path dash_csr_base preferredWidth 80
        dashboard_set_property $dash_path dash_csr_base editable false
        dashboard_set_property $dash_path dash_csr_base htmlCapable false
        dashboard_set_property $dash_path dash_csr_base text "0"

	      
        after idle ::cgx_fusion::dash_update

        puts stdout "dashBoard end"

        return -code ok
    }


    proc dash_init_device {} {
    	
        set ::cgx_fusion::debug 1

        cgx_fusion::init -1  
        cgx_fusion::dash_get_config

        set ::cgx_fusion::debug 0
    }


    proc dash_dump_device {} {

        cgx_fusion::dump_all  
 
    }


    proc dash_get_caps {} {
    	
        set ::cgx_fusion::debug 1

        cgx_fusion::get_caps   
 
        set ::cgx_fusion::debug 0
    }


    proc dash_set_config {} {

        set ::cgx_fusion::debug 1

        cgx_fusion::get_dev_base -1 -1    
       
        cgx_fusion::set_config -1 -1   
    #   cgx_fusion::set_interrupt -1 -1 
       
        set ::cgx_fusion::debug 0
        
    }


    proc dash_get_config {} {

        set ::cgx_fusion::debug 1

        cgx_fusion::get_config

        set ::cgx_fusion::debug 0
    }
    
   
    proc dash_get_status {} {

        set ::cgx_fusion::debug 1

        cgx_fusion::get_status          
    #   cgx_fusion::cmd_get_status
    #   cgx_fusion::get_context

        set ::cgx_fusion::debug 0

    }


    proc dash_clr_status {} {

        set ::cgx_fusion::debug 1

        cgx_fusion::clr_status          
    #   cgx_fusion::cmd_clr_status          

        set ::cgx_fusion::debug 0

    }


    proc dash_run_status {} {

    # TODO

    }

   
    proc dash_update {} {

        if { ${::cgx_fusion::dashboardActive} > 0 } {
     
            if { ${::cgx_fusion::initialized} > 0 } {

              # ::cgx_fusion::dash_get_status

              # after 300 ::cgx_fusion::dash_update

            }
        }
    }
}





 
