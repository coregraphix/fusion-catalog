

  # added common TCL for <ip_name>_hw.tcl & <ip_name>_core_hw.tcl 
  set FUSION_VERSION_MAJOR 4
  set FUSION_VERSION_MINOR 1
  set FUSION_VERSION $FUSION_VERSION_MAJOR.$FUSION_VERSION_MINOR 
  
  # 0 (default) => HDL (encrypted)   
  # 1           => SRC 
  set FUSION_HDL_DIRECTORY 0
    