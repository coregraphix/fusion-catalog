@echo off
REM Convert the HPS-merged SOF into a JIC bitstream programmable into the
REM Nano25 QSPI flash.
REM Run from this scripts/ folder (paths below are relative to this folder).

%QUARTUS_ROOTDIR%\bin64\quartus_pfg -c ..\output_files\fusion_top_hps.sof ..\output_files\fusion_top_hps.jic -o device=MT25QU128 -o flash_loader=A5EB013BB23B -o mode=ASX4

pause