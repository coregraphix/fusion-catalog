@echo off
REM Merge the Quartus-generated SOF with the u-boot SPL HEX to produce a SOF
REM that embeds the HPS first-stage bootloader.
REM Run from this scripts/ folder (paths below are relative to this folder).

%QUARTUS_ROOTDIR%\bin64\quartus_pfg -c ..\output_files\fusion_top.sof ..\output_files\fusion_top_hps.sof -o hps_path=..\software\u-boot\spl\u-boot-spl-dtb.hex

pause

